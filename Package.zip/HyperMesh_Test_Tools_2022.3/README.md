# Bốn tool HyperMesh 2022.3

| Nút trong Utility | Công dụng |
| --- | --- |
| **RBE2 bar** | Tạo kết nối RBE2–CBAR–RBE2. |
| **Shared faces** | Tạo các mặt chung và dùng màu đang chọn khi tạo. |
| **Ruled mesh** | Lấp một viền kín hoặc tạo lưới tam giác giữa hai viền. |
| **Imprint** | Đắp lưới mặt nguồn lên mặt đích để hai mặt chung node và lưới trùng nhau (tria3/tria6, tet4/tet10). |

Trong **Ruled mesh**, chỉnh **Element size** trước khi bấm **Create**. Tool giữ cạnh biên với cả hai viền có số node khác nhau. Khi remesh native làm lật tam giác, tool tạo lại trên mặt khớp và điều chỉnh cạnh trong theo size. Lỗ có lưới mồi đã gần size mục tiêu bỏ qua lượt remesh để tiết kiệm thời gian.

**Edge 1** và **Edge 2** có chế độ chọn độc lập. **By path** mở bộ chọn **Nodes → By path** của HyperMesh khi chọn mới. **By node** lấy các node anh bấm. **By edge** dò cả viền từ một đoạn PLOTEL đỏ. **By circle** lấy 3 node mốc và xem trước các node vòng bằng chấm trắng trên mô hình. Mặc định là 8 node vòng. Mũi tên của **Rotation** xoay preview từng 1°. **Create** sinh node tại các vị trí đã xem, tạo một node tâm riêng và tự chọn các node vòng cho Edge. Tool giữ vùng chọn khi tạo lưới để anh có thể Undo rồi mở lại Edge và chỉnh.

Trong **Imprint**, bấm **Target...** rồi **Source...** để chọn mặt. Khi bật **By face**, chọn một element là tool lấy cả mặt (lệch pháp tuyến không quá **Face angle**). **Swap** đổi chỗ hai lựa chọn. Source có thể gồm nhiều mặt, ví dụ đáy ba bu lông lên một mặt mount. Tool chỉ xóa một lớp element của mặt đích quanh bản chép, rồi nối viền. Element nguồn trùm qua lỗ hoặc ra ngoài mép được giữ nguyên, kèm cảnh báo. Mọi thay đổi gộp thành một bước Undo. Target được tô trắng, Source xám; lựa chọn giữ tới khi bấm Reset. Đổi thông số rồi bấm **Re-imprint** thì tool Undo lần trước và làm lại theo thông số mới.

## Chép sang máy khác

1. Chép nguyên thư mục `HyperMesh_Test_Tools_2022.3` sang máy đích. Giữ cấu trúc các thư mục bên trong. Đường dẫn được phép có khoảng trắng nhưng **không nên có chữ có dấu** (ví dụ `Thử nghiệm`): khi thử, `*evaltclscript` (lệnh các nút gọi) bị treo với đường dẫn như vậy trong phiên GUI.
2. Mở **HyperMesh 2022.3** với solver profile **Nastran**.
3. Tại **Tcl Console**, chạy lệnh dưới đây và thay đường dẫn theo chỗ đã chép.

```tcl
source {D:/CAE Tools/HyperMesh_Test_Tools_2022.3/Load_Test_Tools.tcl}
```

Bốn nút xuất hiện trên trang **TEST** ở **Utility**. Khi chuyển gói đến vị trí khác hoặc mở phiên HyperMesh mới, chạy lại lệnh với đường dẫn tương ứng. Tcl tạo MAC theo vị trí đang dùng và nạp vào phiên hiện tại. Lệnh nạp thay menu Utility mà phiên đang dùng. Để trở lại menu của máy đích, nạp lại MAC của máy đó.

Để mở riêng một tool từ Tcl Console, dùng `source` với tệp tương ứng.

- [RbeBarLink/rbe_bar_link.tcl](RbeBarLink/rbe_bar_link.tcl)
- [SharedFaces/shared_faces.tcl](SharedFaces/shared_faces.tcl)
- [RuledMesh/ruled_mesh.tcl](RuledMesh/ruled_mesh.tcl)
- [ElemImprint/elem_imprint.tcl](ElemImprint/elem_imprint.tcl)
