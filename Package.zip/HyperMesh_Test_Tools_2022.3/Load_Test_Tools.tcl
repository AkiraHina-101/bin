# Source this file from the HyperMesh Tcl Console to load the Utility menu.
namespace eval ::HMTestTools {}

proc ::HMTestTools::load {root} {
    set build [string trim [hm_info -appinfo DISPLAYVERSION]]
    if {![regexp {^2022\.3(\.[0-9]+)*$} $build]} {
        error "These tools require HyperMesh 2022.3 (found $build)."
    }

    set root [file normalize $root]
    foreach relative {
        RbeBarLink/rbe_bar_link.tcl
        SharedFaces/shared_faces.tcl
        RuledMesh/ruled_mesh.tcl
        RuledMesh/paths.tcl
        RuledMesh/selection.tcl
        RuledMesh/patch_surface.tcl
        RuledMesh/constrained_patch.tcl
        ElemImprint/elem_imprint.tcl
        Test_Tools.mac.in
    } {
        if {![file isfile [file join $root $relative]]} {
            error "Missing file in the Test Tools package: $relative"
        }
    }

    set input [open [file join $root Test_Tools.mac.in] r]
    set template [read $input]
    close $input
    set temp [pwd]
    foreach name {TEMP TMP} {
        if {[info exists ::env($name)] && [file isdirectory $::env($name)]} {
            set temp $::env($name)
            break
        }
    }
    set macro [file normalize [file join $temp "HM_Test_Tools_[pid]_[clock clicks].mac"]]
    set output [open $macro {WRONLY CREAT EXCL}]
    fconfigure $output -encoding utf-8 -translation lf
    set code [catch {
        puts -nonewline $output [string map [list @PACKAGE_ROOT@ $root] $template]
    } message options]
    set closeCode [catch {close $output} closeResult closeOptions]
    if {$code} {return -options $options $message}
    if {$closeCode} {return -options $closeOptions $closeResult}

    *setmacrofile $macro
    puts "Test Tools loaded in Utility, page 15 ($build)."
    return $macro
}

::HMTestTools::load [file dirname [file normalize [info script]]]
