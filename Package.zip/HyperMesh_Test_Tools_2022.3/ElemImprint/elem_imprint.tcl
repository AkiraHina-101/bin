# Element Imprint (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Makes two touching faces share nodes and carry the same elements in the contact area, the way it is
# done by hand. Elements: tria3/tria6 (mixed allowed) and tet4/tet10.
#   One face inside the other (enclose_once): the enclosed face ("guest") is copied onto the other
#   ("host") as new elements that use the guest's own nodes, the host elements under it (plus Remesh
#   layers rows) are deleted and the ring between them is filled (ruled between closed outlines, ear
#   clipping elsewhere). Target and Source may be picked either way round.
#   Partial overlap (imprint_twoway): the source is cut along the target outline (clip, one snap
#   rounding for the whole mesh), that overlap is copied into the target and then into the source.
#   A tet face: the tets within Solid layers of the contact are rebuilt with *tetmesh from the new
#   face shell (fixed shell), same component and order; the other tets keep ids and nodes.
#   Every change is one Undo step; a failed attempt is undone and retried (more rows for Min size, a
#   larger tet patch), an unexpected failure rolls back ("Nothing changed").
# Entry point for the menu: *evaltclscript elem_imprint.tcl 0. Set ::ElemImprint_no_gui to load
# the procedures without opening the window (tests).

namespace eval ::ElemImprint {
    variable W .elemImprint
    variable cfg2D {103 106}
    variable cfg3D {204 210}
    variable names {103 tria3 106 tria6 204 tet4 210 tet10}
    variable tetString "tet: 579 1.2 2 0 0.8 0 0"
    variable tetPars "pars: fix_comp_bdr=1 fix_top_bdr=0 shell_swap=0 shell_remesh=0 upd_shell=0 shell_dev=0.0,0.0"
    variable eps 1e-9
    variable snapFrac 0.05
    variable faceComps {}
    variable outer 0
    variable sel
    variable opt
    variable status
    variable P
    if {![info exists status]} {set status ""}
    # sel: the picked elements (kept until Reset); shown: the elements highlighted for each side (after
    # an imprint, the new face); last: the imprint the window made last, undone before a re-imprint
    variable shown
    variable last
    if {![info exists last]} {set last {}}
    foreach {k v} {target {} source {}} {if {![info exists sel($k)]} {set sel($k) $v}; if {![info exists shown($k)]} {set shown($k) $v}}
    foreach {k v} {layers 1 maxDist "" angle 30 minSize "" solidLayers 2 byFace 1 faceAngle 30} {if {![info exists opt($k)]} {set opt($k) $v}}
}

# ---------------------------------------------------------------- vectors
proc ::ElemImprint::vsub {a b} {list [expr {[lindex $a 0]-[lindex $b 0]}] [expr {[lindex $a 1]-[lindex $b 1]}] [expr {[lindex $a 2]-[lindex $b 2]}]}
proc ::ElemImprint::vadd {a b} {list [expr {[lindex $a 0]+[lindex $b 0]}] [expr {[lindex $a 1]+[lindex $b 1]}] [expr {[lindex $a 2]+[lindex $b 2]}]}
proc ::ElemImprint::vscale {a s} {list [expr {[lindex $a 0]*$s}] [expr {[lindex $a 1]*$s}] [expr {[lindex $a 2]*$s}]}
proc ::ElemImprint::dot {a b} {expr {[lindex $a 0]*[lindex $b 0]+[lindex $a 1]*[lindex $b 1]+[lindex $a 2]*[lindex $b 2]}}
proc ::ElemImprint::cross {a b} {
    lassign $a ax ay az; lassign $b bx by bz
    list [expr {$ay*$bz-$az*$by}] [expr {$az*$bx-$ax*$bz}] [expr {$ax*$by-$ay*$bx}]
}
proc ::ElemImprint::norm {a} {expr {sqrt([dot $a $a])}}
proc ::ElemImprint::unit {a} {
    set l [norm $a]
    if {$l < 1e-300} {return {0.0 0.0 0.0}}
    vscale $a [expr {1.0/$l}]
}

# ---------------------------------------------------------------- model reads
proc ::ElemImprint::count {type} {hm_count $type all 0 0}
proc ::ElemImprint::existing {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 {*}$ids
    set out [hm_getmark elems 1]
    *clearmark elems 1
    return $out
}
proc ::ElemImprint::existing_nodes {ids} {
    if {![llength $ids]} {return {}}
    *createmark nodes 1 {*}$ids
    set out [hm_getmark nodes 1]
    *clearmark nodes 1
    return $out
}
proc ::ElemImprint::configs {ids} {
    if {![llength $ids]} {return {}}
    hm_getvalue elems user_ids=$ids dataname=config
}
proc ::ElemImprint::elem_nodes {ids} {
    if {![llength $ids]} {return {}}
    hm_getvalue elems user_ids=$ids dataname=nodes
}
proc ::ElemImprint::node_set {ids} {
    set all {}
    foreach nl [elem_nodes $ids] {foreach n $nl {lappend all $n}}
    lsort -unique -integer $all
}
proc ::ElemImprint::comps_of {ids} {
    if {![llength $ids]} {return {}}
    lsort -unique [hm_getvalue elems user_ids=$ids dataname=collector.name]
}
# Node coordinates into the cache P (one bulk read per coordinate).
proc ::ElemImprint::load_xyz {ids} {
    variable P
    set need {}
    foreach n $ids {if {![info exists P($n)]} {lappend need $n}}
    set need [lsort -unique -integer $need]
    if {![llength $need]} {return}
    foreach n $need x [hm_getvalue nodes user_ids=$need dataname=x] y [hm_getvalue nodes user_ids=$need dataname=y] \
        z [hm_getvalue nodes user_ids=$need dataname=z] {set P($n) [list $x $y $z]}
}

# Kind of a selection: {dim order config}. dim 2 = tria3/tria6, 3 = tet4/tet10, one config only.
proc ::ElemImprint::kind {ids what} {
    variable cfg2D; variable cfg3D; variable names
    set cs [lsort -unique [configs $ids]]
    foreach c $cs {
        if {$c ni [concat $cfg2D $cfg3D]} {error "The $what has elements that are not tria3, tria6, tet4 or tet10 (config $c)."}
    }
    # tria3 and tria6 may be mixed (order 2 when any tria6); tets of one order only
    if {[llength $cs] > 1 && ($cs ne {103 106})} {error "The $what mixes [join [lmap_names $cs] {, }]: use one element type."}
    set c [lindex $cs end]
    list [expr {$c in $cfg2D ? 2 : 3}] [expr {$c in {106 210} ? 2 : 1}] $c
}
proc ::ElemImprint::lmap_names {cs} {
    variable names
    set o {}
    foreach c $cs {lappend o [dict get $names $c]}
    return $o
}

# Triangle rows {eid a b c} (corner nodes) of tria3/tria6 elements.
proc ::ElemImprint::tri_rows {eids} {
    set rows {}
    foreach e $eids nl [elem_nodes $eids] {lappend rows [list $e [lindex $nl 0] [lindex $nl 1] [lindex $nl 2]]}
    return $rows
}

# Free faces of tets (created by *findfaces as tria3/tria6 in ^faces). Returns their ids.
# *findfaces empties the ^faces component first (runtime 2022.3: earlier faces are deleted and their
# ids reused). Elements already in ^faces are parked in a temporary component and put back; the new
# faces go to their own temporary component (listed in faceComps, removed by cleanup_faces).
proc ::ElemImprint::find_faces {tets} {
    variable faceComps
    set parked {}
    if {[hm_entityinfo exist comps ^faces -byname]} {
        *createmark elems 1 "by collector name" ^faces
        set parked [hm_getmark elems 1]
        *clearmark elems 1
    }
    set park ""
    if {[llength $parked]} {
        set park [temp_comp]
        *createmark elems 1 {*}$parked; *movemark elems 1 $park; *clearmark elems 1
    }
    *createmark elems 1 {*}$tets
    catch {hm_entityrecorder elems off}
    hm_entityrecorder elems on
    set rc [catch {*findfaces elems 1} m]
    hm_entityrecorder elems off
    *clearmark elems 1
    set faces [existing [hm_entityrecorder elems ids]]
    if {!$rc && [llength $faces]} {
        set own [temp_comp]
        lappend faceComps $own
        *createmark elems 1 {*}$faces; *movemark elems 1 $own; *clearmark elems 1
    }
    if {$park ne ""} {
        *createmark elems 1 {*}[existing $parked]; *movemark elems 1 ^faces; *clearmark elems 1
        delete_comp_if_empty $park
    }
    if {$rc} {error "Finding the faces of the solid failed: $m"}
    return $faces
}
proc ::ElemImprint::cleanup_faces {} {
    variable faceComps
    foreach c $faceComps {delete_comp_if_empty $c}
    set faceComps {}
}

# ---------------------------------------------------------------- triangle grid
# A grid over triangle rows for point location. Name: grid key prefix (T or S).
proc ::ElemImprint::grid_build {name rows} {
    variable P
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    array unset G; array unset D
    set ids {}
    foreach r $rows {lappend ids {*}[lrange $r 1 3]}
    load_xyz $ids
    set sum 0.0; set k 0
    set i 0
    foreach r $rows {
        lassign $r e a b c
        set pa $P($a); set pb $P($b); set pc $P($c)
        set nn [cross [vsub $pb $pa] [vsub $pc $pa]]
        set D($i) [list $pa $pb $pc [unit $nn] [norm $nn]]
        foreach {p q} [list $pa $pb $pb $pc $pc $pa] {set sum [expr {$sum+[norm [vsub $q $p]]}]; incr k}
        incr i
    }
    set D(n) $i
    set D(rows) $rows
    set D(mean) [expr {$k ? $sum/$k : 1.0}]
    return $D(mean)
}
proc ::ElemImprint::grid_index {name h} {
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    array unset G
    set D(h) $h
    for {set i 0} {$i < $D(n)} {incr i} {
        lassign $D($i) pa pb pc
        set lo {}; set hi {}
        foreach k {0 1 2} {
            set v [list [lindex $pa $k] [lindex $pb $k] [lindex $pc $k]]
            lappend lo [expr {int(floor([tcl::mathfunc::min {*}$v]/$h))}]
            lappend hi [expr {int(floor([tcl::mathfunc::max {*}$v]/$h))}]
        }
        for {set x [lindex $lo 0]} {$x <= [lindex $hi 0]} {incr x} {
            for {set y [lindex $lo 1]} {$y <= [lindex $hi 1]} {incr y} {
                for {set z [lindex $lo 2]} {$z <= [lindex $hi 2]} {incr z} {lappend G($x,$y,$z) $i}
            }
        }
    }
}
# Row indices with a cell within distance r of p.
proc ::ElemImprint::grid_near {name p r} {
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    set h $D(h)
    set out {}
    set lo {}; set hi {}
    foreach v $p {lappend lo [expr {int(floor(($v-$r)/$h))}]; lappend hi [expr {int(floor(($v+$r)/$h))}]}
    for {set x [lindex $lo 0]} {$x <= [lindex $hi 0]} {incr x} {
        for {set y [lindex $lo 1]} {$y <= [lindex $hi 1]} {incr y} {
            for {set z [lindex $lo 2]} {$z <= [lindex $hi 2]} {incr z} {
                if {[info exists G($x,$y,$z)]} {lappend out {*}$G($x,$y,$z)}
            }
        }
    }
    lsort -unique -integer $out
}
# Barycentric coordinates of the projection of p on triangle i, and the signed normal distance.
proc ::ElemImprint::tri_project {name i p} {
    upvar #0 ::ElemImprint::GD_$name D
    lassign $D($i) pa pb pc n
    set d [dot [vsub $p $pa] $n]
    set q [vsub $p [vscale $n $d]]
    set area [dot [cross [vsub $pb $pa] [vsub $pc $pa]] $n]
    if {abs($area) < 1e-300} {return [list -1 -1 -1 $d]}
    set u [expr {[dot [cross [vsub $pb $q] [vsub $pc $q]] $n]/$area}]
    set v [expr {[dot [cross [vsub $pc $q] [vsub $pa $q]] $n]/$area}]
    list $u $v [expr {1.0-$u-$v}] $d
}
# Triangle on which p projects (inside, |distance| <= r), nearest first: {index distance} or {}.
proc ::ElemImprint::locate {name p r {tol 1e-7}} {
    set best {}
    foreach i [grid_near $name $p $r] {
        lassign [tri_project $name $i $p] u v w d
        if {$u >= -$tol && $v >= -$tol && $w >= -$tol && abs($d) <= $r} {
            if {![llength $best] || abs($d) < abs([lindex $best 1])} {set best [list $i $d]}
        }
    }
    return $best
}

# Free (boundary) corner edges of triangle rows: dict "a b" (a<b) -> 1.
proc ::ElemImprint::boundary_edges {rows} {
    set cnt [dict create]
    foreach r $rows {
        lassign $r e a b c
        foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
    }
    set out [dict create]
    dict for {k v} $cnt {if {$v == 1} {dict set out $k 1}}
    return $out
}

# Rows of "rows" that lie on grid "name": centroid projects inside within r, normals within angle.
proc ::ElemImprint::rows_on {rows name r cosA} {
    upvar #0 ::ElemImprint::GD_$name D
    variable P
    set ids {}
    foreach row $rows {lappend ids {*}[lrange $row 1 3]}
    load_xyz $ids
    set out {}
    foreach row $rows {
        lassign $row e a b c
        set c3 [vscale [vadd [vadd $P($a) $P($b)] $P($c)] [expr {1.0/3}]]
        set hit [locate $name $c3 $r]
        if {![llength $hit]} {continue}
        set n [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
        if {abs([dot $n [lindex $D([lindex $hit 0]) 3]]) >= $cosA} {lappend out $row}
    }
    return $out
}

# Grow seed rows across shared edges while the normals stay within the angle (same orientation).
proc ::ElemImprint::flood {rows seeds cosA} {
    variable P
    set byEdge [dict create]
    set N [dict create]
    foreach row $rows {
        lassign $row e a b c
        dict set N $e [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
        dict set R $e $row
        foreach {p q} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$p < $q ? "$p $q" : "$q $p"}] $e}
    }
    set done [dict create]
    set queue {}
    foreach s $seeds {dict set done [lindex $s 0] 1; lappend queue [lindex $s 0]}
    while {[llength $queue]} {
        set e [lindex $queue end]; set queue [lrange $queue 0 end-1]
        lassign [dict get $R $e] x a b c
        foreach {p q} [list $a $b $b $c $c $a] {
            foreach f [dict get $byEdge [expr {$p < $q ? "$p $q" : "$q $p"}]] {
                if {[dict exists $done $f]} {continue}
                if {[dot [dict get $N $e] [dict get $N $f]] >= $cosA} {dict set done $f 1; lappend queue $f}
            }
        }
    }
    set out {}
    foreach row $rows {if {[dict exists $done [lindex $row 0]]} {lappend out $row}}
    return $out
}

# ---------------------------------------------------------------- clipping
# 2D helpers (points {x y}).
proc ::ElemImprint::cross2 {o a b} {expr {([lindex $a 0]-[lindex $o 0])*([lindex $b 1]-[lindex $o 1])-([lindex $a 1]-[lindex $o 1])*([lindex $b 0]-[lindex $o 0])}}
proc ::ElemImprint::in_tri2 {p a b c tol} {
    set s [cross2 $a $b $c]
    if {abs($s) < 1e-300} {return 0}
    expr {[cross2 $a $b $p]/$s > $tol && [cross2 $b $c $p]/$s > $tol && [cross2 $c $a $p]/$s > $tol}
}
# Proper intersection of segments p1-p2 and q1-q2: {t u} or {}.
proc ::ElemImprint::seg_x {p1 p2 q1 q2} {
    lassign $p1 x1 y1; lassign $p2 x2 y2; lassign $q1 x3 y3; lassign $q2 x4 y4
    set den [expr {($x2-$x1)*($y4-$y3)-($y2-$y1)*($x4-$x3)}]
    set scale [expr {hypot($x2-$x1,$y2-$y1)*hypot($x4-$x3,$y4-$y3)}]
    if {abs($den) <= 1e-12*$scale} {return {}}
    set t [expr {(($x3-$x1)*($y4-$y3)-($y3-$y1)*($x4-$x3))/$den}]
    set u [expr {(($x3-$x1)*($y2-$y1)-($y3-$y1)*($x2-$x1))/$den}]
    list $t $u
}
proc ::ElemImprint::poly_area2 {pts} {
    set a 0.0; set n [llength $pts]
    for {set i 0} {$i < $n} {incr i} {
        lassign [lindex $pts $i] x1 y1; lassign [lindex $pts [expr {($i+1)%$n}]] x2 y2
        set a [expr {$a+$x1*$y2-$x2*$y1}]
    }
    return $a
}
# Ear clipping of a simple polygon given as keys with 2D points. Returns triangles of keys, CCW.
proc ::ElemImprint::ear_clip {keys pts} {
    if {[poly_area2 $pts] < 0} {set keys [lreverse $keys]; set pts [lreverse $pts]}
    set tris {}
    set guard 0
    while {[llength $keys] > 3} {
        set n [llength $keys]
        set cut -1; set bestQ -1.0
        for {set i 0} {$i < $n} {incr i} {
            set ia [expr {($i+$n-1)%$n}]; set ib [expr {($i+1)%$n}]
            set a [lindex $pts $ia]; set b [lindex $pts $i]; set c [lindex $pts $ib]
            if {[cross2 $a $b $c] <= 1e-14*max(1.0,[poly_scale $pts])} {continue}
            set ok 1
            set kabc [list [lindex $keys $ia] [lindex $keys $i] [lindex $keys $ib]]
            for {set j 0} {$j < $n} {incr j} {
                if {$j == $ia || $j == $i || $j == $ib} {continue}
                if {[lindex $keys $j] in $kabc} {continue}
                # a vertex on the ear's diagonal blocks it too (collinear vertices along a side)
                if {[in_tri2 [lindex $pts $j] $a $b $c -1e-12]} {set ok 0; break}
            }
            if {$ok} {
                set q [tri_quality2 $a $b $c]
                if {$cut < 0 || $q > $bestQ} {set cut $i; set bestQ $q}
            }
        }
        if {$cut < 0} {error "polygon cannot be triangulated"}
        set ia [expr {($cut+$n-1)%$n}]; set ib [expr {($cut+1)%$n}]
        lappend tris [list [lindex $keys $ia] [lindex $keys $cut] [lindex $keys $ib]]
        set keys [lreplace $keys $cut $cut]; set pts [lreplace $pts $cut $cut]
        if {[incr guard] > 10000} {error "polygon cannot be triangulated"}
    }
    if {[cross2 {*}$pts] > 1e-14*max(1.0,[poly_scale $pts])} {lappend tris $keys}
    return $tris
}
proc ::ElemImprint::poly_scale {pts} {
    set m 0.0
    foreach p $pts {set m [expr {max($m,abs([lindex $p 0]),abs([lindex $p 1]))}]}
    expr {$m*$m}
}

# Clips source triangle rows to the footprint of grid T (boundary edges B). Returns
# {tris pointsDict stats}: tris are triangles of point keys (orientation of the source), pointsDict
# maps keys to 3D positions of the copy: "s<node>" source corners, "t<node>" target boundary nodes
# that lie on the source mesh (merged with a source node or on a source edge), "x<lo>.<hi>.<a>.<b>"
# crossings of source edge lo-hi with boundary edge a-b, "t<node>@<elem>" boundary nodes inside a
# source triangle.
# Every relation is decided once for the whole mesh (snap rounding), never per triangle, so the two
# triangles beside an edge always see the same cut points:
#   1. a source node within snapD of a boundary node (measured along the target surface) is merged
#      with it; else within snapD of a boundary edge it is moved onto that edge;
#   2. a boundary node within snapD of a source edge lies on that edge;
#   3. the crossing of a source edge and a boundary edge is computed once, unless 1 or 2 already
#      decided where they meet.
# The copy therefore differs from the source by at most snapD next to the target boundary.
proc ::ElemImprint::clip {Srows B r} {
    variable P; variable snapFrac
    upvar #0 ::ElemImprint::GD_T D
    upvar #0 ::ElemImprint::GD_S DS
    set tolL [expr {1e-9*$D(mean)}]
    set snapD [expr {$snapFrac*min($D(mean),$DS(mean))}]
    set ids {}
    foreach row $Srows {lappend ids {*}[lrange $row 1 3]}
    set ids [lsort -unique -integer $ids]
    load_xyz $ids
    # boundary edges with the normal of their target row, boundary nodes with a normal
    set Bn [dict create]; set Vn [dict create]; set Bthird [dict create]
    for {set i 0} {$i < $D(n)} {incr i} {
        lassign [lindex $D(rows) $i] te ta tb tc
        set nT [lindex $D($i) 3]
        foreach {x y} [list $ta $tb $tb $tc $tc $ta] {
            set k [expr {$x < $y ? "$x $y" : "$y $x"}]
            if {![dict exists $B $k]} {continue}
            dict set Bn $k $nT
            foreach w [list $ta $tb $tc] {if {$w != $x && $w != $y} {dict set Bthird $k $w}}
            dict set Vn $x $nT; dict set Vn $y $nT
        }
    }
    # source edges -> opposite corners (to find the triangles of an edge)
    set Sedges [dict create]
    foreach row $Srows {
        lassign $row e a b c
        foreach {p q} [list $a $b $b $c $c $a] {dict set Sedges [expr {$p < $q ? "$p $q" : "$q $p"}] 1}
    }
    # ---- 1. source nodes: merge with a boundary node or move onto a boundary edge
    set SP [dict create]; set nkey [dict create]; set onB [dict create]
    foreach n $ids {
        set p $P($n)
        set bestV ""; set dV $snapD; set bestE ""; set dE $snapD
        foreach i [grid_near T $p [expr {$r+$snapD}]] {
            lassign [lindex $D(rows) $i] te ta tb tc
            foreach {x y} [list $ta $tb $tb $tc $tc $ta] {
                set k [expr {$x < $y ? "$x $y" : "$y $x"}]
                if {![dict exists $B $k]} {continue}
                set nT [dict get $Bn $k]
                foreach v [list $x $y] {
                    set d [plane_dist $p $P($v) $nT]
                    if {$d <= $dV} {set dV $d; set bestV $v}
                }
                lassign [seg_param $p $P($x) $P($y) $nT] s d
                if {$d <= $dE} {set dE $d; set bestE [list $k $s]}
            }
        }
        if {$bestV ne ""} {
            set nT [dict get $Vn $bestV]
            dict set SP $n [vadd $P($bestV) [vscale $nT [dot [vsub $p $P($bestV)] $nT]]]
            dict set nkey $n t$bestV
        } elseif {$bestE ne "" && [near_end $bestE $snapD] ne ""} {
            set v [near_end $bestE $snapD]
            set nT [dict get $Vn $v]
            dict set SP $n [vadd $P($v) [vscale $nT [dot [vsub $p $P($v)] $nT]]]
            dict set nkey $n t$v
        } elseif {$bestE ne ""} {
            lassign $bestE k s
            lassign $k x y
            set nT [dict get $Bn $k]
            set q [vadd $P($x) [vscale [vsub $P($y) $P($x)] $s]]
            dict set SP $n [vadd $q [vscale $nT [dot [vsub $p $q] $nT]]]
            dict set nkey $n s$n
            dict lappend onB $k [list $s s$n]
        } else {
            dict set SP $n $p
            dict set nkey $n s$n
        }
    }
    set pts [dict create]
    foreach n $ids {
        set k [dict get $nkey $n]
        if {![dict exists $pts $k]} {dict set pts $k [dict get $SP $n]}
    }
    # ---- 2. boundary nodes lying on source edges
    set onS [dict create]
    set vOnS [dict create]
    dict for {se one} $Sedges {
        lassign $se lo hi
        set klo [dict get $nkey $lo]; set khi [dict get $nkey $hi]
        if {$klo eq $khi} {continue}
        set plo [dict get $SP $lo]; set phi [dict get $SP $hi]
        set mid [vscale [vadd $plo $phi] 0.5]
        set half [expr {0.5*[norm [vsub $phi $plo]]}]
        set seen [dict create]
        foreach i [grid_near T $mid [expr {$half+$r+$snapD}]] {
            lassign [lindex $D(rows) $i] te ta tb tc
            foreach v [list $ta $tb $tc] {
                if {[dict exists $seen $v] || ![dict exists $Vn $v]} {continue}
                dict set seen $v 1
                if {"t$v" eq $klo || "t$v" eq $khi} {continue}
                lassign [seg_param $P($v) $plo $phi [dict get $Vn $v]] s d
                set len [expr {2*$half}]
                if {$d > $snapD || $s*$len <= $snapD || (1-$s)*$len <= $snapD} {continue}
                dict lappend vOnS $v $se
                dict lappend onS $se [list $s t$v]
                if {![dict exists $pts t$v]} {dict set pts t$v [vadd $plo [vscale [vsub $phi $plo] $s]]}
            }
        }
    }
    # ---- 3. crossings of source edges and boundary edges
    set onBx [dict create]
    dict for {se one} $Sedges {
        lassign $se lo hi
        set klo [dict get $nkey $lo]; set khi [dict get $nkey $hi]
        if {$klo eq $khi} {continue}
        set plo [dict get $SP $lo]; set phi [dict get $SP $hi]
        set mid [vscale [vadd $plo $phi] 0.5]
        set half [expr {0.5*[norm [vsub $phi $plo]]}]
        set done [dict create]
        foreach i [grid_near T $mid [expr {$half+$r}]] {
            lassign [lindex $D(rows) $i] te ta tb tc
            foreach {x y} [list $ta $tb $tb $tc $tc $ta] {
                set k [expr {$x < $y ? "$x $y" : "$y $x"}]
                if {![dict exists $B $k] || [dict exists $done $k]} {continue}
                dict set done $k 1
                lassign $k ta2 tb2
                # already decided: an end of one lies on the other
                if {$klo in [list t$ta2 t$tb2] || $khi in [list t$ta2 t$tb2]} {continue}
                if {[dict exists $vOnS $ta2] && $se in [dict get $vOnS $ta2]} {continue}
                if {[dict exists $vOnS $tb2] && $se in [dict get $vOnS $tb2]} {continue}
                set skip 0
                if {[dict exists $onB $k]} {foreach it [dict get $onB $k] {if {[lindex $it 1] in [list s$lo s$hi]} {set skip 1}}}
                if {$skip} {continue}
                set x3 [cross_3d $plo $phi $P($ta2) $P($tb2) [dict get $Bn $k]]
                if {![llength $x3]} {continue}
                lassign $x3 t u
                set lS [expr {2*$half}]; set lB [norm [vsub $P($tb2) $P($ta2)]]
                if {$t*$lS <= $snapD || (1-$t)*$lS <= $snapD || $u*$lB <= $snapD || (1-$u)*$lB <= $snapD} {continue}
                set key "x$lo.$hi.$ta2.$tb2"
                dict set pts $key [vadd $plo [vscale [vsub $phi $plo] $t]]
                dict lappend onS $se [list $t $key]
                dict lappend onBx $k [list $u $key]
            }
        }
    }
    # events along each boundary edge: its nodes, source nodes moved onto it, crossings
    set Bev [dict create]
    dict for {k one} $B {
        lassign $k ta tb
        set items [list [list 0.0 t$ta] [list 1.0 t$tb]]
        if {[dict exists $onB $k]} {lappend items {*}[dict get $onB $k]}
        if {[dict exists $onBx $k]} {lappend items {*}[dict get $onBx $k]}
        set seq {}
        foreach it [lsort -real -index 0 $items] {if {[lindex $it 1] ne [lindex $seq end]} {lappend seq [lindex $it 1]}}
        dict set Bev $k $seq
    }
    # keys of points on the target boundary
    set bnd [dict create]
    dict for {k seq} $Bev {foreach kk $seq {dict set bnd $kk 1}}
    # ---- 4. per triangle: pieces of (triangle ∩ footprint) from the shared events
    set tris {}
    set kept 0; set cut 0; set dropped 0
    foreach row $Srows {
        lassign $row e a b c
        set ka [dict get $nkey $a]; set kb [dict get $nkey $b]; set kc [dict get $nkey $c]
        if {$ka eq $kb || $kb eq $kc || $kc eq $ka} {incr dropped; continue}
        set pa [dict get $SP $a]; set pb [dict get $SP $b]; set pc [dict get $SP $c]
        set nn [cross [vsub $pb $pa] [vsub $pc $pa]]
        if {[norm $nn] <= 1e-12*max(1.0,pow($DS(mean),2))} {incr dropped; continue}
        set c3 [vscale [vadd [vadd $pa $pb] $pc] [expr {1.0/3}]]
        set rad [expr {max([norm [vsub $pa $c3]],[norm [vsub $pb $c3]],[norm [vsub $pc $c3]])}]
        set near [grid_near T $c3 [expr {$rad+$r+$snapD}]]
        set bEdges [dict create]
        foreach i $near {
            lassign [lindex $D(rows) $i] te ta tb tc
            foreach {x y} [list $ta $tb $tb $tc $tc $ta] {
                set k [expr {$x < $y ? "$x $y" : "$y $x"}]
                if {[dict exists $B $k]} {dict set bEdges $k 1}
            }
        }
        set e1 [unit [vsub $pb $pa]]; set nu [unit $nn]; set e2 [cross $nu $e1]
        set to2 [list $pa $e1 $e2]
        set A2 [to2d $to2 $pa]; set B2 [to2d $to2 $pb]; set C2 [to2d $to2 $pc]
        # edges of the triangle with their event sequences
        set tEdges {}
        set onEdge [dict create]
        foreach {ni nj nk} [list $a $b $c $b $c $a $c $a $b] {
            set lo [expr {min($ni,$nj)}]; set hi [expr {max($ni,$nj)}]
            set items [list [list 0.0 [dict get $nkey $lo]] [list 1.0 [dict get $nkey $hi]]]
            if {[dict exists $onS "$lo $hi"]} {lappend items {*}[dict get $onS "$lo $hi"]}
            set seq {}
            foreach it [lsort -real -index 0 $items] {if {[lindex $it 1] ne [lindex $seq end]} {lappend seq [lindex $it 1]}}
            lappend tEdges [list $lo $hi $nk $seq]
            foreach k $seq {dict lappend onEdge $k "$lo $hi"}
        }
        if {![dict size $bEdges]} {
            if {[llength [locate T $c3 $r]]} {
                lappend tris [list $ka $kb $kc]; incr kept
            } else {incr dropped}
            continue
        }
        set segs {}
        # source edge pieces: the side of the target boundary is tested just inside the triangle
        foreach te $tEdges {
            lassign $te lo hi opp seq
            set popp [dict get $SP $opp]
            for {set i 0} {$i < [llength $seq]-1} {incr i} {
                set k1 [lindex $seq $i]; set k2 [lindex $seq [expr {$i+1}]]
                set m [vscale [vadd [dict get $pts $k1] [dict get $pts $k2]] 0.5]
                if {[dict exists $bnd $k1] && [dict exists $bnd $k2]} {
                    # a piece with both ends on one boundary edge runs along it: it belongs to the
                    # triangle when the target face of that edge is on the same side as the triangle
                    set side [along_side $k1 $k2 $bEdges $Bev $Bthird $to2 [to2d $to2 $popp]]
                    if {$side ne ""} {
                        if {$side} {lappend segs [list $k1 $k2]}
                        continue
                    }
                }
                if {[llength [locate T $m $r]]} {lappend segs [list $k1 $k2]}
            }
        }
        # boundary pieces strictly inside the triangle
        set loc [dict create]
        dict for {k one} $bEdges {
            set seq [dict get $Bev $k]
            for {set i 0} {$i < [llength $seq]-1} {incr i} {
                set k1 [lindex $seq $i]; set k2 [lindex $seq [expr {$i+1}]]
                if {[shared_edge $onEdge $k1 $k2]} {continue}
                set q {}
                foreach kk [list $k1 $k2] {
                    if {[dict exists $pts $kk]} {lappend q [to2d $to2 [dict get $pts $kk]]} else {lappend q [to2d $to2 $P([string range $kk 1 end])]}
                }
                lassign $q q1 q2
                set m [list [expr {0.5*([lindex $q1 0]+[lindex $q2 0])}] [expr {0.5*([lindex $q1 1]+[lindex $q2 1])}]]
                if {![in_tri2 $m $A2 $B2 $C2 1e-9]} {continue}
                lappend segs [list $k1 $k2]
                dict set loc $k1 $q1; dict set loc $k2 $q2
            }
        }
        if {![llength $segs]} {incr dropped; continue}
        # chain into loops
        set adj [dict create]
        foreach s $segs {lassign $s k1 k2; dict lappend adj $k1 $k2; dict lappend adj $k2 $k1}
        set open {}
        dict for {k v} $adj {if {[llength $v] != 2} {lappend open $k [llength $v]}}
        if {[llength $open]} {
            set bev {}; dict for {k one} $bEdges {lappend bev $k [dict get $Bev $k] [list $P([lindex $k 0]) $P([lindex $k 1])]}
            set kp {}; foreach s $segs {foreach k $s {if {[dict exists $pts $k]} {lappend kp $k [dict get $pts $k]}}}
            set ::ElemImprint::clipDebug [list e $e corners [list $a $pa $b $pb $c $pc] keys [list $ka $kb $kc] tEdges $tEdges segs $segs bev $bev pts $kp snapD $snapD]
            error "Source element $e: the cut along the target boundary is not closed. Open points: $open"
        }
        set loops {}
        set seen [dict create]
        dict for {k v} $adj {
            if {[dict exists $seen $k]} {continue}
            set loop [list $k]; dict set seen $k 1
            set prev $k; set cur [lindex $v 0]
            while {$cur ne $k} {
                lappend loop $cur; dict set seen $cur 1
                set nx [dict get $adj $cur]
                set nxt [expr {[lindex $nx 0] eq $prev ? [lindex $nx 1] : [lindex $nx 0]}]
                set prev $cur; set cur $nxt
                if {[llength $loop] > 10000} {error "Source element $e: clipping loop does not close."}
            }
            lappend loops $loop
        }
        # whole triangle kept unchanged
        if {[llength $loops] == 1 && [llength [lindex $loops 0]] == 3 && [lsort [lindex $loops 0]] eq [lsort [list $ka $kb $kc]]} {
            lappend tris [list $ka $kb $kc]; incr kept
            continue
        }
        incr cut
        foreach loop $loops {
            set p2 {}
            foreach k $loop {
                if {[dict exists $loc $k]} {lappend p2 [dict get $loc $k]} else {lappend p2 [to2d $to2 [dict get $pts $k]]}
            }
            if {abs([poly_area2 $p2]) <= 1e-12*max(1.0,[poly_scale $p2])} {continue}
            if {[llength $loops] > 1} {
                foreach other $loops {
                    if {$other eq $loop} {continue}
                    set k0 [lindex $other 0]
                    set q0 [expr {[dict exists $loc $k0] ? [dict get $loc $k0] : [to2d $to2 [dict get $pts $k0]]}]
                    if {[point_in_poly $q0 $p2]} {error "Source element $e encloses a hole of the target: use a finer source mesh."}
                }
            }
            if {[catch {ear_clip $loop $p2} tt]} {error "Source element $e: $tt."}
            foreach t $tt {
                set out {}
                foreach k $t {
                    if {[dict exists $pts $k]} {lappend out $k; continue}
                    # a boundary node inside this triangle: its place on the triangle plane
                    set q [dict get $loc $k]
                    dict set pts "$k@$e" [vadd $pa [vadd [vscale $e1 [lindex $q 0]] [vscale $e2 [lindex $q 1]]]]
                    lappend out "$k@$e"
                }
                # keep the orientation of the source triangle
                lassign $out o1 o2 o3
                set n2 [cross [vsub [dict get $pts $o2] [dict get $pts $o1]] [vsub [dict get $pts $o3] [dict get $pts $o1]]]
                if {[dot $n2 $nu] < 0} {set out [list $o1 $o3 $o2]}
                lappend tris $out
            }
        }
    }
    list $tris $pts [list kept $kept cut $cut dropped $dropped]
}
# Boundary node at the end of {edge param} when the parameter is within snapD of it, else "".
proc ::ElemImprint::near_end {best snapD} {
    variable P
    lassign $best k s
    lassign $k x y
    set l [norm [vsub $P($y) $P($x)]]
    if {$s*$l <= $snapD} {return $x}
    if {(1-$s)*$l <= $snapD} {return $y}
    return ""
}
# Side test for a source edge piece k1-k2 lying on a boundary edge: 1 when the target face of that
# edge and the point o (2D) are on the same side of it, 0 when not, "" when no edge holds both keys.
proc ::ElemImprint::along_side {k1 k2 bEdges Bev Bthird to2 o} {
    variable P
    dict for {k one} $bEdges {
        set seq [dict get $Bev $k]
        if {$k1 ni $seq || $k2 ni $seq} {continue}
        lassign $k ta tb
        set a [to2d $to2 $P($ta)]; set b [to2d $to2 $P($tb)]; set c [to2d $to2 $P([dict get $Bthird $k])]
        set s1 [cross2 $a $b $c]; set s2 [cross2 $a $b $o]
        return [expr {$s1*$s2 > 0}]
    }
    return ""
}
# 1 when both keys lie on the same edge of the current source triangle.
proc ::ElemImprint::shared_edge {onEdge k1 k2} {
    if {![dict exists $onEdge $k1] || ![dict exists $onEdge $k2]} {return 0}
    foreach se [dict get $onEdge $k1] {if {$se in [dict get $onEdge $k2]} {return 1}}
    return 0
}
# Distance between p and q measured along a surface with normal n (the normal part removed).
proc ::ElemImprint::plane_dist {p q n} {
    set v [vsub $p $q]
    norm [vsub $v [vscale $n [dot $v $n]]]
}
# Parameter of the point of segment a-b nearest to p (along a surface with normal n) and the distance.
proc ::ElemImprint::seg_param {p a b n} {
    set ab [vsub $b $a]; set ab [vsub $ab [vscale $n [dot $ab $n]]]
    set ap [vsub $p $a]; set ap [vsub $ap [vscale $n [dot $ap $n]]]
    set l2 [dot $ab $ab]
    set s [expr {$l2 > 0 ? max(0.0,min(1.0,[dot $ap $ab]/$l2)) : 0.0}]
    list $s [norm [vsub $ap [vscale $ab $s]]]
}
# Crossing of segments p1-p2 and q1-q2 seen along normal n: {t u} or {}.
proc ::ElemImprint::cross_3d {p1 p2 q1 q2 n} {
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set f [list $p1 $e1 $e2]
    seg_x [to2d $f $p1] [to2d $f $p2] [to2d $f $q1] [to2d $f $q2]
}
proc ::ElemImprint::to2d {frame p} {
    lassign $frame o e1 e2
    set d [vsub $p $o]
    list [dot $d $e1] [dot $d $e2]
}
proc ::ElemImprint::point_in_poly {p poly} {
    lassign $p x y
    set in 0; set n [llength $poly]
    for {set i 0; set j [expr {$n-1}]} {$i < $n} {set j $i; incr i} {
        lassign [lindex $poly $i] xi yi; lassign [lindex $poly $j] xj yj
        if {(($yi > $y) != ($yj > $y)) && ($x < ($xj-$xi)*($y-$yi)/($yj-$yi)+$xi)} {set in [expr {!$in}]}
    }
    return $in
}

# ---------------------------------------------------------------- checks
proc ::ElemImprint::check_options {opts} {
    set layers [dict get $opts layers]
    if {![string is integer -strict $layers] || $layers < 0 || $layers > 20} {error "Remesh layers must be a whole number 0..20."}
    set d [dict get $opts maxDist]
    if {$d ne "" && (![string is double -strict $d] || $d <= 0)} {error "Max distance must be empty or a positive number."}
    set a [dict get $opts angle]
    if {![string is double -strict $a] || $a <= 0 || $a >= 90} {error "Feature angle must be between 0 and 90 degrees."}
    set s [dict get $opts minSize]
    if {$s ne "" && (![string is double -strict $s] || $s <= 0)} {error "Min size must be empty or a positive number."}
    set n [dict get $opts solidLayers]
    if {![string is integer -strict $n] || $n < 1 || ($n > 10 && $n != 1000)} {error "Solid layers must be a whole number 1..10."}
}


# Elements using any of the nodes (mark 1 -> elems mark 2).
proc ::ElemImprint::elems_on_nodes {nodes} {
    if {![llength $nodes]} {return {}}
    *createmark nodes 1 {*}$nodes
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set out [hm_getmark elems 2]
    *clearmark nodes 1; *clearmark elems 2
    return $out
}
proc ::ElemImprint::tet_face_keys {tets} {
    set keys [dict create]
    foreach nl [elem_nodes $tets] {
        lassign $nl a b c d
        foreach f [list [list $a $b $c] [list $a $b $d] [list $a $c $d] [list $b $c $d]] {dict set keys [lsort -integer $f] 1}
    }
    return $keys
}
# Target tets within "layers" rows of the contact face (rows grow through shared corner nodes, as in
# the Tet repair tool). Returns {patch neighbours}: neighbours are the other target tets touching it.
proc ::ElemImprint::solid_patch {target Trows layers} {
    set tset [lsort -integer $target]
    set nodes {}
    foreach row $Trows {lappend nodes {*}[lrange $row 1 3]}
    set seen [dict create]
    set patch [dict create]
    set frontier [lsort -unique -integer $nodes]
    foreach n $frontier {dict set seen $n 1}
    for {set k 0} {$k < $layers} {incr k} {
        set add {}
        foreach e [elems_on_nodes $frontier] {
            if {[lsearch -sorted -integer $tset $e] >= 0 && ![dict exists $patch $e]} {dict set patch $e 1; lappend add $e}
        }
        set frontier {}
        foreach nl [elem_nodes $add] {foreach n [lrange $nl 0 3] {if {![dict exists $seen $n]} {dict set seen $n 1; lappend frontier $n}}}
    }
    set patch [lsort -integer [dict keys $patch]]
    set pnodes {}; foreach nl [elem_nodes $patch] {lappend pnodes {*}[lrange $nl 0 3]}
    set neigh {}
    foreach e [elems_on_nodes [lsort -unique -integer $pnodes]] {
        if {[lsearch -sorted -integer $tset $e] >= 0 && [lsearch -sorted -integer $patch $e] < 0} {lappend neigh $e}
    }
    list $patch $neigh
}
# Patch tets must not be referenced (loads, sets, ...) and no element outside the target may use a
# patch node that is not kept (kept = also used by the remaining tets).
proc ::ElemImprint::guard_patch {target patch neigh} {
    *createmark elems 1 {*}$patch
    set types [hm_getcrossreferencedentitiesmark elems 1 7 2 0 0 0]
    *clearmark elems 1
    foreach type $types {
        if {$type in {comps components collectors}} {continue}
        set refs [hm_getmark $type 2]
        catch {*clearmark $type 2}
        if {[llength $refs]} {error "The tets next to the contact are referenced by $type ([lrange $refs 0 9]): imprinting there is blocked."}
    }
    set kept [lsort -integer [node_set $neigh]]
    set pn [node_set $patch]
    set tset [lsort -integer $target]
    set bad 0
    foreach e [elems_on_nodes $pn] {
        if {[lsearch -sorted -integer $tset $e] >= 0} {continue}
        foreach n [lindex [elem_nodes [list $e]] 0] {
            if {[lsearch -sorted -integer $pn $n] >= 0 && [lsearch -sorted -integer $kept $n] < 0} {incr bad; break}
        }
    }
    if {$bad} {error "$bad other elements (RBE, shells, ...) use nodes of the tets next to the contact: imprinting there is blocked."}
}

# Corner edges of triangles used once (open) as "a b" keys.
proc ::ElemImprint::open_edges {eids} {
    set cnt [dict create]
    foreach nl [elem_nodes $eids] {
        lassign $nl a b c
        foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
    }
    set out {}
    dict for {k v} $cnt {if {$v == 1} {lappend out $k}}
    return $out
}
# Shortest corner edge of triangles (or "" when there are none).
proc ::ElemImprint::min_edge {eids} {
    variable P
    if {![llength $eids]} {return ""}
    set rows [tri_rows $eids]
    set ids {}; foreach r $rows {lappend ids {*}[lrange $r 1 3]}
    load_xyz $ids
    set m ""
    foreach r $rows {
        lassign $r e a b c
        foreach {p q} [list $a $b $b $c $c $a] {
            set l [norm [vsub $P($q) $P($p)]]
            if {$m eq "" || $l < $m} {set m $l}
        }
    }
    return $m
}

proc ::ElemImprint::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::ElemImprint::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}

proc ::ElemImprint::unused_nodes {ids} {
    set ids [existing_nodes [lsort -unique -integer $ids]]
    if {![llength $ids]} {return {}}
    *createmark nodes 1 {*}$ids
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set used [node_set [hm_getmark elems 2]]
    *clearmark nodes 1; *clearmark elems 2
    set out {}
    foreach n $ids {if {[lsearch -sorted -integer $used $n] < 0} {lappend out $n}}
    return $out
}
proc ::ElemImprint::delete_elems {ids} {
    set ids [existing $ids]
    if {[llength $ids]} {*createmark elems 1 {*}$ids; *deletemark elems 1; *clearmark elems 1}
}
proc ::ElemImprint::delete_comp_if_empty {name} {
    if {$name eq "" || ![hm_entityinfo exist comps $name -byname]} {return}
    *createmark elems 1 "by collector name" $name
    set n [llength [hm_getmark elems 1]]
    *clearmark elems 1
    if {!$n} {*createmark comps 1 $name; catch {*deletemark comps 1}; *clearmark comps 1}
}
proc ::ElemImprint::temp_comp {} {
    set i 0
    while {[hm_entityinfo exist comps "__imprint_tmp$i" -byname]} {incr i}
    *createentity comps name=__imprint_tmp$i
    return __imprint_tmp$i
}

# Next patch size after a failed tet rebuild: one more row, twice, then the whole connected solid.
proc ::ElemImprint::next_solid {solid solid0} {expr {$solid < $solid0+2 ? $solid+1 : 1000}}

# ---------------------------------------------------------------- enclosed imprint (shared nodes)
# The way it is done by hand when one face lies inside the other: the enclosed face ("guest") is
# copied onto the enclosing face ("host") as new elements that use the guest's own nodes, the host
# elements under it (and "layers" rows around) are deleted, and the ring between the guest outline
# and the hole edge is filled with ruled triangles. Both faces then share nodes and have the same
# elements in the contact area. A tet host is rebuilt from its new face shell (patch, as before).

# 1 when p is within snapD of a boundary edge of grid "name" (measured along that surface).
proc ::ElemImprint::near_boundary {name p Bd snapD} {
    variable P
    upvar #0 ::ElemImprint::GD_$name D
    foreach i [grid_near $name $p $snapD] {
        lassign [lindex $D(rows) $i] e a b c
        set n [lindex $D($i) 3]
        foreach {x y} [list $a $b $b $c $c $a] {
            if {![dict exists $Bd [expr {$x < $y ? "$x $y" : "$y $x"}]]} {continue}
            if {[lindex [seg_param $p $P($x) $P($y) $n] 1] <= $snapD} {return 1}
        }
    }
    return 0
}
# 1 when every corner node of rows lies over grid "name" or within snapD of its boundary (within
# holeTol of the hole edges Bh: a washer hole a little smaller than the hole it sits on).
proc ::ElemImprint::all_over {rows name Bd r snapD {Bh {}} {holeTol 0}} {
    variable P
    set ids {}
    foreach row $rows {lappend ids {*}[lrange $row 1 3]}
    foreach n [lsort -unique -integer $ids] {
        if {[llength [locate $name $P($n) $r]]} {continue}
        if {[near_boundary $name $P($n) $Bd $snapD]} {continue}
        if {$holeTol > 0 && [dict size $Bh] && [near_boundary $name $P($n) $Bh $holeTol]} {continue}
        return 0
    }
    return 1
}
# The free edges of a face that are holes: every closed outline but the largest one.
proc ::ElemImprint::hole_edges {Bd} {
    variable P
    set keys {}; dict for {k one} $Bd {lappend keys $k}
    lassign [edge_chains $keys] chains pinch
    set loops {}
    foreach ch $chains {
        lassign $ch closed nodes
        if {!$closed} {continue}
        set A {0 0 0}; set nn [llength $nodes]
        for {set i 0} {$i < $nn} {incr i} {set A [vadd $A [cross $P([lindex $nodes $i]) $P([lindex $nodes [expr {($i+1)%$nn}]])]]}
        lappend loops [list [norm $A] $nodes]
    }
    set out [dict create]
    foreach item [lrange [lsort -real -decreasing -index 0 $loops] 1 end] {
        set nodes [lindex $item 1]; set nn [llength $nodes]
        for {set i 0} {$i < $nn} {incr i} {
            set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
            dict set out [expr {$a < $b ? "$a $b" : "$b $a"}] 1
        }
    }
    return $out
}
# Nodes made by *createnode stay temp nodes (yellow in the graphics) until their temp mark is cleared;
# the ones now used by elements keep existing. One native call for all of them.
set ::ElemImprint::madeNodes {}
proc ::ElemImprint::clear_temp_nodes {} {
    set ids {}
    foreach n [lsort -unique -integer $::ElemImprint::madeNodes] {if {[hm_entityinfo exist nodes $n -byid]} {lappend ids $n}}
    set ::ElemImprint::madeNodes {}
    if {[llength $ids]} {*createmark nodes 1 {*}$ids; *nodemarkcleartempmark 1; *clearmark nodes 1}
}
proc ::ElemImprint::row_area {row} {
    variable P
    lassign $row e a b c
    expr {0.5*[norm [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]}
}
proc ::ElemImprint::avg_normal {rows} {
    variable P
    set s {0.0 0.0 0.0}
    foreach row $rows {
        lassign $row e a b c
        set s [vadd $s [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
    }
    unit $s
}
proc ::ElemImprint::loop_area {loop N} {
    variable P
    set s {0.0 0.0 0.0}
    set n [llength $loop]
    set o $P([lindex $loop 0])
    for {set i 1} {$i < $n-1} {incr i} {
        set s [vadd $s [cross [vsub $P([lindex $loop $i]) $o] [vsub $P([lindex $loop [expr {$i+1}]]) $o]]]
    }
    dot $s $N
}
# Mean distance from the nodes of loop a to the nodes of loop b.
proc ::ElemImprint::loop_gap {a b} {
    variable P
    set sum 0.0
    foreach n $a {
        set best 1e300
        foreach m $b {set d [norm [vsub $P($n) $P($m)]]; if {$d < $best} {set best $d}}
        set sum [expr {$sum+$best}]
    }
    expr {$sum/max(1,[llength $a])}
}
# Ruled triangles between closed loops A and B (same direction around N): shortest diagonal first.
proc ::ElemImprint::ruled {A B N {align 1}} {
    variable P
    if {[loop_area $A $N]*[loop_area $B $N] < 0} {set B [lreverse $B]}
    set n [llength $A]; set m [llength $B]
    if {$align} {
        set best 0; set bd 1e300
        for {set j 0} {$j < $m} {incr j} {set d [norm [vsub $P([lindex $B $j]) $P([lindex $A 0])]]; if {$d < $bd} {set bd $d; set best $j}}
        set B [concat [lrange $B $best end] [lrange $B 0 [expr {$best-1}]]]
    }
    set tris {}
    set i 0; set j 0
    while {$i < $n || $j < $m} {
        set a0 [lindex $A [expr {$i % $n}]]; set a1 [lindex $A [expr {($i+1) % $n}]]
        set b0 [lindex $B [expr {$j % $m}]]; set b1 [lindex $B [expr {($j+1) % $m}]]
        if {$i >= $n} {set adv B} elseif {$j >= $m} {set adv A} else {
            set adv [expr {[norm [vsub $P($a1) $P($b0)]] <= [norm [vsub $P($b1) $P($a0)]] ? "A" : "B"}]
        }
        if {$adv eq "A"} {lappend tris [list $a0 $a1 $b0]; incr i} else {lappend tris [list $a0 $b1 $b0]; incr j}
    }
    # one orientation, along N
    set out {}
    foreach t $tris {
        lassign $t x y z
        if {$x == $y || $y == $z || $x == $z} {continue}
        if {[dot [cross [vsub $P($y) $P($x)] [vsub $P($z) $P($x)]] $N] < 0} {set t [list $x $z $y]}
        lappend out $t
    }
    return $out
}
# Midside node of edge a-b from the map (existing elements), else a new node at the midpoint.
proc ::ElemImprint::mid_node {mapVar a b} {
    variable P
    upvar 1 $mapVar map
    set k [expr {$a < $b ? "$a $b" : "$b $a"}]
    if {[dict exists $map $k]} {return [dict get $map $k]}
    *createnode {*}[vscale [vadd $P($a) $P($b)] 0.5] 0 0 0
    set id [hm_latestentityid nodes]
    lappend ::ElemImprint::madeNodes $id
    set P($id) [vscale [vadd $P($a) $P($b)] 0.5]
    dict set map $k $id
    return $id
}
proc ::ElemImprint::add_mids {mapVar eids} {
    upvar 1 $mapVar map
    if {![llength $eids]} {return}
    foreach nl [elem_nodes $eids] c [configs $eids] {
        if {$c != 106} {continue}
        lassign $nl a b cc m1 m2 m3
        foreach {x y m} [list $a $b $m1 $b $cc $m2 $cc $a $m3] {dict set map [expr {$x < $y ? "$x $y" : "$y $x"}] $m}
    }
}
# Creates elements: rows of full node lists with their config. Returns the new ids.
proc ::ElemImprint::create_rows {rows cfg} {
    if {![llength $rows]} {return {}}
    set conn {}
    foreach nl $rows {lappend conn {*}$nl}
    hm_entityrecorder elems on
    set rc [catch {*createarray [llength $conn] {*}$conn; *createelements $cfg 1 1 [llength $conn]} m]
    hm_entityrecorder elems off
    if {$rc} {error "Creating elements failed: $m"}
    set ids [existing [hm_entityrecorder elems ids]]
    if {[llength $ids] != [llength $rows]} {error "Expected [llength $rows] elements of config $cfg, got [llength $ids] (readback)."}
    # readback: the new elements have exactly the requested node lists
    set want [dict create]
    foreach nl $rows {dict incr want [lsort -integer $nl]}
    foreach nl [elem_nodes $ids] {
        set k [lsort -integer $nl]
        if {![dict exists $want $k]} {error "Created element nodes $nl were not requested (readback; recorder ids [lrange $ids 0 4], first request [lindex $rows 0])."}
    }
    return $ids
}

# One attempt in one Undo step. Errors: "PARTIAL" (no face encloses the other), "RETRY: ..." (tets
# could not be rebuilt; rolled back). Returns a dict (see the end).
# Ring triangles thinner than this (smallest angle, radians) make the next host row go too.
set ::ElemImprint::wrote 0
set ::ElemImprint::thinAngle [expr {15.0*acos(-1)/180.0}]
proc ::ElemImprint::enclose_once {target source opts} {
    variable P; variable tetString; variable tetPars; variable snapFrac; variable outer
    array unset P
    set ::ElemImprint::ringNodes {}
    set target [existing $target]; set source [existing $source]
    if {![llength $target]} {error "Select the target elements."}
    if {![llength $source]} {error "Select the source elements."}
    set t [lsort -integer $target]; set both 0
    foreach e $source {if {[lsearch -sorted -integer $t $e] >= 0} {incr both}}
    if {$both} {error "$both elements are both target and source."}
    lassign [kind $target target] tDim tOrder tCfg
    lassign [kind $source source] sDim sOrder sCfg
    set cosA [expr {cos([dict get $opts angle]*acos(-1)/180.0)}]
    foreach {ids dim} [list $target $tDim $source $sDim] {
        if {$dim == 3 && [llength [comps_of $ids]] != 1} {error "Tets must be in one component."}
    }
    set before [list [count elems] [count nodes]]
    set curComp [hm_info currentcomponent]
    set label "Element imprint"
    # inside imprint_twoway the caller owns the Undo step and the rollback
    if {!$outer} {history_begin $label; set ::ElemImprint::wrote 0}
    set temps {}; set comps {}
    set code [catch {
        # surfaces of both sides
        if {$tDim == 2} {set Tall [tri_rows $target]} else {set f [find_faces $target]; lappend temps {*}$f; set Tall [tri_rows $f]}
        if {$sDim == 2} {set Sall [tri_rows $source]} else {set f [find_faces $source]; lappend temps {*}$f; set Sall [tri_rows $f]}
        set mT [grid_build T $Tall]; set mS [grid_build S $Sall]
        set r [dict get $opts maxDist]
        if {$r eq ""} {set r [expr {$mT+$mS}]}
        grid_index T [expr {max($mT,$r/2.0)}]
        # faces of tets in contact: within Max distance, or half the mesh size when it is empty
        set rc3 [expr {[dict get $opts maxDist] ne "" ? [dict get $opts maxDist] : 0.5*min($mT,$mS)}]
        set Srows $Sall
        if {$sDim == 3} {
            set Srows [rows_on $Sall T $rc3 $cosA]
            if {![llength $Srows]} {error "No face of the source tets lies on the target within [format %.4g $r] (Max distance) and Feature angle."}
            grid_build S $Srows
        }
        grid_index S [expr {max($mS,$r/2.0)}]
        set Trows $Tall
        if {$tDim == 3} {
            set seeds [rows_on $Tall S $rc3 $cosA]
            if {![llength $seeds]} {error "No face of the target tets lies under the source within [format %.4g $r] (Max distance)."}
            set Trows [flood $Tall $seeds $cosA]
            grid_build T $Trows; grid_index T [expr {max($mT,$r/2.0)}]
        }
        set snapD [expr {$snapFrac*min($mT,$mS)}]
        if {[dict exists $opts snapD]} {set snapD [expr {max($snapD,[dict get $opts snapD])}]}
        set BT [boundary_edges $Trows]; set BS [boundary_edges $Srows]
        # nodes this close to a hole edge of the other face count as on it (see hole_edges)
        set holeTol0 [expr {[dict exists $opts mergeTol] ? 0 : 0.3*min($mT,$mS)}]
        set HT [hole_edges $BT]; set HS [hole_edges $BS]
        # which face encloses the other
        if {[all_over $Srows T $BT $r $snapD $HT $holeTol0]} {
            set swapped 0
            set H [list name T ids $target dim $tDim order $tOrder all $Tall contact $Trows]
            set G [list name S ids $source dim $sDim order $sOrder rows $Srows B $BS]
        } elseif {![dict exists $opts force] && [all_over $Trows S $BS $r $snapD $HS $holeTol0]} {
            set swapped 1
            # a tet host takes its whole contact face (grown across edges), as the target does
            set hc [expr {$sDim == 3 ? [flood $Sall $Srows $cosA] : $Srows}]
            set H [list name S ids $source dim $sDim order $sOrder all $Sall contact $hc]
            set G [list name T ids $target dim $tDim order $tOrder rows $Trows B $BT]
        } elseif {[dict exists $opts trim] && [dict get $opts trim]} {
            # neither face lies wholly on the other (e.g. a bolt head over a hole with a chamfer): the
            # larger face is the host, and only the elements of the other face lying wholly on it are
            # copied; the rest overhangs (over a hole or past an edge) and stays as it is
            set aT 0.0; foreach row $Trows {set aT [expr {$aT+[row_area $row]}]}
            set aS 0.0; foreach row $Srows {set aS [expr {$aS+[row_area $row]}]}
            set swapped [expr {$aS > $aT && ![dict exists $opts force]}]
            if {$swapped} {
                set hc [expr {$sDim == 3 ? [flood $Sall $Srows $cosA] : $Srows}]
                set H [list name S ids $source dim $sDim order $sOrder all $Sall contact $hc]
                set gRows $Trows; set gBd $BS; set gn T; set gIn [list $target $tDim $tOrder]
            } else {
                set H [list name T ids $target dim $tDim order $tOrder all $Tall contact $Trows]
                set gRows $Srows; set gBd $BT; set gn S; set gIn [list $source $sDim $sOrder]
            }
            set hn [expr {$swapped ? "S" : "T"}]
            set kept {}
            set gHo [expr {$swapped ? $HS : $HT}]
            foreach row $gRows {if {[all_over [list $row] $hn $gBd $r $snapD $gHo $holeTol0]} {lappend kept $row}}
            if {![llength $kept]} {error "PARTIAL"}
            set ::ElemImprint::trimmed [expr {[llength $gRows]-[llength $kept]}]
            lassign $gIn gIds0 gDim0 gOrder0
            grid_build $gn $kept
            set G [list name $gn ids $gIds0 dim $gDim0 order $gOrder0 rows $kept B [boundary_edges $kept]]
        } else {
            error "PARTIAL"
        }
        set hName [dict get $H name]; set gName [dict get $G name]
        set Grows [dict get $G rows]; set BG [dict get $G B]
        set hDim [dict get $H dim]; set hOrder [dict get $H order]
        if {$hDim == 3 && [dict get $G order] != $hOrder} {error "The tet face and the other face have different element orders: use the same order on both."}
        # host surface rows that may change
        set internal {}; set patch {}
        if {$hDim == 2} {
            set Hsurf [tri_rows [dict get $H ids]]
            set hostComp [lindex [comps_of [dict get $H ids]] 0]
        } else {
            lassign [solid_patch [dict get $H ids] [dict get $H contact] [dict get $opts solidLayers]] patch neigh
            delete_elems $temps; set temps {}
            # the guest faces were temporary too when the guest is tets: find them again
            if {[dict get $G dim] == 3} {
                set f [find_faces [dict get $G ids]]; lappend temps {*}$f
                set Grows [regrid_guest $f $Grows]
                set BG [boundary_edges $Grows]
            }
            guard_patch [dict get $H ids] $patch $neigh
            set pf [find_faces $patch]; lappend temps {*}$pf
            set nkeys [tet_face_keys $neigh]
            set Hsurf {}
            foreach row [tri_rows $pf] {
                lassign $row e a b c
                if {[dict exists $nkeys [lsort -integer [list $a $b $c]]]} {lappend internal $e} else {lappend Hsurf $row}
            }
            set hostComp [lindex [comps_of [dict get $H ids]] 0]
        }
        grid_build $gName $Grows; grid_index $gName [expr {max($mS,$mT,$r/2.0)}]
        set ids {}; foreach row [concat $Hsurf $Grows] {lappend ids {*}[lrange $row 1 3]}
        load_xyz $ids
        # free edges of the host face (a tet shell has none)
        set BH [expr {$hDim == 2 ? [boundary_edges $Hsurf] : [dict create]}]
        # host rows under the guest: a corner over it or next to its outline, the centroid over it,
        # an outline node inside the row, or an outline edge crossing the row
        set R [dict create]
        set gB {}; dict for {k one} $BG {lappend gB $k}
        # only rows of the host contact face can lie under the guest (not the other faces of a patch)
        set contactKeys [dict create]
        foreach row [dict get $H contact] {dict set contactKeys [lsort -integer [lrange $row 1 3]] 1}
        foreach row $Hsurf {
            lassign $row e a b c
            if {![dict exists $contactKeys [lsort -integer [list $a $b $c]]]} {continue}
            set hit 0
            foreach n [list $a $b $c] {
                if {[llength [locate $gName $P($n) $r]] || [near_boundary $gName $P($n) $BG $snapD]} {set hit 1; break}
            }
            set c3 [vscale [vadd [vadd $P($a) $P($b)] $P($c)] [expr {1.0/3}]]
            if {!$hit && [llength [locate $gName $c3 $r]]} {set hit 1}
            if {!$hit} {
                set n3 [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
                set e1 [unit [vsub $P($b) $P($a)]]; set f [list $P($a) $e1 [cross $n3 $e1]]
                set A2 [to2d $f $P($a)]; set B2 [to2d $f $P($b)]; set C2 [to2d $f $P($c)]
                set rad [expr {max([norm [vsub $P($a) $c3]],[norm [vsub $P($b) $c3]],[norm [vsub $P($c) $c3]])}]
                foreach i [grid_near $gName $c3 [expr {$rad+$r}]] {
                    upvar #0 ::ElemImprint::GD_$gName DG
                    lassign [lindex $DG(rows) $i] ge ga gb gc
                    foreach {x y} [list $ga $gb $gb $gc $gc $ga] {
                        if {![dict exists $BG [expr {$x < $y ? "$x $y" : "$y $x"}]]} {continue}
                        set X2 [to2d $f $P($x)]; set Y2 [to2d $f $P($y)]
                        if {[in_tri2 $X2 $A2 $B2 $C2 1e-9]} {set hit 1; break}
                        foreach {p q} [list $A2 $B2 $B2 $C2 $C2 $A2] {
                            set s [seg_x $p $q $X2 $Y2]
                            if {[llength $s] && [lindex $s 0] > 0 && [lindex $s 0] < 1 && [lindex $s 1] > 0 && [lindex $s 1] < 1} {set hit 1; break}
                        }
                        if {$hit} {break}
                    }
                    if {$hit} {break}
                }
            }
            if {$hit} {dict set R $e $row}
        }
        if {![dict size $R]} {error "PARTIAL"}
        # more rows around (Remesh layers), never reaching the host's free edge
        set byNode [dict create]
        foreach row $Hsurf {foreach n [lrange $row 1 3] {dict lappend byNode $n $row}}
        for {set k 0} {$k < [dict get $opts layers]} {incr k} {
            set add {}
            dict for {e row} $R {
                foreach n [lrange $row 1 3] {
                    foreach r2 [dict get $byNode $n] {
                        set e2 [lindex $r2 0]
                        if {[dict exists $R $e2]} {continue}
                        if {![dict exists $contactKeys [lsort -integer [lrange $r2 1 3]]]} {continue}
                        lassign $r2 x a b c
                        set free 0
                        foreach {p q} [list $a $b $b $c $c $a] {if {[dict exists $BH [expr {$p < $q ? "$p $q" : "$q $p"}]]} {set free 1}}
                        if {!$free} {lappend add $e2 $r2}
                    }
                }
            }
            if {![llength $add]} {break}
            foreach {e2 r2} $add {dict set R $e2 $r2}
        }
        # host rows next to a gap too narrow in an earlier attempt are removed too (corner triples)
        if {[dict exists $opts extra] && [llength [dict get $opts extra]]} {
            set want [dict create]; foreach k [dict get $opts extra] {dict set want $k 1}
            foreach row $Hsurf {
                if {[dict exists $want [lsort -integer [lrange $row 1 3]]]} {dict set R [lindex $row 0] $row}
            }
        }
        # --- the region to fill: R minus the guest. Grow R first where a hole edge of the host lies
        # under the guest (e.g. the top of a hole wall just inside a washer) or where the hole
        # touches itself at a node.
        for {set it 0} {$it < 8} {incr it} {
            set cnt [dict create]
            dict for {e row} $R {
                lassign $row x a b c
                foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
            }
            set holeEdges {}
            dict for {k v} $cnt {if {$v == 1 && ![dict exists $BH $k]} {lappend holeEdges $k}}
            set grow {}
            lassign [edge_chains $holeEdges] chains pinches
            foreach n $pinches {foreach r2 [dict get $byNode $n] {if {![dict exists $R [lindex $r2 0]]} {lappend grow [lindex $r2 0] $r2}}}
            foreach ch $chains {
                lassign $ch closed nodes
                if {!$closed} {continue}
                set under 1
                foreach n $nodes {if {![llength [locate $gName $P($n) $rc3]] && ![near_boundary $gName $P($n) $BG $snapD]} {set under 0; break}}
                if {$under} {foreach n $nodes {foreach r2 [dict get $byNode $n] {if {![dict exists $R [lindex $r2 0]]} {lappend grow [lindex $r2 0] $r2}}}}
            }
            if {![llength $grow]} {break}
            foreach {e2 r2} $grow {dict set R $e2 $r2}
        }
        if {[llength $grow]} {error "LAYER: the hole in the host face is not a simple outline."}
        set Rrows {}; dict for {e row} $R {lappend Rrows $row}
        set N [avg_normal $Rrows]
        # boundary edges of R (hole edges and host free edges) and the host face normal near them
        set Rb {}
        dict for {k v} $cnt {if {$v == 1} {lappend Rb $k}}
        set gNodes [dict create]
        foreach k $gB {foreach n $k {dict set gNodes $n 1}}
        load_xyz [concat [dict keys $gNodes] [node_set [dict keys $R]]]
        # guest outline nodes on the R boundary: merged with a host node or inserted into an edge
        # node merge tolerance: snapD, or the caller's (exact for the cut overlap on its own target)
        set mtol [expr {[dict exists $opts mergeTol] ? [dict get $opts mergeTol] : $snapD}]
        # a host node this close to a copy node is merged into it (as an equivalence by hand would)
        set mtolV [expr {[dict exists $opts mergeTol] ? $mtol : max($snapD,0.15*min($mT,$mS))}]
        set vmap [dict create]; set splits [dict create]
        set rbNodes [dict create]
        foreach k $Rb {foreach n $k {dict set rbNodes $n 1}}
        # every host node on the R boundary takes the nearest guest outline node within mtol
        dict for {v one2} $rbNodes {
            set bestG ""; set dG $mtolV
            dict for {g one} $gNodes {
                set d [norm [vsub $P($g) $P($v)]]
                if {$d <= $dG} {set dG $d; set bestG $g}
            }
            if {$bestG ne ""} {dict set vmap $v $bestG}
        }
        set mappedG [dict create]
        dict for {v g} $vmap {dict set mappedG $g 1}
        # merge them in the whole model (*replacenodes moves the host node onto the copy node and
        # every element using it, also outside the selection, takes the copy node)
        # (merges keep the counts, so a failure after them must be undone by this flag)
        if {[dict size $vmap]} {set ::ElemImprint::wrote 1}
        dict for {v g} $vmap {if {$v != $g} {*replacenodes $v $g 1 0}}
        # a host edge also used by elements outside the host face is never split (it would leave
        # those elements unconnected)
        set hsIds [dict create]
        foreach row $Hsurf {dict set hsIds [lindex $row 0] 1}
        dict for {g one} $gNodes {
            if {[dict exists $mappedG $g]} {continue}
            foreach k $Rb {
                lassign $k x y
                set l [norm [vsub $P($y) $P($x)]]
                set s [expr {$l > 0 ? max(0.0,min(1.0,[dot [vsub $P($g) $P($x)] [vsub $P($y) $P($x)]]/($l*$l))) : 0.0}]
                set d [norm [vsub $P($g) [vadd $P($x) [vscale [vsub $P($y) $P($x)] $s]]]]
                if {$d <= $mtol && $s*$l > $mtol && (1-$s)*$l > $mtol} {
                    if {[edge_used_outside $x $y $hsIds]} {break}
                    dict lappend splits $k [list $s $g]; break
                }
            }
        }
        # host pieces of the R boundary; free-edge pieces under the guest are dropped. Every piece of a
        # free edge stays an allowed free edge for the crack check.
        set hostPieces {}; set freePieces [dict create]
        # A closed hole edge of the host lying wholly along the guest outline within holeTol (every node
        # and edge middle under the guest or that close to its outline) is the same edge seen by two
        # meshes, e.g. a coarse hole polygon under a washer with an equal, finer hole: it is dropped
        # with the guest pieces along it, so the hole edge follows the guest outline instead of leaving
        # slivers between the two. Open runs of free edge (a plate's outer edge) are left as they are.
        set holeTol [expr {[dict exists $opts mergeTol] ? max($mtol,1e-9) : max($mtol,0.3*min($mT,$mS))}]
        set dropBH [dict create]; set dropK [dict create]
        if {$hDim == 2 && $holeTol > $mtol} {
            set freeRb {}; foreach k $Rb {if {[dict exists $BH $k]} {lappend freeRb $k}}
            foreach ch [lindex [edge_chains $freeRb] 0] {
                lassign $ch closed nodes
                if {!$closed} {continue}
                set nn [llength $nodes]; set along 1
                for {set i 0} {$i < $nn && $along} {incr i} {
                    set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
                    foreach p [list $P($a) [vscale [vadd $P($a) $P($b)] 0.5]] {
                        if {![llength [locate $gName $p $rc3]] && ![near_boundary $gName $p $BG $holeTol]} {set along 0; break}
                    }
                }
                if {!$along} {continue}
                for {set i 0} {$i < $nn} {incr i} {
                    set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
                    dict set dropK [expr {$a < $b ? "$a $b" : "$b $a"}] 1
                }
            }
        }
        foreach k $Rb {
            lassign $k x y
            set seq [list [list 0.0 $x]]
            if {[dict exists $splits $k]} {foreach it [lsort -real -index 0 [dict get $splits $k]] {lappend seq $it}}
            lappend seq [list 1.0 $y]
            for {set i 0} {$i < [llength $seq]-1} {incr i} {
                set a [lindex $seq $i 1]; set b [lindex $seq [expr {$i+1}] 1]
                if {[dict exists $vmap $a]} {set a [dict get $vmap $a]}
                if {[dict exists $vmap $b]} {set b [dict get $vmap $b]}
                if {$a == $b} {continue}
                if {[dict exists $BH $k]} {
                    dict set freePieces [expr {$a < $b ? "$a $b" : "$b $a"}] 1
                    set m [vscale [vadd $P($a) $P($b)] 0.5]
                    if {[llength [locate $gName $m $rc3]] || [near_boundary $gName $m $BG [expr {max($mtol,1e-9)}]]} {continue}
                    if {[dict exists $dropK $k]} {dict set dropBH [expr {$a < $b ? "$a $b" : "$b $a"}] 1; continue}
                }
                lappend hostPieces [expr {$a < $b ? "$a $b" : "$b $a"}]
            }
        }
        # guest outline pieces inside the host face; on a host shell face, pieces on its free edge or
        # over a hole of it stay free edges (a tet host has neither)
        set guestPieces {}
        foreach k $gB {
            lassign $k a b
            set m [vscale [vadd $P($a) $P($b)] 0.5]
            if {$hDim == 2 && ([near_edges $m $BH [expr {max($mtol,1e-9)}] $N] || ![llength [locate $hName $m $rc3]])} {continue}
            if {[dict size $dropBH] && [near_edges $m $dropBH $holeTol $N]} {continue}
            lappend guestPieces $k
        }
        # a piece that is both a host and a guest piece encloses nothing
        set fill [dict create]
        foreach k $hostPieces {dict lappend fill $k host}
        foreach k $guestPieces {dict lappend fill $k guest}
        set fillEdges {}; set from [dict create]
        dict for {k who} $fill {
            if {[llength $who] > 1} {continue}
            lappend fillEdges $k
            dict set from $k [lindex $who 0]
        }
        set fillEdges [split_touches $fillEdges $from $N]
        lassign [edge_chains $fillEdges] fchains fpinch
        if {[llength $fpinch]} {error "LAYER: the ring between the copy and the host face is not a simple outline."}
        set hostLoops {}; set guestLoops {}; set mixed {}
        set fixed {}
        foreach ch $fchains {
            lassign $ch closed nodes
            set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
            lappend fixed [list $closed $nn]
        }
        set fchains $fixed
        foreach ch $fchains {
            lassign $ch closed nodes
            if {!$closed} {
                # kept for diagnosis: the open chain with its piece kinds and end points
                set ends {}; foreach n [list [lindex $nodes 0] [lindex $nodes end]] {lappend ends [list $n $P($n)]}
                set ::ElemImprint::lastOpen [list ends $ends length [llength $nodes] hostPieces [llength $hostPieces] guestPieces [llength $guestPieces] free [dict size $freePieces]]
                error "LAYER: the ring between the copy and the host face is open."
            }
            set kinds [dict create]
            set n [llength $nodes]
            for {set i 0} {$i < $n} {incr i} {
                set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$n}]]
                dict set kinds [dict get $from [expr {$a < $b ? "$a $b" : "$b $a"}]] 1
            }
            if {[dict size $kinds] == 2} {lappend mixed $nodes} elseif {[dict exists $kinds host]} {lappend hostLoops $nodes} else {lappend guestLoops $nodes}
        }
        # Every outline of the removed area (closed hole edges, or outlines mixing host and copy pieces
        # where the area reaches the host's edge), smallest first, takes the copy outlines inside it as
        # holes, except copy outlines lying inside another one of them (e.g. the hole of a washer).
        # One hole: rows between the two outlines; several: joined and ear-clipped; none (mixed only):
        # the outline is ear-clipped.
        set bands {}
        set used {}
        set outers {}
        foreach loop [concat $hostLoops $mixed] {lappend outers [list [expr {abs([loop_area $loop $N])}] $loop [expr {$loop in $mixed}]]}
        foreach item [lsort -real -index 0 $outers] {
            lassign $item area loop isMixed
            set cands {}
            foreach gl $guestLoops {
                if {$gl in $used} {continue}
                if {[loop_inside $gl $loop $N]} {lappend cands $gl}
            }
            set holes {}
            foreach gl $cands {
                set nested 0
                foreach other $cands {if {$other ne $gl && [loop_inside $gl $other $N]} {set nested 1; break}}
                if {!$nested} {lappend holes $gl}
            }
            if {![llength $holes] && !$isMixed} {
                # a closed hole edge with no copy outline inside (e.g. a hole wall just inside a washer):
                # the nearest copy outline
                set best ""; set bd 1e300
                foreach gl $guestLoops {
                    if {$gl in $used} {continue}
                    set d [loop_gap $loop $gl]
                    if {$d < $bd} {set bd $d; set best $gl}
                }
                if {$best eq ""} {error "LAYER: a hole edge in the host has no matching outline of the copy."}
                set holes [list $best]
            }
            foreach h $holes {lappend used $h}
            if {[llength $holes] == 1 && [loop_inside $loop [lindex $holes 0] $N]} {
                # the host edge lies inside the copy outline (a hole edge of the host just inside a
                # trimmed copy): the band runs from that edge out to the copy outline
                lappend bands {*}[ring_fill $loop [lindex $holes 0] $N [dict get $opts minSize] $hName]
            } elseif {[llength $holes] == 1} {
                lappend bands {*}[ring_fill [lindex $holes 0] $loop $N [dict get $opts minSize] $hName]
            } else {
                lappend bands {*}[fill_with_holes $loop $holes $N]
            }
        }
        # a copy outline left over (e.g. the hole of a washer) that lies over host material, where the
        # host had no hole, is filled again: a node at its centre on the old host face and a fan, or
        # ear clipping when the fan would fold
        foreach gl $guestLoops {
            if {$gl in $used} {continue}
            set c [vscale [lindex [loop_sum $gl] 0] [expr {1.0/[llength $gl]}]]
            if {![llength [locate $hName $c $rc3]]} {continue}
            lappend used $gl
            lappend bands {*}[fill_disk $gl $N $hName]
        }
        # better shapes: interior edges of the fill flipped while that raises the smallest angle
        set bands [flip_improve $bands $N]
        # smallest angle of the fill (degrees), to compare attempts
        set ringAngle 180.0
        foreach tr $bands {set a1 [expr {[tri_min_angle {*}$tr]*180.0/acos(-1)}]; if {$a1 < $ringAngle} {set ringAngle $a1}}
        # a gap too narrow between the copy and a kept host row gives a thin triangle (or an edge
        # shorter than Min size): only the host row next to it is removed and the ring made again
        # (as one would by hand), never a whole layer
        if {[dict exists $opts growLeft] && [dict get $opts growLeft] > 0} {
            set rKeys [dict create]; dict for {e row} $R {dict set rKeys [lsort -integer [lrange $row 1 3]] 1}
            set keptByEdge [dict create]
            foreach row $Hsurf {
                set k [lsort -integer [lrange $row 1 3]]
                if {[dict exists $rKeys $k] || ![dict exists $contactKeys $k]} {continue}
                lassign $row e a b c
                foreach {p q} [list $a $b $b $c $c $a] {dict lappend keptByEdge [expr {$p < $q ? "$p $q" : "$q $p"}] $k}
            }
            set more {}
            set ms [dict get $opts minSize]
            foreach tr $bands {
                set bad [expr {[tri_min_angle {*}$tr] < $::ElemImprint::thinAngle}]
                if {!$bad && $ms ne ""} {
                    lassign $tr a b c
                    foreach {p q} [list $a $b $b $c $c $a] {if {[norm [vsub $P($p) $P($q)]] < $ms*(1-1e-9)} {set bad 1; break}}
                }
                if {!$bad} {continue}
                lassign $tr a b c
                foreach {p q} [list $a $b $b $c $c $a] {
                    set ek [expr {$p < $q ? "$p $q" : "$q $p"}]
                    if {[dict exists $keptByEdge $ek]} {lappend more {*}[dict get $keptByEdge $ek]}
                }
            }
            if {[llength $more]} {error "GROW: [list $ringAngle [lsort -unique $more]]"}
        }
        # kept host rows next to the R boundary: merged nodes replaced, inserted nodes split them
        set splitRows {}; set splitOld {}
        foreach row $Hsurf {
            lassign $row e a b c
            if {[dict exists $R $e]} {continue}
            set touched 0
            foreach {p q} [list $a $b $b $c $c $a] {if {[dict exists $splits [expr {$p < $q ? "$p $q" : "$q $p"}]]} {set touched 1}}
            if {!$touched} {continue}
            set poly {}
            foreach {p q} [list $a $b $b $c $c $a] {
                lappend poly $p
                set k [expr {$p < $q ? "$p $q" : "$q $p"}]
                if {[dict exists $splits $k]} {
                    set its [lsort -real -index 0 [dict get $splits $k]]
                    if {$p > $q} {set its [lreverse $its]}
                    foreach it $its {lappend poly [lindex $it 1]}
                }
            }
            set poly2 {}
            foreach n $poly {lappend poly2 [expr {[dict exists $vmap $n] ? [dict get $vmap $n] : $n}]}
            set nRow [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
            lappend splitOld $e
            lappend splitRows {*}[fill_polygon $poly2 $nRow]
        }
        # build: guest copy with the guest nodes, ruled ring, all in the host component
        set mids [dict create]
        if {$hOrder == 2} {
            add_mids mids [dict keys $R]
            set keep {}; foreach row $Hsurf {if {![dict exists $R [lindex $row 0]]} {lappend keep [lindex $row 0]}}
            add_mids mids $keep
            add_mids mids [lmap_ids $Grows]
        }
        set targetComp [expr {$hDim == 2 ? $hostComp : [temp_comp]}]
        if {$hDim == 3} {lappend comps $targetComp}
        *currentcollector components $targetComp
        set dup {}
        set gIds [lmap_ids $Grows]
        set byCfg [dict create]
        upvar #0 ::ElemImprint::GD_$hName DH
        load_xyz [node_set $gIds]
        foreach nl [elem_nodes $gIds] c [configs $gIds] {
            lassign $nl a b cc
            set c3 [vscale [vadd [vadd $P($a) $P($b)] $P($cc)] [expr {1.0/3}]]
            set hit [locate $hName $c3 $r]
            set nH [expr {[llength $hit] ? [lindex $DH([lindex $hit 0]) 3] : $N}]
            if {[dot [cross [vsub $P($b) $P($a)] [vsub $P($cc) $P($a)]] $nH] < 0} {
                set nl [expr {$c == 106 ? [list $a $cc $b [lindex $nl 5] [lindex $nl 4] [lindex $nl 3]] : [list $a $cc $b]}]
            }
            dict lappend byCfg $c $nl
        }
        dict for {c rows} $byCfg {lappend dup {*}[create_rows $rows $c]}
        # the ring elements
        lassign [ring_mesh $bands "" $hOrder mids $N] band ringInfo
        # kept host rows split at inserted nodes
        set spRows {}
        foreach t $splitRows {
            lassign $t a b c
            if {$hOrder == 2} {lappend spRows [list $a $b $c [mid_node mids $a $b] [mid_node mids $b $c] [mid_node mids $c $a]]} else {lappend spRows $t}
        }
        set splitNew [create_rows $spRows [expr {$hOrder == 2 ? 106 : 103}]]
        set removedIds [concat [dict keys $R] $splitOld]
        set oldNodes [concat [node_set $removedIds] $::ElemImprint::ringNodes [dict keys $vmap]]
        delete_elems $removedIds
        set minEdge [dict get $ringInfo minInner]
        set created [concat $dup $band $splitNew]
        set crack 0
        if {$hDim == 2} {
            set result [lsort -integer [concat [existing [dict get $H ids]] $created]]
            # open edges may only be the host's own free edges or the guest outline
            set okE [dict create]
            dict for {k one} $BH {dict set okE $k 1}
            foreach k $gB {dict set okE $k 1}
            dict for {k one} $freePieces {dict set okE $k 1}
            foreach k [open_edges $result] {if {![dict exists $okE $k]} {incr crack}}
        } else {
            set keepExt {}; foreach row $Hsurf {if {![dict exists $R [lindex $row 0]]} {lappend keepExt [lindex $row 0]}}
            set shell [existing [concat $keepExt $internal $created]]
            set open [llength [open_edges $shell]]
            if {$open} {error "RETRY: the new face of the host has $open open edges."}
            *createmark elems 1 {*}$shell; *movemark elems 1 $targetComp; *clearmark elems 1
            delete_elems $patch
            *currentcollector components $hostComp
            *createstringarray 2 $tetString $tetPars
            *createmark comps 2 $targetComp
            hm_entityrecorder elems on
            set rc [catch {*tetmesh comps 2 0 elems 0 -1 1 2} m]
            hm_entityrecorder elems off
            *clearmark comps 2
            if {$rc} {error "RETRY: rebuilding the host tets failed ([llength $shell] faces, patch [llength $patch] tets)."}
            set newTets [existing [hm_entityrecorder elems ids]]
            set want [expr {$hOrder == 2 ? 210 : 204}]
            if {![llength $newTets] || [lsort -unique [configs $newTets]] ne [list $want]} {error "RETRY: rebuilt tets are not [lmap_names $want]."}
            set tn [node_set $newTets]
            foreach n [node_set $shell] {if {[lsearch -sorted -integer $tn $n] < 0} {error "RETRY: rebuilt tets do not use all face nodes."}}
            set all [lsort -integer [concat [existing [dict get $H ids]] $newTets]]
            set fk [dict create]
            foreach nl [elem_nodes $all] {lassign $nl a b c d; foreach f [list [list $a $b $c] [list $a $b $d] [list $a $c $d] [list $b $c $d]] {dict incr fk [lsort -integer $f]}}
            set ek [dict create]
            dict for {f n} $fk {if {$n > 2} {error "RETRY: rebuilt tets overlap."}; if {$n == 1} {lassign $f a b c; foreach e2 [list "$a $b" "$a $c" "$b $c"] {dict incr ek $e2}}}
            dict for {e2 n} $ek {if {$n != 2} {error "RETRY: the rebuilt tets leave open edges."}}
            delete_elems $shell
            set result $all
        }
        delete_elems $temps
        foreach c [concat $comps ^faces] {delete_comp_if_empty $c}
        cleanup_faces
        set orphans [unused_nodes $oldNodes]
        if {[llength $orphans]} {*createmark nodes 1 {*}$orphans; *nodemarkcleartempmark 1; *clearmark nodes 1}
        clear_temp_nodes
        if {$curComp ne "" && [hm_entityinfo exist comps $curComp -byname]} {*currentcollector components $curComp}
    } msg]
    # keep the trace of an unexpected failure for the Tcl console
    if {$code} {set ::ElemImprint::lastErrorInfo $::errorInfo}
    if {$outer} {
        if {$code} {error $msg}
    } else {
        history_end $label
    }
    if {$code} {
        set now [list [count elems] [count nodes]]
        if {$now ne $before || $::ElemImprint::wrote} {
            *undohistorystate 1
            set back [list [count elems] [count nodes]]
            if {$back ne $before} {error "$msg Rolling back failed ($before -> $back): check the model."}
        }
        error $msg
    }
    dict create result $result created [llength $created] dup [llength $dup] band [llength $band] removed [llength $removedIds] \
        swapped $swapped hostDim $hDim minEdge $minEdge ringAngle $ringAngle ring $ringInfo loops [llength $fchains] layers [dict get $opts layers] crack $crack         guest [lmap_ids_existing $gIds] warning ""
}
proc ::ElemImprint::lmap_ids_existing {ids} {existing $ids}
proc ::ElemImprint::lmap_ids {rows} {set o {}; foreach r $rows {lappend o [lindex $r 0]}; return $o}
# Guest contact rows again after its temporary faces were rebuilt: the new faces with the same corners.
proc ::ElemImprint::regrid_guest {faces oldRows} {
    set want [dict create]
    foreach r $oldRows {dict set want [lsort -integer [lrange $r 1 3]] 1}
    set out {}
    foreach r [tri_rows $faces] {if {[dict exists $want [lsort -integer [lrange $r 1 3]]]} {lappend out $r}}
    return $out
}

# target, source: element ids (tria3/tria6, mixed allowed, or tet4/tet10). opts: layers (extra host
# rows replaced around the copy), maxDist ("" = automatic), angle (feature angle), minSize ("" = no
# check), solidLayers (tets rebuilt around the contact). When one face lies inside the other the
# result shares nodes (enclose_once); while a ring edge is shorter than minSize one more row is
# replaced (each attempt its own Undo step, failed ones undone); a tet host that cannot be rebuilt
# takes a larger patch. Faces that only partly overlap go through imprint_twoway (nodes shared).
proc ::ElemImprint::imprint {target source {opts {}}} {
    set opts [dict merge {layers 1 maxDist "" angle 30 minSize "" solidLayers 2} $opts]
    check_options $opts
    set ::ElemImprint::lastAttempts {}
    set L [dict get $opts layers]
    set solid [dict get $opts solidLayers]; set solid0 $solid
    set L0 $L
    set minSize [dict get $opts minSize]
    set attempts {}
    set extra {}; set grows 0; set trim 0
    set bestAng ""; set bestExtra {}; set bestL $L; set fallback 0
    set ::ElemImprint::trimmed 0
    while 1 {
        set before [list [count elems] [count nodes]]
        set tA [clock milliseconds]
        if {[catch {enclose_once $target $source [dict merge $opts [list layers $L solidLayers $solid extra $extra growLeft [expr {3-$grows}] trim $trim]]} r]} {
            # a gap too narrow next to some host rows: remove them too and make the ring again
            if {[string match "GROW:*" $r]} {
                lassign [string trim [string range $r 5 end]] ang add
                lappend attempts [list layers $L solid $solid grow [llength $add] angle [format %.1f $ang] ms [expr {[clock milliseconds]-$tA}]]
                set ::ElemImprint::lastAttempts $attempts
                # the best fill so far (largest smallest angle) and the rows removed for it
                if {$bestAng eq "" || $ang > $bestAng} {set bestAng $ang; set bestExtra $extra; set bestL $L}
                lappend extra {*}$add; incr grows
                continue
            }
            if {$r eq "PARTIAL"} {
                if {$trim} {error "The two faces do not overlap enough to imprint: no source element lies wholly on the target. Nothing changed."}
                if {![catch {imprint_twoway $target $source [dict merge $opts [list layers $L solidLayers $solid]]} p]} {
                    dict set p attempts $attempts
                    return $p
                }
                # copying the overlap both ways failed: copy only the elements lying wholly on the other
                # face instead (the overhang stays as it is)
                lappend attempts [list two-way failed $p ms [expr {[clock milliseconds]-$tA}]]
                set ::ElemImprint::lastAttempts $attempts
                set trim 1
                continue
            }
            if {[string match "RETRY:*" $r]} {
                lappend attempts [list layers $L solid $solid failed [string trim [string range $r 6 end]]]
                set ::ElemImprint::lastAttempts $attempts
                if {$solid < 1000} {set solid [next_solid $solid $solid0]; continue}
                set r [string trim [string range $r 6 end]]
            }
            # the ring could not be filled: one more row of host elements and try again (twice at
            # most, so the change stays close to the source)
            if {[string match "LAYER:*" $r]} {
                lappend attempts [list layers $L solid $solid failed [string trim [string range $r 6 end]] ms [expr {[clock milliseconds]-$tA}]]
                set ::ElemImprint::lastAttempts $attempts
                if {$L < $L0+2} {incr L; continue}
                set r "Could not fill the ring between the copy and the host face with [expr {$L-$L0+1}] different widths ([string trim [string range $r 6 end]]) Nothing changed."
            }
            error $r
        }
        lappend attempts [list layers $L solid $solid crack [dict get $r crack] minEdge [dict get $r minEdge] removed [dict get $r removed] ms [expr {[clock milliseconds]-$tA}]]
        set ::ElemImprint::lastAttempts $attempts
        # Min size is met by removing single host rows next to short edges (inside the attempt), not
        # by whole layers; what is left short is only reported
        set small [expr {$minSize ne "" && [dict get $r minEdge] ne "" && [dict get $r minEdge] < $minSize*(1-1e-9)}]
        # removing rows made the shapes worse than an earlier fill: go back to that one
        if {![dict get $r crack] && !$fallback && $bestAng ne "" && [dict get $r ringAngle] < $bestAng-1e-6} {
            *undohistorystate 1
            set back [list [count elems] [count nodes]]
            if {$back ne $before} {error "Undoing an attempt failed ($before -> $back): check the model."}
            set extra $bestExtra; set L $bestL; set grows 3; set fallback 1
            continue
        }
        if {![dict get $r crack]} {
            if {$trim} {dict set r warning [string trim "[dict get $r warning] $::ElemImprint::trimmed source elements off the target face (over a hole or edge) left as they were."]}
            if {$small} {dict set r warning [string trim "[dict get $r warning] Smallest ring edge [format %.4g [dict get $r minEdge]] is below Min size."]}
            dict set r attempts $attempts
            dict set r shared 1
            return $r
        }
        *undohistorystate 1
        set back [list [count elems] [count nodes]]
        if {$back ne $before} {error "Undoing an attempt failed ($before -> $back): check the model."}
        error "The new mesh would leave [dict get $r crack] open edges inside the host face. Nothing changed."
    }
}


# Faces that only partly overlap: the overlap M (the source cut along the target outline) is built as
# temporary shells, copied into the target, then the same M (same nodes) into the source, and the
# temporary shells are removed. Both faces then share the nodes of M. One Undo step.
proc ::ElemImprint::imprint_twoway {target source opts} {
    variable P; variable outer
    array unset P
    set target [existing $target]; set source [existing $source]
    lassign [kind $target target] tDim tOrder tCfg
    lassign [kind $source source] sDim sOrder sCfg
    if {$tDim == 3 && $sDim == 3 && $tOrder != $sOrder} {error "The two solids have different element orders: use the same order on both."}
    set order [expr {$tDim == 3 ? $tOrder : ($sDim == 3 ? $sOrder : max($tOrder,$sOrder))}]
    set cosA [expr {cos([dict get $opts angle]*acos(-1)/180.0)}]
    set before [list [count elems] [count nodes]]
    set curComp [hm_info currentcomponent]
    set label "Element imprint"
    history_begin $label
    set ::ElemImprint::wrote 0
    set outer 1
    set temps {}; set tmp ""
    set code [catch {
        # contact surfaces (as in enclose_once)
        if {$tDim == 2} {set Tall [tri_rows $target]} else {set f [find_faces $target]; lappend temps {*}$f; set Tall [tri_rows $f]}
        if {$sDim == 2} {set Sall [tri_rows $source]} else {set f [find_faces $source]; lappend temps {*}$f; set Sall [tri_rows $f]}
        set mT [grid_build T $Tall]; set mS [grid_build S $Sall]
        set r [dict get $opts maxDist]
        if {$r eq ""} {set r [expr {$mT+$mS}]}
        set rc3 [expr {[dict get $opts maxDist] ne "" ? [dict get $opts maxDist] : 0.5*min($mT,$mS)}]
        grid_index T [expr {max($mT,$r/2.0)}]
        set Srows $Sall
        if {$sDim == 3} {
            set Srows [rows_on $Sall T $rc3 $cosA]
            if {![llength $Srows]} {error "No face of the source tets lies on the target within [format %.4g $rc3] and Feature angle."}
            grid_build S $Srows
        }
        grid_index S [expr {max($mS,$r/2.0)}]
        set Trows $Tall
        if {$tDim == 3} {
            set seeds [rows_on $Tall S $rc3 $cosA]
            if {![llength $seeds]} {error "No face of the target tets lies under the source within [format %.4g $rc3]."}
            set Trows [flood $Tall $seeds $cosA]
            grid_build T $Trows; grid_index T [expr {max($mT,$r/2.0)}]
        }
        # the overlap: the source contact face cut along the target outline
        lassign [clip $Srows [boundary_edges $Trows] $r] tris pts stats
        if {![llength $tris]} {error "The source does not overlap the target."}
        delete_elems $temps; set temps {}
        cleanup_faces
        set tmp [temp_comp]
        *currentcollector components $tmp
        set nid [dict create]
        dict for {k p} $pts {
            *createnode {*}$p 0 0 0
            dict set nid $k [hm_latestentityid nodes]
            lappend ::ElemImprint::madeNodes [hm_latestentityid nodes]
        }
        set rows {}
        foreach t $tris {set nl {}; foreach k $t {lappend nl [dict get $nid $k]}; lappend rows $nl}
        set M [create_rows $rows 103]
        if {$order == 2} {*createmark elems 1 {*}$M; *orderchangetosecond 1 0 0; *clearmark elems 1; set M [existing $M]}
        # the overlap goes into the target, then the same shells into the source
        # the copy may lie up to the cut tolerance off either face
        set sd [expr {1.5*$::ElemImprint::snapFrac*min($mT,$mS)}]
        set r1 [enclose_once $target $M [dict merge $opts [list force guest snapD $sd mergeTol [expr {1e-6*min($mT,$mS)}]]]]
        set r2 [enclose_once $source $M [dict merge $opts [list force guest snapD $sd mergeTol $sd]]]
        set mNodes [node_set $M]
        delete_elems $M
        delete_comp_if_empty $tmp
        cleanup_faces
        set orphans [unused_nodes [concat $mNodes [dict values $nid]]]
        if {[llength $orphans]} {*createmark nodes 1 {*}$orphans; *nodemarkcleartempmark 1; *clearmark nodes 1}
        clear_temp_nodes
        if {$curComp ne "" && [hm_entityinfo exist comps $curComp -byname]} {*currentcollector components $curComp}
    } msg]
    set outer 0
    if {$code} {set ::ElemImprint::lastErrorInfo $::errorInfo}
    history_end $label
    if {$code} {
        if {[list [count elems] [count nodes]] ne $before || $::ElemImprint::wrote} {
            *undohistorystate 1
            set back [list [count elems] [count nodes]]
            if {$back ne $before} {error "$msg Rolling back failed ($before -> $back): check the model."}
        }
        if {[string match "RETRY:*" $msg] || [string match "LAYER:*" $msg]} {set msg [string trim [string range $msg 6 end]]}
        error "$msg Nothing changed."
    }
    dict create result [dict get $r1 result] sourceResult [dict get $r2 result] created [expr {[dict get $r1 created]+[dict get $r2 created]}] \
        dup [llength $M] band [expr {[dict get $r1 band]+[dict get $r2 band]}] removed [expr {[dict get $r1 removed]+[dict get $r2 removed]}] \
        swapped 0 twoWay 1 hostDim [dict get $r1 hostDim] minEdge [dict get $r1 minEdge] crack [expr {[dict get $r1 crack]+[dict get $r2 crack]}] \
        clip $stats warning "" shared 1
}


# Chains of edges ("a b" keys): {{closed nodes} ...} and the nodes used by more than two edges.
proc ::ElemImprint::edge_chains {edges} {
    set adj [dict create]
    foreach k $edges {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}
    set pinch {}
    dict for {n v} $adj {if {[llength $v] > 2} {lappend pinch $n}}
    if {[llength $pinch]} {return [list {} $pinch]}
    set chains {}; set seen [dict create]
    # open chains first (start at an end), then loops
    foreach pass {open closed} {
        dict for {n v} $adj {
            if {[dict exists $seen $n]} {continue}
            if {$pass eq "open" && [llength $v] != 1} {continue}
            set nodes [list $n]; dict set seen $n 1
            set prev ""; set cur $n
            while 1 {
                set nx {}
                foreach m [dict get $adj $cur] {if {$m != $prev && ![dict exists $seen $m]} {lappend nx $m}}
                if {![llength $nx]} {break}
                set prev $cur; set cur [lindex $nx 0]
                lappend nodes $cur; dict set seen $cur 1
            }
            lappend chains [list [expr {$pass eq "closed"}] $nodes]
        }
    }
    list $chains {}
}
# 1 when p lies within snapD of one of the edges (dict of "a b" keys), measured along normal n.
proc ::ElemImprint::near_edges {p edges snapD n} {
    variable P
    dict for {k one} $edges {
        lassign $k a b
        if {[lindex [seg_param $p $P($a) $P($b) $n] 1] <= $snapD} {return 1}
    }
    return 0
}
# Triangles of a simple polygon (node ids) seen along n, oriented along n.
proc ::ElemImprint::fill_polygon {nodes n} {
    variable P
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set f [list $P([lindex $nodes 0]) $e1 $e2]
    set pts {}; foreach k $nodes {lappend pts [to2d $f $P($k)]}
    if {[catch {ear_clip $nodes $pts} tris]} {error "LAYER: the ring between the copy and the host face cannot be meshed ($tris)."}
    set out {}
    foreach t $tris {
        lassign $t a b c
        if {$a == $b || $b == $c || $a == $c} {continue}
        set nn [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]
        if {[norm $nn] <= 1e-12} {continue}
        if {[dot $nn $n] < 0} {set t [list $a $c $b]}
        lappend out $t
    }
    return $out
}


# Where the fill outline touches itself at a node (4 or more edges), its edges are paired by angle
# around n, each host piece with the guest piece next to it, and every pair after the first gets
# its own copy of the node ("node#k"), so that the outline splits into simple loops there.
proc ::ElemImprint::split_touches {edges from n} {
    variable P
    set adj [dict create]
    foreach k $edges {lassign $k a b; dict lappend adj $a $k; dict lappend adj $b $k}
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set rename [dict create]
    dict for {v ks} $adj {
        if {[llength $ks] < 4 || [llength $ks] % 2} {continue}
        set ang {}
        foreach k $ks {
            lassign $k a b
            set o [expr {$a == $v ? $b : $a}]
            set d [vsub $P($o) $P($v)]
            lappend ang [list [expr {atan2([dot $d $e2],[dot $d $e1])}] $k]
        }
        set ang [lsort -real -index 0 $ang]
        set m [llength $ang]
        # start so that each pair (i, i+1) mixes a host and a guest piece
        set start 0
        if {[dict get $from [lindex $ang 0 1]] eq [dict get $from [lindex $ang 1 1]]} {set start 1}
        for {set i 0} {$i < $m} {incr i 2} {
            if {$i == 0} {continue}
            foreach j [list [expr {($start+$i)%$m}] [expr {($start+$i+1)%$m}]] {dict lappend rename [lindex $ang $j 1] [list $v "$v#[expr {$i/2}]"]}
        }
    }
    set out {}
    foreach k $edges {
        lassign $k a b
        if {[dict exists $rename $k]} {
            foreach r [dict get $rename $k] {lassign $r old new; if {$a == $old} {set a $new}; if {$b == $old} {set b $new}}
        }
        lappend out [list $a $b]
    }
    return $out
}


# Triangles between closed loops A (copy outline) and B (hole edge), along n. As in the Ruled Mesh
# tool: rows of nodes between the two outlines (spacing about "size", "" = mean outline edge),
# placed by arc length and put back on the old host face (grid "surf"), ruled row by row. A layout
# that folds or does not cover the ring exactly falls back to one ruled row, then to a keyhole cut.
# New nodes are listed in ::ElemImprint::ringNodes (unused ones are deleted by the caller).
proc ::ElemImprint::ring_fill {A B n {size ""} {surf ""}} {
    variable P
    if {[loop_area $A $n]*[loop_area $B $n] < 0} {set B [lreverse $B]}
    set best 0; set bd 1e300
    for {set j 0} {$j < [llength $B]} {incr j} {set d [norm [vsub $P([lindex $B $j]) $P([lindex $A 0])]]; if {$d < $bd} {set bd $d; set best $j}}
    set B [concat [lrange $B $best end] [lrange $B 0 [expr {$best-1}]]]
    set want [expr {abs(abs([loop_area $B $n])-abs([loop_area $A $n]))}]
    if {$size eq ""} {set size [expr {0.5*([loop_mean_edge $A]+[loop_mean_edge $B])}]}
    set k [expr {max(1,int(round([loop_gap $A $B]/max($size,1e-12))))}]
    foreach rows [lsort -unique -integer -decreasing [list $k 1]] {
        set loops [list $A]
        for {set i 1} {$i < $rows} {incr i} {
            set tt [expr {double($i)/$rows}]
            set c [expr {max(3,int(round([llength $A]+([llength $B]-[llength $A])*$tt)))}]
            set loop {}
            for {set m 0} {$m < $c} {incr m} {
                set s [expr {double($m)/$c}]
                set q [vadd [vscale [loop_point $A $s] [expr {1.0-$tt}]] [vscale [loop_point $B $s] $tt]]
                if {$surf ne ""} {set q [onto_grid $surf $q]}
                *createnode {*}$q 0 0 0
                set id [hm_latestentityid nodes]
                lappend ::ElemImprint::madeNodes $id
                set P($id) $q
                lappend ::ElemImprint::ringNodes $id
                lappend loop $id
            }
            lappend loops $loop
        }
        lappend loops $B
        set tris {}
        for {set i 0} {$i < [llength $loops]-1} {incr i} {lappend tris {*}[ruled [lindex $loops $i] [lindex $loops [expr {$i+1}]] $n 0]}
        set got 0.0; set fold 0
        foreach tr $tris {
            lassign $tr a b c
            set d [dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n]
            if {$d <= 0} {incr fold}
            set got [expr {$got+abs($d)}]
        }
        if {!$fold && abs($got-$want) <= 1e-3*max($want,1e-12)} {return $tris}
    }
    # keyhole: B counter-clockwise, A clockwise, joined at the closest pair
    if {[loop_area $B $n] < 0} {set B [lreverse $B]}
    if {[loop_area $A $n] > 0} {set A [lreverse $A]}
    set bi 0; set bj 0; set bd 1e300
    for {set i 0} {$i < [llength $A]} {incr i} {
        for {set j 0} {$j < [llength $B]} {incr j} {
            set d [norm [vsub $P([lindex $A $i]) $P([lindex $B $j])]]
            if {$d < $bd} {set bd $d; set bi $i; set bj $j}
        }
    }
    set Br [concat [lrange $B $bj end] [lrange $B 0 $bj]]
    set Ar [concat [lrange $A $bi end] [lrange $A 0 $bi]]
    fill_polygon [concat $Br $Ar] $n
}
proc ::ElemImprint::loop_mean_edge {L} {
    variable P
    set s 0.0; set n [llength $L]
    for {set i 0} {$i < $n} {incr i} {set s [expr {$s+[norm [vsub $P([lindex $L [expr {($i+1)%$n}]]) $P([lindex $L $i])]]}]}
    expr {$s/max(1,$n)}
}
# Point at fraction s (0..1) of the length of closed loop L, from its first node.
proc ::ElemImprint::loop_point {L s} {
    variable P
    set n [llength $L]
    set lens {}; set tot 0.0
    for {set i 0} {$i < $n} {incr i} {
        set l [norm [vsub $P([lindex $L [expr {($i+1)%$n}]]) $P([lindex $L $i])]]
        lappend lens $l; set tot [expr {$tot+$l}]
    }
    set goal [expr {$s*$tot}]
    for {set i 0} {$i < $n} {incr i} {
        set l [lindex $lens $i]
        if {$goal <= $l || $i == $n-1} {
            set f [expr {$l > 0 ? min(1.0,$goal/$l) : 0.0}]
            set a $P([lindex $L $i]); set b $P([lindex $L [expr {($i+1)%$n}]])
            return [vadd $a [vscale [vsub $b $a] $f]]
        }
        set goal [expr {$goal-$l}]
    }
}
# p moved onto the triangle of grid "name" it projects into (unchanged when none).
proc ::ElemImprint::onto_grid {name p} {
    upvar #0 ::ElemImprint::GD_$name D
    set hit [locate $name $p $D(mean)]
    if {![llength $hit]} {return $p}
    vsub $p [vscale [lindex $D([lindex $hit 0]) 3] [lindex $hit 1]]
}


# 1 when loop a lies inside loop b, seen along n (first node of a tested).
proc ::ElemImprint::loop_inside {a b n} {
    variable P
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set f [list $P([lindex $b 0]) $e1 $e2]
    set poly {}; foreach k $b {lappend poly [to2d $f $P($k)]}
    set in 0
    foreach k $a {incr in [point_in_poly [to2d $f $P($k)] $poly]}
    expr {2*$in > [llength $a]}
}
# Triangles of an outline with holes: each hole joined to the outline at its closest node pair,
# then ear clipping. Outline counter-clockwise and holes clockwise along n.
proc ::ElemImprint::fill_with_holes {outer holes n} {
    variable P
    if {![llength $holes]} {return [fill_polygon $outer $n]}
    if {[llength $holes] == 1} {return [ring_fill [lindex $holes 0] $outer $n]}
    if {[loop_area $outer $n] < 0} {set outer [lreverse $outer]}
    foreach h $holes {
        if {[loop_area $h $n] > 0} {set h [lreverse $h]}
        set bi 0; set bj 0; set bd 1e300
        for {set i 0} {$i < [llength $h]} {incr i} {
            for {set j 0} {$j < [llength $outer]} {incr j} {
                set d [norm [vsub $P([lindex $h $i]) $P([lindex $outer $j])]]
                if {$d < $bd} {set bd $d; set bi $i; set bj $j}
            }
        }
        set outer [concat [lrange $outer 0 $bj] [lrange $h $bi end] [lrange $h 0 $bi] [lrange $outer $bj end]]
    }
    fill_polygon $outer $n
}


# Ring elements from triangles (node triples): tria3, or tria6 with the existing midside nodes on
# shared edges. (A native *defaultremeshelems of the ring crashed HyperMesh 2022.3 with a
# segmentation error, so the ring is laid out in Tcl by ring_fill.) Returns {ids info}.
proc ::ElemImprint::ring_mesh {tris size order midsVar n} {
    variable P
    upvar 1 $midsVar mids
    if {![llength $tris]} {return [list {} [dict create count 0 minInner ""]]}
    set cnt [dict create]
    foreach tr $tris {lassign $tr a b c; foreach {x y} [list $a $b $b $c $c $a] {dict incr cnt [expr {$x < $y ? "$x $y" : "$y $x"}]}}
    set full {}
    foreach tr $tris {
        lassign $tr a b c
        if {$order == 2} {lappend full [list $a $b $c [mid_node mids $a $b] [mid_node mids $b $c] [mid_node mids $c $a]]} else {lappend full $tr}
    }
    set ids [create_rows $full [expr {$order == 2 ? 106 : 103}]]
    # shortest edge inside the ring (outline edges are fixed by the two faces)
    set minInner ""
    foreach tr $tris {
        lassign $tr a b c
        foreach {x y} [list $a $b $b $c $c $a] {
            if {[dict get $cnt [expr {$x < $y ? "$x $y" : "$y $x"}]] == 1} {continue}
            set l [norm [vsub $P($y) $P($x)]]
            if {$minInner eq "" || $l < $minInner} {set minInner $l}
        }
    }
    list $ids [dict create count [llength $tris] minInner $minInner]
}


# Smallest corner angle (as its cosine-free measure: sine-based, 0..1) of a 2D triangle.
proc ::ElemImprint::tri_quality2 {a b c} {
    set m 1e300
    foreach {o p q} [list $a $b $c $b $c $a $c $a $b] {
        set ux [expr {[lindex $p 0]-[lindex $o 0]}]; set uy [expr {[lindex $p 1]-[lindex $o 1]}]
        set vx [expr {[lindex $q 0]-[lindex $o 0]}]; set vy [expr {[lindex $q 1]-[lindex $o 1]}]
        set ang [expr {atan2(abs($ux*$vy-$uy*$vx),$ux*$vx+$uy*$vy)}]
        if {$ang < $m} {set m $ang}
    }
    return $m
}
# Smallest corner angle (radians) of a 3D triangle of node ids.
proc ::ElemImprint::tri_min_angle {a b c} {
    variable P
    set m 1e300
    foreach {o p q} [list $a $b $c $b $c $a $c $a $b] {
        set u [vsub $P($p) $P($o)]; set v [vsub $P($q) $P($o)]
        set ang [expr {atan2([norm [cross $u $v]],[dot $u $v])}]
        if {$ang < $m} {set m $ang}
    }
    return $m
}
proc ::ElemImprint::loop_sum {L} {
    variable P
    set s {0.0 0.0 0.0}
    foreach n $L {set s [vadd $s $P($n)]}
    list $s
}
# Triangles closing loop L: a fan from a new node at its centre (on the old face, grid "surf") when
# no triangle of the fan folds, else ear clipping.
proc ::ElemImprint::fill_disk {L n surf} {
    variable P
    set c [vscale [lindex [loop_sum $L] 0] [expr {1.0/[llength $L]}]]
    set c [onto_grid $surf $c]
    set m [llength $L]
    set sign [expr {[loop_area $L $n] > 0 ? 1 : -1}]
    set ok 1
    for {set i 0} {$i < $m} {incr i} {
        set a $P([lindex $L $i]); set b $P([lindex $L [expr {($i+1)%$m}]])
        if {$sign*[dot [cross [vsub $a $c] [vsub $b $c]] $n] <= 0} {set ok 0; break}
    }
    if {!$ok} {return [fill_polygon $L $n]}
    *createnode {*}$c 0 0 0
    set id [hm_latestentityid nodes]
    lappend ::ElemImprint::madeNodes $id
    set P($id) $c
    lappend ::ElemImprint::ringNodes $id
    set tris {}
    for {set i 0} {$i < $m} {incr i} {
        set a [lindex $L $i]; set b [lindex $L [expr {($i+1)%$m}]]
        set t [list $id $a $b]
        if {[dot [cross [vsub $P($a) $c] [vsub $P($b) $c]] $n] < 0} {set t [list $id $b $a]}
        lappend tris $t
    }
    return $tris
}
# Lawson edge flips on triangles (node triples, oriented along n): an interior edge shared by two
# triangles is swapped for the other diagonal of their quad when the quad is convex and the
# smallest angle of the pair grows. Outline edges never change.
proc ::ElemImprint::flip_improve {tris n} {
    variable P
    for {set pass 0} {$pass < 20} {incr pass} {
        set byEdge [dict create]
        for {set i 0} {$i < [llength $tris]} {incr i} {
            lassign [lindex $tris $i] a b c
            foreach {x y} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$x < $y ? "$x $y" : "$y $x"}] $i}
        }
        set done [dict create]; set changed 0
        dict for {k ts} $byEdge {
            if {[llength $ts] != 2} {continue}
            lassign $ts i j
            if {[dict exists $done $i] || [dict exists $done $j]} {continue}
            lassign $k x y
            set ti [lindex $tris $i]; set tj [lindex $tris $j]
            set c ""; set d ""
            foreach v $ti {if {$v != $x && $v != $y} {set c $v}}
            foreach v $tj {if {$v != $x && $v != $y} {set d $v}}
            if {$c eq "" || $d eq "" || $c == $d} {continue}
            # the new diagonal must not exist already
            if {[dict exists $byEdge [expr {$c < $d ? "$c $d" : "$d $c"}]]} {continue}
            set before [expr {min([tri_min_angle {*}$ti],[tri_min_angle {*}$tj])}]
            set t1 [list $c $d $x]; set t2 [list $d $c $y]
            set ok 1
            foreach tt [list $t1 $t2] {
                lassign $tt a b e
                if {[dot [cross [vsub $P($b) $P($a)] [vsub $P($e) $P($a)]] $n] <= 0} {
                    set tt [list $a $e $b]
                    lassign $tt a b e
                    if {[dot [cross [vsub $P($b) $P($a)] [vsub $P($e) $P($a)]] $n] <= 0} {set ok 0}
                }
            }
            if {!$ok} {continue}
            # orient both along n and make sure the pair covers the same area (convex quad)
            set n1 [list $c $d $x]; if {[dot [cross [vsub $P($d) $P($c)] [vsub $P($x) $P($c)]] $n] < 0} {set n1 [list $c $x $d]}
            set n2 [list $c $d $y]; if {[dot [cross [vsub $P($d) $P($c)] [vsub $P($y) $P($c)]] $n] < 0} {set n2 [list $c $y $d]}
            set areaOld [expr {[tri_area_n $ti $n]+[tri_area_n $tj $n]}]
            set areaNew [expr {[tri_area_n $n1 $n]+[tri_area_n $n2 $n]}]
            if {abs($areaNew-$areaOld) > 1e-9*max($areaOld,1e-12)} {continue}
            set after [expr {min([tri_min_angle {*}$n1],[tri_min_angle {*}$n2])}]
            if {$after <= $before + 1e-9} {continue}
            lset tris $i $n1; lset tris $j $n2
            dict set done $i 1; dict set done $j 1
            incr changed
        }
        if {!$changed} {break}
    }
    return $tris
}
proc ::ElemImprint::tri_area_n {t n} {
    variable P
    lassign $t a b c
    expr {abs([dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n])}
}


# 1 when an element outside "inside" (dict of element ids) uses both nodes x and y.
proc ::ElemImprint::edge_used_outside {x y inside} {
    set ex [elems_on_nodes [list $x]]
    set ey [lsort -integer [elems_on_nodes [list $y]]]
    foreach e $ex {
        if {[lsearch -sorted -integer $ey $e] >= 0 && ![dict exists $inside $e]} {return 1}
    }
    return 0
}

# ---------------------------------------------------------------- GUI
# The selection stays highlighted the native way while the window is open: target in the selection
# colour (white, mark 2 "high"), source grey (mark 1 "low"). The highlight lives on the marks, so the
# marks are kept; the imprint uses marks 1 and 2 itself, so the highlight is taken off before and put
# back after, as the last step of refresh (the element reads there reuse mark 1). Runtime picture
# check: tests/explore_highlight.tcl, tests/gui_redo.tcl.
proc ::ElemImprint::highlight {} {
    variable shown
    clear_highlight
    foreach {k m mode} {target 2 high source 1 low} {
        set ids [existing $shown($k)]
        if {[llength $ids]} {*createmark elems $m {*}$ids; catch {hm_highlightmark elems $m $mode}}
    }
    catch {hm_redraw}
}
proc ::ElemImprint::clear_highlight {} {
    foreach m {1 2} {catch {hm_highlightmark elems $m norm}; *clearmark elems $m}
    catch {hm_redraw}
}

# The imprint made last by this window is kept (Imprint again undoes it first). Picking a new target
# or source keeps it in the model: the other side then becomes the face as it is now.
proc ::ElemImprint::keep_last {} {
    variable last; variable sel; variable shown
    if {![llength $last]} {return}
    foreach k {target source} {set sel($k) [existing $shown($k)]}
    set last {}
}

proc ::ElemImprint::pick {what} {
    variable W; variable sel; variable shown; variable status
    if {[winfo exists $W]} {wm withdraw $W}
    clear_highlight
    keep_last
    set rc [catch {
        if {[llength [existing $sel($what)]]} {*createmark elems 1 {*}[existing $sel($what)]}
        catch {*createmarkpanel elems 1 "Imprint $what: tria3/tria6 or tet4/tet10 elements"}
        set ids [hm_getmark elems 1]
        *clearmark elems 1
        variable opt
        if {$opt(byFace) && [llength $ids]} {set ids [by_face $ids [string trim $opt(faceAngle)]]}
        set ids
    } r]
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {$rc} {set status $r} else {
        set sel($what) $r
        set status ""
        if {![llength $r]} {set status "No $what elements selected."} elseif {[catch {kind $r $what} err]} {set status $err}
    }
    foreach k {target source} {set shown($k) $sel($k)}
    refresh
}

# The whole faces of the picked shells: neighbours across shared edges in the same components while
# the normals differ by at most "angle" degrees (either orientation). Tets are kept as picked.
proc ::ElemImprint::by_face {ids angle} {
    variable P
    if {![string is double -strict $angle] || $angle < 0 || $angle > 90} {error "Face angle must be a number from 0 to 90."}
    set shells {}; set other {}
    foreach e $ids c [configs $ids] {if {$c in {103 106}} {lappend shells $e} else {lappend other $e}}
    if {![llength $shells]} {return $ids}
    set all {}
    foreach c [comps_of $shells] {
        *createmark elems 1 "by collector name" $c
        foreach e [hm_getmark elems 1] {lappend all $e}
        *clearmark elems 1
    }
    set rows {}
    foreach e $all nl [elem_nodes $all] c [configs $all] {
        if {$c in {103 106}} {lappend rows [list $e [lindex $nl 0] [lindex $nl 1] [lindex $nl 2]]}
    }
    set nids {}; foreach row $rows {lappend nids {*}[lrange $row 1 3]}
    load_xyz $nids
    set cosA [expr {cos($angle*acos(-1)/180.0)}]
    set byEdge [dict create]; set N [dict create]; set R [dict create]
    foreach row $rows {
        lassign $row e a b c
        dict set N $e [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
        dict set R $e $row
        foreach {p q} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$p < $q ? "$p $q" : "$q $p"}] $e}
    }
    set done [dict create]; set queue {}
    foreach e $shells {if {[dict exists $R $e]} {dict set done $e 1; lappend queue $e}}
    while {[llength $queue]} {
        set e [lindex $queue end]; set queue [lrange $queue 0 end-1]
        lassign [dict get $R $e] x a b c
        foreach {p q} [list $a $b $b $c $c $a] {
            foreach f [dict get $byEdge [expr {$p < $q ? "$p $q" : "$q $p"}]] {
                if {[dict exists $done $f]} {continue}
                if {abs([dot [dict get $N $e] [dict get $N $f]]) >= $cosA} {dict set done $f 1; lappend queue $f}
            }
        }
    }
    concat [dict keys $done] $other
}

proc ::ElemImprint::swap {} {
    variable sel; variable shown; variable status
    lassign [list $sel(target) $sel(source)] a b
    set sel(target) $b; set sel(source) $a
    lassign [list $shown(target) $shown(source)] a b
    set shown(target) $b; set shown(source) $a
    set status ""
    refresh
}

proc ::ElemImprint::gui_options {} {
    variable opt
    dict create layers [string trim $opt(layers)] maxDist [string trim $opt(maxDist)] angle [string trim $opt(angle)] minSize [string trim $opt(minSize)] solidLayers [string trim $opt(solidLayers)]
}

proc ::ElemImprint::undo_actions {} {if {[catch {hm_getundoactions} a]} {return {}}; return $a}

# Undo the imprint this window made last, only while it is still the latest Undo step and the model
# has not changed since; the picked elements must be back afterwards.
proc ::ElemImprint::undo_last {} {
    variable last; variable sel
    if {[undo_actions] ne [dict get $last history] || [list [count elems] [count nodes]] ne [dict get $last after]} {
        error "The model changed after the last imprint (another edit or an Undo), so nothing was redone. Press Reset to start again."
    }
    *undohistorystate 1
    set back [list [count elems] [count nodes]]
    if {$back ne [dict get $last before]} {error "Undoing the last imprint failed ([dict get $last after] -> $back): check the model."}
    foreach k {target source} {
        if {[llength [existing $sel($k)]] != [llength $sel($k)]} {error "Undoing the last imprint did not bring back the $k elements: check the model."}
    }
    set last {}
}

proc ::ElemImprint::do_imprint {} {
    variable sel; variable shown; variable last; variable status
    set status "Imprinting..."
    update idletasks
    clear_highlight
    set redo [llength $last]
    if {$redo && [catch {undo_last} r]} {
        set status $r
        refresh
        return
    }
    set before [list [count elems] [count nodes]]
    if {[catch {imprint $sel(target) $sel(source) [gui_options]} r]} {
        if {$redo} {set r "The last imprint was undone. With these options: $r"}
        set status $r
        foreach k {target source} {set shown($k) $sel($k)}
        refresh
        return
    }
    set last [dict create before $before after [list [count elems] [count nodes]] history [undo_actions]]
    if {[dict exists $r twoWay]} {
        set shown(target) [dict get $r result]; set shown(source) [dict get $r sourceResult]
    } elseif {[dict get $r shared] && [dict get $r swapped]} {
        set shown(target) [existing $sel(target)]; set shown(source) [dict get $r result]
    } elseif {[dict get $r shared]} {
        set shown(target) [dict get $r result]; set shown(source) [existing $sel(source)]
    } else {
        set shown(target) [existing $sel(target)]; set shown(source) [existing $sel(source)]
    }
    if {[dict exists $r twoWay]} {
        set text "Shared nodes: the overlap ([dict get $r dup] elements) was copied into the target and into the source, [dict get $r band] ring elements, [dict get $r removed] elements replaced."
    } elseif {[dict get $r shared]} {
        set host [expr {[dict get $r swapped] ? "source" : "target"}]
        set text "Shared nodes: [dict get $r dup] elements copied into the $host, [dict get $r band] ring elements, [dict get $r removed] replaced."
        if {[dict get $r swapped]} {append text " The target lies inside the source, so the source face took the copy."}
        if {[dict get $r hostDim] == 3} {append text " Tets rebuilt around the contact."}
    } else {
        set text "Imprinted [dict get $r copy] source triangles ([dict get [dict get $r clip] cut] cut at the target edge)."
    }
    if {[dict get $r warning] ne ""} {append text " [dict get $r warning]"}
    if {$redo} {set text "Redone with the new options. $text"}
    set status $text
    refresh
}

proc ::ElemImprint::reset {} {
    variable sel; variable shown; variable last; variable status
    clear_highlight
    foreach k {target source} {set sel($k) {}; set shown($k) {}}
    set last {}
    set status ""
    refresh
}

proc ::ElemImprint::close {} {
    variable W
    reset
    destroy $W
}

proc ::ElemImprint::describe {ids} {
    variable names
    set ids [existing $ids]
    if {![llength $ids]} {return "Nothing selected"}
    set cs [lsort -unique [configs $ids]]
    set types {}
    foreach c $cs {lappend types [expr {[dict exists $names $c] ? [dict get $names $c] : "config $c"}]}
    set comps [comps_of $ids]
    set t "[llength $ids] [join $types /]"
    if {[llength $comps] == 1} {append t " in [lindex $comps 0]"} else {append t " in [llength $comps] comps"}
    return $t
}

proc ::ElemImprint::face_state {} {
    variable W; variable opt
    if {[winfo exists $W.body.sel.face]} {$W.body.sel.face configure -state [expr {$opt(byFace) ? "normal" : "disabled"}]}
}

proc ::ElemImprint::refresh {} {
    variable W; variable sel; variable shown; variable last; variable opt
    if {![winfo exists $W]} {return}
    foreach k {target source} {set opt(info,$k) [describe $shown($k)]}
    set ok [expr {[llength $last] || ([llength [existing $sel(target)]] && [llength [existing $sel(source)]])}]
    $W.foot.run configure -state [expr {$ok ? "normal" : "disabled"}] -text [expr {[llength $last] ? "Re-imprint" : "Imprint"}]
    if {[winfo exists $W.body.sel.swap]} {$W.body.sel.swap configure -state [expr {[llength $sel(target)] || [llength $sel(source)] ? "normal" : "disabled"}]}
    face_state
    # last: the reads above reuse mark 1
    highlight
}

proc ::ElemImprint::show {} {
    variable W; variable status
    if {[winfo exists $W]} {destroy $W}
    reset
    toplevel $W
    wm withdraw $W
    wm title $W "Element Imprint"
    wm resizable $W 0 0
    frame $W.body -padx 12 -pady 10
    pack $W.body -fill both -expand 1

    set s [labelframe $W.body.sel -text "Elements" -padx 8 -pady 6]
    set r 0
    foreach {k text} {target "Target..." source "Source..."} {
        button $s.$k -text $text -width 10 -command [list ::ElemImprint::pick $k]
        label $s.i_$k -textvariable ::ElemImprint::opt(info,$k) -anchor w -width 30
        grid $s.$k -row $r -column 0 -sticky ew -pady 2
        grid $s.i_$k -row $r -column 1 -columnspan 3 -sticky w -padx {8 0}
        incr r
    }
    checkbutton $s.byface -text "By face" -variable ::ElemImprint::opt(byFace) -command ::ElemImprint::face_state -anchor w
    label $s.l_face -text "Face angle" -anchor e
    entry $s.face -width 6 -justify right -textvariable ::ElemImprint::opt(faceAngle)
    button $s.swap -text "Swap" -width 8 -command ::ElemImprint::swap
    grid $s.byface -row $r -column 0 -sticky w -pady {4 0}
    grid $s.l_face -row $r -column 1 -sticky e -padx {8 0} -pady {4 0}
    grid $s.face -row $r -column 2 -sticky w -padx {6 0} -pady {4 0}
    grid $s.swap -row $r -column 3 -sticky e -padx {12 0} -pady {4 0}
    grid columnconfigure $s 1 -weight 1
    grid $s -row 0 -column 0 -sticky ew

    set f [labelframe $W.body.opt -text "Options" -padx 8 -pady 6]
    label $f.l_layers -text "Remesh layers" -anchor w
    spinbox $f.layers -from 0 -to 20 -width 6 -justify right -textvariable ::ElemImprint::opt(layers)
    label $f.l_max -text "Max distance" -anchor w
    entry $f.max -width 8 -justify right -textvariable ::ElemImprint::opt(maxDist)
    label $f.l_angle -text "Feature angle" -anchor w
    entry $f.angle -width 8 -justify right -textvariable ::ElemImprint::opt(angle)
    grid $f.l_layers -row 0 -column 0 -sticky w -pady 2
    grid $f.layers -row 0 -column 1 -sticky ew -padx {6 18} -pady 2
    grid $f.l_max -row 0 -column 2 -sticky w -pady 2
    grid $f.max -row 0 -column 3 -sticky ew -padx {6 0} -pady 2
    label $f.l_min -text "Min size" -anchor w
    entry $f.min -width 6 -justify right -textvariable ::ElemImprint::opt(minSize)
    grid $f.l_min -row 1 -column 0 -sticky w -pady 2
    grid $f.min -row 1 -column 1 -sticky ew -padx {6 18} -pady 2
    grid $f.l_angle -row 1 -column 2 -sticky w -pady 2
    grid $f.angle -row 1 -column 3 -sticky ew -padx {6 0} -pady 2
    label $f.l_solid -text "Solid layers" -anchor w
    spinbox $f.solid -from 1 -to 10 -width 6 -justify right -textvariable ::ElemImprint::opt(solidLayers)
    grid $f.l_solid -row 2 -column 0 -sticky w -pady 2
    grid $f.solid -row 2 -column 1 -sticky ew -padx {6 18} -pady 2
    grid $f -row 1 -column 0 -sticky ew -pady {8 0}
    grid columnconfigure $W.body 0 -weight 1

    frame $W.foot -padx 12 -pady 8
    label $W.foot.status -textvariable ::ElemImprint::status -anchor nw -justify left -height 4 -wraplength 300
    frame $W.foot.buttons
    button $W.foot.close -text "Close" -width 8 -command ::ElemImprint::close
    button $W.foot.reset -text "Reset" -width 8 -command ::ElemImprint::reset
    button $W.foot.run -text "Imprint" -width 10 -command ::ElemImprint::do_imprint
    pack $W.foot.close $W.foot.reset $W.foot.run -in $W.foot.buttons -side right -padx {6 0}
    pack $W.foot.status -side top -fill x
    pack $W.foot.buttons -side top -fill x -pady {6 0}
    pack $W.foot -fill x
    wm protocol $W WM_DELETE_WINDOW ::ElemImprint::close
    set status "Select the target, then the source (tria3/tria6 or tet4/tet10)."
    refresh
    place_center
    wm deiconify $W
    keep_above_host
}

# Center over the HyperMesh main window while withdrawn (works on any monitor).
proc ::ElemImprint::place_center {} {
    variable W
    update idletasks
    $W.foot.status configure -wraplength [expr {max(200,[winfo reqwidth $W.body]-24)}]
    update idletasks
    set w [winfo reqwidth $W]; set h [winfo reqheight $W]
    set x [expr {[winfo rootx .] + ([winfo width .]-$w)/2}]
    set y [expr {[winfo rooty .] + ([winfo height .]-$h)/2}]
    if {[winfo width .] < 50} {
        set x [expr {([winfo screenwidth $W]-$w)/2}]
        set y [expr {([winfo screenheight $W]-$h)/2}]
    }
    wm geometry $W +[expr {max($x,0)}]+[expr {max($y,0)}]
}

# HyperMesh main window as Win32 owner: above HyperMesh only.
proc ::ElemImprint::keep_above_host {} {
    variable W
    catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $W]}] HWND] -8 [expr {[wm frame .]}]
    }
}

if {![info exists ::ElemImprint_no_gui]} {
    ::ElemImprint::show
}
