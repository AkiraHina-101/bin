# Shared faces for HyperMesh 2022.3 (Nastran). A small window has two buttons: Components (native
# component selector) and Elements (native element selector). Selected elements are grouped
# by component; for every pair of those components that shares nodes, faces whose nodes (corner and
# midside) are all shared by the two groups are created in sf_<A>-<B>, one undo step. The window
# also recolors (one color, or automatic distinct colors) or deletes the components it created.
# Scope is the selected elements only: selecting part of a component gives a smaller interface.
# When both groups have 2D/3D elements, faces come from the first group and must match a face of
# the other group or lie on its shared faces; a group with only 1D/rigid elements accepts the faces
# of the other group. Non-tetra solids use a temporary *findfaces that is removed again.

namespace eval ::SharedFaces {
    variable S
    foreach side {A B} {
        foreach {key value} {mode comps ids {} comps {}} {
            if {![info exists S($side,$key)]} {set S($side,$key) $value}
        }
    }
    variable shellConfigs {103 104 106 108}
    # Tetra faces from connectivity (same tables as SharedEdges): corner triplet + midside.
    variable tetFaces {204 {103 {{0 1 2} {0 1 3} {0 2 3} {1 2 3}}} 210 {106 {{0 1 2 4 5 6} {0 1 3 4 8 7} {0 2 3 6 9 7} {1 2 3 5 9 8}}}}
}

# ---------------------------------------------------------------- model reads (no changes)
# user_ids= reads avoid *createmark/mark= scans of the whole model (see RUNTIME_DA_KIEM section 10).
proc ::SharedFaces::read_elems {eids} {
    set rows {}
    for {set i 0} {$i < [llength $eids]} {incr i 2048} {
        set chunk [lrange $eids $i [expr {$i+2047}]]
        foreach e $chunk c [hm_getvalue elems user_ids=$chunk dataname=collector.id] \
            g [hm_getvalue elems user_ids=$chunk dataname=config] \
            n [hm_getvalue elems user_ids=$chunk dataname=nodes] {
            lappend rows [list $e $c $g $n]
        }
    }
    return $rows
}

proc ::SharedFaces::comp_name {cid} {
    if {[catch {hm_getvalue comps id=$cid dataname=name} name]} {return $cid}
    return $name
}

proc ::SharedFaces::comp_elems {cids} {
    set out {}
    foreach cid $cids {
        *createmark elems 1 "by collector id" $cid
        foreach e [hm_getmark elems 1] {lappend out $e}
        *clearmark elems 1
    }
    return $out
}

# Candidate nodes: shared nodes among the selected components (native *findbetween) plus every
# node of the selected elements. Any node shared by a pair is in this set.
proc ::SharedFaces::candidate_nodes {} {
    variable S
    set nodes [dict create]
    set comps {}
    foreach side {A B} {if {$S($side,mode) eq "comps"} {foreach c $S($side,ids) {lappend comps $c}}}
    # Element selection with known components: nodes shared by two of those components (native,
    # fast) are a superset of nodes shared by the selected elements; no need to read every element.
    set elemSides {}
    foreach side {A B} {
        if {$S($side,mode) ne "elems" || ![llength $S($side,ids)]} {continue}
        if {[info exists S($side,comps)] && [llength $S($side,comps)]} {
            foreach c $S($side,comps) {lappend comps $c}
        } else {
            lappend elemSides $side
        }
    }
    set comps [lsort -unique -integer $comps]
    if {[llength $comps] >= 2} {
        *createmark comps 1 "by id only" {*}$comps
        *createmark nodes 2
        *findbetween nodes components 1 0 0 2
        set found [hm_getmark nodes 2]
        # *findbetween marks what it finds as temp nodes; remove only those marks.
        if {[llength $found]} {*nodemarkcleartempmark 2}
        *clearmark nodes 2; *clearmark comps 1
        foreach n $found {dict set nodes $n 1}
    }
    foreach side $elemSides {
        foreach row [read_elems $S($side,ids)] {foreach n [lindex $row 3] {dict set nodes $n 1}}
    }
    dict keys $nodes
}

# Faces of one group: shells are their own face; tetra faces come from connectivity; other
# solids use *findfaces on the candidate elements (temporary ^faces, removed again).
# Only faces whose nodes are all in $shared are returned, as {cornerKey cfg nodes}.
proc ::SharedFaces::group_faces {rows shared} {
    variable shellConfigs; variable tetFaces
    set out {}
    set counts [dict create]; set values [dict create]
    set others {}
    foreach row $rows {
        lassign $row e c cfg ns
        if {$cfg in $shellConfigs} {
            set ok 1
            foreach n $ns {if {![dict exists $shared $n]} {set ok 0; break}}
            if {$ok} {
                set k [expr {$cfg in {103 106} ? 3 : 4}]
                lappend out [list [join [lsort -integer [lrange $ns 0 [expr {$k-1}]]] ,] $cfg $ns]
            }
        } elseif {[dict exists $tetFaces $cfg]} {
            lassign [dict get $tetFaces $cfg] fcfg patterns
            # Only faces with all three corners shared can qualify; a face inside the group is
            # seen twice (two elements both touch shared nodes), a boundary face once.
            set in 0
            foreach n [lrange $ns 0 3] {if {[dict exists $shared $n]} {incr in}}
            if {$in < 3} {continue}
            foreach p $patterns {
                set face {}
                foreach i $p {lappend face [lindex $ns $i]}
                set corners [lrange $face 0 2]
                if {![dict exists $shared [lindex $corners 0]] || ![dict exists $shared [lindex $corners 1]] || ![dict exists $shared [lindex $corners 2]]} {continue}
                set key [join [lsort -integer $corners] ,]
                dict incr counts $key
                if {![dict exists $values $key]} {dict set values $key [list $fcfg $face]}
            }
        } elseif {$cfg >= 200} {
            lappend others $e
        }
    }
    dict for {key count} $counts {
        if {$count != 1} {continue}
        lassign [dict get $values $key] fcfg face
        set ok 1
        foreach n $face {if {![dict exists $shared $n]} {set ok 0; break}}
        if {$ok} {lappend out [list $key $fcfg $face]}
    }
    if {[llength $others]} {
        foreach f [find_faces_native $others] {
            lassign $f fcfg face
            set ok 1
            foreach n $face {if {![dict exists $shared $n]} {set ok 0; break}}
            if {!$ok} {continue}
            set k [expr {$fcfg in {103 106} ? 3 : 4}]
            lappend out [list [join [lsort -integer [lrange $face 0 [expr {$k-1}]]] ,] $fcfg $face]
        }
    }
    return $out
}

proc ::SharedFaces::find_faces_native {eids} {
    if {![catch {hm_getvalue comps name=^faces dataname=id} old] && $old ne "" && $old ne "0"} {
        error "Component ^faces already exists; rename or delete it first."
    }
    set out {}
    *createmark elems 1 {*}$eids
    *findfaces elems 1
    set rc [catch {
        set fid [hm_getvalue comps name=^faces dataname=id]
        *createmark elems 1 "by collector id" $fid
        set faces [hm_getmark elems 1]
        *clearmark elems 1
        foreach row [read_elems $faces] {lappend out [list [lindex $row 2] [lindex $row 3]]}
    } err opts]
    catch {*createmark elems 1 "by collector name" ^faces; *deletemark elems 1}
    catch {*createmark comps 1 "by name only" ^faces; *deletemark comps 1}
    catch {*clearmark elems 1; *clearmark comps 1}
    if {$rc} {return -options $opts $err}
    return $out
}

# Builds the pair list: {keyA keyB nameA nameB sharedNodeCount faces} with faces as {cfg nodes}.
proc ::SharedFaces::find {} {
    variable S
    if {![llength $S(A,ids)]} {error "Select Side A first."}
    variable prof [dict create]
    set t0 [clock milliseconds]
    set candidates [candidate_nodes]
    dict set prof candidates [expr {[clock milliseconds]-$t0}]
    if {![llength $candidates]} {return {}}
    # Every element touching a candidate node (cross-reference: no display change, unlike *findmark).
    *createmark nodes 1 {*}$candidates
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    dict set prof xref [expr {[clock milliseconds]-$t0}]
    *clearmark nodes 1
    set near [hm_getmark elems 2]
    *clearmark elems 2
    set cand [dict create]
    foreach n $candidates {dict set cand $n 1}
    # Side membership
    foreach side {A B} {
        set member($side,comps) [dict create]; set member($side,elems) [dict create]
        foreach id $S($side,ids) {dict set member($side,[expr {$S($side,mode) eq "comps" ? "comps" : "elems"}]) $id 1}
    }
    set useB [llength $S(B,ids)]
    set groups [dict create]
    set owners [dict create]
    foreach row [read_elems $near] {
        lassign $row e c cfg ns
        set keys {}
        foreach side {A B} {
            if {$side eq "B" && !$useB} {continue}
            if {[dict exists $member($side,comps) $c] || [dict exists $member($side,elems) $e]} {lappend keys "$side:$c"}
        }
        foreach key $keys {
            dict lappend groups $key $row
            foreach n $ns {if {[dict exists $cand $n]} {dict set owners $n $key 1}}
        }
    }
    dict set prof owners [expr {[clock milliseconds]-$t0}]
    return [pairs_from $groups $owners $useB $t0]
}

proc ::SharedFaces::pairs_from {groups owners useB t0} {
    variable S; variable prof
    # Pairs and their shared nodes
    set pairNodes [dict create]
    dict for {n keys} $owners {
        set ks [lsort [dict keys $keys]]
        for {set i 0} {$i < [llength $ks]} {incr i} {
            for {set j [expr {$i+1}]} {$j < [llength $ks]} {incr j} {
                set a [lindex $ks $i]; set b [lindex $ks $j]
                if {$useB} {
                    if {[string index $a 0] eq [string index $b 0]} {continue}
                    if {[string index $a 0] eq "B"} {set t $a; set a $b; set b $t}
                } elseif {$a eq $b} {continue}
                if {$useB && $S(A,mode) eq "comps" && $S(B,mode) eq "comps" && [lindex [split $a :] 1] == [lindex [split $b :] 1]} {continue}
                dict set pairNodes "$a|$b" $n 1
            }
        }
    }
    dict set prof pairs [expr {[clock milliseconds]-$t0}]
    # Faces of each group are computed once against all multi-owner nodes, then filtered per pair.
    set multi [dict create]
    dict for {n keys} $owners {if {[dict size $keys] > 1} {dict set multi $n 1}}
    set faceCache [dict create]
    set result {}
    foreach pairKey [lsort [dict keys $pairNodes]] {
        lassign [split $pairKey |] a b
        set shared [dict get $pairNodes $pairKey]
        foreach g [list $a $b] {
            if {![dict exists $faceCache $g]} {dict set faceCache $g [group_faces [dict get $groups $g] $multi]}
        }
        set fa [faces_within [dict get $faceCache $a] $shared]
        set fb [faces_within [dict get $faceCache $b] $shared]
        set solidA [has_2d3d [dict get $groups $a]]; set solidB [has_2d3d [dict get $groups $b]]
        set faces {}
        set seen [dict create]
        if {$solidA && $solidB} {
            # Faces come from the first side. A face is kept when the other side has the same face
            # (same corner nodes) or when every one of its nodes lies on the other side's shared
            # faces (non-matching meshes, e.g. one hex quad against two tet trias). A face whose
            # nodes only touch the other side along edges is rejected.
            set src $fa; set other $fb
            if {![llength $fa]} {set src $fb; set other $fa}
            set keysOther [dict create]; set nodesOther [dict create]
            foreach f $other {
                dict set keysOther [lindex $f 0] 1
                foreach n [lindex $f 2] {dict set nodesOther $n 1}
            }
            foreach f $src {
                set k [lindex $f 0]
                if {[dict exists $seen $k]} {continue}
                set ok [dict exists $keysOther $k]
                if {!$ok} {
                    set ok 1
                    foreach n [lindex $f 2] {if {![dict exists $nodesOther $n]} {set ok 0; break}}
                }
                if {$ok} {dict set seen $k 1; lappend faces [lrange $f 1 2]}
            }
        } else {
            foreach f [concat $fa $fb] {
                set k [lindex $f 0]
                if {![dict exists $seen $k]} {dict set seen $k 1; lappend faces [lrange $f 1 2]}
            }
        }
        set ca [lindex [split $a :] 1]; set cb [lindex [split $b :] 1]
        lappend result [list $a $b [comp_name $ca] [comp_name $cb] [dict size $shared] $faces [dict keys $shared]]
    }
    dict set prof faces [expr {[clock milliseconds]-$t0}]
    return $result
}

proc ::SharedFaces::faces_within {faces shared} {
    set out {}
    foreach f $faces {
        set ok 1
        foreach n [lindex $f 2] {if {![dict exists $shared $n]} {set ok 0; break}}
        if {$ok} {lappend out $f}
    }
    return $out
}

proc ::SharedFaces::has_2d3d {rows} {
    foreach row $rows {if {[lindex $row 2] >= 100} {return 1}}
    return 0
}

# ---------------------------------------------------------------- model writes
proc ::SharedFaces::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::SharedFaces::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}

proc ::SharedFaces::unique_comp_name {base} {
    set base [string map {" " _ \" _ \{ _ \} _} $base]
    set name $base; set i 1
    while {[hm_entityinfo exist comps $name -byname]} {set name "${base}_$i"; incr i}
    return $name
}

# Creates one component per pair; returns {name count ...}. One undo step; removes all on error.
proc ::SharedFaces::create {pairList {color ""}} {
    set made {}
    set out {}
    set previous [hm_info currentcollector comps]
    set previousName ""
    if {$previous ne "" && $previous ne "0"} {catch {set previousName [comp_name $previous]}}
    variable created
    history_begin "Shared faces"
    set code [catch {
        foreach pair $pairList {
            lassign $pair a b na nb count faces
            if {![llength $faces]} {continue}
            set name [unique_comp_name "sf_${na}-${nb}"]
            set compColor $color
            if {$compColor eq ""} {set compColor [next_color]}
            *collectorcreateonly comps $name "" $compColor
            lappend made $name
            *currentcollector comps $name
            set byCfg [dict create]
            foreach f $faces {dict lappend byCfg [lindex $f 0] [lindex $f 1]}
            # Readback with the entity recorder (ids actually created), not a mark scan of the model.
            # Runtime 2022.3, 2.8M elements: *createelements ~0.25 s per call is the floor; one call
            # per pair and config was faster (6.1 s / 20 pairs) than one call plus *movemark (14.8 s).
            set actual 0
            dict for {cfg rows} $byCfg {
                set conn {}
                foreach ns $rows {foreach n $ns {lappend conn $n}}
                hm_entityrecorder elems on
                set rc [catch {
                    *createarray [llength $conn] {*}$conn
                    *createelements $cfg 1 1 [llength $conn]
                } e]
                hm_entityrecorder elems off
                if {$rc} {error $e}
                set ids [hm_entityrecorder elems ids]
                if {[llength $ids] != [llength $rows]} {error "Readback for $name: expected [llength $rows] faces of config $cfg, got [llength $ids]."}
                set cfgs [hm_getvalue elems user_ids=$ids dataname=config]
                if {[lsort -unique $cfgs] ne [list $cfg]} {error "Readback for $name: wrong element config."}
                incr actual [llength $ids]
            }
            lappend out $name $actual
        }
    } err opts]
    if {$code} {
        foreach name $made {catch {*createmark comps 1 "by name only" $name; *deletemark comps 1}}
        catch {*clearmark comps 1}
    }
    if {$previousName ne ""} {catch {*currentcollector comps $previousName}}
    history_end "Shared faces"
    if {$code} {return -options $opts $err}
    foreach name $made {lappend created $name}
    return $out
}

# ---------------------------------------------------------------- managing created shared faces
# Components created by this tool in this HyperMesh session (kept when the window is reopened).
namespace eval ::SharedFaces {
    variable created
    if {![info exists created]} {set created {}}
    variable colorIndex
    if {![info exists colorIndex]} {set colorIndex 0}
}

# Saturated HyperMesh palette entries (1-based) ordered by hue, so neighbours differ clearly.
proc ::SharedFaces::palette {} {
    variable paletteCache
    if {[info exists paletteCache] && [llength $paletteCache]} {return $paletteCache}
    set rows {}
    set i 0
    foreach rgb [hm_winfo entitycolors] {
        incr i
        if {[llength $rgb] < 3} {continue}
        lassign $rgb r g b
        set mx [expr {max($r,$g,$b)}]; set mn [expr {min($r,$g,$b)}]
        if {$mx - $mn < 120 || $mx < 150} {continue}
        set d [expr {double($mx-$mn)}]
        if {$mx == $r} {
            set h [expr {fmod(($g-$b)/$d+6.0,6.0)}]
        } elseif {$mx == $g} {
            set h [expr {($b-$r)/$d+2.0}]
        } else {
            set h [expr {($r-$g)/$d+4.0}]
        }
        lappend rows [list $i $h]
    }
    set paletteCache {}
    foreach row [lsort -real -index 1 $rows] {lappend paletteCache [lindex $row 0]}
    if {![llength $paletteCache]} {set paletteCache {3 4 5 6 7}}
    return $paletteCache
}

# Next color: steps through the hue-ordered palette by about a third, so consecutive components
# get clearly different colors.
proc ::SharedFaces::next_color {} {
    variable colorIndex
    set pal [palette]
    set n [llength $pal]
    set step [expr {max(1,$n/3+1)}]
    set c [lindex $pal [expr {($colorIndex*$step) % $n}]]
    incr colorIndex
    return $c
}

proc ::SharedFaces::existing_created {} {
    variable created
    set keep {}
    foreach name $created {
        if {[hm_entityinfo exist comps $name -byname] && $name ni $keep} {lappend keep $name}
    }
    set created $keep
    return $keep
}

# One color for every created shared-face component (one undo step).
proc ::SharedFaces::color_all {color} {
    set names [existing_created]
    if {![llength $names]} {error "No shared-face components to color."}
    history_begin "Shared faces color"
    set rc [catch {
        *createmark comps 1 "by name only" {*}$names
        *colormark comps 1 $color
        *clearmark comps 1
    } err opts]
    history_end "Shared faces color"
    if {$rc} {return -options $opts $err}
    return [llength $names]
}

# A different color for each created shared-face component (one undo step).
proc ::SharedFaces::color_auto {} {
    variable colorIndex
    set names [existing_created]
    if {![llength $names]} {error "No shared-face components to color."}
    set colorIndex 0
    history_begin "Shared faces color"
    set rc [catch {
        foreach name $names {
            *createmark comps 1 "by name only" $name
            *colormark comps 1 [next_color]
        }
        *clearmark comps 1
    } err opts]
    history_end "Shared faces color"
    if {$rc} {return -options $opts $err}
    return [llength $names]
}

# Deletes every created shared-face component and its faces (one undo step).
proc ::SharedFaces::delete_created {} {
    variable created
    set names [existing_created]
    if {![llength $names]} {error "No shared-face components to delete."}
    history_begin "Shared faces delete"
    set rc [catch {
        *createmark comps 1 "by name only" {*}$names
        *deletemark comps 1
        *clearmark comps 1
    } err opts]
    history_end "Shared faces delete"
    if {$rc} {return -options $opts $err}
    set left {}
    foreach name $names {if {[hm_entityinfo exist comps $name -byname]} {lappend left $name}}
    set created $left
    if {[llength $left]} {error "Could not delete: [join $left {, }]."}
    return [llength $names]
}

# ---------------------------------------------------------------- entry
# Small window with two buttons: Components opens the native component selector, Elements the
# native element selector. Elements are grouped by their component; every touching pair of those
# components gets an sf_<A>-<B> component with the faces shared by the selection only.
namespace eval ::SharedFaces {
    variable W .sharedFaces
    variable status ""
}

proc ::SharedFaces::message {text} {
    variable status
    set status $text
    puts "Shared faces: $text"
    catch {hm_usermessage $text}
}

proc ::SharedFaces::run_on {eids {color ""}} {
    variable S
    set t [clock milliseconds]
    set eids [lsort -unique -integer $eids]
    # When the selection is exactly whole components (selector "by collector"), use the
    # component path: native *findbetween instead of reading every selected element.
    set comps [dict create]
    for {set i 0} {$i < [llength $eids]} {incr i 4096} {
        foreach c [hm_getvalue elems user_ids=[lrange $eids $i [expr {$i+4095}]] dataname=collector.id] {dict set comps $c 1}
    }
    set comps [lsort -integer [dict keys $comps]]
    *createmark elems 2 "by collector id" {*}$comps
    set whole [expr {[hm_marklength elems 2] == [llength $eids]}]
    *clearmark elems 2
    if {$whole} {
        set S(A,mode) comps; set S(A,ids) $comps
    } else {
        set S(A,mode) elems; set S(A,ids) $eids
    }
    set S(A,comps) $comps
    return [find_and_create $whole $t $color]
}

# Whole components picked directly: component path, no per-element read.
proc ::SharedFaces::run_on_comps {cids {color ""}} {
    variable S
    set t [clock milliseconds]
    set cids [lsort -unique -integer $cids]
    set S(A,mode) comps; set S(A,ids) $cids; set S(A,comps) $cids
    return [find_and_create 1 $t $color]
}

proc ::SharedFaces::find_and_create {whole t {color ""}} {
    variable S
    set S(B,mode) comps; set S(B,ids) {}
    set pairs [find]
    set withFaces {}
    foreach p $pairs {if {[llength [lindex $p 5]]} {lappend withFaces $p}}
    if {![llength $withFaces]} {
        return [list pairs [llength $pairs] made {} faces 0 whole $whole ms [expr {[clock milliseconds]-$t}]]
    }
    set made [create $withFaces $color]
    set faces 0
    foreach {name n} $made {incr faces $n}
    list pairs [llength $pairs] made $made faces $faces whole $whole ms [expr {[clock milliseconds]-$t}]
}

# kind: comps or elems. Opens the native selector, then finds and creates the faces.
# return/ESC makes the panel raise an error ("0"); the mark is cleared first, so an empty mark
# afterwards means cancel and a filled mark is still a selection.
proc ::SharedFaces::pick {kind} {
    variable W
    set label [expr {$kind eq "comps" ? "components" : "elements"}]
    if {[winfo exists $W]} {wm withdraw $W}
    *clearmark $kind 1
    catch {*createmarkpanel $kind 1 "Shared faces: select $label"}
    set ids [hm_getmark $kind 1]
    *clearmark $kind 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {![llength $ids]} {message "Selection cancelled."; return}
    message "Finding shared faces between [llength $ids] $label..."
    update idletasks
    if {$kind eq "comps"} {
        set rc [catch {run_on_comps $ids [chosen_color]} r]
    } else {
        set rc [catch {run_on $ids [chosen_color]} r]
    }
    if {$rc} {message "Error: $r"; return}
    if {![dict get $r faces]} {
        message "No shared faces ([llength $ids] $label, [dict get $r pairs] touching pairs)."
        return
    }
    message "Created [dict get $r faces] faces in [expr {[llength [dict get $r made]]/2}] components ([dict get $r ms] ms)."
    refresh_count
    puts "Shared faces: [dict get $r made]"
    catch {hm_redraw}
}

proc ::SharedFaces::refresh_count {} {
    variable countText; variable W
    set n [llength [existing_created]]
    set countText "Created: $n component[expr {$n == 1 ? "" : "s"}]"
    if {[winfo exists $W.manage]} {
        foreach b {apply auto delete} {$W.manage.$b configure -state [expr {$n ? "normal" : "disabled"}]}
    }
}

proc ::SharedFaces::chosen_color {} {
    variable W; variable tkColor
    set w $W.manage.color
    if {[winfo class $w] eq "Button"} {
        return $tkColor
    }
    return [$w color]
}

proc ::SharedFaces::pick_color_tk {} {
    variable tkColor; variable W
    set hex [tk_chooseColor -parent $W]
    if {$hex eq ""} {return}
    scan $hex "#%2x%2x%2x" r g b
    set bestRGB {}; set bestD 1e30; set i 0
    foreach rgb [hm_winfo entitycolors] {
        incr i
        if {[llength $rgb] < 3} {continue}
        set d 0.0
        foreach a [lrange $rgb 0 2] c [list $r $g $b] {set d [expr {$d+($a-$c)*($a-$c)}]}
        if {$d < $bestD} {set bestD $d; set best $i; set bestRGB [lrange $rgb 0 2]}
    }
    if {![llength $bestRGB]} {return}
    set tkColor $best
    $W.manage.color configure -background [format "#%02x%02x%02x" {*}$bestRGB]
}

proc ::SharedFaces::do_color {} {
    if {[catch {color_all [chosen_color]} r]} {message $r} else {message "Colored $r components."; catch {hm_redraw}}
    refresh_count
}

proc ::SharedFaces::do_auto {} {
    if {[catch {color_auto} r]} {message $r} else {message "Auto colors on $r components."; catch {hm_redraw}}
    refresh_count
}

proc ::SharedFaces::do_delete {} {
    if {[catch {delete_created} r]} {message $r} else {message "Deleted $r shared-face components."; catch {hm_redraw}}
    refresh_count
}

proc ::SharedFaces::show {} {
    variable W; variable tkColor
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Shared Faces"
    wm resizable $W 0 0
    frame $W.body -padx 12 -pady 10
    pack $W.body -fill both -expand 1
    label $W.body.l -text "Select" -anchor w
    button $W.body.comps -text "Components..." -width 14 -command {::SharedFaces::pick comps}
    button $W.body.elems -text "Elements..." -width 14 -command {::SharedFaces::pick elems}
    grid $W.body.l -row 0 -column 0 -sticky w -padx {0 10}
    grid $W.body.comps -row 0 -column 1 -padx {0 6}
    grid $W.body.elems -row 0 -column 2
    frame $W.foot -padx 12 -pady 8
    label $W.foot.status -textvariable ::SharedFaces::status -anchor w -justify left -height 2 -wraplength 260
    button $W.foot.close -text "Close" -width 8 -command [list destroy $W]
    pack $W.foot.close -side right -padx {6 0}
    pack $W.foot.status -side left -fill x -expand 1
    pack $W.foot -fill x
    set m [labelframe $W.manage -text "Shared faces" -padx 8 -pady 6]
    grid columnconfigure $m 0 -minsize 56
    label $m.l_color -text "Color" -anchor w
    set defaultColor [lindex [palette] 0]
    if {[catch {hwtk::colorbutton $m.color -startindex 1 -color $defaultColor}]} {
        # Fallback without HWTK: Tk chooser, mapped to the nearest HyperMesh palette entry.
        set tkColor $defaultColor
        set rgb [lrange [lindex [hm_winfo entitycolors] [expr {$tkColor - 1}]] 0 2]
        button $m.color -text "Pick..." -width 8 -command ::SharedFaces::pick_color_tk \
            -background [format "#%02x%02x%02x" {*}$rgb]
    }
    button $m.apply -text "Apply" -width 8 -command ::SharedFaces::do_color
    button $m.auto -text "Auto" -width 8 -command ::SharedFaces::do_auto
    label $m.count -textvariable ::SharedFaces::countText -anchor w
    button $m.delete -text "Delete all" -width 8 -command ::SharedFaces::do_delete
    grid $m.l_color -row 0 -column 0 -sticky w -pady 2
    grid $m.color -row 0 -column 1 -sticky w -padx {0 10} -pady 2
    grid $m.apply -row 0 -column 2 -padx {0 6} -pady 2
    grid $m.auto -row 0 -column 3 -pady 2
    grid $m.count -row 1 -column 0 -columnspan 3 -sticky w -pady 2
    grid $m.delete -row 1 -column 3 -pady 2
    pack $m -after $W.body -fill x -padx 12
    bind $W <Escape> [list destroy $W]
    message "Ready."
    refresh_count
    update idletasks
    set w [winfo reqwidth $W]; set h [winfo reqheight $W]
    set x [expr {[winfo rootx .] + ([winfo width .]-$w)/2}]
    set y [expr {[winfo rooty .] + ([winfo height .]-$h)/2}]
    if {[winfo width .] < 50} {set x [expr {([winfo screenwidth $W]-$w)/2}]; set y [expr {([winfo screenheight $W]-$h)/2}]}
    wm geometry $W +[expr {max($x,0)}]+[expr {max($y,0)}]
    wm deiconify $W
    # HyperMesh main window as Win32 owner: stays above HyperMesh only (as Material Manager).
    catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $W]}] HWND] -8 [expr {[wm frame .]}]
    }
}

if {![info exists ::SharedFaces_no_gui]} {
    ::SharedFaces::show
}
