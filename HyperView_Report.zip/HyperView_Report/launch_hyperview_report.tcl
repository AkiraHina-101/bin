# Entry point: run this file inside HyperView 2022.3 (File > Run > Tcl/Tk Script).
if {[catch {
    source [file join [file dirname [file normalize [info script]]] hyperview_report.tcl]
    ::hvr::show
} hvrLaunchError]} {
    tk_messageBox -icon error -title "HyperView Report" -message "Could not open HyperView Report:\n$hvrLaunchError"
}
