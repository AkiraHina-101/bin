# HyperView Report

Công cụ chạy trong HyperView (đã thử với 2022.3): lập danh sách view kèm các mode cần xuất, chụp GIF, gom GIF vào PowerPoint và trích các bước đã chọn ra H3D.

## Cài đặt

Chép nguyên thư mục này vào vị trí có quyền ghi trên máy mới. Máy cần HyperView 2022.3. Công cụ dùng Tcl/Tk và HWTK của HyperView, cùng Python và HvTrans trong bộ cài Altair. Bộ xuất PowerPoint dùng thư viện chuẩn của Python 3.8 trở lên.

## Mở

Trong HyperView: `File > Run > Tcl/Tk Script`, chọn `launch_hyperview_report.tcl`. Hoặc gõ trong Tcl console (đổi đường dẫn theo máy):

```
source {D:/Tools/HyperView_Report/launch_hyperview_report.tcl}
```

## Đường dẫn trên máy khác

Cấu hình tập trung ở `paths.cfg` cạnh launcher. Mặc định các ô trống và công cụ tự tìm theo bộ cài của HyperView đang chạy.

- **Trong công cụ**, vào **Settings → Program paths**. Nhập đường dẫn hoặc bấm `...` để chọn, rồi bấm **Save paths**. **Find automatically** xóa cả ba giá trị đã lưu và chạy lại tự dò.
- **Bằng tay**, mở `paths.cfg` bằng Notepad, lưu UTF-8 rồi mở lại công cụ. Đường dẫn tương đối được tính từ thư mục chứa `paths.cfg`.

```
altair_home = C:/Program Files/Altair/2022.3
python      =
hvtrans     =
```

Điền `altair_home` (**Altair folder**) nếu cần chỉ rõ thư mục Altair 2022.3 chứa `common` và `hwdesktop`. Công cụ tìm các chương trình bên dưới thư mục đó. Điền `python` hoặc `hvtrans` để dùng một tệp `.exe` cụ thể. PPTX cần Python. H3D cần cả Python lẫn HvTrans.

## Dùng nhanh

1. `Load models...` để nạp OP2 hoặc H3D vào các cửa sổ, hoặc dùng model đang mở rồi bấm `Refresh`.
2. Panel `Views`: mỗi dòng là một view. Chọn một dòng rồi tích các mode ở bảng bên phải; đó là các mode sẽ xuất với view ấy.
3. Khung `Export`: `Export GIFs`, `Export PPTX`, `Export H3D`. Chưa chọn thư mục thì công cụ hỏi.
4. Tab `Settings`: result, legend, note (chỉ tác động lên HyperView khi bấm `Apply All Components`), bố cục PowerPoint, mức nén H3D.

Preset và view đã lưu nằm trong thư mục `settings` cạnh launcher; chép thư mục đó theo nếu muốn mang cả preset.

## Các file

- `launch_hyperview_report.tcl`: điểm mở.
- `hyperview_report.tcl`, `hvtrans_export.tcl`: mã Tcl.
- `make_pptx.py`, `hvtrans_export.py`: tạo PPTX và chạy HvTrans.
- `paths.cfg`: đường dẫn chương trình ngoài.
