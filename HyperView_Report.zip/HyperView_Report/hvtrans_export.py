"""Translate selected Nastran OP2 simulations to H3D using Altair 2022.3."""

import collections
import math
import os
from pathlib import Path
import subprocess
import sys


def read_request(path):
    groups = {}
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            model, result, output, subcase, simulation = line.rstrip("\r\n").split("\t")
            key = Path(model), Path(result), Path(output)
            subcase, simulation = int(subcase), int(simulation)
            if subcase < 1 or simulation < 1:
                raise ValueError("Subcase and simulation must be positive integers.")
            groups.setdefault(key, collections.defaultdict(set))[subcase].add(simulation)
    if not groups:
        raise ValueError("No simulations were selected.")
    return groups


def write_config(path, subcases, loss):
    lines = ["EnableCompression = {:.12g}, 7".format(loss)]
    for subcase, simulations in sorted(subcases.items()):
        lines.append("BeginSubcase:{}".format(subcase))
        for simulation in sorted(simulations):
            lines.extend(("    BeginSimulation:{}".format(simulation), "        (all)", "    EndSimulation"))
        lines.append("EndSubcase")
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def translate(executable, work, model, result, output, subcases, loss):
    if result.suffix.lower() != ".op2" or not result.is_file() or not model.is_file():
        raise ValueError("A readable Nastran OP2 and its geometry source are required.")
    if output.suffix.lower() != ".h3d" or output.resolve() in {model.resolve(), result.resolve()}:
        raise ValueError("The output must be a separate H3D file.")
    work.mkdir()
    write_config(work / "selection.cfg", subcases, loss)
    staged = work / "selected.h3d"
    log = work / "hvtrans.log"
    command = [str(executable), "-cselection.cfg", str(result), str(model), "-oselected.h3d"]
    with log.open("wb") as stream:
        process = subprocess.run(command, cwd=work, stdin=subprocess.DEVNULL, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
    if process.returncode or not staged.is_file() or staged.stat().st_size == 0:
        raise RuntimeError("HvTrans failed (exit {}).".format(process.returncode))
    os.replace(str(staged), str(output))
    return sum(len(steps) for steps in subcases.values())


def main(argv):
    if len(argv) != 4:
        print("Usage: hvtrans_export.py <hvtrans.exe> <request.tsv> <max loss percent>")
        return 2
    executable, request = Path(argv[1]).resolve(), Path(argv[2]).resolve()
    try:
        loss = float(argv[3])
        if not math.isfinite(loss) or not 0 <= loss <= 100:
            raise ValueError("Compression loss must be between 0 and 100 percent.")
        groups = read_request(request)
    except (OSError, ValueError) as error:
        print("Invalid HvTrans request: {}".format(error), flush=True)
        return 2
    made = 0
    for index, ((model, result, output), subcases) in enumerate(groups.items(), 1):
        work = request.parent / "model_{:02d}".format(index)
        try:
            count = translate(executable, work, model, result, output, subcases, loss)
            made += 1
            print("{}: {} selected step(s)".format(output.name, count), flush=True)
        except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as error:
            print("{}: {}. Details: {}".format(output.name, error, work), flush=True)
    print("Wrote {} of {} H3D file(s).".format(made, len(groups)), flush=True)
    return 0 if made == len(groups) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
