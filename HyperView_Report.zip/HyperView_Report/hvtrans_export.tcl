# The report supplies the same row keys used in the export preview.

proc ::hvr::h3d_groups {jobs} {
    variable rowData
    set groups [dict create]
    foreach job $jobs {
        set d $rowData([lindex $job 0])
        set source [list [dict get $d modelFile] [dict get $d resultFile]]
        set step [list [dict get $d sc] [dict get $d idx]]
        if {![dict exists $groups $source $step]} {dict set groups $source $step $d}
    }
    return $groups
}

proc ::hvr::require_current_row {m r d} {
    set sc [dict get $d sc]
    set idx [dict get $d idx]
    if {[$m GetFileName] ne [dict get $d modelFile] || [$m GetResultFileName] ne [dict get $d resultFile] ||
        $sc ni [$r GetSubcaseList] || $idx >= [$r GetNumberOfSimulations $sc] ||
        [string trim [$r GetSimulationLabel $sc $idx]] ne [dict get $d label]} {
        error "The model or result steps changed in window [dict get $d win]. Press Refresh."
    }
}

proc ::hvr::export_h3d {} {
    variable P
    variable dir
    variable python
    variable h3dLog
    variable h3dWork
    variable exporting
    if {[info exists exporting] && $exporting} {return}
    if {![ensure_output]} {return}
    set loss $P(h3dLoss)
    if {![regexp {^[0-9]+(?:\.[0-9]+)?$} $loss] || $loss > 100} {
        say "Maximum compression loss must be between 0 and 100 percent."
        return
    }
    variable hvtrans
    if {![file isfile $hvtrans] || ![file isfile $python]} {
        say "HvTrans or Python was not found. Set the paths in Settings > Program paths."
        return
    }
    if {[catch {
        set groups [h3d_groups [export_jobs]]
        if {![dict size $groups]} {error "Check steps for at least one view first."}
        set outputDir [file normalize $P(outputDir)]
        set records {}
        stack {
            lassign [page_handles] s p pg
            dict for {source steps} $groups {
                lassign $source model result
                if {[string tolower [file extension $result]] ne ".op2" || ![file isfile $result] || ![file isfile $model]} {
                    error "HvTrans requires a readable Nastran OP2 and geometry source: $result"
                }
                set first [lindex [dict values $steps] 0]
                set stem [safe_name "[safe_name $P(prefix)]_[dict get $first model]_W[dict get $first win]"]
                set out [file join $outputDir [format "%s_selected.h3d" $stem]]
                dict for {step d} $steps {
                    set wi [dict get $d win]
                    set handles [window_handles $pg $wi]
                    if {![llength $handles]} {error "Window $wi has no model. Press Refresh."}
                    lassign $handles c m r
                    require_current_row $m $r $d
                    lassign $step sc idx
                    lappend records [join [list [file normalize $model] [file normalize $result] $out $sc [expr {$idx + 1}]] \t]
                }
            }
        }
        set h3dWork [file join $outputDir "hvtrans-[clock seconds]-[pid]-[clock clicks]"]
        set request [file join $h3dWork request.tsv]
        write_dict $request [join $records \n]
        set command [list $python -B -X utf8 [file join $dir hvtrans_export.py] $hvtrans $request $loss 2>@1]
        set pipe [open [linsert $command 0 |] r]
        fconfigure $pipe -blocking 0 -encoding utf-8
    } err]} {say "HvTrans: $err"; return}
    set h3dLog ""
    export_state 1 h3d
    say "HvTrans is translating [dict size $groups] model source(s)..."
    fileevent $pipe readable [list ::hvr::h3d_readable $pipe]
}

proc ::hvr::h3d_readable {pipe} {
    variable h3dLog
    variable h3dWork
    append h3dLog [read $pipe]
    if {![eof $pipe]} {return}
    fileevent $pipe readable {}
    fconfigure $pipe -blocking 1
    set failed [catch {close $pipe} errorText]
    set log [string trim $h3dLog]
    if {$failed && $errorText ne ""} {append log \n $errorText}
    catch {write_dict [file join $h3dWork summary.log] $log}
    export_state 0 h3d
    if {$failed} {
        say "HvTrans incomplete. See [file tail $h3dWork]/summary.log."
    } else {
        say [lindex [split $log \n] end]
    }
}
