"""Build a PPTX of animated GIFs laid out on a grid. Standard library only (Python 3.8).

Usage: python make_pptx.py <records.tsv> <output.pptx> <cols> <rows> <row|column> <frequency|step|model|single|none> <header 0|1>

Each tab-separated record: path, model, view, window, subcase, step, value, label, optional axis.
Axis is frequency, time or label.
"""
import os
import struct
import sys
import tempfile
import zipfile
from decimal import Decimal, InvalidOperation
from xml.sax.saxutils import escape

SLIDE_W, SLIDE_H = 12192000, 6858000
MARGIN, TITLE_H = 457200, 640080
EMU_PER_INCH = 914400
MIN_DPI = 96
TARGET_DPI = 144

NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'

THEME = HEAD + (
    '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Report">'
    '<a:themeElements><a:clrScheme name="Report">'
    '<a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1>'
    '<a:dk2><a:srgbClr val="44546A"/></a:dk2><a:lt2><a:srgbClr val="E7E6E6"/></a:lt2>'
    '<a:accent1><a:srgbClr val="4472C4"/></a:accent1><a:accent2><a:srgbClr val="ED7D31"/></a:accent2>'
    '<a:accent3><a:srgbClr val="A5A5A5"/></a:accent3><a:accent4><a:srgbClr val="FFC000"/></a:accent4>'
    '<a:accent5><a:srgbClr val="5B9BD5"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6>'
    '<a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink>'
    '</a:clrScheme><a:fontScheme name="Report">'
    '<a:majorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
    '<a:minorFont><a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont>'
    '</a:fontScheme><a:fmtScheme name="Report"><a:fillStyleLst>'
    + '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' * 3 +
    '</a:fillStyleLst><a:lnStyleLst>'
    + '<a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>' * 3 +
    '</a:lnStyleLst><a:effectStyleLst>'
    + '<a:effectStyle><a:effectLst/></a:effectStyle>' * 3 +
    '</a:effectStyleLst><a:bgFillStyleLst>'
    + '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' * 3 +
    '</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>')

EMPTY_TREE = ('<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
              '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
              '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>%s</p:spTree>')

MASTER = HEAD + (
    '<p:sldMaster %s><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>'
    '<a:effectLst/></p:bgPr></p:bg>%s</p:cSld>'
    '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" '
    'accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" '
    'folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/>'
    '</p:sldLayoutIdLst></p:sldMaster>') % (NS, EMPTY_TREE % "")

LAYOUT = HEAD + (
    '<p:sldLayout %s type="blank" preserve="1"><p:cSld name="Blank">%s</p:cSld>'
    '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>') % (NS, EMPTY_TREE % "")


def rels(items):
    body = "".join('<Relationship Id="%s" Type="%s/%s" Target="%s"/>' % (rid, REL, kind, target)
                   for rid, kind, target in items)
    return HEAD + ('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   + body + '</Relationships>')


def gif_size(path):
    with open(path, "rb") as handle:
        header = handle.read(10)
    if len(header) != 10 or header[:6] not in (b"GIF87a", b"GIF89a"):
        raise ValueError("Not a GIF file: %s" % path)
    width, height = struct.unpack("<HH", header[6:10])
    if not width or not height:
        raise ValueError("GIF has empty dimensions: %s" % path)
    return width, height


def text_box(shape_id, x, y, cx, cy, text, size, bold, align="l"):
    return (
        '<p:sp><p:nvSpPr><p:cNvPr id="%d" name="Text %d"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        '<p:txBody><a:bodyPr wrap="square" anchor="ctr" lIns="0" rIns="0" tIns="0" bIns="0">'
        '<a:normAutofit/></a:bodyPr><a:lstStyle/>'
        '<a:p><a:pPr algn="%s"/><a:r><a:rPr lang="en-US" sz="%d" b="%d">'
        '<a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:rPr>'
        '<a:t>%s</a:t></a:r></a:p></p:txBody></p:sp>'
    ) % (shape_id, shape_id, x, y, cx, cy, align, size, 1 if bold else 0, escape(text))


def picture(shape_id, rel_id, x, y, cx, cy):
    return (
        '<p:pic><p:nvPicPr><p:cNvPr id="%d" name="Animation %d"/><p:cNvPicPr>'
        '<a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
        '<p:blipFill><a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
        '<p:spPr><a:xfrm><a:off x="%d" y="%d"/><a:ext cx="%d" cy="%d"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>'
    ) % (shape_id, shape_id, rel_id, x, y, cx, cy)


def number(text, default=0.0):
    try:
        return float(text)
    except ValueError:
        return default


def result_axis(record):
    axis = record.get("axis")
    if axis:
        return axis
    if record["label"].lstrip().lower().startswith("time"):
        return "time"
    return "frequency" if record["freq"] else "label"


def frequency(record):
    if result_axis(record) == "frequency" and record["freq"]:
        try:
            value = Decimal(record["freq"])
        except InvalidOperation:
            return None
        if value.is_finite():
            return value
    return None


def result_text(record):
    if frequency(record) is not None:
        return "%s Hz" % record["freq"]
    if result_axis(record) == "time" and record["freq"]:
        return "Time %s" % record["freq"]
    return record["label"]


def cell_header(record):
    # A picture title written for the view (already expanded by HyperView) is the whole header.
    if record.get("title"):
        return record["title"]
    return "%s  |  Step %s  |  %s" % (record["model"], record["step"], result_text(record))


def make_groups(records, mode):
    """Returns a list of (slide title, records) in slide order."""
    if mode == "none":
        return [("", records)]
    if mode == "single":
        return [
            ("%s  |  View %s" % (cell_header(record), record["view"]), [record])
            for record in records
        ]
    keyed = {}
    view_order = {}
    for index, record in enumerate(records):
        view = record["view"]
        view_order.setdefault(view, len(view_order))
        if mode == "model":
            key = (record["model"], record["win"], view)
        elif mode == "frequency":
            freq = frequency(record)
            # A time or static result has no frequency to compare across models.
            key = (view, record["sc"], freq, index if freq is None else -1)
        else:
            key = (view, record["sc"], record["step"])
        keyed.setdefault(key, []).append(record)

    if mode == "model":
        return [
            ("%s  |  View %s" % (key[0], key[2]),
             sorted(items, key=lambda r: (number(r["sc"]), number(r["step"]))))
            for key, items in keyed.items()
        ]
    if mode == "frequency":
        order = sorted(keyed, key=lambda k: (view_order[k[0]], number(k[1]), k[2] is None, k[2], k[3]))
    else:
        order = sorted(keyed, key=lambda k: (view_order[k[0]], number(k[1]), number(k[2])))

    groups = []
    for key in order:
        items = sorted(keyed[key], key=lambda r: number(r["win"]))
        if mode == "frequency":
            title = cell_header(items[0]) if key[2] is None else result_text(items[0])
        else:
            labels = {result_text(record) for record in items}
            title = "Step %s" % key[2]
            if len(labels) == 1 and next(iter(labels)):
                title += "  |  %s" % labels.pop()
        groups.append(("%s  |  Subcase %s  |  View %s" % (title, key[1], key[0]), items))
    return groups


def make_pages(records, mode, per_slide):
    pages = []
    for title, items in make_groups(records, mode):
        for start in range(0, len(items), per_slide):
            pages.append((title, items[start:start + per_slide]))
    return pages


def slide_xml(title, items, cols, rows, order, header, first_image):
    """Returns slide XML, relationships and the number of low-density GIFs."""
    shapes = []
    relations = [("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml")]
    top = MARGIN // 2
    if title:
        shapes.append(text_box(2, MARGIN, top, SLIDE_W - 2 * MARGIN, TITLE_H, title, 2000, True))
        top += TITLE_H
    gap = 150000
    area_w = SLIDE_W - 2 * MARGIN
    area_h = SLIDE_H - top - MARGIN // 2
    cell_w = (area_w - gap * (cols - 1)) // cols
    cell_h = (area_h - gap * (rows - 1)) // rows
    header_h = 300000 if header else 0
    font = 1400 if cols <= 2 else (1100 if cols <= 3 else 900)
    low_density = 0
    for index, record in enumerate(items):
        if order == "column":
            col, row = index // rows, index % rows
        else:
            row, col = index // cols, index % cols
        x0 = MARGIN + col * (cell_w + gap)
        y0 = top + row * (cell_h + gap)
        if header:
            shapes.append(text_box(10 + 2 * index, x0, y0, cell_w, header_h, cell_header(record), font, True, "ctr"))
        width, height = gif_size(record["path"])
        box_h = cell_h - header_h
        fit_scale = min(cell_w / width, box_h / height)
        if fit_scale > EMU_PER_INCH / TARGET_DPI:
            low_density += 1
        scale = min(fit_scale, EMU_PER_INCH / MIN_DPI)
        cx, cy = int(width * scale), int(height * scale)
        rel_id = "rId%d" % (index + 2)
        shapes.append(picture(11 + 2 * index, rel_id, x0 + (cell_w - cx) // 2, y0 + header_h + (box_h - cy) // 2, cx, cy))
        relations.append((rel_id, "image", "../media/image%d.gif" % (first_image + index)))
    xml = HEAD + ('<p:sld %s><p:cSld>%s</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'
                  % (NS, EMPTY_TREE % "".join(shapes)))
    return xml, relations, low_density


def build(records, output, cols, rows, order, mode, header):
    if mode == "single":
        cols, rows, header = 1, 1, False
    pages = make_pages(records, mode, cols * rows)
    count = len(pages)
    types = (
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Default Extension="gif" ContentType="image/gif"/>'
        '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
        '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
        '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
        '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
        + "".join('<Override PartName="/ppt/slides/slide%d.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' % (i + 1)
                  for i in range(count))
        + '</Types>')
    presentation = HEAD + (
        '<p:presentation %s><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
        '<p:sldIdLst>%s</p:sldIdLst><p:sldSz cx="%d" cy="%d"/><p:notesSz cx="6858000" cy="9144000"/>'
        '</p:presentation>') % (
            NS, "".join('<p:sldId id="%d" r:id="rId%d"/>' % (256 + i, i + 2) for i in range(count)),
            SLIDE_W, SLIDE_H)
    pres_rels = [("rId1", "slideMaster", "slideMasters/slideMaster1.xml")]
    pres_rels += [("rId%d" % (i + 2), "slide", "slides/slide%d.xml" % (i + 1)) for i in range(count)]
    pres_rels.append(("rId%d" % (count + 2), "theme", "theme/theme1.xml"))

    low_density = 0
    output_dir = os.path.dirname(os.path.abspath(output))
    with tempfile.TemporaryDirectory(prefix=".pptx-", dir=output_dir) as staging:
        temp = os.path.join(staging, "report.pptx")
        with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED) as package:
            package.writestr("[Content_Types].xml", HEAD + types)
            package.writestr("_rels/.rels", rels([("rId1", "officeDocument", "ppt/presentation.xml")]))
            package.writestr("ppt/presentation.xml", presentation)
            package.writestr("ppt/_rels/presentation.xml.rels", rels(pres_rels))
            package.writestr("ppt/theme/theme1.xml", THEME)
            package.writestr("ppt/slideMasters/slideMaster1.xml", MASTER)
            package.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", rels([
                ("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"),
                ("rId2", "theme", "../theme/theme1.xml")]))
            package.writestr("ppt/slideLayouts/slideLayout1.xml", LAYOUT)
            package.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels([
                ("rId1", "slideMaster", "../slideMasters/slideMaster1.xml")]))
            image = 1
            for i, (title, items) in enumerate(pages):
                xml, relations, slide_low_density = slide_xml(title, items, cols, rows, order, header, image)
                low_density += slide_low_density
                package.writestr("ppt/slides/slide%d.xml" % (i + 1), xml)
                package.writestr("ppt/slides/_rels/slide%d.xml.rels" % (i + 1), rels(relations))
                for record in items:
                    # GIF data is already compressed. Store it as is.
                    package.write(record["path"], "ppt/media/image%d.gif" % image, zipfile.ZIP_STORED)
                    image += 1
        os.replace(temp, output)
    return count, low_density


FIELDS = ("path", "model", "view", "win", "sc", "step", "freq", "label")


def main(argv):
    if len(argv) != 8:
        sys.stderr.write(__doc__)
        return 2
    records = []
    with open(argv[1], "r", encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\n").split("\t")
            if len(parts) < len(FIELDS) or not os.path.isfile(parts[0]):
                continue
            record = dict(zip(FIELDS, parts))
            if len(parts) > len(FIELDS):
                record["axis"] = parts[len(FIELDS)]
            if len(parts) > len(FIELDS) + 1:
                record["title"] = parts[len(FIELDS) + 1].strip()
            records.append(record)
    if not records:
        sys.stderr.write("No GIF listed\n")
        return 1
    cols, rows = int(argv[3]), int(argv[4])
    order, mode, header = argv[5:8]
    if not (1 <= cols <= 6 and 1 <= rows <= 6 and order in ("row", "column")
            and mode in ("frequency", "step", "model", "single", "none") and header in ("0", "1")):
        sys.stderr.write("Invalid slide layout\n")
        return 2
    try:
        slides, low_density = build(records, argv[2], cols, rows, order, mode, header == "1")
    except (OSError, ValueError) as error:
        sys.stderr.write("%s\n" % error)
        return 1
    summary = "%d slide(s), %d GIF(s)" % (slides, len(records))
    if low_density:
        summary += ". %d GIF(s) below %d dpi at full cell size" % (low_density, TARGET_DPI)
    print(summary)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
