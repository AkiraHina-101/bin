# HyperView Report: result presets, saved views, frequency table, GIF and PPTX export.
# Runs inside HyperView 2022.3 (Tcl 8.5) and works on the windows of the active page.

namespace eval ::hvr {
    variable dir [file dirname [file normalize [info script]]]
    variable win .hvreport
    variable seq 0
    variable status "Ready"
    variable filter ""
    variable appliedSettings ""
    # Picture titles use HyperView note fields, so they can be customised like a note.
    variable defaultTitle "{window.modeltitle} | {window.simulationstep}"
    variable settingsRead 0
    variable windowCount 1
    variable rangeText ""
    variable rangeBy Freq
    variable rows {}
    variable rowData
    array set rowData {}
    variable grid
    array set grid {}
    variable lastGifs {}
    variable presetName ""
    variable viewName iso
    variable viewFit 1
    variable standardViews {iso front back left right top bottom}
    variable layoutFor {1 0 2 1 3 3 4 9 5 10 6 10 7 12 8 12 9 12}
    # External programs. Both come from paths.cfg next to the launcher, or are found from the
    # running HyperView when paths.cfg leaves them empty (see load_paths).
    variable python ""
    variable hvtrans ""
    variable altairHome ""
    # Preset fields (everything in this array is saved in a preset).
    variable P
    variable defaults {
        resultType "Strain Energy" component "Energy Density" scale 1.0
        legendPosition upperleft legendFormat scientific legendPrecision 3 legendLevels 9
        legendMax "" legendMin ""
        noteShow 1 noteText "{window.modeltitle}\n{window.loadcase} : {window.simulationstep}"
        animMode modal frames 12 outputDir "" prefix "" view iso
        plan {} usePlan 0 gifScale 300
        pptSource last pptGroup frequency pptCols 2 pptRows 1 pptOrder row pptHeader 1
        h3dLoss 0
    }
    array set P $defaults
}

source [file join $::hvr::dir hvtrans_export.tcl]

# ---------------------------------------------------------------- external paths

proc ::hvr::paths_file {} {
    variable dir
    return [file join $dir paths.cfg]
}

# Reads "key = value" lines of paths.cfg; lines starting with # are comments.
proc ::hvr::read_paths_file {} {
    set values [dict create altair_home "" python "" hvtrans ""]
    set text [string trimleft [read_dict [paths_file]] \ufeff]
    foreach line [split $text \n] {
        if {![regexp {^\s*(\w+)\s*=(.*)$} $line -> key value]} {continue}
        set key [string tolower $key]
        if {[dict exists $values $key]} {dict set values $key [string trim $value]}
    }
    return $values
}

# Resolve overrides from the package folder, regardless of HyperView's current directory.
proc ::hvr::resolve_program_path {value} {
    variable dir
    set value [string trim $value]
    regexp {^"(.*)"$} $value -> value
    if {$value eq ""} {return ""}
    return [file normalize [file join $dir [string map {\\ /} $value]]]
}

# The Altair install folder of the running HyperView: the first folder above the executable
# or ALTAIR_HOME that contains the bundled Python or result readers.
proc ::hvr::find_altair_home {} {
    set starts [list [file dirname [info nameofexecutable]]]
    if {[info exists ::env(ALTAIR_HOME)] && $::env(ALTAIR_HOME) ne ""} {lappend starts $::env(ALTAIR_HOME)}
    foreach folder $starts {
        set folder [file normalize $folder]
        while {1} {
            if {[file isdirectory [file join $folder common python]] ||
                [file isdirectory [file join $folder hwdesktop io result_readers]]} {return $folder}
            set parent [file dirname $folder]
            if {$parent eq $folder} {break}
            set folder $parent
        }
    }
    return ""
}

# Keep the saved overrides separate from their resolved runtime values.
proc ::hvr::load_paths {} {
    variable python
    variable hvtrans
    variable altairHome
    variable pathOverride
    array set pathOverride [read_paths_file]
    set altairHome [resolve_program_path $pathOverride(altair_home)]
    if {$altairHome eq ""} {set altairHome [find_altair_home]}
    set python [resolve_program_path $pathOverride(python)]
    if {$python eq "" && $altairHome ne ""} {
        # Newest Python 3 shipped with this Altair version.
        set found [lsort -dictionary -decreasing [glob -nocomplain -types f \
            -directory [file join $altairHome common python] python3*/win64/python.exe]]
        set python [lindex $found 0]
    }
    set hvtrans [resolve_program_path $pathOverride(hvtrans)]
    if {$hvtrans eq "" && $altairHome ne ""} {
        set hvtrans [file join $altairHome hwdesktop io result_readers bin win64 hvtrans.exe]
    }
}

# Replace the config after the complete file has been written.
proc ::hvr::save_paths {altair python hvtrans} {
    set path [paths_file]
    set staged "$path.[pid].[clock clicks].tmp"
    set lines {
        "# HyperView Report - external program paths."
        "# Leave values blank for automatic detection. Relative paths start here."
        "# altair_home: Altair 2022.3 folder containing common and hwdesktop."
        "# python: python.exe (Python 3.8 or newer). hvtrans: hvtrans.exe (Altair 2022.3)."
        ""
    }
    lappend lines "altair_home = $altair" "python      = $python" "hvtrans     = $hvtrans"
    if {[catch {
        write_dict $staged [join $lines \n]
        file rename -force -- $staged $path
    } message options]} {
        catch {file delete -- $staged}
        return -options $options $message
    }
}

# Settings tab: keep the typed paths, or go back to automatic detection.
proc ::hvr::paths_apply {{auto 0}} {
    variable python
    variable hvtrans
    variable pathOverride
    set overrides {}
    foreach key {altair_home python hvtrans} {
        lappend overrides [expr {$auto ? "" : [string trim $pathOverride($key)]}]
    }
    if {[catch {
        save_paths {*}$overrides
        load_paths
    } message]} {
        say "Could not apply paths.cfg: $message"
        return
    }
    set missing {}
    if {![file isfile $python]} {lappend missing "Python"}
    if {![file isfile $hvtrans]} {lappend missing "HvTrans"}
    if {[llength $missing]} {
        say "Not found: [join $missing { and }]. Check the paths in Settings."
    } else {
        say "Paths saved to paths.cfg. Python and HvTrans were found."
    }
}

proc ::hvr::paths_browse {which} {
    variable win
    variable dir
    variable pathOverride
    variable altairHome
    set current [resolve_program_path $pathOverride($which)]
    if {$which eq "altair_home"} {
        if {![file isdirectory $current]} {set current $altairHome}
        if {![file isdirectory $current]} {set current $dir}
        set selected [tk_chooseDirectory -parent $win -title "Choose the Altair 2022.3 folder" -initialdir $current -mustexist 1]
    } else {
        variable $which
        if {$current eq ""} {set current [set $which]}
        set folder [file dirname $current]
        if {![file isdirectory $folder]} {set folder $dir}
        set selected [tk_getOpenFile -parent $win -title "Choose $which.exe" -initialdir $folder \
            -filetypes {{"Programs" {.exe}} {"All files" *}}]
    }
    if {$selected ne ""} {set pathOverride($which) $selected}
}

# ---------------------------------------------------------------- utilities

proc ::hvr::h {} {
    variable seq
    return hvr_h[incr seq]
}

# Run a script between hwi OpenStack/CloseStack so every handle is released.
proc ::hvr::stack {script} {
    hwi OpenStack
    set code [catch {uplevel 1 $script} result options]
    catch {hwi CloseStack}
    return -options $options $result
}

proc ::hvr::say {text} {
    variable status
    set status $text
    update idletasks
}

proc ::hvr::safe_name {text} {
    set text [string trim $text]
    regsub -all {[^A-Za-z0-9._+-]+} $text _ text
    return [string trim $text _]
}

proc ::hvr::read_dict {path} {
    if {![file isfile $path]} {return {}}
    set f [open $path r]
    fconfigure $f -encoding utf-8
    set data [read $f]
    close $f
    return $data
}

proc ::hvr::write_dict {path data} {
    file mkdir [file dirname $path]
    set f [open $path w]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f $data
    close $f
}

# ---------------------------------------------------------------- HyperView access

# Returns {session project page} handle names for the active page.
proc ::hvr::page_handles {} {
    set s [h]; hwi GetSessionHandle $s
    set p [h]; $s GetProjectHandle $p
    set pg [h]; $p GetPageHandle $pg [$p GetActivePage]
    return [list $s $p $pg]
}

# Returns {client model result modelId} for a window index, or {} when it has no model.
proc ::hvr::window_handles {pg wi} {
    set w [h]; $pg GetWindowHandle $w $wi
    if {[$w GetClientType] ne "Animation"} {return {}}
    set c [h]; $w GetClientHandle $c
    set models [$c GetModelList]
    if {![llength $models]} {return {}}
    set mid [$c GetActiveModel]
    if {$mid ni $models} {set mid [lindex $models 0]}
    set m [h]; $c GetModelHandle $m $mid
    set r [h]; $m GetResultCtrlHandle $r
    return [list $c $m $r $mid $w]
}

proc ::hvr::frequency {label} {
    if {[regexp -nocase {Frequency\s*=\s*([-+0-9.eE]+)} $label -> value]} {return $value}
    if {[regexp -nocase {Time\s*=\s*([-+0-9.eE]+)} $label -> value]} {return $value}
    return ""
}

proc ::hvr::axis {label} {
    if {[regexp -nocase {Frequency\s*=} $label]} {return frequency}
    if {[regexp -nocase {Time\s*=} $label]} {return time}
    return label
}

proc ::hvr::step_value {d} {
    switch [dict get $d axis] {
        frequency {return "[dict get $d freq] Hz"}
        time {return "[dict get $d freq] s"}
        default {return [dict get $d label]}
    }
}

# Reads every window of the active page: one row per subcase and simulation.
proc ::hvr::scan {} {
    variable rowData
    variable rows
    variable types
    array unset rowData
    set rows {}
    set types {}
    stack {
        lassign [page_handles] s p pg
        set count [$pg GetNumberOfWindows]
        for {set wi 1} {$wi <= $count} {incr wi} {
            set handles [window_handles $pg $wi]
            if {![llength $handles]} {continue}
            lassign $handles c m r mid w
            set modelFile [$m GetFileName]
            set resultFile [$m GetResultFileName]
            set model [file rootname [file tail $modelFile]]
            foreach sc [$r GetSubcaseList] {
                if {![llength $types]} {set types [$r GetDataTypeList $sc]}
                set subcase [string trim [$r GetSubcaseLabel $sc]]
                set n [$r GetNumberOfSimulations $sc]
                for {set idx 0} {$idx < $n} {incr idx} {
                    set label [string trim [$r GetSimulationLabel $sc $idx]]
                    set key r[llength $rows]
                    set rowData($key) [dict create win $wi model $model sc $sc subcase $subcase \
                        idx $idx label $label freq [frequency $label] axis [axis $label] \
                        modelFile $modelFile resultFile $resultFile]
                    lappend rows $key
                }
            }
        }
    }
    return [llength $rows]
}

proc ::hvr::component_list {type} {
    set out {}
    catch {
        stack {
            lassign [page_handles] s p pg
            set count [$pg GetNumberOfWindows]
            for {set wi 1} {$wi <= $count && ![llength $out]} {incr wi} {
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {continue}
                lassign $handles c m r
                set sc [$r GetCurrentSubcase]
                set out [$r GetDataComponentList $sc $type]
            }
        }
    }
    return $out
}

# Applies the current preset fields to one window. Handles come from window_handles.
proc ::hvr::apply_window {c m r {settings ""}} {
    if {$settings eq ""} {variable P} else {array set P $settings}
    set notes {}
    set sc [$r GetCurrentSubcase]
    set ro [h]; $c GetRenderOptionsHandle $ro
    $ro SetBackgroundColor "255 255 255" "255 255 255"
    $ro SetForegroundColor "0 0 0"
    set ct [h]; $r GetContourCtrlHandle $ct
    if {$P(resultType) in [$r GetDataTypeList $sc]} {
        $ct SetDataType $P(resultType)
        if {$P(component) in [$r GetDataComponentList $sc $P(resultType)]} {
            $ct SetDataComponent $P(component)
        } elseif {$P(component) ne ""} {
            lappend notes "component '$P(component)' not available"
        }
    } else {
        lappend notes "result '$P(resultType)' not available"
    }
    # Own the component set so applying the report does not edit an existing user selection set.
    if {![llength $notes]} {
        set setId ""
        foreach candidate [$m GetSelectionSetList] {
            set sel [h]; $m GetSelectionSetHandle $sel $candidate
            if {[$sel GetLabel] eq "HyperView Report - All Components" && [$sel GetType] in {component part}} {
                set setId $candidate
                break
            }
        }
        if {$setId eq ""} {
            set setId [$m AddSelectionSet component]
            set sel [h]; $m GetSelectionSetHandle $sel $setId
            $sel SetLabel "HyperView Report - All Components"
        }
        $sel Clear
        $sel Add all
        set expected [$m GetNumberOfComponents]
        if {$expected < 1 || [$sel GetSize] != $expected || [$ct SetSelectionSet $setId] != 0} {
            error "Could not apply the contour to all $expected components."
        }
    } else {
        return $notes
    }
    $ct SetEnableState true
    $c SetDisplayOptions contour true
    $c SetDisplayOptions legend true
    set lg [h]; $ct GetLegendHandle $lg
    set fixed [expr {$P(legendMax) ne "" || $P(legendMin) ne ""}]
    $lg SetType [expr {$fixed ? "user" : "dynamic"}]
    $lg SetNumberOfColors $P(legendLevels)
    $lg SetNumericFormat $P(legendFormat)
    $lg SetNumericPrecision $P(legendPrecision)
    $lg SetPosition $P(legendPosition)
    if {$fixed} {
        # The legend only accepts fixed values once the contour has been drawn.
        $c Draw
        if {$P(legendMin) ne ""} {$lg SetMin $P(legendMin)}
        if {$P(legendMax) ne ""} {$lg SetMax $P(legendMax)}
        if {$P(legendMin) ne "" && $P(legendMax) ne ""} {
            # Write every level so the scale is identical in all windows and steps.
            set n $P(legendLevels)
            for {set i 0} {$i <= $n} {incr i} {
                $lg OverrideValue $i [expr {$P(legendMin) + ($P(legendMax) - $P(legendMin)) * double($i) / $n}]
            }
        }
    }
    $lg SetTransparency true
    $lg SetMinMaxVisibility true
    foreach getter {GetNumberAttributeHandle GetTitleAttributeHandle GetHeaderAttributeHandle GetFooterAttributeHandle} {
        set attr [h]
        if {![catch {$lg $getter $attr}]} {catch {$attr SetColor "0 0 0"}}
    }
    if {[string is double -strict $P(scale)]} {
        set scale [h]; $r GetScaleCtrlHandle $scale
        $scale SetScale "$P(scale) $P(scale) $P(scale)"
    }
    set noteIds [$c GetNoteList]
    if {![llength $noteIds] && $P(noteShow)} {set noteIds [list [$c AddNote]]}
    if {[llength $noteIds]} {
        set n [h]; $c GetNoteHandle $n [lindex $noteIds 0]
        $n SetVisibility [expr {$P(noteShow) ? "true" : "false"}]
        if {$P(noteShow)} {
            $n SetText [string map [list "\\n" "\n"] $P(noteText)]
            $n SetTextColor "0 0 0"
            $n SetBackgroundColor "255 255 255"
            $n SetColor "0 0 0"
        }
    }
    $c SetDisplayOptions notes [expr {$P(noteShow) ? "true" : "false"}]
    $c Draw
    return $notes
}

proc ::hvr::apply_view_window {w c name fit} {
    variable standardViews
    set v [h]; $w GetViewControlHandle $v
    if {$name in $standardViews} {
        $v SetOrientation $name
        $v Fit
    } else {
        set views [read_dict [views_file]]
        if {![dict exists $views $name]} {error "View '$name' is not saved."}
        $v SetViewMatrix [dict get $views $name matrix]
        if {$fit} {$v Fit} else {$v SetOrtho [dict get $views $name ortho]}
    }
    $c Draw
}

proc ::hvr::apply_all {} {
    variable P
    variable viewName
    variable viewFit
    if {![validate]} {return 0}
    set applied 0
    set notes {}
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set count [$pg GetNumberOfWindows]
            for {set wi 1} {$wi <= $count} {incr wi} {
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {continue}
                lassign $handles c m r mid w
                set windowNotes [apply_window $c $m $r]
                foreach note $windowNotes {lappend notes "window $wi: $note"}
                apply_view_window $w $c $viewName $viewFit
                if {![llength $windowNotes]} {incr applied}
            }
        }
    } err]
    if {$code} {say "Apply failed: $err"; return 0}
    if {!$applied} {
        say [expr {[llength $notes] ? [join $notes {; }] : "No model in the active page. Load models first."}]
        return 0
    }
    # From now on exports and step previews keep these settings on screen.
    variable appliedSettings [array get P]
    if {[llength $notes]} {say "Applied to $applied window(s); [join $notes {; }]"} else {say "Applied to $applied window(s)"}
    return 1
}

# Fills the settings fields from what the first window with a model really shows.
proc ::hvr::read_window_settings {} {
    variable P
    set found 0
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set order [concat [$pg GetActiveWindow] {1 2 3 4 5 6 7 8 9}]
            foreach wi $order {
                if {$wi > [$pg GetNumberOfWindows]} {continue}
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {continue}
                lassign $handles c m r
                set ct [h]; $r GetContourCtrlHandle $ct
                if {[string is true [$ct GetEnableState]]} {
                    set P(resultType) [$ct GetDataType]
                    set P(component) [$ct GetDataComponent]
                }
                set lg [h]; $ct GetLegendHandle $lg
                set position [string map {" " ""} [$lg GetPosition]]
                if {$position in {upperleft upperright lowerleft lowerright}} {set P(legendPosition) $position}
                if {[$lg GetNumericFormat] in {scientific fixed auto}} {set P(legendFormat) [$lg GetNumericFormat]}
                set P(legendPrecision) [$lg GetNumericPrecision]
                set n [$lg GetNumberOfColors]
                set P(legendLevels) $n
                # A legend range counts as fixed only when its end values were typed in.
                set P(legendMin) ""
                set P(legendMax) ""
                if {[string is true [$lg IsValueOverriden 0]]} {set P(legendMin) [format %.6g [string trim [$lg GetValue 0]]]}
                if {[string is true [$lg IsValueOverriden $n]]} {set P(legendMax) [format %.6g [string trim [$lg GetValue $n]]]}
                set scale [h]; $r GetScaleCtrlHandle $scale
                set P(scale) [format %g [lindex [$scale GetScale] 0]]
                set noteIds [$c GetNoteList]
                if {[llength $noteIds]} {
                    set note [h]; $c GetNoteHandle $note [lindex $noteIds 0]
                    set P(noteShow) [expr {[string is true [$note GetVisibility]] && [string is true [$c GetDisplayOptions notes]]}]
                    set P(noteText) [$note GetText]
                } else {
                    set P(noteShow) 0
                }
                set found $wi
                break
            }
        }
    } err]
    if {$code} {say "Could not read the window settings: $err"; return 0}
    if {!$found} {return 0}
    refresh_components
    note_to_widget
    say "Settings read from window $found"
    return $found
}

# Sets how many windows the active page shows.
proc ::hvr::set_window_count {} {
    variable windowCount
    variable layoutFor
    if {![dict exists $layoutFor $windowCount]} {return}
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            $pg SetLayout [dict get $layoutFor $windowCount]
            set windowCount [$pg GetNumberOfWindows]
        }
    } err]
    if {$code} {say "Could not change the layout: $err"; return}
    refresh
    say "The page now has $windowCount window(s)"
}

proc ::hvr::read_window_count {} {
    variable windowCount
    catch {
        stack {
            lassign [page_handles] s p pg
            set windowCount [$pg GetNumberOfWindows]
        }
    }
}

proc ::hvr::validate {} {
    variable P
    foreach {key label} {legendMax "Legend max" legendMin "Legend min"} {
        if {$P($key) ne "" && ![string is double -strict $P($key)]} {say "$label must be a number or empty."; return 0}
    }
    if {$P(legendMax) ne "" && $P(legendMin) ne "" && $P(legendMax) <= $P(legendMin)} {
        say "Legend max must be greater than legend min."; return 0
    }
    if {![string is double -strict $P(scale)]} {say "Deformed scale must be a number."; return 0}
    if {![string is integer -strict $P(frames)] || $P(frames) < 2 || $P(frames) > 200} {say "Frames must be an integer from 2 to 200."; return 0}
    if {![string is integer -strict $P(gifScale)] || $P(gifScale) < 50 || $P(gifScale) > 400} {say "GIF size must be from 50 to 400 percent."; return 0}
    if {![string is integer -strict $P(legendLevels)] || $P(legendLevels) < 2 || $P(legendLevels) > 32} {say "Legend levels must be from 2 to 32."; return 0}
    if {![string is integer -strict $P(legendPrecision)] || $P(legendPrecision) < 0 || $P(legendPrecision) > 10} {say "Legend precision must be from 0 to 10."; return 0}
    return 1
}

# ---------------------------------------------------------------- views

proc ::hvr::views_file {} {
    variable dir
    return [file join $dir settings views.dict]
}

proc ::hvr::view_names {} {
    variable standardViews
    return [concat $standardViews [lsort -dictionary [dict keys [read_dict [views_file]]]]]
}

proc ::hvr::save_view {} {
    variable viewName
    variable standardViews
    set name [ask_name "Save view" "View name" [expr {$viewName in $standardViews ? "" : $viewName}]]
    if {$name eq ""} {return}
    if {$name in $standardViews} {say "'$name' is a standard view name."; return}
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set wi [$pg GetActiveWindow]
            set w [h]; $pg GetWindowHandle $w $wi
            set v [h]; $w GetViewControlHandle $v
            set entry [dict create matrix [$v GetViewMatrix] ortho [$v GetOrtho]]
        }
    } err]
    if {$code} {say "Save view failed: $err"; return}
    set views [read_dict [views_file]]
    dict set views $name $entry
    write_dict [views_file] $views
    set viewName $name
    refresh_view_list
    # The highlighted view line now uses the view that was just saved.
    variable planView $name
    plan_edited
    say "Saved view '$name' from the active window"
}

proc ::hvr::delete_view {} {
    variable viewName
    variable standardViews
    if {$viewName in $standardViews} {say "Standard views cannot be deleted."; return}
    set views [read_dict [views_file]]
    if {![dict exists $views $viewName]} {return}
    write_dict [views_file] [dict remove $views $viewName]
    set deleted $viewName
    set viewName iso
    refresh_view_list
    variable planView iso
    plan_edited
    say "Deleted view '$deleted'. Lines that used it need another view."
}

proc ::hvr::apply_view {} {
    variable viewName
    variable viewFit
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set count [$pg GetNumberOfWindows]
            for {set wi 1} {$wi <= $count} {incr wi} {
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {continue}
                lassign $handles c m r mid w
                apply_view_window $w $c $viewName $viewFit
            }
        }
    } err]
    if {$code} {say "Apply view failed: $err"} else {say "Applied view '$viewName'"}
}

# ---------------------------------------------------------------- presets

proc ::hvr::preset_dir {} {
    variable dir
    return [file join $dir settings presets]
}

proc ::hvr::preset_names {} {
    set names {}
    foreach path [glob -nocomplain -directory [preset_dir] *.dict] {lappend names [file rootname [file tail $path]]}
    return [lsort -dictionary $names]
}

proc ::hvr::save_preset {{ask 0}} {
    variable P
    variable presetName
    variable viewName
    note_from_widget
    set name $presetName
    if {$ask || $name eq ""} {set name [ask_name "Save preset" "Preset name" $presetName]}
    set name [safe_name $name]
    if {$name eq ""} {return}
    if {![validate]} {return}
    set P(view) $viewName
    write_dict [file join [preset_dir] $name.dict] [array get P]
    set presetName $name
    refresh_preset_list
    say "Saved preset '$name'"
}

proc ::hvr::load_preset {} {
    variable P
    variable presetName
    variable defaults
    variable viewName
    set data [read_dict [file join [preset_dir] $presetName.dict]]
    if {![llength $data]} {say "Preset '$presetName' not found."; return 0}
    array set P $defaults
    foreach {key value} $data {if {[info exists P($key)]} {set P($key) $value}}
    if {$P(view) in [view_names]} {set viewName $P(view)}
    refresh_components
    note_to_widget
    plan_show
    say "Loaded preset '$presetName'"
    return 1
}

proc ::hvr::delete_preset {} {
    variable presetName
    if {$presetName eq ""} {return}
    set path [file join [preset_dir] $presetName.dict]
    if {![file isfile $path]} {return}
    if {[tk_messageBox -parent $::hvr::win -type yesno -icon question -message "Delete preset '$presetName'?"] ne "yes"} {return}
    file delete $path
    say "Deleted preset '$presetName'"
    set presetName ""
    refresh_preset_list
}

proc ::hvr::apply_preset {} {
    note_from_widget
    apply_all
}

# ---------------------------------------------------------------- model loading

proc ::hvr::load_models {} {
    variable win
    variable layoutFor
    set files [tk_getOpenFile -parent $win -multiple 1 -title "Load result models" \
        -filetypes {{"Result files" {.op2 .h3d}} {"All files" *}}]
    if {![llength $files]} {return}
    load_files $files
}

proc ::hvr::load_files {files} {
    variable layoutFor
    set loaded 0
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set count [$pg GetNumberOfWindows]
            set free {}
            set used 0
            for {set wi 1} {$wi <= $count} {incr wi} {
                if {[llength [window_handles $pg $wi]]} {incr used} else {lappend free $wi}
            }
            set need [expr {$used + [llength $files]}]
            if {$need > 9} {error "A page holds at most 9 windows ($used already used)."}
            if {$need > $count} {
                $pg SetLayout [dict get $layoutFor $need]
                set count [$pg GetNumberOfWindows]
                set free {}
                for {set wi 1} {$wi <= $count} {incr wi} {
                    if {![llength [window_handles $pg $wi]]} {lappend free $wi}
                }
            }
            foreach path $files wi [lrange $free 0 [expr {[llength $files] - 1}]] {
                say "Loading [file tail $path] into window $wi..."
                $pg SetActiveWindow $wi
                set w [h]; $pg GetWindowHandle $w $wi
                $w SetClientType Animation
                set c [h]; $w GetClientHandle $c
                set mid [$c AddModel $path]
                set m [h]; $c GetModelHandle $m $mid
                $m SetResult $path
                $c Draw
                incr loaded
            }
        }
    } err]
    if {$code} {say "Load failed after $loaded model(s): $err"} else {say "Loaded $loaded model(s)"}
    refresh
    return $loaded
}

# ---------------------------------------------------------------- table

proc ::hvr::refresh {} {
    variable types
    variable win
    variable checked
    if {[catch {scan} count]} {say "Could not read the active page: $count"; return}
    array unset checked
    variable tableRows [dict create]
    variable tokenKeys [dict create]
    variable rows
    variable rowData
    foreach key $rows {dict set tokenKeys [step_token $rowData($key)] $key}
    if {[winfo exists $win.left.result.type]} {$win.left.result.type configure -values $types}
    refresh_components
    read_window_count
    fill_table
    # The first time models are found, start the settings from what their window shows.
    variable settingsRead
    if {$count && !$settingsRead && [winfo exists $win.left.result.type]} {
        set settingsRead 1
        read_window_settings
        say "$count result step(s) listed"
    }
    if {!$count} {say "No model in the active page. Use Load models."}
}

proc ::hvr::refresh_components {} {
    variable P
    variable win
    if {![winfo exists $win.left.result.comp]} {return}
    $win.left.result.comp configure -values [component_list $P(resultType)]
}

proc ::hvr::type_changed {} {
    variable P
    variable win
    set values [component_list $P(resultType)]
    if {[winfo exists $win.left.result.comp]} {$win.left.result.comp configure -values $values}
    if {$P(component) ni $values} {set P(component) [lindex $values 0]}
}

proc ::hvr::check_glyph {key} {
    variable checked
    variable checkNative
    if {$checkNative} {return [info exists checked($key)]}
    return [expr {[info exists checked($key)] ? "☑" : "☐"}]
}

# Adds grid lines to every cell style (styles are shared by all rows, so one row is enough).
proc ::hvr::table_decorate {raw row} {
    if {"hvr_grid" ni [$raw element names]} {
        $raw element create hvr_grid rect -outline #c8c8c8 -outlinewidth 1 -open nw
    }
    foreach column [$raw column list] {
        set style [$raw item style set $row [$raw column id $column]]
        set elements [$raw style elements $style]
        if {$style eq "" || "hvr_grid" in $elements} {continue}
        $raw style elements $style [concat $elements hvr_grid]
        $raw style layout $style hvr_grid -union $elements -iexpand xy -detach yes
    }
}

proc ::hvr::fill_table {} {
    variable rows
    variable rowData
    variable filter
    variable tableRows
    variable keyItems
    variable win
    set table $win.right.table
    if {![winfo exists $table]} {return}
    set raw [$table component treectrl]
    $raw item delete all
    set tableRows [dict create]
    set keyItems [dict create]
    variable drawnChecks
    array unset drawnChecks
    set shown 0
    set needle [string tolower [string trim $filter]]
    variable rangeText
    variable rangeBy
    set rangeError ""
    if {[catch {parse_ranges $rangeText} ranges]} {set rangeError $ranges; set ranges {}}
    foreach key $rows {
        set d $rowData($key)
        if {![in_ranges $d $rangeBy $ranges]} {continue}
        set text [string tolower "[dict get $d win] [dict get $d model] [dict get $d subcase] [dict get $d label]"]
        set ok 1
        foreach word [split $needle] {
            if {$word ne "" && [string first $word $text] < 0} {set ok 0; break}
        }
        if {!$ok} {continue}
        set item [$table item create -parent 0 -values [list chk [check_glyph $key] win [dict get $d win] \
            model [dict get $d model] mode [expr {[dict get $d idx] + 1}] freq [step_value $d] \
            label [dict get $d label] subcase [dict get $d subcase]]]
        dict set tableRows $item $key
        dict set keyItems $key $item
        set drawnChecks($key) [check_glyph $key]
        if {!$shown} {catch {table_decorate $raw $item}}
        incr shown
    }
    if {$rangeError ne ""} {say $rangeError} else {say "$shown of [llength $rows] result step(s) shown"}
    plan_show [plan_index]
}

# Rows highlighted in the table (sweep, Ctrl or Shift), in table order.
proc ::hvr::selected_keys {} {
    variable tableRows
    variable win
    set raw [$win.right.table component treectrl]
    # Item ids grow in table order, so sorting them gives the rows top to bottom.
    set keys {}
    foreach item [lsort -integer [$raw selection get]] {
        if {[dict exists $tableRows $item]} {lappend keys [dict get $tableRows $item]}
    }
    return $keys
}

# Shows the checked() array in the check column of the rows on screen.
proc ::hvr::redraw_checks {} {
    variable keyItems
    variable drawnChecks
    variable win
    set table $win.right.table
    if {![winfo exists $table]} {return}
    dict for {key item} $keyItems {
        set value [check_glyph $key]
        if {[info exists drawnChecks($key)] && $drawnChecks($key) eq $value} {continue}
        $table item configure $item -values [list chk $value]
        set drawnChecks($key) $value
    }
}

# Sweep selection. Every cell is "sensitive" so a click anywhere selects its row, and TreeCtrl
# then treats a drag as drag-and-drop; the sweep is therefore handled here.
proc ::hvr::sweep_start {x y} {
    variable sweepAnchor ""
    variable sweepLast ""
    variable win
    set hit [[$win.right.table component treectrl] identify $x $y]
    if {[lindex $hit 0] eq "item"} {set sweepAnchor [lindex $hit 1]}
}

proc ::hvr::sweep_move {x y add} {
    variable sweepAnchor
    variable sweepLast
    variable win
    # Not sweeping rows (for example dragging a column edge in the header): leave it to the table.
    if {![info exists sweepAnchor] || $sweepAnchor eq ""} {return 0}
    set raw [$win.right.table component treectrl]
    # Keep sweeping past the top or bottom edge.
    if {$y < 0} {$raw yview scroll -1 units} elseif {$y > [winfo height $raw]} {$raw yview scroll 1 units}
    if {[catch {$raw item id [list nearest $x $y]} item] || $item eq "" || $item eq $sweepLast} {return 1}
    set sweepLast $item
    set range [$raw item range $sweepAnchor $item]
    if {$add} {$raw selection add $sweepAnchor $item} else {$raw selection modify $range all}
    # Paint the swept range now: mouse moves keep the event loop too busy for the idle redraw.
    update idletasks
    return 1
}

# Button released: when rows were swept, keep them. Releasing on a row that was already selected
# makes TreeCtrl reduce the selection to that row, so the swept range is put back afterwards.
proc ::hvr::sweep_end {} {
    variable sweepAnchor
    variable sweepLast
    variable win
    if {![info exists sweepAnchor] || $sweepAnchor eq "" || $sweepLast eq "" || $sweepLast eq $sweepAnchor} {
        set sweepAnchor ""
        return
    }
    set raw [$win.right.table component treectrl]
    set keep [$raw selection get]
    set sweepAnchor ""
    after idle [list ::hvr::sweep_restore $keep]
}

proc ::hvr::sweep_restore {items} {
    variable win
    set table $win.right.table
    if {![winfo exists $table]} {return}
    set raw [$table component treectrl]
    set alive {}
    foreach item $items {if {[$raw item id $item] ne ""} {lappend alive $item}}
    if {[llength $alive]} {$raw selection modify $alive all}
}

# Space bar: check or uncheck the highlighted rows.
proc ::hvr::toggle_selected {} {
    variable checked
    set keys [selected_keys]
    if {![llength $keys]} {return}
    set_checks $keys [expr {![info exists checked([lindex $keys 0])]}]
}

proc ::hvr::checked_keys {} {
    variable rows
    variable checked
    set keys {}
    foreach key $rows {if {[info exists checked($key)]} {lappend keys $key}}
    return $keys
}

# Rows that Export works on: checked rows, or the highlighted rows when nothing is checked.
proc ::hvr::export_keys {} {
    set keys [checked_keys]
    if {![llength $keys]} {set keys [selected_keys]}
    return $keys
}

proc ::hvr::set_checks {keys value} {
    variable checked
    foreach key $keys {
        if {$value} {set checked($key) 1} else {unset -nocomplain checked($key)}
    }
    redraw_checks
    plan_store
    update_counts
}

# A click in the check column toggles that row, or every highlighted row when it is one of them.
proc ::hvr::table_clicked {x y} {
    variable tableRows
    variable checked
    variable win
    set table $win.right.table
    set raw [$table component treectrl]
    set hit [$raw identify $x $y]
    if {[lindex $hit 0] ne "item" || [lindex $hit 2] ne "column"} {return}
    set item [lindex $hit 1]
    if {[lindex $hit 3] != [$table column id chk] || ![dict exists $tableRows $item]} {return}
    set key [dict get $tableRows $item]
    set value [expr {![info exists checked($key)]}]
    set keys [selected_keys]
    if {$key ni $keys} {set keys [list $key]}
    set_checks $keys $value
}

# TreeCtrl selects a row only when the click lands on a "sensitive" element; make every cell sensitive.
proc ::hvr::table_sensitive {} {
    variable win
    set raw [$win.right.table component treectrl]
    set row [lindex [$raw item children root] 0]
    if {$row eq ""} {return}
    set list {}
    foreach column [$raw column list] {
        set id [$raw column id $column]
        set style [$raw item style set $row $id]
        lappend list [concat [list $id $style] [$raw style elements $style]]
    }
    ::TreeCtrl::SetSensitive $raw $list
}

proc ::hvr::shown_keys {} {
    variable tableRows
    return [dict values $tableRows]
}

proc ::hvr::update_counts {} {
    variable summary
    variable rowData
    variable win
    if {![winfo exists $win.right.table]} {return}
    variable planView
    set text "View '$planView': [llength [checked_keys]] step(s) checked"
    if {[catch {export_jobs} jobs]} {
        append text "   |   $jobs"
    } else {
        set steps 0
        if {![catch {h3d_groups $jobs} groups]} {
            dict for {source items} $groups {incr steps [dict size $items]}
        }
        append text "   |   All views: [llength $jobs] GIF(s), $steps H3D step(s)"
    }
    set summary $text
}

proc ::hvr::table_menu {x y X Y} {
    variable win
    set tree [$win.right.table component treectrl]
    set hit [$tree identify $x $y]
    if {[lindex $hit 0] eq "item"} {
        set item [lindex $hit 1]
        if {$item ni [$tree selection get]} {
            $tree selection clear
            $tree selection add $item
        }
    }
    set menu $win.tablemenu
    catch {destroy $menu}
    menu $menu -tearoff 0
    set n [llength [selected_keys]]
    $menu add command -label "Check selected ($n)" -command {::hvr::set_checks [::hvr::selected_keys] 1}
    $menu add command -label "Uncheck selected ($n)" -command {::hvr::set_checks [::hvr::selected_keys] 0}
    $menu add separator
    $menu add command -label "Check all shown" -command {::hvr::set_checks [::hvr::shown_keys] 1}
    $menu add command -label "Uncheck all" -command {::hvr::set_checks $::hvr::rows 0}
    $menu add separator
    $menu add command -label "Show in window" -command ::hvr::show_selected
    if {!$n} {foreach index {0 1 6} {$menu entryconfigure $index -state disabled}}
    tk_popup $menu $X $Y
}

# Displays the first highlighted step in its window with the current settings.
proc ::hvr::show_selected {} {
    set keys [selected_keys]
    if {![llength $keys]} {say "Select a row first."; return 0}
    return [show_step [lindex $keys 0]]
}

proc ::hvr::show_step {key} {
    variable rowData
    note_from_widget
    if {![validate]} {return 0}
    set d $rowData($key)
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set wi [dict get $d win]
            $pg SetActiveWindow $wi
            set handles [window_handles $pg $wi]
            if {![llength $handles]} {error "Window $wi has no model any more. Press Refresh."}
            lassign $handles c m r mid w
            $r SetCurrentSubcase [dict get $d sc]
            $r SetCurrentSimulation [dict get $d idx]
            # Settings are re-applied only after Apply was pressed; otherwise the window stays as it is.
            variable appliedSettings
            if {$appliedSettings ne ""} {apply_window $c $m $r $appliedSettings} else {$c Draw}
        }
    } err]
    if {$code} {say "Show failed: $err"; return 0}
    say "Window [dict get $d win]: [dict get $d label]"
    return 1
}

# Fills the fixed max/min fields from the legend of the active window.
proc ::hvr::legend_from_current {} {
    variable P
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set handles [window_handles $pg [$pg GetActiveWindow]]
            if {![llength $handles]} {error "The active window has no model."}
            lassign $handles c m r
            set ct [h]; $r GetContourCtrlHandle $ct
            set lg [h]; $ct GetLegendHandle $lg
            set n [$lg GetNumberOfColors]
            set values [list [string trim [$lg GetValue 0]] [string trim [$lg GetValue $n]]]
        }
    } err]
    if {$code} {say "Could not read the legend: $err"; return 0}
    lassign $values low high
    if {![string is double -strict $low] || ![string is double -strict $high]} {
        say "The active window has no contour values yet. Press Apply first."
        return 0
    }
    set P(legendMin) [format %.6g $low]
    set P(legendMax) [format %.6g $high]
    say "Legend range read from the active window"
    return 1
}

proc ::hvr::legend_auto {} {
    variable P
    set P(legendMin) ""
    set P(legendMax) ""
    say "Legend range is automatic for each step"
}

proc ::hvr::gif_name {d {view ""}} {
    variable P
    variable viewName
    if {$view eq ""} {set view $viewName}
    set parts {}
    if {[safe_name $P(prefix)] ne ""} {lappend parts [safe_name $P(prefix)]}
    lappend parts [safe_name [dict get $d model]] [safe_name $view] W[dict get $d win] SC[dict get $d sc] \
        M[format %03d [expr {[dict get $d idx] + 1}]]
    set freq [dict get $d freq]
    if {[dict get $d axis] eq "frequency" && [string is double -strict $freq]} {
        lappend parts [format %.4g $freq]Hz
    } elseif {[dict get $d axis] eq "time" && [string is double -strict $freq]} {
        lappend parts [format %.4g $freq]s
    } else {
        lappend parts [safe_name [dict get $d label]]
    }
    return [join $parts _].gif
}

# Parses "1-10 50-100 7" into a flat {low high ...} list; raises an error on a bad token.
proc ::hvr::parse_ranges {text} {
    set ranges {}
    foreach token [regexp -all -inline {\S+} $text] {
        if {[regexp {^([0-9.]+(?:[eE][-+]?[0-9]+)?)-([0-9.]+(?:[eE][-+]?[0-9]+)?)$} $token -> low high] && [string is double -strict $low] && [string is double -strict $high] && $low <= $high} {
            lappend ranges $low $high
        } elseif {[string is double -strict $token]} {
            lappend ranges $token $token
        } else {
            error "Range '$token' is not valid. Use values such as 1-10 50-100."
        }
    }
    return $ranges
}

proc ::hvr::in_ranges {d by ranges} {
    if {![llength $ranges]} {return 1}
    if {$by eq "Freq" && [dict get $d axis] ne "frequency"} {return 0}
    if {$by eq "Time" && [dict get $d axis] ne "time"} {return 0}
    set value [expr {$by eq "Step" ? [dict get $d idx] + 1 : [dict get $d freq]}]
    if {![string is double -strict $value]} {return 0}
    foreach {low high} $ranges {
        if {$value >= $low && $value <= $high} {return 1}
    }
    return 0
}

# ---------------------------------------------------------------- view list

# P(plan) holds one line per exported view: {v2 view title tokens}. A token names a step as
# "window:subcase:step", so a saved plan can be applied to the same kind of models later.
proc ::hvr::step_token {d} {
    return "[dict get $d win]:[dict get $d sc]:[expr {[dict get $d idx] + 1}]"
}

# Brings P(plan) to the current format and keeps at least one line.
proc ::hvr::plan_normalize {} {
    variable P
    variable rows
    variable rowData
    set lines {}
    foreach line $P(plan) {
        if {[lindex $line 0] eq "v2" && [llength $line] == 4} {
            lappend lines $line
        } elseif {[llength $line] == 3} {
            # Older presets stored {view by ranges}: resolve the ranges against the loaded steps.
            lassign $line view by ranges
            set tokens {}
            if {![catch {parse_ranges $ranges} parsed]} {
                foreach key $rows {
                    if {[in_ranges $rowData($key) $by $parsed]} {lappend tokens [step_token $rowData($key)]}
                }
            }
            lappend lines [list v2 $view "" $tokens]
        }
    }
    variable defaultTitle
    if {![llength $lines]} {lappend lines [list v2 iso $defaultTitle {}]}
    set P(plan) $lines
}

# Row keys of the loaded steps that a plan line exports.
proc ::hvr::plan_keys {line} {
    variable tokenKeys
    set keys {}
    foreach token [lindex $line 3] {
        if {[dict exists $tokenKeys $token]} {lappend keys [dict get $tokenKeys $token]}
    }
    return $keys
}

# "1 2 3 7" -> "1-3, 7"
proc ::hvr::compact_numbers {numbers} {
    set parts {}
    set start ""
    foreach n [lsort -integer -unique $numbers] {
        if {$start eq ""} {
            set start $n
        } elseif {$n != $last + 1} {
            lappend parts [expr {$start == $last ? $start : "$start-$last"}]
            set start $n
        }
        set last $n
    }
    if {$start ne ""} {lappend parts [expr {$start == $last ? $start : "$start-$last"}]}
    return [join $parts " "]
}

# Short text of the steps of a plan line, grouped by window: "W1: 1-3, 7   W2: 1-2".
proc ::hvr::plan_modes {line} {
    set byWindow [dict create]
    foreach token [lindex $line 3] {
        lassign [split $token :] wi sc step
        dict lappend byWindow $wi $step
    }
    if {![dict size $byWindow]} {return "(no step checked)"}
    set parts {}
    foreach wi [lsort -integer [dict keys $byWindow]] {
        lappend parts "W$wi: [compact_numbers [dict get $byWindow $wi]]"
    }
    # One window: the mode numbers alone, for example "1 2-5 10".
    if {[dict size $byWindow] == 1} {return [compact_numbers [lindex [dict values $byWindow] 0]]}
    return [join $parts "   "]
}

proc ::hvr::plan_index {} {
    variable win
    set list $win.right.views.list
    if {![winfo exists $list]} {return -1}
    set raw [$list component treectrl]
    set item [lindex [$raw selection get] 0]
    if {$item eq ""} {return -1}
    return [lsearch -exact [$raw item children root] $item]
}

proc ::hvr::plan_row_values {line} {
    lassign $line tag view title
    return [list view $view modes [plan_modes $line] title [string map [list \n " / "] $title]]
}

# Rebuilds the view list and highlights line "select".
proc ::hvr::plan_show {{select -1}} {
    variable P
    variable win
    variable planBusy
    set list $win.right.views.list
    if {![winfo exists $list]} {return}
    plan_normalize
    if {$select < 0} {set select [plan_index]}
    set planBusy 1
    set raw [$list component treectrl]
    $raw item delete all
    set first 1
    foreach line $P(plan) {
        set item [$list item create -parent 0 -values [plan_row_values $line]]
        if {$first} {catch {table_decorate $raw $item}; set first 0}
    }
    set items [$raw item children root]
    set select [expr {min(max(0, $select), [llength $items] - 1)}]
    $raw selection modify [lindex $items $select] all
    set planBusy 0
    plan_selected
}

# TreeCtrl selects a row only when the click lands on a "sensitive" element; make every cell sensitive.
proc ::hvr::tree_sensitive {table} {
    set raw [$table component treectrl]
    set row [lindex [$raw item children root] 0]
    if {$row eq ""} {return}
    set list {}
    foreach column [$raw column list] {
        set id [$raw column id $column]
        set style [$raw item style set $row $id]
        lappend list [concat [list $id $style] [$raw style elements $style]]
    }
    ::TreeCtrl::SetSensitive $raw $list
}

# Double-click on a column edge in the header: fit that column to its content.
# Returns 1 when the double-click was on the header.
proc ::hvr::header_fit {table x y} {
    set raw [$table component treectrl]
    set hit [$raw identify $x $y]
    if {[lindex $hit 0] ne "header"} {return 0}
    set column [lindex $hit 1]
    set columns [$raw column list]
    set side [lindex $hit end]
    if {$column eq "tail"} {
        # The empty header area after the last column: its left edge is the last column's edge.
        if {$side ne "left"} {return 1}
        set column [lindex $columns end]
    } elseif {$side eq "left"} {
        # The left edge of a header belongs to the column before it.
        set index [lsearch -exact $columns $column]
        if {$index < 1} {return 1}
        set column [lindex $columns [expr {$index - 1}]]
    } elseif {$side ne "right"} {
        return 1
    }
    if {$column eq "" || $column ni $columns} {return 1}
    set width [expr {[font measure TkDefaultFont [$raw column cget $column -text]] + 24}]
    foreach item [$raw item children root] {
        set text [$raw item text $item $column]
        set width [expr {max($width, [font measure TkDefaultFont $text] + 16)}]
    }
    $raw column configure $column -width [expr {min($width, 600)}]
    return 1
}

# Double-click in the step table: fit a column (header edge) or show the step (row).
proc ::hvr::table_double {table x y} {
    if {![header_fit $table $x $y]} {after idle ::hvr::show_selected}
    return -code break
}

# Double-click in the view list: fit a column (header edge) or show the view (row).
proc ::hvr::views_double {table x y} {
    if {![header_fit $table $x $y]} {after idle ::hvr::plan_look}
    return -code break
}

# Right-click menu of the view list.
proc ::hvr::views_menu {x y X Y} {
    variable win
    set list $win.right.views.list
    set raw [$list component treectrl]
    set hit [$raw identify $x $y]
    if {[lindex $hit 0] eq "item"} {$raw selection modify [lindex $hit 1] all; update idletasks}
    set menu $win.viewsmenu
    catch {destroy $menu}
    menu $menu -tearoff 0
    $menu add command -label "Show view in HyperView" -command ::hvr::plan_look
    $menu add separator
    $menu add command -label "Add view" -command ::hvr::plan_add
    $menu add command -label "Duplicate (view and checked steps)" -command {::hvr::plan_add 1}
    $menu add command -label "Remove" -command ::hvr::plan_remove
    $menu add separator
    $menu add command -label "Save current HyperView view as..." -command ::hvr::save_view
    $menu add command -label "Delete saved view" -command ::hvr::delete_view
    $menu add separator
    $menu add command -label "Split windows: one view per line" -command ::hvr::split_views
    tk_popup $menu $X $Y
}

# Inserts a native HyperView note field into the picture title.
proc ::hvr::title_insert {field} {
    variable win
    variable planTitleText
    set entry $win.right.views.edit.title
    if {[winfo exists $entry]} {$entry insert insert $field} else {append planTitleText $field}
    plan_edited
}

# Expands a title written with HyperView note fields, such as {window.modeltitle}, for one window.
proc ::hvr::expand_title {c template} {
    if {$template eq ""} {return ""}
    set id [$c AddNote]
    set note [h]; $c GetNoteHandle $note $id
    $note SetVisibility false
    $note SetText $template
    set text [$note GetExpandedText]
    $c RemoveNote $id
    set text [regsub -all {\s*\n\s*} [string trim $text] " | "]
    return [string trim [regsub -all {[ \t]+} $text " "]]
}

# One model, several views: copies the window that holds the model into the other windows
# of the page and gives every window the view of one line of the view list.
proc ::hvr::split_views {} {
    variable P
    variable viewFit
    variable windowCount
    variable layoutFor
    variable standardViews
    set views {}
    foreach line $P(plan) {lappend views [lindex $line 1]}
    set wanted [expr {max(2, [llength $views])}]
    foreach size {2 3 4 6 9} {if {$size >= $wanted} {set wanted $size; break}}
    if {$wanted > 9} {set wanted 9}
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set source 0
            foreach wi [concat [$pg GetActiveWindow] {1 2 3 4 5 6 7 8 9}] {
                if {$wi <= [$pg GetNumberOfWindows] && [llength [window_handles $pg $wi]]} {set source $wi; break}
            }
            if {!$source} {error "Load a model first."}
            $pg SetLayout [dict get $layoutFor $wanted]
            set count [$pg GetNumberOfWindows]
            $pg CopyWindow $source
            for {set wi 1} {$wi <= $count} {incr wi} {
                if {$wi != $source} {$pg PasteWindow $wi}
            }
            for {set wi 1} {$wi <= $count} {incr wi} {
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {continue}
                lassign $handles c m r mid w
                set view [lindex $views [expr {$wi - 1}]]
                if {$view eq ""} {set view [lindex $standardViews [expr {($wi - 1) % [llength $standardViews]}]]}
                apply_view_window $w $c $view $viewFit
            }
        }
    } err]
    if {$code} {say "Split views failed: $err"; return 0}
    refresh
    say "The model of window $source is now shown in $windowCount windows, one view each"
    return 1
}

# A view line was highlighted: its steps become the checked rows of the step table.
proc ::hvr::plan_selected {} {
    variable P
    variable checked
    variable planBusy
    variable planView
    variable planTitleText
    variable viewName
    if {[info exists planBusy] && $planBusy} {return}
    set index [plan_index]
    if {$index < 0} {return}
    set line [lindex $P(plan) $index]
    lassign $line tag planView planTitleText
    set viewName $planView
    array unset checked
    foreach key [plan_keys $line] {set checked($key) 1}
    redraw_checks
    update_counts
}

# Writes the checked rows back into the highlighted view line.
proc ::hvr::plan_store {} {
    variable P
    variable checked
    variable rows
    variable rowData
    variable planView
    variable planTitleText
    variable win
    set index [plan_index]
    if {$index < 0} {return}
    set tokens {}
    foreach key $rows {
        if {[info exists checked($key)]} {lappend tokens [step_token $rowData($key)]}
    }
    # Keep the steps of windows that are not loaded right now, so a saved plan is not trimmed.
    variable tokenKeys
    foreach token [lindex $P(plan) $index 3] {
        if {![dict exists $tokenKeys $token]} {lappend tokens $token}
    }
    set line [list v2 $planView [string trim $planTitleText] $tokens]
    lset P(plan) $index $line
    set list $win.right.views.list
    $list item configure [lindex [[$list component treectrl] item children root] $index] -values [plan_row_values $line]
}

proc ::hvr::plan_add {{copy 0}} {
    variable P
    variable planView
    variable planTitleText
    if {$planView ni [view_names]} {say "Choose a saved or standard view first."; return}
    set index [plan_index]
    set tokens [expr {$copy && $index >= 0 ? [lindex $P(plan) $index 3] : {}}]
    variable defaultTitle
    lappend P(plan) [list v2 $planView [expr {$copy ? [string trim $planTitleText] : $defaultTitle}] $tokens]
    plan_show [expr {[llength $P(plan)] - 1}]
    say [expr {$copy ? "Copied the view line. Pick another view for it." : "Added a view line. Check the steps it should export."}]
}

proc ::hvr::plan_remove {} {
    variable P
    set index [plan_index]
    if {$index < 0} {return}
    set P(plan) [lreplace $P(plan) $index $index]
    plan_show [expr {min($index, [llength $P(plan)] - 1)}]
}

# The view box or the title field of the highlighted line changed.
proc ::hvr::plan_edited {} {
    variable planView
    variable viewName
    set viewName $planView
    plan_store
    update_counts
}

# Puts the view of the highlighted line on screen so it can be checked before exporting.
proc ::hvr::plan_look {} {
    variable planView
    variable viewName
    set viewName $planView
    apply_view
}

# Export jobs as {rowKey view title}, one per checked step of every view line.
proc ::hvr::export_jobs {} {
    variable P
    set jobs [dict create]
    set available [view_names]
    foreach line $P(plan) {
        lassign $line tag view title
        if {$view ni $available} {error "View '$view' is missing. Pick another view for that line."}
        foreach key [plan_keys $line] {
            if {![dict exists $jobs [list $key $view]]} {dict set jobs [list $key $view] [list $key $view $title]}
        }
    }
    return [dict values $jobs]
}

# ---------------------------------------------------------------- export

proc ::hvr::export_state {running {kind gif}} {
    variable win
    variable exporting $running
    variable exportKind $kind
    set f $win.right.export
    if {![winfo exists $f.gif]} {return}
    $f.gif configure -state [expr {$running ? "disabled" : "normal"}]
    $f.pptx configure -state [expr {$running ? "disabled" : "normal"}]
    $f.h3d configure -state [expr {$running ? "disabled" : "normal"}]
    $f.pause configure -state [expr {$running && $kind eq "gif" ? "normal" : "disabled"}] -text Pause
    $f.cancel configure -state [expr {$running && $kind eq "gif" ? "normal" : "disabled"}]
    catch {$win.left.apply configure -state [expr {$running ? "disabled" : "normal"}]}
    if {!$running} {$f.progress configure -value 0}
}

proc ::hvr::export_pause {} {
    variable exportPaused
    variable win
    set exportPaused [expr {!$exportPaused}]
    $win.right.export.pause configure -text [expr {$exportPaused ? "Resume" : "Pause"}]
    if {$exportPaused} {say "Paused. Press Resume to continue or Cancel to stop."}
    set ::hvr::exportSignal 1
}

proc ::hvr::export_cancel {} {
    variable exportCancelled 1
    set ::hvr::exportSignal 1
}

proc ::hvr::close_tool {} {
    variable win
    variable exporting
    variable exportKind
    if {[info exists exporting] && $exporting && $exportKind eq "gif"} {export_cancel}
    destroy $win
}

proc ::hvr::export_gifs {{jobs ""}} {
    variable P
    variable rowData
    variable lastGifs
    variable viewFit
    variable exporting
    variable exportPaused 0
    variable exportCancelled 0
    variable win
    if {[info exists exporting] && $exporting} {say "An export is already running."; return 0}
    note_from_widget
    if {$jobs eq ""} {
        if {[catch {export_jobs} jobs]} {say $jobs; return 0}
    }
    if {![llength $jobs]} {
        say "Nothing to export: check steps for at least one view."
        return 0
    }
    if {![validate]} {return 0}
    if {![ensure_output]} {return 0}
    if {[catch {file mkdir $P(outputDir)} err]} {say "Cannot create output folder: $err"; return 0}
    set made {}
    set records {}
    set settings [array get P]
    array set captureSettings $settings
    variable appliedSettings
    set applied $appliedSettings
    set fit $viewFit
    set names [dict create]
    set captures {}
    foreach job $jobs {
        lassign $job key view title
        set d $rowData($key)
        dict set d title $title
        set name [gif_name $d $view]
        if {[dict exists $names [string tolower $name]]} {
            say "Two jobs resolve to $name. Use distinct view names."
            return 0
        }
        dict set names [string tolower $name] 1
        lappend captures [list $d $view $name]
    }
    set outputDir [file normalize $P(outputDir)]
    set total [llength $jobs]
    set done 0
    export_state 1
    if {[winfo exists $win.right.export.progress]} {$win.right.export.progress configure -maximum $total -value 0}
    set code [catch {
        stack {
            lassign [page_handles] s p pg
            set log [open [file join $outputDir hyperview_report_export.log] a]
            fconfigure $log -translation lf
            foreach capture $captures {
                # Let the Pause and Cancel buttons act between two captures.
                update
                while {$exportPaused && !$exportCancelled} {vwait ::hvr::exportSignal}
                if {$exportCancelled} {break}
                lassign $capture d view name
                set wi [dict get $d win]
                say "Exporting [expr {$done + 1}] of $total: [dict get $d model], $view, [dict get $d label]"
                $pg SetActiveWindow $wi
                set handles [window_handles $pg $wi]
                if {![llength $handles]} {error "Window $wi has no model any more. Press Refresh."}
                lassign $handles c m r mid w
                require_current_row $m $r $d
                $r SetCurrentSubcase [dict get $d sc]
                $r SetCurrentSimulation [dict get $d idx]
                # Display settings are the user's choice: they are re-applied after a step change only
                # when Apply was pressed in Settings; otherwise the window is captured as it is.
                if {$applied ne ""} {
                    set notes [apply_window $c $m $r $applied]
                    if {[llength $notes]} {error "Window $wi: [join $notes {; }]."}
                }
                apply_view_window $w $c $view $fit
                $pg SetAnimationMode $captureSettings(animMode)
                set a [h]; $pg GetAnimatorHandle $a
                $a SetAnimationMode $captureSettings(animMode)
                if {$captureSettings(animMode) ne "transient"} {
                    catch {$a SetIncrementBy frame}
                    $a SetNumberOfFrames $captureSettings(frames)
                }
                $a SetCurrentFrame 0
                $c Draw
                update idletasks
                set gif [file join $outputDir $name]
                set staged [file join $outputDir ".hvr-[pid]-[clock clicks].gif"]
                set rc [$s CaptureAnimationByWindow [expr {$wi - 1}] gif $staged 0 0 1 1 percent $captureSettings(gifScale) $captureSettings(gifScale)]
                if {$rc != 0 || ![file exists $staged] || [file size $staged] == 0} {
                    error "GIF capture failed for [file tail $gif] (return $rc)."
                }
                file rename -force $staged $gif
                lappend made $gif
                # The picture title is expanded by HyperView for this window and step.
                if {[dict exists $d title] && [catch {dict set d title [expand_title $c [dict get $d title]]}]} {dict set d title ""}
                lappend records [manifest_record $gif $d $view]
                incr done
                if {[winfo exists $win.right.export.progress]} {$win.right.export.progress configure -value $done}
                puts $log "[clock format [clock seconds] -format {%Y-%m-%d %H:%M:%S}] window=$wi subcase=[dict get $d sc] step=[dict get $d idx] label={[dict get $d label]} result={$captureSettings(resultType)/$captureSettings(component)} view=$view frames=$captureSettings(frames) gif=$gif bytes=[file size $gif]"
            }
            close $log
        }
    } err]
    catch {close $log}
    if {[info exists staged] && [file exists $staged]} {catch {file delete $staged}}
    set lastGifs $made
    variable lastRecords $records
    if {[llength $records]} {
        catch {
            set f [open [manifest_file $outputDir] a]
            fconfigure $f -encoding utf-8 -translation lf
            foreach record $records {puts $f $record}
            close $f
        }
    }
    if {[winfo exists $win]} {export_state 0}
    if {$code} {say "Export stopped after $done of $total GIF(s): $err"; return 0}
    if {$exportCancelled} {say "Cancelled: $done of $total GIF(s) exported, the rest was skipped."; return $done}
    say "Exported $done GIF(s) to $outputDir"
    return $done
}

proc ::hvr::manifest_file {{outputDir ""}} {
    variable P
    if {$outputDir eq ""} {set outputDir $P(outputDir)}
    return [file join $outputDir hyperview_report_gifs.tsv]
}

# One exported GIF as a tab-separated record: path model view win subcase step value label axis.
proc ::hvr::manifest_record {gif d view} {
    set fields [list $gif [dict get $d model] $view [dict get $d win] [dict get $d sc] \
        [expr {[dict get $d idx] + 1}] [dict get $d freq] [dict get $d label] [dict get $d axis] \
        [expr {[dict exists $d title] ? [dict get $d title] : ""}]]
    set clean {}
    foreach field $fields {lappend clean [string map [list \t " " \n " "] $field]}
    return [join $clean \t]
}

proc ::hvr::export_pptx {} {
    variable P
    variable lastRecords
    variable dir
    variable python
    note_from_widget
    if {![ensure_output]} {return 0}
    foreach {key label} {pptCols "Columns" pptRows "Rows"} {
        if {![string is integer -strict $P($key)] || $P($key) < 1 || $P($key) > 6} {say "$label must be from 1 to 6."; return 0}
    }
    set records {}
    if {$P(pptSource) eq "last"} {
        set records $lastRecords
    } elseif {[file isfile [manifest_file]]} {
        set f [open [manifest_file] r]
        fconfigure $f -encoding utf-8
        # Keep the newest record of each file that still exists.
        set byPath [dict create]
        foreach line [split [read $f] \n] {
            set path [lindex [split $line \t] 0]
            if {$path ne "" && [file isfile $path]} {dict set byPath $path $line}
        }
        close $f
        set records [dict values $byPath]
    }
    if {![llength $records]} {
        say [expr {$P(pptSource) eq "last" ? "No GIF from this session yet. Export GIFs first, or use all GIFs of the folder." : "No exported GIF is recorded in this folder."}]
        return 0
    }
    if {![file isfile $python]} {say "Python was not found. Set its path in Settings > Program paths."; return 0}
    set name [safe_name $P(prefix)]
    if {$name eq ""} {set name hyperview_report}
    set out [file join $P(outputDir) $name.pptx]
    set listFile [file join $P(outputDir) hyperview_report_pptx_input.tsv]
    set f [open $listFile w]
    fconfigure $f -encoding utf-8 -translation lf
    foreach record $records {puts $f $record}
    close $f
    say "Writing [file tail $out]..."
    if {[catch {exec $python -B [file join $dir make_pptx.py] $listFile $out \
            $P(pptCols) $P(pptRows) $P(pptOrder) $P(pptGroup) $P(pptHeader)} result]} {
        say "PPTX failed: [lindex [split $result \n] end]"
        return 0
    }
    say "Wrote [file tail $out]: [string trim $result]"
    return 1
}

# Asks for the output folder when none is set yet; returns 0 when the user cancels.
proc ::hvr::ensure_output {} {
    variable P
    if {$P(outputDir) eq ""} {pick_output}
    if {$P(outputDir) eq ""} {say "Export needs an output folder."; return 0}
    return 1
}

proc ::hvr::pick_output {} {
    variable P
    variable win
    set folder [tk_chooseDirectory -parent $win -title "Output folder" -mustexist 0]
    if {$folder ne ""} {set P(outputDir) $folder}
}

# ---------------------------------------------------------------- GUI

proc ::hvr::ask_name {title label initial} {
    variable win
    variable askValue $initial
    variable askDone 0
    set top $win.ask
    catch {destroy $top}
    toplevel $top
    wm title $top $title
    wm transient $top $win
    wm resizable $top 0 0
    ttk::label $top.l -text $label
    ttk::entry $top.e -textvariable ::hvr::askValue -width 32
    ttk::button $top.ok -text OK -width 10 -command {set ::hvr::askDone 1}
    ttk::button $top.cancel -text Cancel -width 10 -command {set ::hvr::askDone 2}
    grid $top.l -row 0 -column 0 -padx {12 6} -pady 12 -sticky w
    grid $top.e -row 0 -column 1 -columnspan 2 -padx {0 12} -pady 12 -sticky ew
    grid $top.ok -row 1 -column 1 -padx {0 6} -pady {0 12} -sticky e
    grid $top.cancel -row 1 -column 2 -padx {0 12} -pady {0 12}
    bind $top <Return> {set ::hvr::askDone 1}
    bind $top <Escape> {set ::hvr::askDone 2}
    wm protocol $top WM_DELETE_WINDOW {set ::hvr::askDone 2}
    center $top $win
    focus $top.e
    grab $top
    vwait ::hvr::askDone
    grab release $top
    destroy $top
    if {$askDone != 1} {return ""}
    return [string trim $askValue]
}

# Use the parent window's position, including signed coordinates on Windows.
proc ::hvr::center {top parent} {
    update idletasks
    lassign [wm minsize $top] minWidth minHeight
    set w [expr {max([winfo reqwidth $top], $minWidth)}]
    set hgt [expr {max([winfo reqheight $top], $minHeight)}]
    set x [expr {[winfo rootx $parent] + ([winfo width $parent] - $w) / 2}]
    set y [expr {[winfo rooty $parent] + ([winfo height $parent] - $hgt) / 2}]
    wm geometry $top +$x+$y
}

proc ::hvr::refresh_preset_list {} {
    variable win
    if {[winfo exists $win.top.preset]} {$win.top.preset configure -values [preset_names]}
}

proc ::hvr::refresh_view_list {} {
    variable win
    if {[winfo exists $win.right.views.edit.view]} {$win.right.views.edit.view configure -values [view_names]}
    update_counts
}

# Widgets -> preset array (display labels are translated to HyperView values).
proc ::hvr::note_from_widget {} {
    variable P
    variable D
    variable labels
    variable win
    foreach key {legendPosition legendFormat animMode pptOrder pptGroup} {
        dict for {value text} [dict get $labels $key] {
            if {[info exists D($key)] && $D($key) eq $text} {set P($key) $value}
        }
    }
    if {[winfo exists $win.left.note.text]} {set P(noteText) [string trimright [$win.left.note.text get 1.0 end]]}
}

# Preset array -> widgets.
proc ::hvr::note_to_widget {} {
    variable P
    variable D
    variable labels
    variable win
    foreach key {legendPosition legendFormat animMode pptOrder pptGroup} {
        if {[dict exists $labels $key $P($key)]} {set D($key) [dict get $labels $key $P($key)]}
    }
    if {![winfo exists $win.left.note.text]} {return}
    $win.left.note.text delete 1.0 end
    $win.left.note.text insert 1.0 [string map [list "\\n" "\n"] $P(noteText)]
}

# A settings section: a bold heading with a rule under it; the fields go on the rows below.
proc ::hvr::section {path title} {
    ttk::frame $path
    ttk::label $path.heading -text $title -font TkHeadingFont
    ttk::separator $path.rule -orient horizontal
    grid $path.heading -row 0 -column 0 -sticky w
    grid $path.rule -row 0 -column 1 -columnspan 3 -sticky ew -padx {8 0}
    grid columnconfigure $path 0 -minsize 104
    grid columnconfigure $path 3 -weight 1
    return $path
}

# One labelled field of a section; "pair" 2 puts it in the second label/field pair of the row.
proc ::hvr::form {parent row label widget {span 1} {pair 1}} {
    set column [expr {($pair - 1) * 2}]
    set name $parent.l${row}_$pair
    ttk::label $name -text $label
    grid $name -row $row -column $column -sticky w -padx [expr {$pair == 1 ? {0 10} : {24 10}}] -pady 2
    grid $widget -row $row -column [expr {$column + 1}] -columnspan $span -sticky w -pady 2
}
proc ::hvr::field {parent row label widget} {
    ttk::label $parent.l$row -text $label
    grid $parent.l$row -row $row -column 0 -sticky w -padx {8 6} -pady 2
    grid $widget -row $row -column 1 -sticky ew -padx {0 8} -pady 2
}

proc ::hvr::show {} {
    package require hwtk
    variable win
    variable P
    variable D
    variable labels
    variable summary ""
    variable planView iso
    variable planTitleText ""
    variable planBusy 0
    variable appliedSettings ""
    variable lastRecords
    if {![info exists lastRecords]} {set lastRecords {}}
    set labels [dict create \
        legendPosition {upperleft "Upper left" upperright "Upper right" lowerleft "Lower left" lowerright "Lower right"} \
        legendFormat {scientific Scientific fixed Fixed auto Auto} \
        animMode {modal Modal linear Linear transient Transient} \
        pptOrder {row "Left to right" column "Top to bottom"} \
        pptGroup {frequency "Models at the same frequency" single "One GIF per slide" \
            model "Steps of one model" step "Models at the same step index" none "In export order"}]
    if {[winfo exists $win]} {destroy $win}
    toplevel $win
    wm title $win "HyperView Report"
    wm withdraw $win
    wm protocol $win WM_DELETE_WINDOW ::hvr::close_tool

    # Preset bar
    ttk::frame $win.top
    ttk::label $win.top.l -text Preset
    ttk::combobox $win.top.preset -textvariable ::hvr::presetName -state readonly -width 30 -values [preset_names]
    bind $win.top.preset <<ComboboxSelected>> ::hvr::load_preset
    ttk::button $win.top.save -text Save -width 10 -command ::hvr::save_preset
    ttk::button $win.top.saveas -text "Save as..." -width 10 -command {::hvr::save_preset 1}
    ttk::button $win.top.delete -text Delete -width 10 -command ::hvr::delete_preset
    pack $win.top.l -side left -padx {8 6}
    pack $win.top.preset -side left
    pack $win.top.save $win.top.saveas $win.top.delete -side left -padx {6 0}
    pack $win.top -side top -fill x -pady 8

    # Status bar
    ttk::frame $win.bottom
    ttk::label $win.bottom.status -textvariable ::hvr::status -anchor w
    ttk::button $win.bottom.close -text Close -width 10 -command ::hvr::close_tool
    pack $win.bottom.close -side right -padx 8
    pack $win.bottom.status -side left -fill x -expand 1 -padx 8
    pack $win.bottom -side bottom -fill x -pady 8
    ttk::separator $win.sep2 -orient horizontal
    pack $win.sep2 -side bottom -fill x

    ttk::frame $win.right
    pack $win.right -side top -fill both -expand 1 -padx 8
    ttk::notebook $win.right.nb
    pack $win.right.nb -side top -fill both -expand 1
    foreach {name text} {main "Export" settings "Settings"} {
        ttk::frame $win.right.nb.$name -padding 6
        $win.right.nb add $win.right.nb.$name -text "  $text  "
    }

    # ---------------- Tab Export: three panels with draggable borders
    set tab $win.right.nb.main
    set bg [ttk::style lookup TFrame -background]
    panedwindow $tab.pv -orient vertical -sashwidth 7 -sashrelief flat -borderwidth 0 -opaqueresize 0 -background $bg
    panedwindow $tab.pv.ph -orient horizontal -sashwidth 7 -sashrelief flat -borderwidth 0 -opaqueresize 0 -background $bg
    pack $tab.pv -fill both -expand 1

    # Panel 1: one line per exported view
    set f [ttk::labelframe $win.right.views -text Views -padding {6 2 6 6}]
    # Same native table as the step list; one row is highlighted at a time.
    hwtk::treectrl $f.list -showroot no -showlines false -selectmode single -stripes false
    set vtree [$f.list component treectrl]
    $vtree configure -font TkDefaultFont -background white -showbuttons 0 -height 120
    foreach {col text width} {view View 70 modes Mode 100 title "Picture title" 160} {
        $f.list element create $col str -editable 0
        $f.list column create $col -text $text -elements [list $col] -width $width -sort false -justify center -itemjustify left
    }
    catch {$vtree column configure all -resize 1 -itembackground {white #f2f5f9}}
    $vtree notify bind $f.list <Selection> ::hvr::plan_selected
    bind $vtree <ButtonPress-1> [list ::hvr::tree_sensitive $f.list]
    bind $vtree <ButtonRelease-3> {::hvr::views_menu %x %y %X %Y}
    bind $vtree <Double-Button-1> [list ::hvr::views_double $f.list %x %y]
    ttk::frame $f.edit
    ttk::label $f.edit.lv -text View
    ttk::combobox $f.edit.view -textvariable ::hvr::planView -state readonly -width 16 -values [view_names]
    bind $f.edit.view <<ComboboxSelected>> ::hvr::plan_edited
    ttk::checkbutton $f.edit.fit -text Fit -variable ::hvr::viewFit
    ttk::label $f.edit.lt -text Title
    ttk::entry $f.edit.title -textvariable ::hvr::planTitleText
    bind $f.edit.title <KeyRelease> {after cancel ::hvr::plan_edited; after 250 ::hvr::plan_edited}
    # Native HyperView note fields that can be put into the picture title.
    ttk::menubutton $f.edit.field -text Field -width 6 -menu $f.edit.field.m
    menu $f.edit.field.m -tearoff 0
    foreach {label field} {
        "Model title" "{window.modeltitle}" "Load case" "{window.loadcase}"
        "Simulation step (mode, frequency)" "{window.simulationstep}" "Model file name" "{window.shortmodelfilename}"
        "Result file name" "{window.shortresultfilename}" "Frame" "{window.frame}"
    } {
        $f.edit.field.m add command -label "$label   $field" -command [list ::hvr::title_insert $field]
    }
    ttk::frame $f.edit.buttons
    ttk::button $f.edit.add -text Add -width 10 -command ::hvr::plan_add
    ttk::button $f.edit.copy -text Duplicate -width 10 -command {::hvr::plan_add 1}
    ttk::button $f.edit.remove -text Remove -width 10 -command ::hvr::plan_remove
    pack $f.edit.add $f.edit.copy $f.edit.remove -in $f.edit.buttons -side left -padx {0 6}
    grid $f.edit.lv -row 0 -column 0 -sticky w -padx {0 6} -pady 2
    grid $f.edit.view -row 0 -column 1 -columnspan 2 -sticky ew -pady 2
    grid $f.edit.fit -row 0 -column 3 -sticky w -padx {8 0} -pady 2
    grid $f.edit.lt -row 1 -column 0 -sticky w -padx {0 6} -pady 2
    grid $f.edit.title -row 1 -column 1 -columnspan 2 -sticky ew -pady 2
    grid $f.edit.field -row 1 -column 3 -sticky ew -padx {8 0} -pady 2
    grid $f.edit.buttons -row 2 -column 1 -columnspan 3 -sticky w -pady {6 0}
    foreach w [list $f.edit.add $f.edit.copy $f.edit.remove] {raise $w}
    grid columnconfigure $f.edit 2 -weight 1
    pack $f.edit -side bottom -fill x -pady {6 0}
    pack $f.list -side top -fill both -expand 1

    # Panel 2: result steps; the checked rows belong to the highlighted view
    ttk::labelframe $win.right.steps -text Steps -padding {6 2 6 6}
    ttk::frame $win.right.bar
    set b [ttk::frame $win.right.bar.r1]
    ttk::button $b.load -text "Load models..." -width 14 -command ::hvr::load_models
    ttk::button $b.refresh -text Refresh -width 9 -command ::hvr::refresh
    ttk::label $b.wl -text Windows
    ttk::combobox $b.windows -textvariable ::hvr::windowCount -state readonly -width 3 -values {1 2 3 4 6 9}
    bind $b.windows <<ComboboxSelected>> ::hvr::set_window_count
    ttk::button $b.none -text "Uncheck all" -width 11 -command {::hvr::set_checks $::hvr::rows 0}
    ttk::button $b.all -text "Check shown" -width 12 -command {::hvr::set_checks [::hvr::shown_keys] 1}
    pack $b.load -side left
    pack $b.refresh -side left -padx {6 0}
    ttk::button $b.split -text "Split views" -width 11 -command ::hvr::split_views
    catch {hwtk::tooltip $b.split "Show the loaded model in several windows, one view of the Views list in each"}
    pack $b.wl -side left -padx {14 6}
    pack $b.windows -side left
    pack $b.split -side left -padx {6 0}
    pack $b.none -side right
    pack $b.all -side right -padx {0 6}
    set b [ttk::frame $win.right.bar.r2]
    ttk::label $b.rl -text Range
    ttk::combobox $b.rangeby -textvariable ::hvr::rangeBy -state readonly -width 5 -values {Freq Time Step}
    ttk::entry $b.range -textvariable ::hvr::rangeText -width 22
    bind $b.range <KeyRelease> {after cancel ::hvr::fill_table; after 300 ::hvr::fill_table}
    bind $b.rangeby <<ComboboxSelected>> ::hvr::fill_table
    catch {hwtk::tooltip $b.range "Show only these values, for example: 1-10 50-100"}
    ttk::label $b.fl -text Filter
    ttk::entry $b.filter -textvariable ::hvr::filter -width 18
    bind $b.filter <KeyRelease> {after cancel ::hvr::fill_table; after 200 ::hvr::fill_table}
    pack $b.rl -side left
    pack $b.rangeby -side left -padx {6 4}
    pack $b.range -side left
    pack $b.fl -side left -padx {14 6}
    pack $b.filter -side left -fill x -expand 1
    pack $win.right.bar.r1 -side top -fill x
    pack $win.right.bar.r2 -side top -fill x -pady {6 0}
    pack $win.right.bar -in $win.right.steps -side top -fill x -pady {0 6}

    set table $win.right.table
    # Row-based native table: sweep, Ctrl and Shift select whole rows.
    hwtk::treectrl $table -showroot no -showlines false -selectmode extended -stripes false
    pack $table -in $win.right.steps -side top -fill both -expand 1
    set tree [$table component treectrl]
    $tree configure -font TkDefaultFont -background white -showbuttons 0
    variable checkNative 1
    if {[catch {$table element create chk intcheck -editable 0}]} {
        set checkNative 0
        $table element create chk str -editable 0
    }
    foreach {col text width justify} {
        chk "" 30 center win Win 44 center model Model 130 left mode Step 48 center
        freq "Freq / Time" 100 right label Label 200 left subcase Subcase 110 left
    } {
        if {$col ne "chk"} {$table element create $col str -editable 0}
        $table column create $col -text $text -elements [list $col] -width $width -sort false -justify center -itemjustify $justify
    }
    # Column edges can be dragged in the header; the check column keeps its width.
    catch {$tree column configure all -resize 1}
    catch {$tree column configure [$table column id chk] -resize 0}
    # Alternating row background keeps long lists readable.
    catch {$tree column configure all -itembackground {white #f2f5f9}}
    # No selection handler on purpose: sweeping rows must not run any script.
    bind $tree <ButtonPress-1> {::hvr::table_sensitive; ::hvr::sweep_start %x %y}
    bind $tree <B1-Motion> {if {[::hvr::sweep_move %x %y 0]} break}
    bind $tree <Control-B1-Motion> {if {[::hvr::sweep_move %x %y 1]} break}
    bind $tree <ButtonRelease-1> {::hvr::table_clicked %x %y; ::hvr::sweep_end}
    bind $tree <ButtonRelease-3> {::hvr::table_menu %x %y %X %Y}
    bind $tree <Double-Button-1> [list ::hvr::table_double $table %x %y]
    bind $tree <KeyPress-space> {::hvr::toggle_selected; break}

    # Panel 3: export
    set f [ttk::labelframe $win.right.export -text Export -padding {0 2 0 0}]
    ttk::label $f.lo -text "Output folder"
    ttk::frame $f.out
    ttk::entry $f.out.e -textvariable ::hvr::P(outputDir)
    ttk::button $f.out.b -text "..." -width 3 -command ::hvr::pick_output
    pack $f.out.b -side right -padx {4 0}
    pack $f.out.e -side left -fill x -expand 1
    ttk::label $f.lp -text "File prefix"
    ttk::entry $f.prefix -textvariable ::hvr::P(prefix) -width 16
    ttk::label $f.lm -text Animation
    ttk::combobox $f.mode -textvariable ::hvr::D(animMode) -state readonly -width 10 \
        -values [dict values [dict get $labels animMode]]
    ttk::label $f.lf -text Frames
    ttk::spinbox $f.frames -textvariable ::hvr::P(frames) -from 2 -to 200 -width 5
    ttk::label $f.lz -text "GIF scale %"
    ttk::spinbox $f.size -textvariable ::hvr::P(gifScale) -from 50 -to 400 -increment 50 -width 5
    ttk::label $f.summary -textvariable ::hvr::summary -anchor w
    ttk::button $f.gif -text "Export GIFs" -width 13 -command ::hvr::export_gifs
    ttk::button $f.pptx -text "Export PPTX" -width 13 -command ::hvr::export_pptx
    ttk::button $f.h3d -text "Export H3D" -width 13 -command ::hvr::export_h3d
    ttk::progressbar $f.progress -mode determinate
    ttk::button $f.pause -text Pause -width 13 -state disabled -command ::hvr::export_pause
    ttk::button $f.cancel -text Cancel -width 13 -state disabled -command ::hvr::export_cancel
    grid $f.lo -row 0 -column 0 -sticky w -padx {8 6} -pady 2
    grid $f.out -row 0 -column 1 -columnspan 5 -sticky ew -pady 2
    grid $f.lp -row 0 -column 6 -sticky w -padx {12 6} -pady 2
    grid $f.prefix -row 0 -column 7 -columnspan 3 -sticky ew -padx {0 8} -pady 2
    grid $f.lm -row 1 -column 0 -sticky w -padx {8 6} -pady 2
    grid $f.mode -row 1 -column 1 -sticky w -pady 2
    grid $f.lf -row 1 -column 2 -sticky w -padx {12 6} -pady 2
    grid $f.frames -row 1 -column 3 -sticky w -pady 2
    grid $f.lz -row 1 -column 4 -sticky w -padx {12 6} -pady 2
    grid $f.size -row 1 -column 5 -sticky w -pady 2
    grid $f.gif -row 1 -column 7 -sticky e -pady 2
    grid $f.pptx -row 1 -column 8 -sticky e -padx {6 0} -pady 2
    grid $f.h3d -row 1 -column 9 -sticky e -padx {6 8} -pady 2
    grid $f.summary -row 2 -column 0 -columnspan 7 -sticky ew -padx {8 6} -pady {2 0}
    grid $f.progress -row 3 -column 0 -columnspan 8 -sticky ew -padx {8 6} -pady {2 8}
    grid $f.pause -row 3 -column 8 -sticky e -padx {6 0} -pady {2 8}
    grid $f.cancel -row 3 -column 9 -sticky e -padx {6 8} -pady {2 8}
    grid columnconfigure $f 5 -weight 1

    $tab.pv.ph add $win.right.views -width 370 -minsize 240 -stretch never
    $tab.pv.ph add $win.right.steps -minsize 320 -stretch always
    $tab.pv add $tab.pv.ph -minsize 200 -stretch always
    $tab.pv add $win.right.export -minsize 132 -stretch never
    foreach w [list $win.right.views $win.right.steps $win.right.export $win.right.bar $table] {raise $w}

    # ---------------- Tab Settings: plain sections, no boxes
    set tab $win.right.nb.settings
    ttk::frame $win.left
    pack $win.left -in $tab -fill both -expand 1 -padx 6 -pady 4
    raise $win.left

    ttk::frame $win.left.bar
    ttk::button $win.left.apply -text "Apply All Components" -width 24 -command ::hvr::apply_preset
    ttk::button $win.left.read -text "Read from window" -width 18 -command ::hvr::read_window_settings
    ttk::label $win.left.hint -anchor w -text "HyperView changes only when Apply is pressed. Exports capture what the windows show."
    pack $win.left.apply -in $win.left.bar -side left
    pack $win.left.read -in $win.left.bar -side left -padx {6 14}
    pack $win.left.hint -in $win.left.bar -side left -fill x -expand 1

    set f [section $win.left.result Result]
    ttk::combobox $f.type -textvariable ::hvr::P(resultType) -state readonly -width 34
    bind $f.type <<ComboboxSelected>> ::hvr::type_changed
    ttk::combobox $f.comp -textvariable ::hvr::P(component) -state readonly -width 34
    ttk::entry $f.scale -textvariable ::hvr::P(scale) -width 10
    form $f 1 Type $f.type 3
    form $f 2 Component $f.comp 3
    form $f 3 "Deformed scale" $f.scale

    set f [section $win.left.legend Legend]
    ttk::combobox $f.pos -textvariable ::hvr::D(legendPosition) -state readonly -width 12 \
        -values [dict values [dict get $labels legendPosition]]
    ttk::combobox $f.fmt -textvariable ::hvr::D(legendFormat) -state readonly -width 12 \
        -values [dict values [dict get $labels legendFormat]]
    ttk::spinbox $f.prec -textvariable ::hvr::P(legendPrecision) -from 0 -to 10 -width 6
    ttk::spinbox $f.levels -textvariable ::hvr::P(legendLevels) -from 2 -to 32 -width 6
    ttk::entry $f.min -textvariable ::hvr::P(legendMin) -width 14
    ttk::entry $f.max -textvariable ::hvr::P(legendMax) -width 14
    ttk::frame $f.range
    ttk::button $f.read -text "Use current range" -width 17 -command ::hvr::legend_from_current
    ttk::button $f.auto -text "Automatic range" -width 17 -command ::hvr::legend_auto
    pack $f.read -in $f.range -side left
    pack $f.auto -in $f.range -side left -padx {6 0}
    form $f 1 Position $f.pos
    form $f 1 "Number format" $f.fmt 1 2
    form $f 2 Precision $f.prec
    form $f 2 Levels $f.levels 1 2
    form $f 3 Min $f.min
    form $f 3 Max $f.max 1 2
    grid $f.range -row 4 -column 1 -columnspan 3 -sticky w -pady {4 2}

    set f [section $win.left.note Note]
    ttk::checkbutton $f.show -text "Show note" -variable ::hvr::P(noteShow)
    text $f.text -width 40 -height 5 -wrap none -font TkDefaultFont -relief solid -borderwidth 1
    grid $f.show -row 1 -column 0 -columnspan 4 -sticky w -pady 2
    grid $f.text -row 2 -column 0 -columnspan 4 -sticky ew -pady {2 0}

    set f [section $win.left.ppt PowerPoint]
    ttk::frame $f.source
    ttk::radiobutton $f.last -text "Last export of this session" -variable ::hvr::P(pptSource) -value last
    ttk::radiobutton $f.all -text "All exported GIFs in the output folder" -variable ::hvr::P(pptSource) -value all
    pack $f.last -in $f.source -side top -anchor w
    pack $f.all -in $f.source -side top -anchor w -pady {2 0}
    ttk::combobox $f.group -textvariable ::hvr::D(pptGroup) -state readonly -width 30 \
        -values [dict values [dict get $labels pptGroup]]
    ttk::frame $f.grid
    ttk::spinbox $f.grid.cols -textvariable ::hvr::P(pptCols) -from 1 -to 6 -width 4
    ttk::label $f.grid.lc -text "columns  x"
    ttk::spinbox $f.grid.rows -textvariable ::hvr::P(pptRows) -from 1 -to 6 -width 4
    ttk::label $f.grid.lr -text rows
    pack $f.grid.cols -side left
    pack $f.grid.lc -side left -padx 6
    pack $f.grid.rows -side left
    pack $f.grid.lr -side left -padx 6
    ttk::combobox $f.order -textvariable ::hvr::D(pptOrder) -state readonly -width 30 \
        -values [dict values [dict get $labels pptOrder]]
    ttk::checkbutton $f.header -text "Picture title above each GIF" -variable ::hvr::P(pptHeader)
    form $f 1 "GIFs to place" $f.source 3
    form $f 2 "One slide holds" $f.group 3
    form $f 3 "Grid on a slide" $f.grid 3
    form $f 4 "Fill order" $f.order 3
    grid $f.header -row 5 -column 1 -columnspan 3 -sticky w -pady 2

    set f [section $win.left.h3d "H3D (HvTrans)"]
    ttk::entry $f.loss -textvariable ::hvr::P(h3dLoss) -width 8
    form $f 1 "Maximum compression loss (%)" $f.loss

    # Empty overrides let the tool find the bundled programs.
    set f [section $win.left.paths "Program paths"]
    foreach {row key label} {1 altair_home "Altair folder" 2 python Python 3 hvtrans HvTrans} {
        ttk::frame $f.$key
        ttk::entry $f.$key.e -textvariable ::hvr::pathOverride($key) -width 38
        ttk::button $f.$key.b -text "..." -width 3 -command [list ::hvr::paths_browse $key]
        pack $f.$key.b -side right -padx {4 0}
        pack $f.$key.e -side left -fill x -expand 1
        bind $f.$key.e <Return> ::hvr::paths_apply
        ttk::label $f.l$key -text $label
        grid $f.l$key -row $row -column 0 -sticky w -padx {0 10} -pady 2
        grid $f.$key -row $row -column 1 -columnspan 3 -sticky ew -pady 2
    }
    ttk::frame $f.buttons
    ttk::button $f.save -text "Save paths" -width 14 -command ::hvr::paths_apply
    ttk::button $f.auto -text "Find automatically" -width 18 -command {::hvr::paths_apply 1}
    pack $f.save -in $f.buttons -side left
    pack $f.auto -in $f.buttons -side left -padx {6 0}
    grid $f.buttons -row 4 -column 1 -columnspan 3 -sticky w -pady {4 2}
    ttk::label $f.hint -text "Leave a field blank to find it automatically."
    grid $f.hint -row 5 -column 1 -columnspan 3 -sticky w

    # Two columns across the wide tab: what the windows show, and how files are written.
    grid $win.left.bar -row 0 -column 0 -columnspan 2 -sticky ew -pady {0 4}
    foreach {column boxes} {0 {result legend note} 1 {ppt h3d paths}} {
        ttk::frame $win.left.c$column
        grid $win.left.c$column -row 1 -column $column -sticky new -padx [expr {$column == 0 ? {0 28} : 0}]
        foreach box $boxes {
            pack $win.left.$box -in $win.left.c$column -side top -fill x -pady {8 0}
            raise $win.left.$box
        }
    }
    grid columnconfigure $win.left {0 1} -weight 1 -uniform settings

    note_to_widget
    # refresh also reads the settings of the first model window it finds.
    variable settingsRead 0
    refresh
    wm minsize $win 1080 680
    center $win .
    wm deiconify $win
    raise $win
}

# Resolve the external programs once the file is loaded.
::hvr::load_paths
