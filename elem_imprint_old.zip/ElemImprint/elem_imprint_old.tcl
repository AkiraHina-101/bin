# Element Imprint (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Makes two touching faces share nodes and carry the same elements in the contact area, the way it is
# done by hand. Elements: tria3/tria6 (mixed allowed); solids are not handled.
#   One face inside the other (enclose_once): the enclosed face ("guest") is copied onto the other
#   ("host") as new elements that use the guest's own nodes, the host elements under it (plus Remesh
#   layers rows) are deleted and the ring between them is filled (ruled between closed outlines, ear
#   clipping elsewhere). Target and Source may be picked either way round.
#   Source not wholly on the target (its hole smaller than the target hole, or past an edge): only
#   the source elements lying wholly on the target are copied; the rest stays as it is.
#   Where the ring cannot be closed the direct build is used: the target rows touched by the copy are
#   deleted and their outline is joined by ruled triangles to the outline of the copy.
#   Quality standard (Min length, Max aspect, Min stretch, HyperMesh definitions): a ring triangle
#   that fails it makes the host row next to it go too, and the ring is made again.
#   Every change is one Undo step; a failed attempt is undone and retried, an unexpected failure
#   rolls back ("Nothing changed").
# Entry point for the menu: *evaltclscript elem_imprint.tcl 0. Set ::ElemImprint_no_gui to load
# the procedures without opening the window (tests).

if {![llength [info commands ::TestToolSession::run]]} {
    source [file join [file dirname [file dirname [file normalize [info script]]]] tool_session.tcl]
}
if {![info exists ::ElemImprint_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::ElemImprint {
    variable dir [file dirname [file normalize [info script]]]
    variable W .elemImprint
    variable cfg2D {103 106}
    variable names {103 tria3 106 tria6}
    variable eps 1e-9
    variable snapFrac 0.05
    variable outer 0
    variable sel
    variable opt
    variable status
    variable P
    if {![info exists status]} {set status ""}
    # sel: the picked elements (kept until Reset); shown: the elements highlighted for each side (after
    # an imprint, the new face); last: the imprint the window made last, undone before a re-imprint
    variable shown
    variable last
    # quiet: after a successful imprint no selection color is kept (it hides the new mesh). A new pick
    # or a failed imprint brings the selection color back.
    variable quiet 0
    if {![info exists last]} {set last {}}
    if {![info exists ::ElemImprint::bad]} {set ::ElemImprint::bad {}}
    # newElems: the elements the last imprint made (checked again when a criterion changes);
    foreach {k v} {newElems {} badKind {} badText "" showBad 0 oldMax 0 near {} nearText "" nearPair {} lastFace {} nearOuter {} chamferRows {} showGaps 0 gapIds {}} {if {![info exists ::ElemImprint::$k]} {set ::ElemImprint::$k $v}}
    foreach {k v} {target {} source {}} {if {![info exists sel($k)]} {set sel($k) $v}; if {![info exists shown($k)]} {set shown($k) $v}}
    foreach {k v} {autoSelect 1 targetMode face faceAngle 30 sourceMode elements gapLim 5 delGap 1 maxAspect 5 maxSkew 60 minLen "" nearSrc "" order2 0 qview 0} {if {![info exists opt($k)]} {set opt($k) $v}}
}

# ---------------------------------------------------------------- vectors
proc ::ElemImprint::vsub {a b} {list [expr {[lindex $a 0]-[lindex $b 0]}] [expr {[lindex $a 1]-[lindex $b 1]}] [expr {[lindex $a 2]-[lindex $b 2]}]}
proc ::ElemImprint::vadd {a b} {list [expr {[lindex $a 0]+[lindex $b 0]}] [expr {[lindex $a 1]+[lindex $b 1]}] [expr {[lindex $a 2]+[lindex $b 2]}]}
proc ::ElemImprint::vscale {a s} {list [expr {[lindex $a 0]*$s}] [expr {[lindex $a 1]*$s}] [expr {[lindex $a 2]*$s}]}
proc ::ElemImprint::dot {a b} {expr {[lindex $a 0]*[lindex $b 0]+[lindex $a 1]*[lindex $b 1]+[lindex $a 2]*[lindex $b 2]}}
proc ::ElemImprint::cross {a b} {
    lassign $a ax ay az; lassign $b bx by bz
    list [expr {$ay*$bz-$az*$by}] [expr {$az*$bx-$ax*$bz}] [expr {$ax*$by-$ay*$bx}]
}
proc ::ElemImprint::norm {a} {expr {sqrt([dot $a $a])}}
proc ::ElemImprint::unit {a} {
    set l [norm $a]
    if {$l < 1e-300} {return {0.0 0.0 0.0}}
    vscale $a [expr {1.0/$l}]
}

# ---------------------------------------------------------------- model reads
proc ::ElemImprint::count {type} {hm_count $type all 0 0}
proc ::ElemImprint::existing {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 {*}$ids
    set out [hm_getmark elems 1]
    *clearmark elems 1
    return $out
}
proc ::ElemImprint::existing_nodes {ids} {
    if {![llength $ids]} {return {}}
    *createmark nodes 1 {*}$ids
    set out [hm_getmark nodes 1]
    *clearmark nodes 1
    return $out
}
proc ::ElemImprint::configs {ids} {
    if {![llength $ids]} {return {}}
    hm_getvalue elems user_ids=$ids dataname=config
}
proc ::ElemImprint::elem_nodes {ids} {
    if {![llength $ids]} {return {}}
    hm_getvalue elems user_ids=$ids dataname=nodes
}
proc ::ElemImprint::node_set {ids} {
    set all {}
    foreach nl [elem_nodes $ids] {foreach n $nl {lappend all $n}}
    lsort -unique -integer $all
}
proc ::ElemImprint::comps_of {ids} {
    if {![llength $ids]} {return {}}
    lsort -unique [hm_getvalue elems user_ids=$ids dataname=collector.name]
}
# Node coordinates into the cache P (one bulk read per coordinate).
proc ::ElemImprint::load_xyz {ids} {
    variable P
    set need {}
    foreach n $ids {if {![info exists P($n)]} {lappend need $n}}
    set need [lsort -unique -integer $need]
    if {![llength $need]} {return}
    foreach n $need x [hm_getvalue nodes user_ids=$need dataname=x] y [hm_getvalue nodes user_ids=$need dataname=y] \
        z [hm_getvalue nodes user_ids=$need dataname=z] {set P($n) [list $x $y $z]}
}

# Kind of a selection: {dim order config}; tria3 and tria6 only (mixed: order 2 when any tria6).
proc ::ElemImprint::kind {ids what} {
    variable cfg2D
    set cs [lsort -unique [configs $ids]]
    foreach c $cs {
        if {$c ni $cfg2D} {error "The $what has elements that are not tria3 or tria6 (config $c)."}
    }
    set c [lindex $cs end]
    list 2 [expr {$c == 106 ? 2 : 1}] $c
}

# Triangle rows {eid a b c} (corner nodes) of tria3/tria6 elements.
proc ::ElemImprint::tri_rows {eids} {
    set rows {}
    foreach e $eids nl [elem_nodes $eids] {lappend rows [list $e [lindex $nl 0] [lindex $nl 1] [lindex $nl 2]]}
    return $rows
}


# ---------------------------------------------------------------- triangle grid
# A grid over triangle rows for point location. Name: grid key prefix (T or S).
proc ::ElemImprint::grid_build {name rows} {
    variable P
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    array unset G; array unset D
    set ids {}
    foreach r $rows {lappend ids {*}[lrange $r 1 3]}
    load_xyz $ids
    set sum 0.0; set k 0
    set i 0
    foreach r $rows {
        lassign $r e a b c
        set pa $P($a); set pb $P($b); set pc $P($c)
        set nn [cross [vsub $pb $pa] [vsub $pc $pa]]
        set D($i) [list $pa $pb $pc [unit $nn] [norm $nn]]
        foreach {p q} [list $pa $pb $pb $pc $pc $pa] {set sum [expr {$sum+[norm [vsub $q $p]]}]; incr k}
        incr i
    }
    set D(n) $i
    set D(rows) $rows
    set D(mean) [expr {$k ? $sum/$k : 1.0}]
    return $D(mean)
}
proc ::ElemImprint::grid_index {name h} {
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    array unset G
    set D(h) $h
    for {set i 0} {$i < $D(n)} {incr i} {
        lassign $D($i) pa pb pc
        set lo {}; set hi {}
        foreach k {0 1 2} {
            set v [list [lindex $pa $k] [lindex $pb $k] [lindex $pc $k]]
            lappend lo [expr {int(floor([tcl::mathfunc::min {*}$v]/$h))}]
            lappend hi [expr {int(floor([tcl::mathfunc::max {*}$v]/$h))}]
        }
        for {set x [lindex $lo 0]} {$x <= [lindex $hi 0]} {incr x} {
            for {set y [lindex $lo 1]} {$y <= [lindex $hi 1]} {incr y} {
                for {set z [lindex $lo 2]} {$z <= [lindex $hi 2]} {incr z} {lappend G($x,$y,$z) $i}
            }
        }
    }
}
# Row indices with a cell within distance r of p.
proc ::ElemImprint::grid_near {name p r} {
    upvar #0 ::ElemImprint::G_$name G
    upvar #0 ::ElemImprint::GD_$name D
    set h $D(h)
    set out {}
    set lo {}; set hi {}
    foreach v $p {lappend lo [expr {int(floor(($v-$r)/$h))}]; lappend hi [expr {int(floor(($v+$r)/$h))}]}
    for {set x [lindex $lo 0]} {$x <= [lindex $hi 0]} {incr x} {
        for {set y [lindex $lo 1]} {$y <= [lindex $hi 1]} {incr y} {
            for {set z [lindex $lo 2]} {$z <= [lindex $hi 2]} {incr z} {
                if {[info exists G($x,$y,$z)]} {lappend out {*}$G($x,$y,$z)}
            }
        }
    }
    lsort -unique -integer $out
}
# Barycentric coordinates of the projection of p on triangle i, and the signed normal distance.
proc ::ElemImprint::tri_project {name i p} {
    upvar #0 ::ElemImprint::GD_$name D
    lassign $D($i) pa pb pc n
    set d [dot [vsub $p $pa] $n]
    set q [vsub $p [vscale $n $d]]
    set area [dot [cross [vsub $pb $pa] [vsub $pc $pa]] $n]
    if {abs($area) < 1e-300} {return [list -1 -1 -1 $d]}
    set u [expr {[dot [cross [vsub $pb $q] [vsub $pc $q]] $n]/$area}]
    set v [expr {[dot [cross [vsub $pc $q] [vsub $pa $q]] $n]/$area}]
    list $u $v [expr {1.0-$u-$v}] $d
}
# Triangle on which p projects (inside, |distance| <= r), nearest first: {index distance} or {}.
proc ::ElemImprint::locate {name p r {tol 1e-7}} {
    set best {}
    foreach i [grid_near $name $p $r] {
        lassign [tri_project $name $i $p] u v w d
        if {$u >= -$tol && $v >= -$tol && $w >= -$tol && abs($d) <= $r} {
            if {![llength $best] || abs($d) < abs([lindex $best 1])} {set best [list $i $d]}
        }
    }
    return $best
}

# Free (boundary) corner edges of triangle rows: dict "a b" (a<b) -> 1.
proc ::ElemImprint::boundary_edges {rows} {
    set cnt [dict create]
    foreach r $rows {
        lassign $r e a b c
        foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
    }
    set out [dict create]
    dict for {k v} $cnt {if {$v == 1} {dict set out $k 1}}
    return $out
}



# ---------------------------------------------------------------- clipping
# 2D helpers (points {x y}).
proc ::ElemImprint::cross2 {o a b} {expr {([lindex $a 0]-[lindex $o 0])*([lindex $b 1]-[lindex $o 1])-([lindex $a 1]-[lindex $o 1])*([lindex $b 0]-[lindex $o 0])}}
proc ::ElemImprint::in_tri2 {p a b c tol} {
    set s [cross2 $a $b $c]
    if {abs($s) < 1e-300} {return 0}
    expr {[cross2 $a $b $p]/$s > $tol && [cross2 $b $c $p]/$s > $tol && [cross2 $c $a $p]/$s > $tol}
}
# Proper intersection of segments p1-p2 and q1-q2: {t u} or {}.
proc ::ElemImprint::seg_x {p1 p2 q1 q2} {
    lassign $p1 x1 y1; lassign $p2 x2 y2; lassign $q1 x3 y3; lassign $q2 x4 y4
    set den [expr {($x2-$x1)*($y4-$y3)-($y2-$y1)*($x4-$x3)}]
    set scale [expr {hypot($x2-$x1,$y2-$y1)*hypot($x4-$x3,$y4-$y3)}]
    if {abs($den) <= 1e-12*$scale} {return {}}
    set t [expr {(($x3-$x1)*($y4-$y3)-($y3-$y1)*($x4-$x3))/$den}]
    set u [expr {(($x3-$x1)*($y2-$y1)-($y3-$y1)*($x2-$x1))/$den}]
    list $t $u
}
proc ::ElemImprint::poly_area2 {pts} {
    set a 0.0; set n [llength $pts]
    for {set i 0} {$i < $n} {incr i} {
        lassign [lindex $pts $i] x1 y1; lassign [lindex $pts [expr {($i+1)%$n}]] x2 y2
        set a [expr {$a+$x1*$y2-$x2*$y1}]
    }
    return $a
}
# Ear clipping of a simple polygon given as keys with 2D points. Returns triangles of keys, CCW.
proc ::ElemImprint::ear_clip {keys pts} {
    if {[poly_area2 $pts] < 0} {set keys [lreverse $keys]; set pts [lreverse $pts]}
    set tris {}
    set guard 0
    while {[llength $keys] > 3} {
        set n [llength $keys]
        set cut -1; set bestQ -1.0
        for {set i 0} {$i < $n} {incr i} {
            set ia [expr {($i+$n-1)%$n}]; set ib [expr {($i+1)%$n}]
            set a [lindex $pts $ia]; set b [lindex $pts $i]; set c [lindex $pts $ib]
            if {[cross2 $a $b $c] <= 1e-14*max(1.0,[poly_scale $pts])} {continue}
            set ok 1
            set kabc [list [lindex $keys $ia] [lindex $keys $i] [lindex $keys $ib]]
            for {set j 0} {$j < $n} {incr j} {
                if {$j == $ia || $j == $i || $j == $ib} {continue}
                if {[lindex $keys $j] in $kabc} {continue}
                # a vertex on the ear's diagonal blocks it too (collinear vertices along a side)
                if {[in_tri2 [lindex $pts $j] $a $b $c -1e-12]} {set ok 0; break}
            }
            if {$ok} {
                set q [tri_quality2 $a $b $c]
                if {$cut < 0 || $q > $bestQ} {set cut $i; set bestQ $q}
            }
        }
        if {$cut < 0} {error "polygon cannot be triangulated"}
        set ia [expr {($cut+$n-1)%$n}]; set ib [expr {($cut+1)%$n}]
        lappend tris [list [lindex $keys $ia] [lindex $keys $cut] [lindex $keys $ib]]
        set keys [lreplace $keys $cut $cut]; set pts [lreplace $pts $cut $cut]
        if {[incr guard] > 10000} {error "polygon cannot be triangulated"}
    }
    if {[cross2 {*}$pts] > 1e-14*max(1.0,[poly_scale $pts])} {lappend tris $keys}
    return $tris
}
proc ::ElemImprint::poly_scale {pts} {
    set m 0.0
    foreach p $pts {set m [expr {max($m,abs([lindex $p 0]),abs([lindex $p 1]))}]}
    expr {$m*$m}
}

# Parameter of the point of segment a-b nearest to p (along a surface with normal n) and the distance.
proc ::ElemImprint::seg_param {p a b n} {
    set ab [vsub $b $a]; set ab [vsub $ab [vscale $n [dot $ab $n]]]
    set ap [vsub $p $a]; set ap [vsub $ap [vscale $n [dot $ap $n]]]
    set l2 [dot $ab $ab]
    set s [expr {$l2 > 0 ? max(0.0,min(1.0,[dot $ap $ab]/$l2)) : 0.0}]
    list $s [norm [vsub $ap [vscale $ab $s]]]
}
proc ::ElemImprint::to2d {frame p} {
    lassign $frame o e1 e2
    set d [vsub $p $o]
    list [dot $d $e1] [dot $d $e2]
}
proc ::ElemImprint::point_in_poly {p poly} {
    lassign $p x y
    set in 0; set n [llength $poly]
    for {set i 0; set j [expr {$n-1}]} {$i < $n} {set j $i; incr i} {
        lassign [lindex $poly $i] xi yi; lassign [lindex $poly $j] xj yj
        if {(($yi > $y) != ($yj > $y)) && ($x < ($xj-$xi)*($y-$yi)/($yj-$yi)+$xi)} {set in [expr {!$in}]}
    }
    return $in
}

# 2D distance from p to segment a-b: {distance parameter}.
proc ::ElemImprint::pseg2 {p a b} {
    lassign $p px py; lassign $a ax ay; lassign $b bx by
    set dx [expr {$bx-$ax}]; set dy [expr {$by-$ay}]; set l2 [expr {$dx*$dx+$dy*$dy}]
    set t [expr {$l2 > 0 ? (($px-$ax)*$dx+($py-$ay)*$dy)/$l2 : 0.0}]
    set s [expr {max(0.0,min(1.0,$t))}]
    list [expr {hypot($px-$ax-$s*$dx,$py-$ay-$s*$dy)}] $t
}
# 1 when 2D segments a-b and c-d cross (touching at an end does not count).
proc ::ElemImprint::seg_cross2 {a b c d} {
    lassign $a ax ay; lassign $b bx by; lassign $c cx cy; lassign $d dx dy
    set d1 [expr {($bx-$ax)*($cy-$ay)-($by-$ay)*($cx-$ax)}]
    set d2 [expr {($bx-$ax)*($dy-$ay)-($by-$ay)*($dx-$ax)}]
    set d3 [expr {($dx-$cx)*($ay-$cy)-($dy-$cy)*($ax-$cx)}]
    set d4 [expr {($dx-$cx)*($by-$cy)-($dy-$cy)*($bx-$cx)}]
    expr {$d1*$d2 < 0 && $d3*$d4 < 0}
}
# Narrow gaps: elements of the target face that do not reach under a source patch but would leave a
# thin band to it. Per patch, the band is built as the imprint builds it, in Tcl only (nothing in the
# model): the deleted region R = the face elements under the patch or crossing its outline (and the
# chamfer rows in skip); its outer outline is joined to the outer outline of the patch by ruled
# triangles (ruled, as direct_bands). A band triangle with L/d > lim (longest edge over its height)
# puts the kept face elements at its corners on the outline into R, and the band is built again (4
# rounds at most). Elements with an edge on a free edge of the face and elements far off the patch
# plane stay. Returns the elements added to R this way (the imprint deletes the others anyway);
# ::ElemImprint::gapWhy says for each element near a patch why it was or was not taken.
proc ::ElemImprint::narrow_gaps {face source lim {skip {}}} {
    variable P
    set ::ElemImprint::gapWhy [dict create]; set ::ElemImprint::gapLog {}
    if {[string trim $lim] eq "" || ![string is double -strict $lim] || $lim <= 1} {return {}}
    set face [existing $face]; set source [existing $source]
    if {![llength $face] || ![llength $source]} {return {}}
    set skipS [dict create]; foreach e $skip {dict set skipS $e 1}
    set frows [tri_rows $face]
    set fn {}; foreach r $frows {lappend fn {*}[lrange $r 1 3]}
    load_xyz [lsort -unique -integer $fn]
    set BF [boundary_edges $frows]
    set byNode [dict create]; set rowOf [dict create]
    foreach r $frows {dict set rowOf [lindex $r 0] $r; foreach n [lrange $r 1 3] {dict lappend byNode $n [lindex $r 0]}}
    set hit [dict create]
    foreach part [source_patches $source] {
        set srows [tri_rows $part]
        set sn {}; foreach r $srows {lappend sn {*}[lrange $r 1 3]}
        set sn [lsort -unique -integer $sn]
        load_xyz $sn
        set N [avg_normal $srows]
        set c {0.0 0.0 0.0}; foreach n $sn {set c [vadd $c $P($n)]}
        set c [vscale $c [expr {1.0/[llength $sn]}]]
        set ax [expr {abs([lindex $N 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
        set e1 [unit [cross $N $ax]]; set e2 [cross $N $e1]
        set f [list $c $e1 $e2]
        # the outline of the patch: segments and closed loops (2D), its outer loop (node ids)
        set keys {}; dict for {k one} [boundary_edges $srows] {lappend keys $k}
        set Q [dict create]; set segs {}; set lmax 0.0; set rad 0.0
        foreach k $keys {
            lassign $k a b
            foreach n [list $a $b] {if {![dict exists $Q $n]} {dict set Q $n [to2d $f $P($n)]}}
            set qa [dict get $Q $a]; set qb [dict get $Q $b]
            lappend segs [list $qa $qb]
            set lmax [expr {max($lmax,hypot([lindex $qb 0]-[lindex $qa 0],[lindex $qb 1]-[lindex $qa 1]))}]
        }
        dict for {n q} $Q {set rad [expr {max($rad,hypot([lindex $q 0],[lindex $q 1]))}]}
        set polys {}; set gOuter {}; set gArea -1.0
        foreach ch [lindex [edge_chains $keys] 0] {
            lassign $ch closed nodes
            if {!$closed} {continue}
            set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
            set poly {}; foreach n $nn {lappend poly [dict get $Q $n]}
            lappend polys $poly
            set ar [expr {abs([loop_area $nn $N])}]
            if {$ar > $gArea} {set gArea $ar; set gOuter $nn}
        }
        # the face elements near the patch: in R (deleted anyway) or a candidate
        set R [dict create]; set cand [dict create]
        foreach r $frows {
            lassign $r e a b cc
            set ps {}; set far 0
            foreach n [list $a $b $cc] {
                set v [vsub $P($n) $c]
                if {abs([dot $v $N]) > $rad} {set far 1}
                lappend ps [list [dot $v $e1] [dot $v $e2]]
            }
            if {$far} {continue}
            set dc 1e300
            foreach {i j} {0 1 1 2 2 0} {set dc [expr {min($dc,[lindex [pseg2 {0.0 0.0} [lindex $ps $i] [lindex $ps $j]] 0])}]}
            if {$dc > $rad+2.0*$lmax} {continue}
            if {[dict exists $skipS $e]} {dict set R $e 1; continue}
            set under 0
            foreach p $ps {
                set in 0; foreach poly $polys {if {[point_in_poly $p $poly]} {set in [expr {!$in}]}}
                if {$in} {set under 1; break}
            }
            if {$under} {dict set R $e 1; dict set ::ElemImprint::gapWhy $e under; continue}
            set cross 0
            foreach {i j} {0 1 1 2 2 0} {
                foreach s $segs {if {[seg_cross2 [lindex $ps $i] [lindex $ps $j] [lindex $s 0] [lindex $s 1]]} {set cross 1; break}}
                if {$cross} {break}
            }
            if {$cross} {dict set R $e 1; dict set ::ElemImprint::gapWhy $e cross; continue}
            set free 0
            foreach {x y} [list $a $b $b $cc $cc $a] {if {[dict exists $BF [expr {$x < $y ? "$x $y" : "$y $x"}]]} {set free 1}}
            # an element with an edge on a free edge of the face is a candidate too: it is taken only
            # when the band gets better without its outline touching itself (band_eval)
            if {$free} {dict set ::ElemImprint::gapWhy $e free; dict set cand $e 1; continue}
            dict set cand $e 1
            dict set ::ElemImprint::gapWhy $e ok
        }
        if {![dict size $R] || [llength $gOuter] < 3} {continue}
        # build the band; the kept elements at the corners of its thin triangles go into R, kept only
        # when the band then has fewer thin triangles (a band that cannot get better, e.g. the corners
        # of a square outline on a regular grid, takes nothing more); again, 4 rounds at most
        lassign [band_eval $R $rowOf $gOuter $gArea $N $lim] bad badN
        for {set round 0} {$round < 4 && $bad > 0} {incr round} {
            set add {}
            dict for {n one} $badN {
                if {![dict exists $byNode $n]} {continue}
                foreach e [dict get $byNode $n] {if {[dict exists $cand $e] && ![dict exists $R $e]} {lappend add $e}}
            }
            set add [lsort -unique -integer $add]
            if {![llength $add]} {break}
            set R2 $R; foreach e $add {dict set R2 $e 1}
            lassign [band_eval $R2 $rowOf $gOuter $gArea $N $lim] bad2 badN2 pinch
            # an outline that touches itself: the candidates at the pinch go too (as the imprint grows R)
            if {$bad2 == -1 && [llength $pinch]} {
                foreach n $pinch {if {[dict exists $byNode $n]} {foreach e [dict get $byNode $n] {if {[dict exists $cand $e] && ![dict exists $R2 $e]} {dict set R2 $e 1; lappend add $e}}}}
                lassign [band_eval $R2 $rowOf $gOuter $gArea $N $lim] bad2 badN2 pinch
            }
            lappend ::ElemImprint::gapLog [list round $round bad $bad add [llength $add] bad2 $bad2 pinch [llength $pinch]]
            if {$bad2 < 0 || $bad2 >= $bad} {break}
            set R $R2; set bad $bad2; set badN $badN2
            foreach e $add {dict set hit $e 1; dict set ::ElemImprint::gapWhy $e band}
        }
        # thin target elements already there near the patch (longest edge over height > lim): taken
        # when they touch R (a node shared), again with the ones they bring next to R, 6 rounds at
        # most; a thin one not reaching R is marked thin_far (not taken: it would leave a hole apart)
        set Rn [dict create]
        dict for {e one} $R {foreach n [lrange [dict get $rowOf $e] 1 3] {dict set Rn $n 1}}
        set thin {}
        dict for {e one} $cand {if {![dict exists $R $e] && [thin_ratio [dict get $rowOf $e]] > $lim} {lappend thin $e}}
        for {set round 0} {$round < 6 && [llength $thin]} {incr round} {
            set left {}; set took 0
            foreach e $thin {
                set row [dict get $rowOf $e]
                set touch 0; foreach n [lrange $row 1 3] {if {[dict exists $Rn $n]} {set touch 1; break}}
                if {!$touch} {lappend left $e; continue}
                dict set R $e 1; dict set hit $e 1; dict set ::ElemImprint::gapWhy $e thin; incr took
                foreach n [lrange $row 1 3] {dict set Rn $n 1}
            }
            set thin $left
            if {!$took} {break}
        }
        foreach e $thin {dict set ::ElemImprint::gapWhy $e thin_far}
    }
    lsort -integer [dict keys $hit]
}
# 3D distance between segments p1-q1 and p2-q2 (closest points, clamped to both segments).
proc ::ElemImprint::seg_seg_dist3 {p1 q1 p2 q2} {
    set d1 [vsub $q1 $p1]; set d2 [vsub $q2 $p2]; set r [vsub $p1 $p2]
    set a [expr {double([dot $d1 $d1])}]; set e [expr {double([dot $d2 $d2])}]; set f [expr {double([dot $d2 $r])}]
    if {$a <= 1e-24 && $e <= 1e-24} {return [norm $r]}
    if {$a <= 1e-24} {
        set s 0.0; set t [expr {max(0.0,min(1.0,$f/$e))}]
    } else {
        set c [expr {double([dot $d1 $r])}]
        if {$e <= 1e-24} {
            set t 0.0; set s [expr {max(0.0,min(1.0,-$c/$a))}]
        } else {
            set b [dot $d1 $d2]; set den [expr {$a*$e-$b*$b}]
            set s [expr {$den > 1e-24 ? max(0.0,min(1.0,($b*$f-$c*$e)/$den)) : 0.0}]
            set t [expr {($b*$s+$f)/$e}]
            if {$t < 0.0} {set t 0.0; set s [expr {max(0.0,min(1.0,-$c/$a))}]} elseif {$t > 1.0} {set t 1.0; set s [expr {max(0.0,min(1.0,($b-$c)/$a))}]}
        }
    }
    norm [vsub [vadd $p1 [vscale $d1 $s]] [vadd $p2 [vscale $d2 $t]]]
}
# 3D distance from point p to segment a-b.
proc ::ElemImprint::seg_dist3 {p a b} {
    set ab [vsub $b $a]; set l2 [expr {double([dot $ab $ab])}]
    set t [expr {$l2 > 0 ? max(0.0,min(1.0,[dot [vsub $p $a] $ab]/$l2)) : 0.0}]
    norm [vsub $p [vadd $a [vscale $ab $t]]]
}
# Covered + one layer (Delete covered, nothing else): the elements of the target face under a source
# patch or crossing its outline, and the elements of the layer next to them (in the face or a shell of
# the same components next to it) with an edge between two target nodes closer to the patch outline
# than lim (mm, 3D). The same rule as the Gap of the newer imprint. Returns {all layer}.
proc ::ElemImprint::covered_layer {face source lim {skip {}}} {
    variable P
    set ::ElemImprint::coverWhy [dict create]
    set lim [string trim $lim]
    set useLim [expr {$lim ne "" && [string is double -strict $lim] && $lim > 0}]
    set all [dict create]
    set face [existing $face]; set source [existing $source]
    if {![llength $face] || ![llength $source]} {return {}}
    set skipS [dict create]; foreach e $skip {dict set skipS $e 1}
    set frows [tri_rows $face]
    set fn {}; foreach r $frows {lappend fn {*}[lrange $r 1 3]}
    set tN [dict create]; foreach n $fn {dict set tN $n 1}
    load_xyz [lsort -unique -integer $fn]
    set BF [boundary_edges $frows]
    set byNode [dict create]; set rowOf [dict create]
    foreach r $frows {dict set rowOf [lindex $r 0] $r; foreach n [lrange $r 1 3] {dict lappend byNode $n [lindex $r 0]}}
    set hit [dict create]
    foreach part [source_patches $source] {
        set srows [tri_rows $part]
        set sn {}; foreach r $srows {lappend sn {*}[lrange $r 1 3]}
        set sn [lsort -unique -integer $sn]
        load_xyz $sn
        set N [avg_normal $srows]
        set c {0.0 0.0 0.0}; foreach n $sn {set c [vadd $c $P($n)]}
        set c [vscale $c [expr {1.0/[llength $sn]}]]
        set ax [expr {abs([lindex $N 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
        set e1 [unit [cross $N $ax]]; set e2 [cross $N $e1]
        set f [list $c $e1 $e2]
        # the outline of the patch: segments and closed loops (2D), its outer loop (node ids)
        set keys {}; dict for {k one} [boundary_edges $srows] {lappend keys $k}
        set Q [dict create]; set segs {}; set lmax 0.0; set rad 0.0
        foreach k $keys {
            lassign $k a b
            foreach n [list $a $b] {if {![dict exists $Q $n]} {dict set Q $n [to2d $f $P($n)]}}
            set qa [dict get $Q $a]; set qb [dict get $Q $b]
            lappend segs [list $qa $qb]
            set lmax [expr {max($lmax,hypot([lindex $qb 0]-[lindex $qa 0],[lindex $qb 1]-[lindex $qa 1]))}]
        }
        dict for {n q} $Q {set rad [expr {max($rad,hypot([lindex $q 0],[lindex $q 1]))}]}
        set polys {}; set gOuter {}; set gArea -1.0
        foreach ch [lindex [edge_chains $keys] 0] {
            lassign $ch closed nodes
            if {!$closed} {continue}
            set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
            set poly {}; foreach n $nn {lappend poly [dict get $Q $n]}
            lappend polys $poly
            set ar [expr {abs([loop_area $nn $N])}]
            if {$ar > $gArea} {set gArea $ar; set gOuter $nn}
        }
        # the face elements near the patch: in R (deleted anyway) or a candidate
        set R [dict create]; set cand [dict create]
        foreach r $frows {
            lassign $r e a b cc
            set ps {}; set far 0
            foreach n [list $a $b $cc] {
                set v [vsub $P($n) $c]
                if {abs([dot $v $N]) > $rad} {set far 1}
                lappend ps [list [dot $v $e1] [dot $v $e2]]
            }
            if {$far} {continue}
            set dc 1e300
            foreach {i j} {0 1 1 2 2 0} {set dc [expr {min($dc,[lindex [pseg2 {0.0 0.0} [lindex $ps $i] [lindex $ps $j]] 0])}]}
            if {$dc > $rad+2.0*$lmax} {continue}
            if {[dict exists $skipS $e]} {dict set R $e 1; continue}
            set under 0
            foreach p $ps {
                set in 0; foreach poly $polys {if {[point_in_poly $p $poly]} {set in [expr {!$in}]}}
                if {$in} {set under 1; break}
            }
            if {$under} {dict set R $e 1; dict set ::ElemImprint::coverWhy $e under; continue}
            set cross 0
            foreach {i j} {0 1 1 2 2 0} {
                foreach s $segs {if {[seg_cross2 [lindex $ps $i] [lindex $ps $j] [lindex $s 0] [lindex $s 1]]} {set cross 1; break}}
                if {$cross} {break}
            }
            if {$cross} {dict set R $e 1; dict set ::ElemImprint::coverWhy $e cross; continue}
            set free 0
            foreach {x y} [list $a $b $b $cc $cc $a] {if {[dict exists $BF [expr {$x < $y ? "$x $y" : "$y $x"}]]} {set free 1}}
            # an element with an edge on a free edge of the face is a candidate too
            if {$free} {dict set ::ElemImprint::coverWhy $e free; dict set cand $e 1; continue}
            dict set cand $e 1
            dict set ::ElemImprint::coverWhy $e ok
        }
        dict for {e one} $R {dict set all $e 1}
        if {!$useLim || ![dict size $R] || [llength $gOuter] < 3} {continue}
        # one layer only: the nodes of R as first found (covered by the patch or crossing its
        # outline); a candidate (an element of the face, under the patch or not) must use one of them
        set R0n [dict create]
        dict for {e one} $R {foreach n [lrange [dict get $rowOf $e] 1 3] {dict set R0n $n 1}}
        # shells next to R outside the face (same components, not far off the patch plane): the
        # imprint takes them into its target when they are too close
        set inF [dict create]; foreach r $frows {dict set inF [lindex $r 0] 1}
        set inS [dict create]; foreach e $source {dict set inS $e 1}
        set out {}
        foreach e [elems_on_nodes [dict keys $R0n]] {
            if {![dict exists $inF $e] && ![dict exists $inS $e] && ![dict exists $rowOf $e]} {lappend out $e}
        }
        if {[llength $out]} {
            set fComps [dict create]; foreach cm [comps_of $face] {dict set fComps $cm 1}
            foreach e $out cfg [configs $out] cm [hm_getvalue elems user_ids=$out dataname=collector.name] {
                if {$cfg ni {103 106} || ![dict exists $fComps $cm]} {continue}
                set r [lindex [tri_rows [list $e]] 0]
                load_xyz [lrange $r 1 3]
                set far 0
                foreach n [lrange $r 1 3] {if {abs([dot [vsub $P($n) $c] $N]) > $rad} {set far 1}}
                if {$far} {continue}
                dict set rowOf $e $r
                dict set cand $e 1
                dict set ::ElemImprint::coverWhy $e outside
            }
        }
        set layer1 [dict create]
        dict for {e one} $cand {
            foreach n [lrange [dict get $rowOf $e] 1 3] {if {[dict exists $R0n $n]} {dict set layer1 $e 1; break}}
        }
        # the layer next to R: an edge of the element between two target nodes closer to the patch
        # outline than lim (3D distance between segments: a long edge passing close counts even when
        # its ends are far); an element with no such edge: its target node
        set segs3 {}; foreach k $keys {lassign $k x y; lappend segs3 [list $P($x) $P($y)]}
        dict for {e one} $layer1 {
            if {[dict exists $R $e]} {continue}
            set dmin 1e300
            lassign [lrange [dict get $rowOf $e] 1 3] na nb nc
            set edges {}
            foreach {x y} [list $na $nb $nb $nc $nc $na] {if {[dict exists $tN $x] && [dict exists $tN $y]} {lappend edges [list $x $y]}}
            if {[llength $edges]} {
                foreach ed $edges {
                    lassign $ed x y
                    foreach sg $segs3 {set dmin [expr {min($dmin,[seg_seg_dist3 $P($x) $P($y) {*}$sg])}]}
                }
            } else {
                foreach n [list $na $nb $nc] {
                    if {![dict exists $tN $n]} {continue}
                    foreach sg $segs3 {set dmin [expr {min($dmin,[seg_dist3 $P($n) {*}$sg])}]}
                }
            }
            if {$dmin < $lim} {
                dict set hit $e 1; dict set all $e 1; dict set ::ElemImprint::coverWhy $e [list near [format %.3g $dmin]]
            } else {
                dict set ::ElemImprint::coverWhy $e [list far [format %.3g $dmin]]
            }
        }
    }
    list [lsort -integer [dict keys $all]] [lsort -integer [dict keys $hit]]
}
# Longest edge over the height to it (1.15 for an equilateral triangle) of a row {id a b c ...}.
proc ::ElemImprint::thin_ratio {row} {
    variable P
    lassign $row e a b c
    set l2 0.0
    foreach {x y} [list $a $b $b $c $c $a] {set d [vsub $P($y) $P($x)]; set l2 [expr {max($l2,[dot $d $d])}]}
    set A2 [norm [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
    if {$A2 <= 1e-30} {return 1e30}
    expr {$l2/$A2}
}
# The band of narrow_gaps: R (dict of face elements, rows in rowOf) deleted, its outer outline joined to
# the patch outer outline gOuter (area gArea along N) by ruled triangles. Returns {thin badNodes}: the
# number of triangles with L/d > lim (longest edge over its height) and the outline nodes of R at their
# corners; thin is -1 when the outline cannot be built (pinched, open, not around the patch).
proc ::ElemImprint::band_eval {R rowOf gOuter gArea N lim} {
    variable P
    set cnt [dict create]
    dict for {e one} $R {
        lassign [dict get $rowOf $e] x a b cc
        foreach {p q} [list $a $b $b $cc $cc $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
    }
    set rb {}; dict for {k v} $cnt {if {$v == 1} {lappend rb $k}}
    lassign [edge_chains $rb] chains pinch
    if {[llength $pinch]} {return [list -1 {} $pinch]}
    set hOuter {}; set hArea -1.0
    foreach ch $chains {
        lassign $ch closed nodes
        if {!$closed} {continue}
        set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
        set ar [expr {abs([loop_area $nn $N])}]
        if {$ar > $hArea} {set hArea $ar; set hOuter $nn}
    }
    if {[llength $hOuter] < 3} {return {-2 {}}}
    if {$hArea <= $gArea} {return {-3 {}}}
    if {[catch {ruled $gOuter $hOuter $N} tris]} {return {-4 {}}}
    # as the imprint lays the band: diagonals flipped while the smallest angle grows
    catch {set tris [flip_improve $tris $N]}
    set hS [dict create]; foreach n $hOuter {dict set hS $n 1}
    set bad 0; set badN [dict create]
    foreach t $tris {
        lassign $t x y z
        set l2 0.0
        foreach {p q} [list $x $y $y $z $z $x] {set d [vsub $P($q) $P($p)]; set l2 [expr {max($l2,[dot $d $d])}]}
        set ar2 [norm [cross [vsub $P($y) $P($x)] [vsub $P($z) $P($x)]]]
        # L/d of the triangle = L^2 / (2 area)
        if {$ar2 <= 0 || $l2 > $lim*$ar2} {
            incr bad
            foreach n $t {if {[dict exists $hS $n]} {dict set badN $n 1}}
        }
    }
    list $bad $badN
}

# ---------------------------------------------------------------- checks
proc ::ElemImprint::check_options {opts} {
    set layers [dict get $opts layers]
    if {![string is integer -strict $layers] || $layers < 0 || $layers > 20} {error "Remesh layers must be a whole number 0..20."}
    set d [dict get $opts maxDist]
    if {$d ne "" && (![string is double -strict $d] || $d <= 0)} {error "Max distance must be empty or a positive number."}
    set v [dict get $opts holeGap]
    if {$v ne "" && (![string is double -strict $v] || $v < 0)} {error "Hole gap must be empty or a number from 0."}
    if {[dict exists $opts nearSrc]} {
        set v [dict get $opts nearSrc]
        if {$v ne "" && (![string is double -strict $v] || $v < 0)} {error "Near src must be empty or a number from 0 (mm)."}
    }
    if {[dict exists $opts gapRatio]} {
        set v [dict get $opts gapRatio]
        if {$v ne "" && (![string is double -strict $v] || $v < 0 || $v > 1)} {error "Gap ratio must be a number from 0 to 1."}
    }
}

# Elements using any of the nodes (mark 1 -> elems mark 2).
proc ::ElemImprint::elems_on_nodes {nodes} {
    if {![llength $nodes]} {return {}}
    *createmark nodes 1 {*}$nodes
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set out [hm_getmark elems 2]
    *clearmark nodes 1; *clearmark elems 2
    return $out
}

# Corner edges of triangles used once (open) as "a b" keys.
proc ::ElemImprint::open_edges {eids} {
    set cnt [dict create]
    foreach nl [elem_nodes $eids] {
        lassign $nl a b c
        foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
    }
    set out {}
    dict for {k v} $cnt {if {$v == 1} {lappend out $k}}
    return $out
}
# Shortest corner edge of triangles (or "" when there are none).
proc ::ElemImprint::min_edge {eids} {
    variable P
    if {![llength $eids]} {return ""}
    set rows [tri_rows $eids]
    set ids {}; foreach r $rows {lappend ids {*}[lrange $r 1 3]}
    load_xyz $ids
    set m ""
    foreach r $rows {
        lassign $r e a b c
        foreach {p q} [list $a $b $b $c $c $a] {
            set l [norm [vsub $P($q) $P($p)]]
            if {$m eq "" || $l < $m} {set m $l}
        }
    }
    return $m
}

proc ::ElemImprint::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::ElemImprint::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}

proc ::ElemImprint::unused_nodes {ids} {
    set ids [existing_nodes [lsort -unique -integer $ids]]
    if {![llength $ids]} {return {}}
    *createmark nodes 1 {*}$ids
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set used [node_set [hm_getmark elems 2]]
    *clearmark nodes 1; *clearmark elems 2
    set out {}
    foreach n $ids {if {[lsearch -sorted -integer $used $n] < 0} {lappend out $n}}
    return $out
}
proc ::ElemImprint::delete_elems {ids} {
    set ids [existing $ids]
    if {[llength $ids]} {*createmark elems 1 {*}$ids; *deletemark elems 1; *clearmark elems 1}
}
proc ::ElemImprint::delete_comp_if_empty {name} {
    if {$name eq "" || ![hm_entityinfo exist comps $name -byname]} {return}
    *createmark elems 1 "by collector name" $name
    set n [llength [hm_getmark elems 1]]
    *clearmark elems 1
    if {!$n} {*createmark comps 1 $name; catch {*deletemark comps 1}; *clearmark comps 1}
}
proc ::ElemImprint::temp_comp {} {
    set i 0
    while {[hm_entityinfo exist comps "__imprint_tmp$i" -byname]} {incr i}
    *createentity comps name=__imprint_tmp$i
    return __imprint_tmp$i
}


# ---------------------------------------------------------------- enclosed imprint (shared nodes)
# The way it is done by hand when one face lies inside the other: the enclosed face ("guest") is
# copied onto the enclosing face ("host") as new elements that use the guest's own nodes, the host
# elements under it (and "layers" rows around) are deleted, and the ring between the guest outline
# and the hole edge is filled with ruled triangles. Both faces then share nodes and have the same
# elements in the contact area.

# 1 when p is within snapD of a boundary edge of grid "name" (measured along that surface).
proc ::ElemImprint::near_boundary {name p Bd snapD} {
    variable P
    upvar #0 ::ElemImprint::GD_$name D
    foreach i [grid_near $name $p $snapD] {
        lassign [lindex $D(rows) $i] e a b c
        set n [lindex $D($i) 3]
        foreach {x y} [list $a $b $b $c $c $a] {
            if {![dict exists $Bd [expr {$x < $y ? "$x $y" : "$y $x"}]]} {continue}
            if {[lindex [seg_param $p $P($x) $P($y) $n] 1] <= $snapD} {return 1}
        }
    }
    return 0
}
# 1 when every corner node of rows lies over grid "name" or within snapD of its boundary (within
# holeTol of the hole edges Bh: a washer hole a little smaller than the hole it sits on).
proc ::ElemImprint::all_over {rows name Bd r snapD {Bh {}} {holeTol 0}} {
    variable P
    set ids {}
    foreach row $rows {lappend ids {*}[lrange $row 1 3]}
    foreach n [lsort -unique -integer $ids] {
        if {[llength [locate $name $P($n) $r]]} {continue}
        if {[near_boundary $name $P($n) $Bd $snapD]} {continue}
        if {[over_ridge $name $P($n) $Bd]} {continue}
        if {$holeTol > 0 && [dict size $Bh] && [near_boundary $name $P($n) $Bh $holeTol]} {continue}
        return 0
    }
    return 1
}
# A point over a convex fold of a faceted face (e.g. a washer rim over the cone of a counterbore
# wall) projects into the gap between two triangles, inside none: it still lies on the face when the
# nearest thing of the face is an inner edge (not one of its free edges Bd), within ridgeD.
proc ::ElemImprint::over_ridge {name p Bd} {
    variable ridgeD
    if {![info exists ridgeD] || $ridgeD <= 0} {return 0}
    upvar #0 ::ElemImprint::GD_$name D
    set best 1e300; set inner 0
    foreach i [grid_near $name $p $ridgeD] {
        lassign [lindex $D(rows) $i] e a b c
        lassign $D($i) pa pb pc
        foreach {n1 n2 q1 q2} [list $a $b $pa $pb $b $c $pb $pc $c $a $pc $pa] {
            set ab [vsub $q2 $q1]; set l2 [dot $ab $ab]
            set t [expr {$l2 > 0 ? max(0.0,min(1.0,[dot [vsub $p $q1] $ab]/$l2)) : 0.0}]
            set d [norm [vsub $p [vadd $q1 [vscale $ab $t]]]]
            set free [dict exists $Bd [expr {$n1 < $n2 ? "$n1 $n2" : "$n2 $n1"}]]
            # a tie (a corner shared with a free edge) counts as free
            if {$d < $best-1e-9} {set best $d; set inner [expr {!$free}]} elseif {$d <= $best+1e-9 && $free} {set inner 0}
        }
    }
    expr {$inner && $best <= $ridgeD}
}
# The free edges of a face that are holes: every closed outline but the largest one.
# 1 when every corner node of rows lies over grid "name", near its outline, or inside one of its hole
# loops (Bh, seen along N): a source that hangs over a hole of the target (a washer whose hole is
# smaller than the target hole).
proc ::ElemImprint::over_or_hole {rows name Bd r snapD Bh N} {
    variable P
    if {![dict size $Bh]} {return 0}
    set keys {}; dict for {k one} $Bh {lappend keys $k}
    set loops {}
    foreach ch [lindex [edge_chains $keys] 0] {
        lassign $ch closed nodes
        if {!$closed} {continue}
        set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
        lappend loops $nn
    }
    set ax [expr {abs([lindex $N 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $N $ax]]; set e2 [cross $N $e1]
    set polys {}
    foreach L $loops {
        set f [list $P([lindex $L 0]) $e1 $e2]
        set poly {}; foreach n $L {lappend poly [to2d $f $P($n)]}
        lappend polys [list $f $poly]
    }
    set ids {}; foreach row $rows {lappend ids {*}[lrange $row 1 3]}
    set any 0
    foreach n [lsort -unique -integer $ids] {
        if {[llength [locate $name $P($n) $r]] || [near_boundary $name $P($n) $Bd $snapD]} {continue}
        set inside 0
        foreach fp $polys {lassign $fp f poly; if {[point_in_poly [to2d $f $P($n)] $poly]} {set inside 1; break}}
        if {!$inside} {return 0}
        set any 1
    }
    return $any
}
proc ::ElemImprint::hole_edges {Bd} {
    variable P
    set keys {}; dict for {k one} $Bd {lappend keys $k}
    lassign [edge_chains $keys] chains pinch
    set loops {}
    foreach ch $chains {
        lassign $ch closed nodes
        if {!$closed} {continue}
        set A {0 0 0}; set nn [llength $nodes]
        for {set i 0} {$i < $nn} {incr i} {set A [vadd $A [cross $P([lindex $nodes $i]) $P([lindex $nodes [expr {($i+1)%$nn}]])]]}
        lappend loops [list [norm $A] $nodes]
    }
    set out [dict create]
    foreach item [lrange [lsort -real -decreasing -index 0 $loops] 1 end] {
        set nodes [lindex $item 1]; set nn [llength $nodes]
        for {set i 0} {$i < $nn} {incr i} {
            set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
            dict set out [expr {$a < $b ? "$a $b" : "$b $a"}] 1
        }
    }
    return $out
}
# Nodes made by *createnode stay temp nodes (yellow in the graphics) until their temp mark is cleared;
# the ones now used by elements keep existing. One native call for all of them.
set ::ElemImprint::madeNodes {}
# rtrias: 1 meshes the joining band between two outlines with the native ruled mesher (R-trias,
# ring_fill falls back to its own ruled layout when that fails); 0 (default, about 30-40% faster on
# test4, same smallest angles) uses only the own ruled layout. rtriKeys: R-trias triangles (node sets)
if {![info exists ::ElemImprint::rtrias]} {set ::ElemImprint::rtrias 0}
set ::ElemImprint::rtriKeys [dict create]
if {![info exists ::ElemImprint::rfLog]} {set ::ElemImprint::rfLog {}}
proc ::ElemImprint::clear_temp_nodes {} {
    set ids {}
    foreach n [lsort -unique -integer $::ElemImprint::madeNodes] {if {[hm_entityinfo exist nodes $n -byid]} {lappend ids $n}}
    set ::ElemImprint::madeNodes {}
    if {[llength $ids]} {*createmark nodes 1 {*}$ids; *nodemarkcleartempmark 1; *clearmark nodes 1}
}
proc ::ElemImprint::row_area {row} {
    variable P
    lassign $row e a b c
    expr {0.5*[norm [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]}
}
proc ::ElemImprint::avg_normal {rows} {
    variable P
    set s {0.0 0.0 0.0}
    foreach row $rows {
        lassign $row e a b c
        set s [vadd $s [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
    }
    unit $s
}
proc ::ElemImprint::loop_area {loop N} {
    variable P
    set s {0.0 0.0 0.0}
    set n [llength $loop]
    set o $P([lindex $loop 0])
    for {set i 1} {$i < $n-1} {incr i} {
        set s [vadd $s [cross [vsub $P([lindex $loop $i]) $o] [vsub $P([lindex $loop [expr {$i+1}]]) $o]]]
    }
    dot $s $N
}
# Mean distance from the nodes of loop a to the nodes of loop b.
proc ::ElemImprint::loop_gap {a b} {
    variable P
    set sum 0.0
    foreach n $a {
        set best 1e300
        foreach m $b {set d [norm [vsub $P($n) $P($m)]]; if {$d < $best} {set best $d}}
        set sum [expr {$sum+$best}]
    }
    expr {$sum/max(1,[llength $a])}
}
# Ruled triangles between closed loops A and B, the way the native Ruled tool joins two node lists
# picked in order: both loops are put in the same direction around N and given a parameter t in
# [0,1) from one common start, then merged by t (the side whose next node comes first advances).
# t is the angle around the common centre when both loops go once around it (holes, washers), else
# the normalised arc length from the node nearest in angle to the common start. Never a greedy
# shortest-diagonal walk (it drifts out of phase on eccentric loops). align is kept for callers.
proc ::ElemImprint::loop_frame {A B N} {
    variable P
    # centre: the middle of the smaller loop (the hole), seen from where both loops go around once
    set S [expr {abs([loop_area $A $N]) <= abs([loop_area $B $N]) ? $A : $B}]
    set c {0.0 0.0 0.0}
    foreach n $S {set c [vadd $c $P($n)]}
    set c [vscale $c [expr {1.0/max(1,[llength $S])}]]
    set N [unit $N]
    set ax [expr {abs([lindex $N 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $N $ax]]
    list $c $e1 [cross $N $e1]
}
# Angles (0..2pi) of the nodes of L around frame f; "" when L does not go exactly once around the
# centre with increasing angle (not star-shaped seen from it).
proc ::ElemImprint::loop_angles {L f} {
    variable P
    set tw [expr {2*acos(-1)}]
    set out {}; set turn 0.0; set prev ""
    foreach n $L {
        lassign [to2d $f $P($n)] x y
        set a [expr {atan2($y,$x)}]
        if {$a < 0} {set a [expr {$a+$tw}]}
        if {$prev ne ""} {
            set d [expr {$a-$prev}]
            if {$d < -acos(-1)} {set d [expr {$d+$tw}]} elseif {$d > acos(-1)} {set d [expr {$d-$tw}]}
            if {$d <= 0} {return ""}
            set turn [expr {$turn+$d}]
        }
        set prev $a
        lappend out $a
    }
    set d [expr {[lindex $out 0]-$prev}]
    if {$d < 0} {set d [expr {$d+$tw}]}
    if {abs($turn+$d-$tw) > 1e-6} {return ""}
    return $out
}
# Loop L rotated to start at its smallest parameter, with parameters 0..1: {nodes params}.
# Parameters from angles when given, else from arc length starting at node s0 (offset by its angle).
proc ::ElemImprint::loop_params {L ang f} {
    variable P
    set tw [expr {2*acos(-1)}]
    set n [llength $L]
    if {$ang ne ""} {
        set i0 0
        for {set i 1} {$i < $n} {incr i} {if {[lindex $ang $i] < [lindex $ang $i0]} {set i0 $i}}
        set nodes {}; set ts {}
        for {set k 0} {$k < $n} {incr k} {
            set i [expr {($i0+$k)%$n}]
            lappend nodes [lindex $L $i]; lappend ts [expr {[lindex $ang $i]/$tw}]
        }
        return [list $nodes $ts]
    }
    # arc length: start at the node whose angle is nearest the reference direction
    set i0 0; set best 1e300
    for {set i 0} {$i < $n} {incr i} {
        lassign [to2d $f $P([lindex $L $i])] x y
        set a [expr {abs(atan2($y,$x))}]
        if {$a < $best} {set best $a; set i0 $i}
    }
    set L [concat [lrange $L $i0 end] [lrange $L 0 [expr {$i0-1}]]]
    lassign [loop_cum $L] cum tot
    set ts {}
    for {set i 0} {$i < $n} {incr i} {lappend ts [expr {$tot > 0 ? [lindex $cum $i]/$tot : double($i)/$n}]}
    list $L $ts
}
proc ::ElemImprint::ruled {A B N {align 1}} {
    variable P
    if {[llength $A] < 2 || [llength $B] < 2} {error "LAYER: a ruled outline has fewer than two nodes."}
    # same direction: counter-clockwise around N
    if {[loop_area $A $N] < 0} {set A [lreverse $A]}
    if {[loop_area $B $N] < 0} {set B [lreverse $B]}
    set f [loop_frame $A $B $N]
    set aA [loop_angles $A $f]; set aB [loop_angles $B $f]
    # angles only when both loops go around the centre; else both by arc length
    if {$aA eq "" || $aB eq ""} {set aA ""; set aB ""}
    lassign [loop_params $A $aA $f] A tA
    lassign [loop_params $B $aB $f] B tB
    set na [llength $A]; set nb [llength $B]
    lappend tA [expr {1.0+[lindex $tA 0]}]; lappend tB [expr {1.0+[lindex $tB 0]}]
    # both lists start near t=0; the merge runs once around
    set tris {}
    set i 0; set j 0
    while {$i < $na || $j < $nb} {
        set a0 [lindex $A [expr {$i % $na}]]; set a1 [lindex $A [expr {($i+1) % $na}]]
        set b0 [lindex $B [expr {$j % $nb}]]; set b1 [lindex $B [expr {($j+1) % $nb}]]
        if {$i >= $na} {set adv B} elseif {$j >= $nb} {set adv A} else {
            set adv [expr {[lindex $tA [expr {$i+1}]] <= [lindex $tB [expr {$j+1}]] ? "A" : "B"}]
        }
        if {$adv eq "A"} {lappend tris [list $a0 $a1 $b0]; incr i} else {lappend tris [list $a0 $b1 $b0]; incr j}
    }
    # one orientation, along N
    set out {}
    foreach t $tris {
        lassign $t x y z
        if {$x == $y || $y == $z || $x == $z} {continue}
        if {[dot [cross [vsub $P($y) $P($x)] [vsub $P($z) $P($x)]] $N] < 0} {set t [list $x $z $y]}
        lappend out $t
    }
    return $out
}
# Midside node of edge a-b from the map (existing elements), else a new node at the midpoint.
proc ::ElemImprint::mid_node {mapVar a b} {
    variable P
    upvar 1 $mapVar map
    set k [expr {$a < $b ? "$a $b" : "$b $a"}]
    if {[dict exists $map $k]} {return [dict get $map $k]}
    *createnode {*}[vscale [vadd $P($a) $P($b)] 0.5] 0 0 0
    set id [hm_latestentityid nodes]
    lappend ::ElemImprint::madeNodes $id
    set P($id) [vscale [vadd $P($a) $P($b)] 0.5]
    dict set map $k $id
    return $id
}
proc ::ElemImprint::add_mids {mapVar eids} {
    upvar 1 $mapVar map
    if {![llength $eids]} {return}
    foreach nl [elem_nodes $eids] c [configs $eids] {
        if {$c != 106} {continue}
        lassign $nl a b cc m1 m2 m3
        foreach {x y m} [list $a $b $m1 $b $cc $m2 $cc $a $m3] {dict set map [expr {$x < $y ? "$x $y" : "$y $x"}] $m}
    }
}
# Creates elements: rows of full node lists with their config. Returns the new ids.
proc ::ElemImprint::create_rows {rows cfg} {
    if {![llength $rows]} {return {}}
    set conn {}
    foreach nl $rows {lappend conn {*}$nl}
    hm_entityrecorder elems on
    set rc [catch {*createarray [llength $conn] {*}$conn; *createelements $cfg 1 1 [llength $conn]} m]
    hm_entityrecorder elems off
    if {$rc} {error "Creating elements failed: $m"}
    set ids [existing [hm_entityrecorder elems ids]]
    if {[llength $ids] != [llength $rows]} {error "Expected [llength $rows] elements of config $cfg, got [llength $ids] (readback)."}
    # readback: the new elements have exactly the requested node lists
    set want [dict create]
    foreach nl $rows {dict incr want [lsort -integer $nl]}
    foreach nl [elem_nodes $ids] {
        set k [lsort -integer $nl]
        if {![dict exists $want $k]} {error "Created element nodes $nl were not requested (readback; recorder ids [lrange $ids 0 4], first request [lindex $rows 0])."}
    }
    return $ids
}

# One attempt in one Undo step. Errors: "PARTIAL" (no face encloses the other), "LAYER: ..." (the
# ring could not be filled), "GROW: ..." (ring triangles fail the standard). Returns a dict (see the end).
set ::ElemImprint::wrote 0
proc ::ElemImprint::enclose_once {target source opts} {
    variable P; variable snapFrac; variable outer
    array unset P
    set ::ElemImprint::ringNodes {}
    set ::ElemImprint::rtriKeys [dict create]
    set ::ElemImprint::goneElems [dict create]
    set target [existing $target]; set source [existing $source]
    if {![llength $target]} {error "Select the target elements."}
    if {![llength $source]} {error "Select the source elements."}
    set t [lsort -integer $target]; set both 0
    foreach e $source {if {[lsearch -sorted -integer $t $e] >= 0} {incr both}}
    if {$both} {error "$both elements are both target and source."}
    lassign [kind $target target] tDim tOrder tCfg
    lassign [kind $source source] sDim sOrder sCfg
    set before [list [count elems] [count nodes]]
    set curComp [hm_info currentcomponent]
    set label "Element imprint"
    # (outer is 0: this attempt owns its Undo step and the rollback)
    if {!$outer} {history_begin $label; set ::ElemImprint::wrote 0}
    set temps {}; set comps {}
    set code [catch {
        set Trows [tri_rows $target]; set Srows [tri_rows $source]
        set mT [grid_build T $Trows]; set mS [grid_build S $Srows]
        set r [dict get $opts maxDist]
        if {$r eq ""} {set r [expr {$mT+$mS}]}
        grid_index T [expr {max($mT,$r/2.0)}]
        grid_index S [expr {max($mS,$r/2.0)}]
        # nodes within this of the other face count as on it (Max distance, or half the mesh size)
        set rc3 [expr {[dict get $opts maxDist] ne "" ? [dict get $opts maxDist] : 0.5*min($mT,$mS)}]
        set snapD [expr {$snapFrac*min($mT,$mS)}]
        set ::ElemImprint::ridgeD $rc3
        if {[dict exists $opts snapD]} {set snapD [expr {max($snapD,[dict get $opts snapD])}]}
        set BT [boundary_edges $Trows]; set BS [boundary_edges $Srows]
        # nodes this close to a hole edge of the other face count as on it (see hole_edges)
        set gapTol [expr {[dict get $opts holeGap] ne "" ? [dict get $opts holeGap] : 0.3*min($mT,$mS)}]
        set holeTol0 [expr {[dict exists $opts mergeTol] ? 0 : $gapTol}]
        set HT [hole_edges $BT]; set HS [hole_edges $BS]
        # a source over the chamfer of a target hole hangs over that hole: its nodes may lie farther
        # than Max distance from the sloped chamfer, so Join small hole looks at the holes of the
        # target face without its chamfer rows (their top edge)
        set HTflat $HT
        if {[dict exists $opts chamferRows]} {
            set chS [dict create]; foreach e [dict get $opts chamferRows] {dict set chS $e 1}
            set flat {}; foreach row $Trows {if {![dict exists $chS [lindex $row 0]]} {lappend flat $row}}
            if {[llength $flat]} {set HTflat [hole_edges [boundary_edges $flat]]}
        }
        # which face encloses the other
        if {[all_over $Srows T $BT $r $snapD $HT $holeTol0]} {
            set swapped 0
            set H [list name T ids $target order $tOrder]
            set G [list name S ids $source order $sOrder rows $Srows B $BS]
        } elseif {![dict exists $opts force] && [all_over $Trows S $BS $r $snapD $HS $holeTol0]} {
            set swapped 1
            set H [list name S ids $source order $sOrder]
            set G [list name T ids $target order $tOrder rows $Trows B $BT]
        } elseif {(![dict exists $opts joinSmall] || [dict get $opts joinSmall]) && [over_or_hole $Srows T $BT $r $snapD $HTflat [avg_normal $Trows]]} {
            # Join small hole: the source hangs over a hole of the target (its hole smaller than the
            # target hole): the whole source is copied, the target hole edge is joined to the source
            # hole by a ring (see direct_bands), as for a source hole larger than the target hole
            set swapped 0
            set H [list name T ids $target order $tOrder]
            set G [list name S ids $source order $sOrder rows $Srows B $BS]
        } elseif {[dict exists $opts trim] && [dict get $opts trim]} {
            # neither face lies wholly on the other (e.g. a bolt head over a hole with a chamfer): the
            # larger face is the host, and only the elements of the other face lying wholly on it are
            # copied; the rest overhangs (over a hole or past an edge) and stays as it is
            set aT 0.0; foreach row $Trows {set aT [expr {$aT+[row_area $row]}]}
            set aS 0.0; foreach row $Srows {set aS [expr {$aS+[row_area $row]}]}
            set swapped [expr {$aS > $aT && ![dict exists $opts force]}]
            if {$swapped} {
                set H [list name S ids $source order $sOrder]
                set gRows $Trows; set gBd $BS; set gn T; set gIn [list $target $tOrder]
            } else {
                set H [list name T ids $target order $tOrder]
                set gRows $Srows; set gBd $BT; set gn S; set gIn [list $source $sOrder]
            }
            set hn [expr {$swapped ? "S" : "T"}]
            set kept {}
            set gHo [expr {$swapped ? $HS : $HT}]
            # Hole gap only decided that the two faces are not "the same hole" (the first test above);
            # here every element must lie really on the target (no hole tolerance), or the outline of
            # what is kept would be jagged next to the elements left out
            foreach row $gRows {if {[all_over [list $row] $hn $gBd $r $snapD $gHo 0]} {lappend kept $row}}
            if {![llength $kept]} {error "PARTIAL"}
            set ::ElemImprint::trimmed [expr {[llength $gRows]-[llength $kept]}]
            lassign $gIn gIds0 gOrder0
            grid_build $gn $kept
            set G [list name $gn ids $gIds0 order $gOrder0 rows $kept B [boundary_edges $kept]]
        } else {
            error "PARTIAL"
        }
        set hName [dict get $H name]; set gName [dict get $G name]
        set Grows [dict get $G rows]; set BG [dict get $G B]
        set hOrder [dict get $H order]
        # host rows that may change
        set Hsurf [tri_rows [dict get $H ids]]
        set hostComp [lindex [comps_of [dict get $H ids]] 0]
        grid_build $gName $Grows; grid_index $gName [expr {max($mS,$mT,$r/2.0)}]
        set ids {}; foreach row [concat $Hsurf $Grows] {lappend ids {*}[lrange $row 1 3]}
        load_xyz $ids
        # free edges of the host face
        set BH [boundary_edges $Hsurf]
        # host rows under the guest: a corner over it or next to its outline, the centroid over it,
        # an outline node inside the row, or an outline edge crossing the row
        set R [dict create]
        set gB {}; dict for {k one} $BG {lappend gB $k}
        foreach row $Hsurf {
            lassign $row e a b c
            set hit 0
            foreach n [list $a $b $c] {
                if {[llength [locate $gName $P($n) $r]] || [near_boundary $gName $P($n) $BG $snapD]} {set hit 1; break}
            }
            set c3 [vscale [vadd [vadd $P($a) $P($b)] $P($c)] [expr {1.0/3}]]
            if {!$hit && [llength [locate $gName $c3 $r]]} {set hit 1}
            if {!$hit} {
                set n3 [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
                set e1 [unit [vsub $P($b) $P($a)]]; set f [list $P($a) $e1 [cross $n3 $e1]]
                set A2 [to2d $f $P($a)]; set B2 [to2d $f $P($b)]; set C2 [to2d $f $P($c)]
                set rad [expr {max([norm [vsub $P($a) $c3]],[norm [vsub $P($b) $c3]],[norm [vsub $P($c) $c3]])}]
                foreach i [grid_near $gName $c3 [expr {$rad+$r}]] {
                    upvar #0 ::ElemImprint::GD_$gName DG
                    lassign [lindex $DG(rows) $i] ge ga gb gc
                    foreach {x y} [list $ga $gb $gb $gc $gc $ga] {
                        if {![dict exists $BG [expr {$x < $y ? "$x $y" : "$y $x"}]]} {continue}
                        set X2 [to2d $f $P($x)]; set Y2 [to2d $f $P($y)]
                        if {[in_tri2 $X2 $A2 $B2 $C2 1e-9]} {set hit 1; break}
                        foreach {p q} [list $A2 $B2 $B2 $C2 $C2 $A2] {
                            set s [seg_x $p $q $X2 $Y2]
                            if {[llength $s] && [lindex $s 0] > 0 && [lindex $s 0] < 1 && [lindex $s 1] > 0 && [lindex $s 1] < 1} {set hit 1; break}
                        }
                        if {$hit} {break}
                    }
                    if {$hit} {break}
                }
            }
            if {$hit} {dict set R $e $row}
        }
        if {![dict size $R]} {error "PARTIAL"}
        set byNode [dict create]
        foreach row $Hsurf {foreach n [lrange $row 1 3] {dict lappend byNode $n $row}}
        # A closed hole edge of the host lying under the copy (or within Hole gap of its outline): the
        # rows deleted are counted from that hole edge, Remesh layers rows (1 = only the row touching
        # the hole edge), plus the rows under the copy; no extra row around the copy. Without such a
        # hole edge Remesh layers adds rows around the rows under the copy, as before.
        set holeRows [dict create]
        set freeK {}; dict for {k one} $BH {lappend freeK $k}
        foreach ch [lindex [edge_chains $freeK] 0] {
            lassign $ch closed nodes
            if {!$closed} {continue}
            set under 1
            foreach n $nodes {
                set n [lindex [split $n #] 0]
                if {![llength [locate $gName $P($n) $rc3]] && ![near_boundary $gName $P($n) $BG [expr {max($snapD,$gapTol)}]]} {set under 0; break}
            }
            if {!$under} {continue}
            foreach n $nodes {foreach r2 [dict get $byNode [lindex [split $n #] 0]] {dict set holeRows [lindex $r2 0] $r2}}
        }
        # Chamfer: a closed hole edge of the host near the copy (under it, or within a mesh size of
        # its outline) may be the top of a chamfer that was not picked (By face stops at it). The
        # elements outside the host on that edge, short of the hole wall (under 80 degrees to the host face, also nearly flat steps), are
        # deleted with R, row by row down to the hole wall (steeper than 70 degrees); the top of the
        # wall becomes a hole edge of R and is joined by the ring to the hole of the copy.
        set chamfer {}
        if {![dict exists $opts trim] || ![dict get $opts trim]} {
            set Nh [avg_normal $Hsurf]
            set hsSet [dict create]; foreach row $Hsurf {dict set hsSet [lindex $row 0] 1}
            # holes of the host only: its outer outline (e.g. the top edge of a counterbore wall picked
            # with the floor) is kept, the face around it is not a chamfer
            set HHo [hole_edges $BH]
            foreach ch [lindex [edge_chains $freeK] 0] {
                lassign $ch closed nodes
                if {!$closed} {continue}
                set n0 [lindex [split [lindex $nodes 0] #] 0]; set n1 [lindex [split [lindex $nodes 1] #] 0]
                if {![dict exists $HHo [expr {$n0 < $n1 ? "$n0 $n1" : "$n1 $n0"}]]} {continue}
                set front {}
                set near 1
                foreach n $nodes {
                    set n [lindex [split $n #] 0]
                    lappend front $n
                    if {![llength [locate $gName $P($n) $r]] && ![near_boundary $gName $P($n) $BG [expr {$mT+$mS}]]} {set near 0; break}
                }
                if {!$near} {continue}
                set seenC [dict create]
                for {set it 0} {$it < 4 && [llength $front]} {incr it} {
                    set add {}
                    set es {}
                    foreach e [elems_on_nodes $front] {if {![dict exists $hsSet $e] && ![dict exists $seenC $e]} {lappend es $e}}
                    if {![llength $es]} {break}
                    set nls [elem_nodes $es]
                    set allN {}; foreach nl $nls {lappend allN {*}[lrange $nl 0 2]}
                    load_xyz [lsort -unique -integer $allN]
                    set next {}
                    foreach e $es nl $nls c [configs $es] {
                        if {$c != 103 && $c != 106} {continue}
                        lassign $nl a b cc
                        set nE [unit [cross [vsub $P($b) $P($a)] [vsub $P($cc) $P($a)]]]
                        set ang [expr {acos(min(1.0,abs([dot $nE $Nh])))*180.0/acos(-1)}]
                        if {$ang > 80.0} {continue}
                        dict set seenC $e 1
                        lappend add $e [list $e $a $b $cc]
                        lappend next $a $b $cc
                    }
                    if {![llength $add]} {break}
                    foreach {e2 r2} $add {
                        dict set R $e2 $r2; lappend chamfer $e2
                        foreach n [lrange $r2 1 3] {dict lappend byNode $n $r2}
                    }
                    set front [lsort -unique -integer $next]
                }
            }
        }
        # chamfer rows the target face already holds (target_face): all of them are deleted
        if {[dict exists $opts chamferRows]} {
            set chS [dict create]; foreach e [dict get $opts chamferRows] {dict set chS $e 1}
            foreach row $Hsurf {
                set e2 [lindex $row 0]
                if {[dict exists $chS $e2] && ![dict exists $R $e2]} {
                    dict set R $e2 $row; lappend chamfer $e2
                    foreach n [lrange $row 1 3] {dict lappend byNode $n $row}
                }
            }
        }
        set ::ElemImprint::chamfer $chamfer
        # rows too close to the source outline (narrow_gaps): deleted too, the band starts behind them
        if {[dict exists $opts gapRows]} {
            set gS [dict create]; foreach e [dict get $opts gapRows] {dict set gS $e 1}
            foreach row $Hsurf {
                set e2 [lindex $row 0]
                if {[dict exists $gS $e2] && ![dict exists $R $e2]} {
                    dict set R $e2 $row
                    foreach n [lrange $row 1 3] {dict lappend byNode $n $row}
                }
            }
        }
        set extra [dict get $opts layers]
        if {[dict size $holeRows]} {
            for {set k 1} {$k < $extra} {incr k} {
                set add {}
                dict for {e row} $holeRows {
                    foreach n [lrange $row 1 3] {
                        foreach r2 [dict get $byNode $n] {if {![dict exists $holeRows [lindex $r2 0]]} {lappend add [lindex $r2 0] $r2}}
                    }
                }
                foreach {e2 r2} $add {dict set holeRows $e2 $r2}
            }
            dict for {e row} $holeRows {dict set R $e $row}
            set extra 0
        }
        # more rows around (Remesh layers), never reaching the host's free edge
        for {set k 0} {$k < $extra} {incr k} {
            set add {}
            dict for {e row} $R {
                foreach n [lrange $row 1 3] {
                    foreach r2 [dict get $byNode $n] {
                        set e2 [lindex $r2 0]
                        if {[dict exists $R $e2]} {continue}
                        lassign $r2 x a b c
                        set free 0
                        foreach {p q} [list $a $b $b $c $c $a] {if {[dict exists $BH [expr {$p < $q ? "$p $q" : "$q $p"}]]} {set free 1}}
                        if {!$free} {lappend add $e2 $r2}
                    }
                }
            }
            if {![llength $add]} {break}
            foreach {e2 r2} $add {dict set R $e2 $r2}
        }
        # --- the region to fill: R minus the guest. Grow R first where a hole edge of the host lies
        # under the guest (e.g. the top of a hole wall just inside a washer) or where the hole
        # touches itself at a node.
        for {set it 0} {$it < 8} {incr it} {
            set cnt [dict create]
            dict for {e row} $R {
                lassign $row x a b c
                foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
            }
            set holeEdges {}
            dict for {k v} $cnt {if {$v == 1 && ![dict exists $BH $k]} {lappend holeEdges $k}}
            set grow {}
            lassign [edge_chains $holeEdges] chains pinches
            foreach n $pinches {foreach r2 [dict get $byNode $n] {if {![dict exists $R [lindex $r2 0]]} {lappend grow [lindex $r2 0] $r2}}}
            foreach ch $chains {
                lassign $ch closed nodes
                if {!$closed} {continue}
                set under 1
                foreach n $nodes {if {![llength [locate $gName $P($n) $rc3]] && ![near_boundary $gName $P($n) $BG $snapD]} {set under 0; break}}
                if {$under} {foreach n $nodes {foreach r2 [dict get $byNode $n] {if {![dict exists $R [lindex $r2 0]]} {lappend grow [lindex $r2 0] $r2}}}}
            }
            if {![llength $grow]} {break}
            foreach {e2 r2} $grow {dict set R $e2 $r2}
        }
        if {[llength $grow]} {error "LAYER: the hole in the host face is not a simple outline."}
        # Gap rows: a node of the R outline (not on a free edge of the host) closer to the copy outline
        # than gapNear would leave slivers between them (too close to make a row, too far to merge):
        # its host rows are deleted too, so the ring starts from the next nodes out. Decided by the
        # tool, a few passes at most.
        # Gap ratio (option, default 0.3; the window passes 0): a kept row whose edge on the R outline runs closer to the copy
        # outline than ratio x its length (d/L < ratio, d measured at 7 points along the edge) goes too;
        # its node test uses ratio x 1.5 x the smaller mean edge (0.45 at 0.3). 0 switches it off.
        set gapRatio [expr {[dict exists $opts gapRatio] && [string is double -strict [dict get $opts gapRatio]] ? [dict get $opts gapRatio] : 0.3}]
        set gapNear [expr {1.5*$gapRatio*min($mT,$mS)}]
        # free edges of the target face itself (not the edges where a local window cuts it)
        set BHt $BH
        if {[dict exists $opts faceFree]} {set BHt [dict create]; foreach kk [dict get $opts faceFree] {dict set BHt $kk 1}}
        set freeN [dict create]
        dict for {k one} $BHt {foreach n $k {dict set freeN $n 1}}
        for {set it 0} {$it < 3} {incr it} {
            set grow {}
            set seenN [dict create]
            dict for {k v} $cnt {
                if {$v != 1} {continue}
                foreach n $k {
                    if {[dict exists $seenN $n] || [dict exists $freeN $n]} {continue}
                    dict set seenN $n 1
                    if {![near_boundary $gName $P($n) $BG $gapNear]} {continue}
                    foreach r2 [dict get $byNode $n] {if {![dict exists $R [lindex $r2 0]]} {lappend grow [lindex $r2 0] $r2}}
                }
                # a copy outline node near the middle of this edge would split the kept row beside it
                # into slivers: that row goes too
                if {[dict exists $BHt $k] || $gapRatio <= 0} {continue}
                lassign $k x y
                set l [norm [vsub $P($y) $P($x)]]
                if {$l <= 0} {continue}
                if {[dict exists $BH $k]} {
                    # the window edge: the row across it is outside the window; a wider window is asked for
                    foreach t {0.2 0.5 0.8} {
                        if {[near_boundary $gName [vadd $P($x) [vscale [vsub $P($y) $P($x)] $t]] $BG [expr {$gapRatio*$l}]]} {set ::ElemImprint::needWider 1; break}
                    }
                    continue
                }
                # the edge itself close to the copy outline along its length (d/L < Gap ratio)
                set hitL 0
                foreach t {0.2 0.3 0.4 0.5 0.6 0.7 0.8} {
                    if {[near_boundary $gName [vadd $P($x) [vscale [vsub $P($y) $P($x)] $t]] $BG [expr {$gapRatio*$l}]]} {set hitL 1; break}
                }
                if {$hitL} {
                    foreach r2 [dict get $byNode $x] {
                        if {[dict exists $R [lindex $r2 0]] || [lsearch -exact [lrange $r2 1 3] $y] < 0} {continue}
                        lappend grow [lindex $r2 0] $r2
                    }
                    continue
                }
                foreach gk $gB {
                    set hitE 0
                    foreach g $gk {
                        set s [expr {[dot [vsub $P($g) $P($x)] [vsub $P($y) $P($x)]]/($l*$l)}]
                        if {$s*$l <= $gapNear || (1-$s)*$l <= $gapNear} {continue}
                        if {[norm [vsub $P($g) [vadd $P($x) [vscale [vsub $P($y) $P($x)] $s]]]] <= $gapNear} {set hitE 1; break}
                    }
                    if {$hitE} {
                        foreach r2 [dict get $byNode $x] {
                            if {[dict exists $R [lindex $r2 0]] || [lsearch -exact [lrange $r2 1 3] $y] < 0} {continue}
                            lappend grow [lindex $r2 0] $r2
                        }
                        break
                    }
                }
            }
            # Near src (option, mm, empty = off; the window leaves it off): a kept row on the R outline with an edge closer than
            # Near src to a node of the copy outline (distance to the edge segment) goes too
            if {[dict exists $opts nearSrc] && [string is double -strict [dict get $opts nearSrc]] && [dict get $opts nearSrc] > 0} {
                set nearLim [dict get $opts nearSrc]
                set gN [dict create]; foreach gk $gB {foreach g $gk {dict set gN $g 1}}
                # every host row of the window (not only the ones on the R outline), as Show measures
                set seenR [dict create]
                foreach r2 $Hsurf {
                    if {1} {
                        set e2 [lindex $r2 0]
                        if {[dict exists $R $e2] || [dict exists $seenR $e2]} {continue}
                        dict set seenR $e2 1
                        lassign $r2 xx a b c
                        set hitN 0
                        foreach {u v} [list $a $b $b $c $c $a] {
                            set uv [vsub $P($v) $P($u)]; set l2 [dot $uv $uv]
                            if {$l2 <= 0} {continue}
                            foreach g [dict keys $gN] {
                                if {$g == $u || $g == $v} {continue}
                                set t [expr {max(0.0,min(1.0,[dot [vsub $P($g) $P($u)] $uv]/$l2))}]
                                if {[norm [vsub $P($g) [vadd $P($u) [vscale $uv $t]]]] < $nearLim} {set hitN 1; break}
                            }
                            if {$hitN} {break}
                        }
                        if {$hitN} {lappend grow $e2 $r2}
                    }
                }
            }
            # (never a row on a free edge of the host: the gap rows stay inside the face)
            set g2 {}
            foreach {e2 r2} $grow {
                lassign $r2 x a b c
                set free 0
                set win 0
                foreach {p q} [list $a $b $b $c $c $a] {
                    set kk [expr {$p < $q ? "$p $q" : "$q $p"}]
                    if {[dict exists $BHt $kk]} {set free 1} elseif {[dict exists $BH $kk]} {set win 1}
                }
                # a row on the edge of a local window: not taken here, a wider window is asked for
                if {$win && !$free} {set ::ElemImprint::needWider 1; continue}
                # Near src outer rows (from the face next to the target) are deleted on its outline too
                if {$free && [dict exists $opts nearOuter] && [lsearch -exact -integer [dict get $opts nearOuter] $e2] >= 0} {set free 0}
                if {!$free} {lappend g2 $e2 $r2}
            }
            set grow $g2
            if {![llength $grow]} {break}
            foreach {e2 r2} $grow {dict set R $e2 $r2}
            set cnt [dict create]
            dict for {e row} $R {
                lassign $row x a b c
                foreach {p q} [list $a $b $b $c $c $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
            }
        }
        set Rrows {}; dict for {e row} $R {lappend Rrows $row}
        # the host rows that go (deleted before the band is created; see twin_alive)
        set ::ElemImprint::goneElems [dict create]; dict for {e row} $R {dict set ::ElemImprint::goneElems $e 1}
        set N [avg_normal $Rrows]
        # boundary edges of R (hole edges and host free edges) and the host face normal near them
        set Rb {}
        dict for {k v} $cnt {if {$v == 1} {lappend Rb $k}}
        set gNodes [dict create]
        foreach k $gB {foreach n $k {dict set gNodes $n 1}}
        load_xyz [concat [dict keys $gNodes] [node_set [dict keys $R]]]
        if {[dict exists $opts direct] && [dict get $opts direct]} {
            # Direct build: no node is merged or inserted. The host rows touched by the copy (R, plus
            # the layers asked for) are deleted; the outline of what was deleted (it includes free
            # edges of the face where it reaches them) is joined by ruled triangles to the outline of
            # the copy, loop to loop (the outer one to the outer one, a hole to a hole). The quality
            # is looked at afterwards.
            set vmap [dict create]; set splits [dict create]; set freePieces [dict create]; set fchains {}
            set bands [direct_bands $Rb $BG $N $hName]
            foreach k $::ElemImprint::unfilled {dict set freePieces $k 1}
            set bands [fold_fix [flip_improve $bands $N]]
            set ringAngle 180.0
            foreach tr $bands {set a1 [expr {[tri_min_angle {*}$tr]*180.0/acos(-1)}]; if {$a1 < $ringAngle} {set ringAngle $a1}}
            set fchains [list $bands]
        } else {
        # guest outline nodes on the R boundary: merged with a host node or inserted into an edge
        # node merge tolerance: snapD, or the caller's (exact for the cut overlap on its own target)
        set mtol [expr {[dict exists $opts mergeTol] ? [dict get $opts mergeTol] : $snapD}]
        # a host node this close to a copy node is merged into it (as an equivalence by hand would)
        set mtolV [expr {[dict exists $opts mergeTol] ? $mtol : max($snapD,0.15*min($mT,$mS))}]
        set vmap [dict create]; set splits [dict create]
        set rbNodes [dict create]
        foreach k $Rb {foreach n $k {dict set rbNodes $n 1}}
        # every host node on the R boundary takes the nearest guest outline node within mtol
        dict for {v one2} $rbNodes {
            set bestG ""; set dG $mtolV
            dict for {g one} $gNodes {
                set d [norm [vsub $P($g) $P($v)]]
                if {$d <= $dG} {set dG $d; set bestG $g}
            }
            if {$bestG ne ""} {dict set vmap $v $bestG}
        }
        set mappedG [dict create]
        dict for {v g} $vmap {dict set mappedG $g 1}
        # merge them in the whole model (*replacenodes moves the host node onto the copy node and
        # every element using it, also outside the selection, takes the copy node)
        # (merges keep the counts, so a failure after them must be undone by this flag)
        if {[dict size $vmap]} {set ::ElemImprint::wrote 1}
        dict for {v g} $vmap {if {$v != $g} {*replacenodes $v $g 1 0}}
        # a host edge also used by elements outside the host face is never split (it would leave
        # those elements unconnected)
        set hsIds [dict create]
        foreach row $Hsurf {dict set hsIds [lindex $row 0] 1}
        dict for {g one} $gNodes {
            if {[dict exists $mappedG $g]} {continue}
            foreach k $Rb {
                lassign $k x y
                set l [norm [vsub $P($y) $P($x)]]
                set s [expr {$l > 0 ? max(0.0,min(1.0,[dot [vsub $P($g) $P($x)] [vsub $P($y) $P($x)]]/($l*$l))) : 0.0}]
                set d [norm [vsub $P($g) [vadd $P($x) [vscale [vsub $P($y) $P($x)] $s]]]]
                if {$d <= $mtol && $s*$l > $mtol && (1-$s)*$l > $mtol} {
                    if {[edge_used_outside $x $y $hsIds]} {break}
                    dict lappend splits $k [list $s $g]; break
                }
            }
        }
        # host pieces of the R boundary; free-edge pieces under the guest are dropped. Every piece of a
        # free edge stays an allowed free edge for the crack check.
        set hostPieces {}; set freePieces [dict create]
        # A closed hole edge of the host lying wholly along the guest outline within holeTol (every node
        # and edge middle under the guest or that close to its outline) is the same edge seen by two
        # meshes, e.g. a coarse hole polygon under a washer with an equal, finer hole: it is dropped
        # with the guest pieces along it, so the hole edge follows the guest outline instead of leaving
        # slivers between the two. Open runs of free edge (a plate's outer edge) are left as they are.
        # (not when some source elements are left out, trim: the hole edge is then the real edge of the
        # target and must stay, or the places left out would leave it open)
        set holeTol [expr {[dict exists $opts mergeTol] || ([dict exists $opts trim] && [dict get $opts trim]) ? max($mtol,1e-9) : max($mtol,$gapTol)}]
        set dropBH [dict create]; set dropK [dict create]
        if {$holeTol > $mtol} {
            set freeRb {}; foreach k $Rb {if {[dict exists $BH $k]} {lappend freeRb $k}}
            foreach ch [lindex [edge_chains $freeRb] 0] {
                lassign $ch closed nodes
                if {!$closed} {continue}
                set nn [llength $nodes]; set along 1
                for {set i 0} {$i < $nn && $along} {incr i} {
                    set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
                    foreach p [list $P($a) [vscale [vadd $P($a) $P($b)] 0.5]] {
                        if {![llength [locate $gName $p $rc3]] && ![near_boundary $gName $p $BG $holeTol]} {set along 0; break}
                    }
                }
                if {!$along} {continue}
                for {set i 0} {$i < $nn} {incr i} {
                    set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$nn}]]
                    dict set dropK [expr {$a < $b ? "$a $b" : "$b $a"}] 1
                }
            }
        }
        foreach k $Rb {
            lassign $k x y
            set seq [list [list 0.0 $x]]
            if {[dict exists $splits $k]} {foreach it [lsort -real -index 0 [dict get $splits $k]] {lappend seq $it}}
            lappend seq [list 1.0 $y]
            for {set i 0} {$i < [llength $seq]-1} {incr i} {
                set a [lindex $seq $i 1]; set b [lindex $seq [expr {$i+1}] 1]
                if {[dict exists $vmap $a]} {set a [dict get $vmap $a]}
                if {[dict exists $vmap $b]} {set b [dict get $vmap $b]}
                if {$a == $b} {continue}
                if {[dict exists $BH $k]} {
                    dict set freePieces [expr {$a < $b ? "$a $b" : "$b $a"}] 1
                    set m [vscale [vadd $P($a) $P($b)] 0.5]
                    if {[llength [locate $gName $m $rc3]] || [near_boundary $gName $m $BG [expr {max($mtol,1e-9)}]]} {continue}
                    if {[dict exists $dropK $k]} {dict set dropBH [expr {$a < $b ? "$a $b" : "$b $a"}] 1; continue}
                }
                lappend hostPieces [expr {$a < $b ? "$a $b" : "$b $a"}]
            }
        }
        # guest outline pieces inside the host face; pieces on its free edge (also within the merge
        # distance along the normal: the top of a hole wall below the copy hole is not on it) or over a
        # hole of it stay free edges
        set guestPieces {}
        foreach k $gB {
            lassign $k a b
            set m [vscale [vadd $P($a) $P($b)] 0.5]
            if {([near_edges $m $BH [expr {max($mtol,1e-9)}] $N $mtolV] || ![llength [locate $hName $m $rc3]])} {continue}
            if {[dict size $dropBH] && [near_edges $m $dropBH $holeTol $N]} {continue}
            lappend guestPieces $k
        }
        # a piece that is both a host and a guest piece encloses nothing
        set fill [dict create]
        foreach k $hostPieces {dict lappend fill $k host}
        foreach k $guestPieces {dict lappend fill $k guest}
        set fillEdges {}; set from [dict create]
        dict for {k who} $fill {
            if {[llength $who] > 1} {continue}
            lappend fillEdges $k
            dict set from $k [lindex $who 0]
        }
        set fillEdges [split_touches $fillEdges $from $N]
        lassign [edge_chains $fillEdges] fchains fpinch
        if {[llength $fpinch]} {error "LAYER: the ring between the copy and the host face is not a simple outline."}
        set hostLoops {}; set guestLoops {}; set mixed {}
        set fixed {}
        foreach ch $fchains {
            lassign $ch closed nodes
            set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
            lappend fixed [list $closed $nn]
        }
        set fchains $fixed
        foreach ch $fchains {
            lassign $ch closed nodes
            if {!$closed} {
                # kept for diagnosis: the open chain with its piece kinds and end points
                set ends {}; foreach n [list [lindex $nodes 0] [lindex $nodes end]] {lappend ends [list $n $P($n)]}
                set ::ElemImprint::lastOpen [list ends $ends length [llength $nodes] hostPieces [llength $hostPieces] guestPieces [llength $guestPieces] free [dict size $freePieces]]
                error "LAYER: the ring between the copy and the host face is open."
            }
            set kinds [dict create]
            set n [llength $nodes]
            for {set i 0} {$i < $n} {incr i} {
                set a [lindex $nodes $i]; set b [lindex $nodes [expr {($i+1)%$n}]]
                dict set kinds [dict get $from [expr {$a < $b ? "$a $b" : "$b $a"}]] 1
            }
            if {[dict size $kinds] == 2} {lappend mixed $nodes} elseif {[dict exists $kinds host]} {lappend hostLoops $nodes} else {lappend guestLoops $nodes}
        }
        # Every outline of the removed area (closed hole edges, or outlines mixing host and copy pieces
        # where the area reaches the host's edge), smallest first, takes the copy outlines inside it as
        # holes, except copy outlines lying inside another one of them (e.g. the hole of a washer).
        # One hole: rows between the two outlines; several: joined and ear-clipped; none (mixed only):
        # the outline is ear-clipped.
        set bands {}
        set used {}
        set outers {}
        foreach loop [concat $hostLoops $mixed] {lappend outers [list [expr {abs([loop_area $loop $N])}] $loop [expr {$loop in $mixed}]]}
        foreach item [lsort -real -index 0 $outers] {
            lassign $item area loop isMixed
            set cands {}
            foreach gl $guestLoops {
                if {$gl in $used} {continue}
                if {[loop_inside $gl $loop $N]} {lappend cands $gl}
            }
            set holes {}
            foreach gl $cands {
                set nested 0
                foreach other $cands {if {$other ne $gl && [loop_inside $gl $other $N]} {set nested 1; break}}
                if {!$nested} {lappend holes $gl}
            }
            if {![llength $holes] && !$isMixed} {
                # a closed hole edge with no copy outline inside (e.g. a hole wall just inside a washer):
                # the nearest copy outline
                set best ""; set bd 1e300
                foreach gl $guestLoops {
                    if {$gl in $used} {continue}
                    set d [loop_gap $loop $gl]
                    if {$d < $bd} {set bd $d; set best $gl}
                }
                if {$best eq ""} {
                    # kept for diagnosis: every outline of the fill (kind, nodes, area, centre)
                    set diag {}
                    foreach {kind ls} [list host $hostLoops mixed $mixed guest $guestLoops] {
                        foreach l $ls {
                            set cc {0 0 0}; foreach n $l {set cc [vadd $cc $P($n)]}
                            lappend diag [list $kind [llength $l] [format %.4g [loop_area $l $N]] [vscale $cc [expr {1.0/[llength $l]}]] [expr {$l in $used}]]
                        }
                    }
                    set ::ElemImprint::lastLoops [list failing [list [llength $loop] [format %.4g [loop_area $loop $N]]] loops $diag]
                    error "LAYER: a hole edge in the host has no matching outline of the copy."
                }
                set holes [list $best]
            }
            foreach h $holes {lappend used $h}
            if {[llength $holes] == 1 && [loop_inside $loop [lindex $holes 0] $N]} {
                # the host edge lies inside the copy outline (a hole edge of the host just inside a
                # trimmed copy): the band runs from that edge out to the copy outline
                lappend bands {*}[ring_fill $loop [lindex $holes 0] $N "" $hName]
            } elseif {[llength $holes] == 1} {
                lappend bands {*}[ring_fill [lindex $holes 0] $loop $N "" $hName]
            } else {
                lappend bands {*}[fill_with_holes $loop $holes $N]
            }
        }
        # a copy outline left over (e.g. the hole of a washer) that lies over host material, where the
        # host had no hole, is filled again: a node at its centre on the old host face and a fan, or
        # ear clipping when the fan would fold
        # (a copy hole over a hole of the host must be joined to that hole edge: the direct build
        # pairs them, hole to hole)
        foreach gl $guestLoops {
            if {$gl in $used} {continue}
            set c [vscale [lindex [loop_sum $gl] 0] [expr {1.0/[llength $gl]}]]
            if {![llength [locate $hName $c $rc3]]} {error "LAYER: a hole of the copy is not joined to the host."}
            lappend used $gl
            lappend bands {*}[fill_disk $gl $N $hName]
        }
        # better shapes: interior edges of the fill flipped while that raises the smallest angle
        set bands [fold_fix [flip_improve $bands $N]]
        # smallest angle of the fill (degrees), to compare attempts
        set ringAngle 180.0
        foreach tr $bands {set a1 [expr {[tri_min_angle {*}$tr]*180.0/acos(-1)}]; if {$a1 < $ringAngle} {set ringAngle $a1}}
        }
        # kept host rows next to the R boundary: merged nodes replaced, inserted nodes split them
        set splitRows {}; set splitOld {}
        foreach row $Hsurf {
            lassign $row e a b c
            if {[dict exists $R $e]} {continue}
            set touched 0
            foreach {p q} [list $a $b $b $c $c $a] {if {[dict exists $splits [expr {$p < $q ? "$p $q" : "$q $p"}]]} {set touched 1}}
            if {!$touched} {continue}
            set poly {}
            foreach {p q} [list $a $b $b $c $c $a] {
                lappend poly $p
                set k [expr {$p < $q ? "$p $q" : "$q $p"}]
                if {[dict exists $splits $k]} {
                    set its [lsort -real -index 0 [dict get $splits $k]]
                    if {$p > $q} {set its [lreverse $its]}
                    foreach it $its {lappend poly [lindex $it 1]}
                }
            }
            set poly2 {}
            foreach n $poly {lappend poly2 [expr {[dict exists $vmap $n] ? [dict get $vmap $n] : $n}]}
            set nRow [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
            lappend splitOld $e
            lappend splitRows {*}[fill_polygon $poly2 $nRow]
        }
        # build: guest copy with the guest nodes, ruled ring, all in the host component
        set mids [dict create]
        if {$hOrder == 2} {
            add_mids mids [dict keys $R]
            set keep {}; foreach row $Hsurf {if {![dict exists $R [lindex $row 0]]} {lappend keep [lindex $row 0]}}
            add_mids mids $keep
            add_mids mids [lmap_ids $Grows]
        }
        *currentcollector components $hostComp
        set dup {}
        set gIds [lmap_ids $Grows]
        set byCfg [dict create]
        upvar #0 ::ElemImprint::GD_$hName DH
        load_xyz [node_set $gIds]
        foreach nl [elem_nodes $gIds] c [configs $gIds] {
            lassign $nl a b cc
            set c3 [vscale [vadd [vadd $P($a) $P($b)] $P($cc)] [expr {1.0/3}]]
            set hit [locate $hName $c3 $r]
            set nH [expr {[llength $hit] ? [lindex $DH([lindex $hit 0]) 3] : $N}]
            if {[dot [cross [vsub $P($b) $P($a)] [vsub $P($cc) $P($a)]] $nH] < 0} {
                set nl [expr {$c == 106 ? [list $a $cc $b [lindex $nl 5] [lindex $nl 4] [lindex $nl 3]] : [list $a $cc $b]}]
            }
            dict lappend byCfg $c $nl
        }
        # one sense for the new mesh: the host face's own, spread over shared edges (orient_new)
        set seeds {}
        foreach row $Hsurf {
            if {[dict exists $R [lindex $row 0]]} {continue}
            set cs {}; foreach n [lrange $row 1 3] {lappend cs [expr {[dict exists $vmap $n] ? [dict get $vmap $n] : $n}]}
            lappend seeds $cs
        }
        lassign [orient_new $seeds $byCfg $bands] byCfg bands
        dict for {c rows} $byCfg {lappend dup {*}[create_rows $rows $c]}
        # the ring elements (before the host rows go: HyperMesh deletes the midside nodes of deleted
        # tria6 with them, and an element on a missing node hangs *createelements)
        lassign [ring_mesh $bands "" $hOrder mids $N] band ringInfo
        # kept host rows split at inserted nodes
        set spRows {}
        foreach t $splitRows {
            lassign $t a b c
            if {$hOrder == 2} {lappend spRows [list $a $b $c [mid_node mids $a $b] [mid_node mids $b $c] [mid_node mids $c $a]]} else {lappend spRows $t}
        }
        set splitNew [create_rows $spRows [expr {$hOrder == 2 ? 106 : 103}]]
        set removedIds [concat [dict keys $R] $splitOld]
        set oldNodes [concat [node_set $removedIds] $::ElemImprint::ringNodes [dict keys $vmap]]
        delete_elems $removedIds
        set minEdge [dict get $ringInfo minInner]
        set created [concat $dup $band $splitNew]
        set crack 0
        set result [lsort -integer [concat [existing [dict get $H ids]] $created]]
        # open edges may only be the host's own free edges or the guest outline
        set okE [dict create]
        dict for {k one} $BH {dict set okE $k 1}
        foreach k $gB {dict set okE $k 1}
        dict for {k one} $freePieces {dict set okE $k 1}
        # the top of the hole wall under a deleted chamfer: the wall is outside the host face
        foreach e $chamfer {
            lassign [dict get $R $e] x a b c
            foreach {p q} [list $a $b $b $c $c $a] {
                set k [expr {$p < $q ? "$p $q" : "$q $p"}]
                if {[dict exists $cnt $k] && [dict get $cnt $k] == 1} {dict set okE $k 1}
            }
        }
        set ::ElemImprint::crackEdges {}
        foreach k [open_edges $result] {if {![dict exists $okE $k]} {incr crack; lappend ::ElemImprint::crackEdges $k}}
        delete_elems $temps
        foreach c $comps {delete_comp_if_empty $c}
        set orphans [unused_nodes $oldNodes]
        if {[llength $orphans]} {*createmark nodes 1 {*}$orphans; *nodemarkcleartempmark 1; *clearmark nodes 1}
        clear_temp_nodes
        if {$curComp ne "" && [hm_entityinfo exist comps $curComp -byname]} {*currentcollector components $curComp}
    } msg]
    # keep the trace of an unexpected failure for the Tcl console
    if {$code} {set ::ElemImprint::lastErrorInfo $::errorInfo}
    if {$outer} {
        if {$code} {error $msg}
    } else {
        history_end $label
    }
    if {$code} {
        set now [list [count elems] [count nodes]]
        if {$now ne $before || $::ElemImprint::wrote} {
            *undohistorystate 1
            set back [list [count elems] [count nodes]]
            if {$back ne $before} {error "$msg Rolling back failed ($before -> $back): check the model."}
        }
        error $msg
    }
    dict create result $result created [llength $created] dup [llength $dup] band [llength $band] removed [llength $removedIds] \
        swapped $swapped minEdge $minEdge ringAngle $ringAngle ring $ringInfo         loops [llength $fchains] layers [dict get $opts layers] crack $crack guest [lmap_ids_existing $gIds] warning ""
}
proc ::ElemImprint::lmap_ids_existing {ids} {existing $ids}
proc ::ElemImprint::lmap_ids {rows} {set o {}; foreach r $rows {lappend o [lindex $r 0]}; return $o}

# target, source: element ids (tria3/tria6, mixed allowed). opts: layers (extra host rows replaced
# around the copy), maxDist ("" = automatic). When one face lies inside the other the result shares
# nodes (enclose_once); no quality standard is applied: the source is always connected, by the
# normal build or, where the ring cannot be closed, the direct build.
# holeGap (mm): two hole edges closer than this count as one hole; "" = 0.3 of the smaller mean edge.
# The source not wholly on the target: only the elements lying wholly on it are copied (overhang
# says how many were left as they were).
proc ::ElemImprint::defaults {} {dict create layers 1 maxDist "" holeGap ""}
# The target elements near the source, counted in element rows (so a coarse target still gets k
# rows around the source): the target elements whose box reaches the source disk (centre and
# radius of the source nodes), then k more rows through shared nodes. Returns the subset (sorted).
proc ::ElemImprint::local_window {target source k} {
    set snodes {}
    foreach nl [elem_nodes $source] {lappend snodes {*}$nl}
    set snodes [lsort -unique -integer $snodes]
    set SP [node_coords $snodes]
    set c {0 0 0}; foreach p $SP {set c [vadd $c $p]}
    set c [vscale $c [expr {1.0/[llength $SP]}]]
    set Rs 0.0; foreach p $SP {set d [norm [vsub $p $c]]; if {$d > $Rs} {set Rs $d}}
    set tnl [elem_nodes $target]
    set tnodes {}; foreach nl $tnl {lappend tnodes {*}[lrange $nl 0 2]}
    set tnodes [lsort -unique -integer $tnodes]
    set TP [dict create]; foreach n $tnodes p [node_coords $tnodes] {dict set TP $n $p}
    # seed: element box (corners) within Rs of the centre on every axis
    lassign $c cx cy cz
    set in [dict create]; set byNode [dict create]
    set R2 [expr {$Rs*$Rs}]
    foreach e $target nl $tnl {
        # (as before: an element read back with fewer corners stays out of the window)
        if {[llength $nl] < 3} {continue}
        lassign $nl a b q
        dict lappend byNode $a $e; dict lappend byNode $b $e; dict lappend byNode $q $e
        lassign [dict get $TP $a] ax ay az; lassign [dict get $TP $b] bx by bz; lassign [dict get $TP $q] qx qy qz
        # distance from the centre to the box of the corners, per axis
        set dx [expr {max(0.0,min($ax,$bx,$qx)-$cx,$cx-max($ax,$bx,$qx))}]
        set dy [expr {max(0.0,min($ay,$by,$qy)-$cy,$cy-max($ay,$by,$qy))}]
        set dz [expr {max(0.0,min($az,$bz,$qz)-$cz,$cz-max($az,$bz,$qz))}]
        if {$dx*$dx+$dy*$dy+$dz*$dz <= $R2} {dict set in $e 1}
    }
    set cnl [dict create]; foreach e $target nl $tnl {dict set cnl $e [lrange $nl 0 2]}
    set front [dict keys $in]
    for {set i 0} {$i < $k && [llength $front]} {incr i} {
        set next {}
        foreach e $front {
            foreach n [dict get $cnl $e] {
                foreach f [dict get $byNode $n] {if {![dict exists $in $f]} {dict set in $f 1; lappend next $f}}
            }
        }
        set front $next
    }
    lsort -integer [dict keys $in]
}
proc ::ElemImprint::node_coords {ids} {
    set out {}
    for {set i 0} {$i < [llength $ids]} {incr i 4096} {
        set c [lrange $ids $i [expr {$i+4095}]]
        foreach x [hm_getvalue nodes user_ids=$c dataname=x] y [hm_getvalue nodes user_ids=$c dataname=y] z [hm_getvalue nodes user_ids=$c dataname=z] {lappend out [list $x $y $z]}
    }
    return $out
}

# Source patches: source elements joined by shared nodes (e.g. one patch per washer face).
proc ::ElemImprint::source_patches {source} {
    foreach e $source {set parent($e) $e}
    set byNode [dict create]
    foreach e $source nl [elem_nodes $source] {
        foreach n $nl {
            if {[dict exists $byNode $n]} {
                set a [ufind [dict get $byNode $n]]; set b [ufind $e]
                if {$a ne $b} {set parent($b) $a}
            } else {dict set byNode $n $e}
        }
    }
    set g [dict create]
    foreach e $source {dict lappend g [ufind $e] $e}
    dict values $g
}
proc ::ElemImprint::ufind {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}

# Several source patches (e.g. many washers picked at once) are imprinted one by one, each near its
# own place (imprint_one): a large target is then never worked on as a whole. A patch that fails is
# left as it is and reported; the others are kept. Each patch is its own Undo step; the result says
# steps (Undo steps made), patches, failed ({patch elements, message} per failed patch).
proc ::ElemImprint::imprint {target source {opts {}}} {
    set target [existing $target]; set source [existing $source]
    # the whole selection is checked here, before any window cuts it down
    if {![llength $target]} {error "Select the target elements."}
    if {![llength $source]} {error "Select the source elements."}
    kind $target target; kind $source source
    set tset [dict create]; foreach e $target {dict set tset $e 1}
    set both 0; foreach e $source {if {[dict exists $tset $e]} {incr both}}
    if {$both} {error "$both elements are both target and source."}
    # one patch, or a target not much larger than the source: as one imprint (one Undo step)
    set parts [expr {[llength $source] ? [source_patches $source] : {}}]
    set big 0; foreach pt $parts {if {[llength $pt] > $big} {set big [llength $pt]}}
    if {[llength $parts] <= 1 || [llength $target] <= max(500,8*$big)} {
        set h0 [llength [undo_actions]]
        progress 0 1
        set r [imprint_one $target $source $opts]
        progress 1 1
        dict set r steps [expr {max(1,[llength [undo_actions]]-$h0)}]; dict set r patches 1; dict set r failed {}
        return $r
    }
    set cur $target; set oks {}; set failed {}
    set h0 [llength [undo_actions]]
    set ip 0
    foreach part $parts {
        progress $ip [llength $parts]; incr ip
        if {[catch {imprint_one $cur $part $opts} r]} {
            lappend failed [list $part $r]
        } else {
            lappend oks $r
            if {![dict get $r swapped]} {set cur [dict get $r result]}
        }
    }
    if {![llength $oks]} {error "None of the [llength $parts] source patches could be imprinted. First: [lindex $failed 0 1]"}
    set out [lindex $oks 0]
    foreach k {created dup band removed overhang window} {set v 0; foreach r $oks {if {[dict exists $r $k]} {incr v [dict get $r $k]}}; dict set out $k $v}
    dict set out result [existing $cur]
    dict set out swapped 0
    set warn {}
    if {[llength $failed]} {lappend warn "[llength $failed] of [llength $parts] source patches not imprinted (left as they were): [lindex $failed 0 1]"}
    dict set out warning [join $warn " "]
    # Undo steps made (a patch that failed may leave an empty step too)
    dict set out steps [expr {max(1,[llength [undo_actions]]-$h0)}]; dict set out patches [llength $parts]; dict set out failed $failed
    dict set out attempts {}
    return $out
}


# A large target (many more elements than the source, e.g. a whole face picked By face) is worked on
# only near the source (local_window); when the imprint fails there, the window is doubled, up to the
# whole target. The result says window (target elements used).
proc ::ElemImprint::imprint_one {target source {opts {}}} {
    set target [existing $target]; set source [existing $source]
    set n [llength $target]
    if {$n <= max(200,4*[llength $source]) || ![llength $source]} {
        set r [imprint_region $target $source $opts]
        dict set r window $n
        return $r
    }
    set k 3
    while 1 {
        set win [local_window $target $source $k]
        if {[llength $win] >= $n} {set win $target}
        # the real free edges of the whole target face: the edges where the window cuts it are not
        # free edges, so the gap rows may reach past them
        set o2 $opts
        if {[llength $win] < $n} {
            if {![info exists faceFree]} {set faceFree {}; dict for {kk one} [boundary_edges [tri_rows $target]] {lappend faceFree $kk}}
            dict set o2 faceFree $faceFree
        }
        set ::ElemImprint::needWider 0
        set h0 [llength [undo_actions]]
        set rc [catch {imprint_region $win $source $o2} r]
        if {!$rc && $::ElemImprint::needWider && [llength $win] < $n && $k < 12} {
            # Gap ratio wants a row outside the window: undone, wider window
            set steps [expr {[llength [undo_actions]]-$h0}]
            for {set i 0} {$i < $steps} {incr i} {catch {*undohistorystate 1}}
            set k [expr {$k*2}]
            continue
        }
        if {!$rc} {
            dict set r window [llength $win]
            # the target outside the window is unchanged and still part of the target face
            if {[llength $win] < $n && ![dict get $r swapped]} {dict set r result [lsort -unique -integer [concat [existing $target] [dict get $r result]]]}
            return $r
        }
        # option errors and the like do not depend on the window
        # a wider window twice at most (3, 6, 12 rows); a patch that fails there is reported
        if {[llength $win] >= $n || $k >= 12 || ![string match "*Nothing changed*" $r]} {error $r}
        set k [expr {$k*2}]
    }
}
proc ::ElemImprint::imprint_region {target source {opts {}}} {
    set opts [dict merge [defaults] $opts]
    check_options $opts
    set ::ElemImprint::lastAttempts {}
    set attempts {}
    set trim 0; set direct 0; set dl 0; set extended 0
    set ::ElemImprint::trimmed 0
    set ::ElemImprint::extendedRows {}
    while 1 {
        set before [list [count elems] [count nodes]]
        set tA [clock milliseconds]
        # free edges near the imprint before it (the check after it reports only new ones)
        set maxId [hm_entitymaxid elems]
        set tns {}; foreach nl [elem_nodes $target] {lappend tns {*}[lrange $nl 0 2]}
        set freeBefore [model_free_edges $tns $source]
        # the source's own free edges (e.g. the hole of a washer) may stay free in the result
        dict for {k one} [boundary_edges [tri_rows $source]] {dict set freeBefore $k 1}
        if {[catch {enclose_once $target $source [dict merge $opts [list trim $trim direct $direct layers [expr {$direct ? $dl : [dict get $opts layers]}]]]} r]} {
            if {$r eq "PARTIAL"} {
                if {$trim} {error "The two faces do not overlap enough to imprint: no source element lies wholly on the target. Nothing changed."}
                # the source hangs past an edge of the target: first the rows next to the target that
                # lie under it are taken in too (deleted with the target rows under the source), so
                # the whole source is kept and the mesh joins its whole outline
                if {!$extended} {
                    set extended 1
                    set ext [rows_under_source $target $source]
                    if {[llength $ext]} {
                        set ::ElemImprint::extendedRows $ext
                        set target [concat $target $ext]
                        # the rows too close to the source outline (Gap L/d) are looked for again on the
                        # wider target: they may lie in the rows taken in
                        if {[dict exists $opts gapLim] && [string trim [dict get $opts gapLim]] ne ""} {
                            set ch [expr {[dict exists $opts chamferRows] ? [dict get $opts chamferRows] : {}}]
                            if {![catch {narrow_gaps $target $source [string trim [dict get $opts gapLim]] $ch} gaps]} {
                                set old [expr {[dict exists $opts gapRows] ? [dict get $opts gapRows] : {}}]
                                dict set opts gapRows [lsort -unique -integer [concat $old $gaps]]
                            }
                        }
                        continue
                    }
                }
                set trim 1
                continue
            }
            # the ring could not be filled: build it directly (only the host rows touched by the copy are
            # deleted, no extra layer, and joined to the copy), which always closes
            if {[string match "LAYER:*" $r]} {
                lappend attempts [list direct $direct failed [string trim [string range $r 6 end]] ms [expr {[clock milliseconds]-$tA}]]
                set ::ElemImprint::lastAttempts $attempts
                if {!$direct} {set direct 1; continue}
                # only the rows touched by the copy first; one more row when their outline touches itself
                if {$dl < 5} {incr dl; continue}
                set r "Could not fill the ring between the copy and the host face ([string trim [string range $r 6 end]]) Nothing changed."
            }
            error $r
        }
        # the real topology: open edges and folds of the new mesh, whatever the build counted
        set topo [check_topology $maxId $source $freeBefore]
        lappend attempts [list direct $direct crack [dict get $r crack] removed [dict get $r removed] open [dict get $topo open] folds [dict get $topo folds] ms [expr {[clock milliseconds]-$tA}]]
        set ::ElemImprint::lastAttempts $attempts
        if {[dict get $topo open] || [dict get $topo folds]} {
            *undohistorystate 1
            set back [list [count elems] [count nodes]]
            if {$back ne $before} {error "Undoing an attempt failed ($before -> $back): check the model."}
            if {!$direct} {set direct 1; continue}
            error "The new mesh would have [dict get $topo open] open edges and [dict get $topo folds] folded elements (the source runs past the edge of the target face onto a steep wall). Nothing changed."
        }
        # the direct build is the last resort and must not refuse: open edges it leaves are reported
        if {![dict get $r crack] || $direct} {
            if {[dict get $r crack]} {dict set r warning [string trim "[dict get $r warning] [dict get $r crack] free edges left in the new mesh (show them with Edges > Free edges and fix by hand)."]}
            if {$trim} {dict set r warning [string trim "[dict get $r warning] $::ElemImprint::trimmed source elements off the target face (over a hole or edge) left as they were."]}
            dict set r attempts $attempts
            dict set r shared 1
            dict set r direct $direct
            dict set r overhang [expr {$trim ? $::ElemImprint::trimmed : 0}]
            dict set r extended [llength $::ElemImprint::extendedRows]
            return $r
        }
        # open edges inside the host face: undone, then the direct build (it always closes)
        *undohistorystate 1
        set back [list [count elems] [count nodes]]
        if {$back ne $before} {error "Undoing an attempt failed ($before -> $back): check the model."}
        set direct 1
    }
}

# Rows next to the target (outside it, same components, shells) that lie under the source, layer by
# layer from the target outline (3 layers at most): a corner or the centroid projects onto the source
# (along its normal, within 4 source mesh sizes). Used when the source hangs past an edge of the
# target face, e.g. a washer over the edge of a narrow face onto the slope next to it.
proc ::ElemImprint::rows_under_source {target source} {
    variable P
    set Srows [tri_rows $source]
    if {![llength $Srows]} {return {}}
    set mS [grid_build U $Srows]
    grid_index U $mS
    set reach [expr {4.0*$mS}]
    set inT [dict create]; foreach e $target {dict set inT $e 1}
    set inS [dict create]; foreach e $source {dict set inS $e 1}
    set comps [dict create]; foreach c [comps_of $target] {dict set comps $c 1}
    set rows [tri_rows $target]
    set out {}
    for {set layer 0} {$layer < 3} {incr layer} {
        set front {}
        dict for {k one} [boundary_edges $rows] {lappend front {*}$k}
        set cand {}
        foreach e [elems_on_nodes [lsort -unique -integer $front]] {
            if {![dict exists $inT $e] && ![dict exists $inS $e]} {lappend cand $e}
        }
        if {![llength $cand]} {break}
        set add {}
        foreach e $cand nl [elem_nodes $cand] c [configs $cand] cm [hm_getvalue elems user_ids=$cand dataname=collector.name] {
            if {$c ni {103 106} || ![dict exists $comps $cm]} {continue}
            set corners [lrange $nl 0 2]
            load_xyz $corners
            set pts {}; foreach n $corners {lappend pts $P($n)}
            lappend pts [vscale [vadd [vadd [lindex $pts 0] [lindex $pts 1]] [lindex $pts 2]] [expr {1.0/3}]]
            foreach q $pts {
                if {[llength [locate U $q $reach]]} {lappend add $e; break}
            }
        }
        if {![llength $add]} {break}
        foreach e $add {dict set inT $e 1; lappend out $e}
        set rows [concat $rows [tri_rows $add]]
    }
    return $out
}

# Shell edges ("a b" keys of corner nodes) used once by the shells on the given nodes, the elements in
# skip left out (the source washer shares its nodes with its copy).
proc ::ElemImprint::model_free_edges {nodes skip} {
    if {![llength $nodes]} {return [dict create]}
    set sk [dict create]; foreach e $skip {dict set sk $e 1}
    set es {}
    foreach e [elems_on_nodes [lsort -unique -integer $nodes]] {if {![dict exists $sk $e]} {lappend es $e}}
    set cnt [dict create]
    if {[llength $es]} {
        foreach nl [elem_nodes $es] c [configs $es] {
            if {$c ni {103 106}} {continue}
            lassign $nl a b cc
            foreach {p q} [list $a $b $b $cc $cc $a] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}
        }
    }
    # only edges with both nodes in the set: their every element is among those read
    set inN [dict create]; foreach n $nodes {dict set inN $n 1}
    set out [dict create]
    dict for {k v} $cnt {if {$v == 1 && [dict exists $inN [lindex $k 0]] && [dict exists $inN [lindex $k 1]]} {dict set out $k 1}}
    return $out
}
# Topology of the new elements (ids above maxId): open edges that were not free before (freeBefore),
# and folds (two elements on one edge, one of them new, normals more than 120 degrees apart).
# Returns {open n folds n}.
proc ::ElemImprint::check_topology {maxId skip freeBefore} {
    variable P
    *createmark elems 1 all
    set all [hm_getmark elems 1]
    *clearmark elems 1
    set sk [dict create]; foreach e $skip {dict set sk $e 1}
    set keep {}; foreach e $all {if {$e > $maxId && ![dict exists $sk $e]} {lappend keep $e}}
    set newE $keep
    if {![llength $newE]} {return [dict create open 0 folds 0]}
    set ns {}; foreach nl [elem_nodes $newE] {lappend ns {*}[lrange $nl 0 2]}
    set free [model_free_edges $ns $skip]
    set open 0
    set ::ElemImprint::lastOpen {}
    dict for {k one} $free {
        if {![dict exists $freeBefore $k]} {
            incr open
            lappend ::ElemImprint::lastOpen $k
        }
    }
    # folds on the edges of the new elements
    set rows [tri_rows [concat $newE [lsort -unique -integer [elems_on_nodes [lsort -unique -integer $ns]]]]]
    set isNew [dict create]; foreach e $newE {dict set isNew $e 1}
    set ids {}; foreach row $rows {lappend ids {*}[lrange $row 1 3]}
    load_xyz [lsort -unique -integer $ids]
    set byEdge [dict create]; set seenE [dict create]
    foreach row $rows {
        lassign $row e a b c
        if {[dict exists $sk $e] || [dict exists $seenE $e]} {continue}
        dict set seenE $e 1
        set n [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
        foreach {p q} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$p < $q ? "$p $q" : "$q $p"}] [list $e $p $n]}
    }
    set folds 0
    dict for {k v} $byEdge {
        if {[llength $v] != 2} {continue}
        lassign $v x y
        lassign $x e1 p1 n1; lassign $y e2 p2 n2
        if {![dict exists $isNew $e1] && ![dict exists $isNew $e2]} {continue}
        # same edge run the other way round in the two elements: the normals compare directly
        set d [dot $n1 $n2]
        if {$p1 eq $p2} {set d [expr {-$d}]}
        if {$d < -0.5} {incr folds}
    }
    dict create open $open folds $folds
}

# Chains of edges ("a b" keys): {{closed nodes} ...} and the nodes used by more than two edges.
proc ::ElemImprint::edge_chains {edges} {
    set adj [dict create]
    foreach k $edges {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}
    set pinch {}
    dict for {n v} $adj {if {[llength $v] > 2} {lappend pinch $n}}
    if {[llength $pinch]} {return [list {} $pinch]}
    set chains {}; set seen [dict create]
    # open chains first (start at an end), then loops
    foreach pass {open closed} {
        dict for {n v} $adj {
            if {[dict exists $seen $n]} {continue}
            if {$pass eq "open" && [llength $v] != 1} {continue}
            set nodes [list $n]; dict set seen $n 1
            set prev ""; set cur $n
            while 1 {
                set nx {}
                foreach m [dict get $adj $cur] {if {$m != $prev && ![dict exists $seen $m]} {lappend nx $m}}
                if {![llength $nx]} {break}
                set prev $cur; set cur [lindex $nx 0]
                lappend nodes $cur; dict set seen $cur 1
            }
            lappend chains [list [expr {$pass eq "closed"}] $nodes]
        }
    }
    list $chains {}
}
# 1 when p lies within snapD of one of the edges (dict of "a b" keys), measured along normal n.
# off (optional): the edge must also lie within off of p along n (not only seen along n).
proc ::ElemImprint::near_edges {p edges snapD n {off ""}} {
    variable P
    dict for {k one} $edges {
        lassign $k a b
        lassign [seg_param $p $P($a) $P($b) $n] t d
        if {$d > $snapD} {continue}
        if {$off ne ""} {
            set t [expr {max(0.0,min(1.0,$t))}]
            set q [vadd $P($a) [vscale [vsub $P($b) $P($a)] $t]]
            if {abs([dot [vsub $p $q] $n]) > $off} {continue}
        }
        return 1
    }
    return 0
}
# Triangles of a simple polygon (node ids) seen along n, oriented along n.
proc ::ElemImprint::fill_polygon {nodes n} {
    variable P
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set f [list $P([lindex $nodes 0]) $e1 $e2]
    set pts {}; foreach k $nodes {lappend pts [to2d $f $P($k)]}
    if {[catch {ear_clip $nodes $pts} tris]} {error "LAYER: the ring between the copy and the host face cannot be meshed ($tris)."}
    set out {}
    foreach t $tris {
        lassign $t a b c
        if {$a == $b || $b == $c || $a == $c} {continue}
        set nn [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]
        # a flat (collinear) triangle is kept: dropping it would leave an open edge in the mesh
        if {[norm $nn] > 1e-12 && [dot $nn $n] < 0} {set t [list $a $c $b]}
        lappend out $t
    }
    return $out
}


# Where the fill outline touches itself at a node (4 or more edges), its edges are paired by angle
# around n, each host piece with the guest piece next to it, and every pair after the first gets
# its own copy of the node ("node#k"), so that the outline splits into simple loops there.
proc ::ElemImprint::split_touches {edges from n} {
    variable P
    set adj [dict create]
    foreach k $edges {lassign $k a b; dict lappend adj $a $k; dict lappend adj $b $k}
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set rename [dict create]
    dict for {v ks} $adj {
        if {[llength $ks] < 4 || [llength $ks] % 2} {continue}
        set ang {}
        foreach k $ks {
            lassign $k a b
            set o [expr {$a == $v ? $b : $a}]
            set d [vsub $P($o) $P($v)]
            lappend ang [list [expr {atan2([dot $d $e2],[dot $d $e1])}] $k]
        }
        set ang [lsort -real -index 0 $ang]
        set m [llength $ang]
        # start so that each pair (i, i+1) mixes a host and a guest piece
        set start 0
        if {[dict get $from [lindex $ang 0 1]] eq [dict get $from [lindex $ang 1 1]]} {set start 1}
        for {set i 0} {$i < $m} {incr i 2} {
            if {$i == 0} {continue}
            foreach j [list [expr {($start+$i)%$m}] [expr {($start+$i+1)%$m}]] {dict lappend rename [lindex $ang $j 1] [list $v "$v#[expr {$i/2}]"]}
        }
    }
    set out {}
    foreach k $edges {
        lassign $k a b
        if {[dict exists $rename $k]} {
            foreach r [dict get $rename $k] {lassign $r old new; if {$a == $old} {set a $new}; if {$b == $old} {set b $new}}
        }
        lappend out [list $a $b]
    }
    return $out
}


# Triangles between closed loops A (copy outline) and B (hole edge), along n. As in the Ruled Mesh
# tool: rows of nodes between the two outlines (spacing about "size", "" = mean outline edge),
# placed by arc length and put back on the old host face (grid "surf"), ruled row by row. A layout
# that folds or does not cover the ring exactly falls back to one ruled row, then to a keyhole cut.
# New nodes are listed in ::ElemImprint::ringNodes (unused ones are deleted by the caller).
proc ::ElemImprint::ring_fill {A B n {size ""} {surf ""}} {
    variable P
    if {[loop_area $A $n]*[loop_area $B $n] < 0} {set B [lreverse $B]}
    set best 0; set bd 1e300
    for {set j 0} {$j < [llength $B]} {incr j} {set d [norm [vsub $P([lindex $B $j]) $P([lindex $A 0])]]; if {$d < $bd} {set bd $d; set best $j}}
    set B [concat [lrange $B $best end] [lrange $B 0 [expr {$best-1}]]]
    set want [expr {abs(abs([loop_area $B $n])-abs([loop_area $A $n]))}]
    if {$size eq ""} {set size [expr {0.5*([loop_mean_edge $A]+[loop_mean_edge $B])}]}
    set k [expr {max(1,int(round([loop_gap $A $B]/max($size,1e-12))))}]
    # first choice: the native ruled mesher, R-trias (as Ruled Mesh with the element type R-trias)
    if {$::ElemImprint::rtrias} {
        # 4 cuts, then 8 when the band folds (the loops are paired more closely)
        foreach cm {4 8} {
            set rc [catch {native_ruled $A $B $n $k $surf $cm} tris]
            if {!$rc || ![string match "*folds*" $tris]} {break}
            lappend ::ElemImprint::rfLog [list native failed cuts $cm k $k nA [llength $A] nB [llength $B] reason $tris]
        }
        if {$rc} {
            lappend ::ElemImprint::rfLog [list native failed k $k nA [llength $A] nB [llength $B] reason $tris]
        } else {
            # signed area along n: slivers that flip cancel, the band must cover the ring once
            set got 0.0
            foreach tr $tris {lassign $tr a b c; set got [expr {$got+[dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n]}]}
            lappend ::ElemImprint::rfLog [list native k $k nA [llength $A] nB [llength $B] tris [llength $tris] got [format %.4g $got] want [format %.4g $want]]
            if {abs($got-$want) <= 1e-3*max($want,1e-12)} {
                foreach tr $tris {dict set ::ElemImprint::rtriKeys [lsort -integer $tr] 1}
                return $tris
            }
        }
    }
    foreach rows [lsort -unique -integer -decreasing [list $k 1]] {
        set loops [list $A]
        for {set i 1} {$i < $rows} {incr i} {
            set tt [expr {double($i)/$rows}]
            set c [expr {max(3,int(round([llength $A]+([llength $B]-[llength $A])*$tt)))}]
            set loop {}
            for {set m 0} {$m < $c} {incr m} {
                set s [expr {double($m)/$c}]
                set q [vadd [vscale [loop_point $A $s] [expr {1.0-$tt}]] [vscale [loop_point $B $s] $tt]]
                if {$surf ne ""} {set q [onto_grid $surf $q]}
                *createnode {*}$q 0 0 0
                set id [hm_latestentityid nodes]
                lappend ::ElemImprint::madeNodes $id
                set P($id) $q
                lappend ::ElemImprint::ringNodes $id
                lappend loop $id
            }
            lappend loops $loop
        }
        lappend loops $B
        set tris {}
        for {set i 0} {$i < [llength $loops]-1} {incr i} {lappend tris {*}[ruled [lindex $loops $i] [lindex $loops [expr {$i+1}]] $n 0]}
        set got 0.0; set fold 0
        foreach tr $tris {
            lassign $tr a b c
            set d [dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n]
            if {$d <= 0} {incr fold}
            set got [expr {$got+abs($d)}]
        }
        lappend ::ElemImprint::rfLog [list k $k rows $rows nA [llength $A] nB [llength $B] fold $fold got [format %.4g $got] want [format %.4g $want]]
        if {!$fold && abs($got-$want) <= 1e-3*max($want,1e-12)} {return $tris}
    }
    # keyhole: B counter-clockwise, A clockwise, joined at the closest pair
    if {[loop_area $B $n] < 0} {set B [lreverse $B]}
    if {[loop_area $A $n] > 0} {set A [lreverse $A]}
    set bi 0; set bj 0; set bd 1e300
    for {set i 0} {$i < [llength $A]} {incr i} {
        for {set j 0} {$j < [llength $B]} {incr j} {
            set d [norm [vsub $P([lindex $A $i]) $P([lindex $B $j])]]
            if {$d < $bd} {set bd $d; set bi $i; set bj $j}
        }
    }
    set Br [concat [lrange $B $bj end] [lrange $B 0 $bj]]
    set Ar [concat [lrange $A $bi end] [lrange $A 0 $bi]]
    # last resort (loops that are not flat or touch themselves): march along both loops; always closes
    if {[catch {fill_polygon [concat $Br $Ar] $n} tris]} {return [ruled_arc $A $B $n]}
    return $tris
}
# Ring between closed loops A and B (same turning sense along n, B[0] the node of B nearest A[0])
# meshed by the native ruled mesher: node list to node list, R-trias, k rows, as Ruled Mesh does it.
# A closed ring is meshed in two halves cut at A[0]-B[0] and at the arc-length midpoints; the
# second half's nodes on the two cuts are replaced by the first half's. The native elements are
# read back as node triples and deleted (the caller creates the final elements); their new nodes
# stay, are listed in ringNodes and are put back on the old host face (grid surf). Returns the
# triangles oriented along n; errors (nothing left in the model) when the native mesh is unusable.
proc ::ElemImprint::native_ruled {A B n k {surf ""} {cutsMax 4}} {
    variable P
    if {[llength $A] < 3 || [llength $B] < 3} {error "a loop has fewer than 3 nodes"}
    # cuts at matching parameters of both loops (angle around the smaller loop, else arc length,
    # as ruled does it), up to 4, so that the native mesher pairs the right parts of the two loops
    if {[loop_area $A $n] < 0} {set A [lreverse $A]; set B [lreverse $B]}
    set f [loop_frame $A $B $n]
    set aA [loop_angles $A $f]; set aB [loop_angles $B $f]
    if {$aA eq "" || $aB eq ""} {set aA ""; set aB ""}
    lassign [loop_params $A $aA $f] A tA
    lassign [loop_params $B $aB $f] B tB
    set nA [llength $A]; set nB [llength $B]
    set m [expr {min($cutsMax,$nA,$nB)}]
    set cuts {}
    for {set q 0} {$q < $m} {incr q} {
        set g [expr {double($q)/$m}]
        set ia 0; set bd 1e300
        for {set i 0} {$i < $nA} {incr i} {set d [expr {abs([lindex $tA $i]-$g)}]; set d [expr {min($d,1.0-$d)}]; if {$d < $bd} {set bd $d; set ia $i}}
        set ta [lindex $tA $ia]
        set jb 0; set bd 1e300
        for {set j 0} {$j < $nB} {incr j} {set d [expr {abs([lindex $tB $j]-$ta)}]; set d [expr {min($d,1.0-$d)}]; if {$d < $bd} {set bd $d; set jb $j}}
        lappend cuts [list $ia $jb]
    }
    # both loops start at the first cut; the cuts must go forward on both
    lassign [lindex $cuts 0] i0 j0
    set A [concat [lrange $A $i0 end] [lrange $A 0 [expr {$i0-1}]]]
    set B [concat [lrange $B $j0 end] [lrange $B 0 [expr {$j0-1}]]]
    set kept {{0 0}}
    foreach c [lrange $cuts 1 end] {
        lassign $c ia jb
        set ia [expr {($ia-$i0+$nA)%$nA}]; set jb [expr {($jb-$j0+$nB)%$nB}]
        lassign [lindex $kept end] pa pb
        if {$ia > $pa && $jb > $pb} {lappend kept [list $ia $jb]}
    }
    if {[llength $kept] < 2} {error "the two loops have no matching cuts"}
    lappend A [lindex $A 0]; lappend B [lindex $B 0]
    lappend kept [list $nA $nB]
    set halves {}
    for {set q 0} {$q < [llength $kept]-1} {incr q} {
        lassign [lindex $kept $q] a0 b0; lassign [lindex $kept [expr {$q+1}]] a1 b1
        lappend halves [list [lrange $A $a0 $a1] [lrange $B $b0 $b1]]
    }
    set order [hm_getoption element_order]
    set madeE {}; set madeN {}; set rowsAll {}; set seams {}
    set code [catch {
        if {$order != 1} {*setoption element_order=1}
        foreach h $halves {
            lassign $h a b
            hm_entityrecorder elems on; hm_entityrecorder nodes on
            set rc [catch {
                set step surfacemode; *surfacemode 2
                set step createlist; *createlist nodes 1 {*}$a; *createlist nodes 2 {*}$b
                set step linearsurface; *linearsurfacebetweennodes 1 2 0
                set step edgeparams; *set_meshedgeparams 1 $k 1 0 0 0 0 0 0; *set_meshedgeparams 3 $k 1 0 0 0 0 0 0
                set step faceparams; *set_meshfaceparams 0 1 3 0 0 1 0.5 1 1
                set step automesh; *automesh 0 1 3
                set step store; *storemeshtodatabase 0
            } m]
            if {$rc} {set m "$step: $m"}
            catch {*ameshclearsurface}
            hm_entityrecorder nodes off; hm_entityrecorder elems off
            set es [existing [hm_entityrecorder elems ids]]
            lappend madeE {*}$es
            lappend madeN {*}[hm_entityrecorder nodes ids]
            if {$rc} {error "native ruled: $m"}
            if {![llength $es]} {error "native ruled made no elements"}
            set rows {}
            foreach c [configs $es] nl [elem_nodes $es] {
                if {$c != 103 || [llength $nl] != 3} {error "native ruled made an element of config $c"}
                lappend rows $nl
            }
            lappend seams [ruled_seams $a $b $rows]
            lappend rowsAll $rows
        }
        set madeN [existing_nodes [lsort -unique -integer $madeN]]
        # (ids of nodes deleted earlier can come back: read the new ones again)
        foreach x $madeN {unset -nocomplain P($x)}
        load_xyz $madeN
        # the cuts: the start seam of each patch -> the end seam of the patch before (same count, same place)
        set map [dict create]
        set np [llength $seams]
        for {set q 0} {$q < $np} {incr q} {
            set p [lindex $seams [expr {($q+$np-1)%$np}] 1]
            set r [lindex $seams $q 0]
            if {[llength $p] != [llength $r]} {error "two patches have a different number of rows"}
            foreach u [lrange $p 1 end-1] v [lrange $r 1 end-1] {
                if {$u == $v} {continue}
                if {[norm [vsub $P($u) $P($v)]] > 1e-6*max(1.0,[norm [vsub $P([lindex $p 0]) $P([lindex $p end])]])} {error "the cut nodes of two patches do not match"}
                dict set map $v $u
            }
        }
        set tris {}
        foreach rows $rowsAll {
            foreach tr $rows {
                set t {}
                foreach x $tr {lappend t [expr {[dict exists $map $x] ? [dict get $map $x] : $x}]}
                lappend tris $t
            }
        }
        delete_elems $madeE
        set madeE {}
        # (HyperMesh may have dropped them with the elements already)
        set dupN [existing_nodes [dict keys $map]]
        if {[llength $dupN]} {*createmark nodes 1 {*}$dupN; *nodemarkcleartempmark 1; *clearmark nodes 1}
        set kept {}
        foreach x $madeN {if {![dict exists $map $x]} {lappend kept $x}}
        # HyperMesh drops the mesher's interior nodes with its elements: made again where they were
        # (an element on a missing node hangs *createelements)
        set alive [dict create]; foreach x [existing_nodes $kept] {dict set alive $x 1}
        set madeN {}
        foreach x $kept {
            if {[dict exists $alive $x]} {lappend madeN $x; continue}
            *createnode {*}$P($x) 0 0 0
            set y [hm_latestentityid nodes]
            lappend ::ElemImprint::madeNodes $y
            set P($y) $P($x)
            dict set map $x $y
            lappend madeN $y
        }
        if {[dict size $map]} {
            set t2 {}
            foreach t $tris {set u {}; foreach x $t {lappend u [expr {[dict exists $map $x] ? [dict get $map $x] : $x}]}; lappend t2 $u}
            set tris $t2
        }
        # interior nodes back on the old host face
        if {$surf ne ""} {
            foreach x $madeN {
                set q [onto_grid $surf $P($x)]
                if {[norm [vsub $q $P($x)]] > 1e-12} {*nodemodify $x {*}$q; set P($x) $q}
            }
        }
        # one turning sense for the whole band: each patch turned to run its cut edge against the patch
        # before (the native patches are each consistently oriented), then all along n by the signed
        # area (a steep band, outlines at different heights, may have slivers that flip seen along n)
        set parts {}; set at 0
        foreach rows $rowsAll {lappend parts [lrange $tris $at [expr {$at+[llength $rows]-1}]]; incr at [llength $rows]}
        for {set q 1} {$q < [llength $parts]} {incr q} {
            lassign [lrange [lindex $seams [expr {$q-1}] 1] 0 1] u v
            if {[dict exists $map $u]} {set u [dict get $map $u]}
            if {[dict exists $map $v]} {set v [dict get $map $v]}
            set d0 [edge_dir [lindex $parts [expr {$q-1}]] $u $v]
            set d1 [edge_dir [lindex $parts $q] $u $v]
            if {!$d0 || !$d1} {error "the native patches do not share their cut edge"}
            if {$d0 == $d1} {
                set o {}; foreach t [lindex $parts $q] {lassign $t a b c; lappend o [list $a $c $b]}
                lset parts $q $o
            }
        }
        set out [concat {*}$parts]
        # no flat triangle (three nodes in a line, e.g. on a straight run of one outline): HyperMesh
        # does not take it as an element
        set le 0.0; foreach L [list $A $B] {foreach x [lrange $L 0 end-1] y [lrange $L 1 end] {set le [expr {$le+[norm [vsub $P($y) $P($x)]]}]}}
        set le [expr {$le/max(1,[llength $A]+[llength $B]-2)}]
        # no fold in 3D: two band triangles on one edge must not face opposite ways (on a flat face a
        # fold is an overlap; on a steep band a sliver may flip seen along n but not in 3D)
        # (a sliver's normal is not reliable: only triangles of a fair size are compared)
        set le0 0.0; foreach L [list $A $B] {foreach x [lrange $L 0 end-1] y [lrange $L 1 end] {set le0 [expr {$le0+[norm [vsub $P($y) $P($x)]]}]}}
        set le0 [expr {$le0/max(1,[llength $A]+[llength $B]-2)}]
        set byEdge [dict create]
        foreach t $out {
            lassign $t a b c
            set nt [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]
            set l [norm $nt]
            if {$l < 0.1*$le0*$le0} {continue}
            set nt [vscale $nt [expr {1.0/$l}]]
            foreach {x y} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$x < $y ? "$x $y" : "$y $x"}] $nt}
        }
        dict for {k ns} $byEdge {
            if {[llength $ns] == 2 && [dot [lindex $ns 0] [lindex $ns 1]] < 0} {error "the native ruled mesh folds at edge $k"}
        }
        set onA [dict create]; foreach x $A {dict set onA $x 1}
        set onB [dict create]; foreach x $B {dict set onB $x 1}
        foreach t $out {
            lassign $t a b c
            if {$a == $b || $b == $c || $a == $c} {error "the native ruled mesh has a triangle with a repeated node"}
            # a triangle on three nodes of one outline can repeat an element that stays (the copy, or
            # the host outside the deleted rows): only allowed on an outline of deleted host rows
            # (they are deleted right after the band is made)
            foreach on [list $onA $onB] {
                if {[dict exists $on $a] && [dict exists $on $b] && [dict exists $on $c] && [twin_alive $t]} {error "the native ruled mesh has a triangle on one outline"}
            }
            if {[norm [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]] < 1e-6*$le*$le} {error "the native ruled mesh has a flat triangle"}
        }
        set sum 0.0
        foreach t $out {lassign $t a b c; set sum [expr {$sum+[dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n]}]}
        if {$sum < 0} {set o {}; foreach t $out {lassign $t a b c; lappend o [list $a $c $b]}; set out $o}
        set tris $out
    } msg]
    catch {*clearlist nodes 1}; catch {*clearlist nodes 2}
    if {$order != 1} {catch {*setoption element_order=$order}}
    lappend ::ElemImprint::ringNodes {*}$madeN
    if {$code} {
        delete_elems $madeE
        set gone [existing_nodes $madeN]
        if {[llength $gone]} {set gone [unused_nodes $gone]}
        if {[llength $gone]} {*createmark nodes 1 {*}$gone; *nodemarkcleartempmark 1; *clearmark nodes 1}
        error $msg
    }
    return $tris
}
# 1 when an element that stays (not in ::ElemImprint::goneElems) has the corner nodes of triangle t.
proc ::ElemImprint::twin_alive {t} {
    set want [lsort -integer $t]
    set es [existing [elems_on_nodes [list [lindex $t 0]]]]
    foreach e $es nl [elem_nodes $es] {
        if {[lsort -integer [lrange $nl 0 2]] eq $want && ![dict exists $::ElemImprint::goneElems $e]} {return 1}
    }
    return 0
}
# 1 when a triangle of tris runs u->v, -1 when one runs v->u, 0 when no triangle has the edge.
proc ::ElemImprint::edge_dir {tris u v} {
    foreach t $tris {
        foreach {x y} [list [lindex $t 0] [lindex $t 1] [lindex $t 1] [lindex $t 2] [lindex $t 2] [lindex $t 0]] {
            if {$x == $u && $y == $v} {return 1}
            if {$x == $v && $y == $u} {return -1}
        }
    }
    return 0
}
# The two connecting edges of a native ruled patch between open node lists a and b: {a0..b0 aEnd..bEnd}.
proc ::ElemImprint::ruled_seams {a b rows} {
    set cnt [dict create]
    foreach tr $rows {lassign $tr x y z; foreach {p q} [list $x $y $y $z $z $x] {dict incr cnt [expr {$p < $q ? "$p $q" : "$q $p"}]}}
    set free [dict create]
    dict for {k v} $cnt {if {$v == 1} {dict set free $k 1}}
    foreach L [list $a $b] {
        foreach p [lrange $L 0 end-1] q [lrange $L 1 end] {
            set k [expr {$p < $q ? "$p $q" : "$q $p"}]
            if {![dict exists $free $k]} {error "the native ruled mesh did not keep the outline edge $k"}
            dict unset free $k
        }
    }
    set adj [dict create]
    foreach k [dict keys $free] {lassign $k p q; dict lappend adj $p $q; dict lappend adj $q $p}
    set seams {}
    foreach end {0 end} {
        set x [lindex $a $end]; set stop [lindex $b $end]; set prev ""; set path [list $x]
        while {$x != $stop} {
            set next {}
            if {[dict exists $adj $x]} {foreach y [dict get $adj $x] {if {$y ne $prev && [dict exists $free [expr {$x < $y ? "$x $y" : "$y $x"}]]} {lappend next $y}}}
            if {[llength $next] != 1} {error "the native ruled mesh has no single connecting edge"}
            set y [lindex $next 0]
            dict unset free [expr {$x < $y ? "$x $y" : "$y $x"}]
            set prev $x; set x $y; lappend path $x
        }
        lappend seams $path
    }
    if {[dict size $free]} {error "the native ruled mesh has unexpected free edges"}
    return $seams
}
# Cumulative lengths of closed loop L: {cum total}, cum has one entry per node plus the total.
proc ::ElemImprint::loop_cum {L} {
    variable P
    set n [llength $L]; set c {0.0}; set t 0.0
    for {set i 0} {$i < $n} {incr i} {
        set t [expr {$t+[norm [vsub $P([lindex $L [expr {($i+1)%$n}]]) $P([lindex $L $i])]]}]
        lappend c $t
    }
    list $c $t
}
# Point at arc length s (0 <= s < total) of closed loop L (binary search in the cumulative lengths).
proc ::ElemImprint::loop_at {L cum total s} {
    variable P
    set s [expr {$s - $total*floor($s/$total)}]
    set lo 0; set hi [expr {[llength $L]-1}]
    while {$lo < $hi} {
        set mid [expr {($lo+$hi+1)/2}]
        if {[lindex $cum $mid] <= $s} {set lo $mid} else {set hi [expr {$mid-1}]}
    }
    set n [llength $L]
    set a $P([lindex $L $lo]); set b $P([lindex $L [expr {($lo+1)%$n}]])
    set l [expr {[lindex $cum [expr {$lo+1}]]-[lindex $cum $lo]}]
    set f [expr {$l > 0 ? ($s-[lindex $cum $lo])/$l : 0.0}]
    vadd $a [vscale [vsub $b $a] $f]
}
# Last resort of ring_fill: the parameter-ordered ruled triangles (see ruled).
proc ::ElemImprint::ruled_arc {A B N} {ruled $A $B $N}
proc ::ElemImprint::loop_mean_edge {L} {
    variable P
    set s 0.0; set n [llength $L]
    for {set i 0} {$i < $n} {incr i} {set s [expr {$s+[norm [vsub $P([lindex $L [expr {($i+1)%$n}]]) $P([lindex $L $i])]]}]}
    expr {$s/max(1,$n)}
}
# Point at fraction s (0..1) of the length of closed loop L, from its first node.
proc ::ElemImprint::loop_point {L s} {
    variable P
    set n [llength $L]
    set lens {}; set tot 0.0
    for {set i 0} {$i < $n} {incr i} {
        set l [norm [vsub $P([lindex $L [expr {($i+1)%$n}]]) $P([lindex $L $i])]]
        lappend lens $l; set tot [expr {$tot+$l}]
    }
    set goal [expr {$s*$tot}]
    for {set i 0} {$i < $n} {incr i} {
        set l [lindex $lens $i]
        if {$goal <= $l || $i == $n-1} {
            set f [expr {$l > 0 ? min(1.0,$goal/$l) : 0.0}]
            set a $P([lindex $L $i]); set b $P([lindex $L [expr {($i+1)%$n}]])
            return [vadd $a [vscale [vsub $b $a] $f]]
        }
        set goal [expr {$goal-$l}]
    }
}
# p moved onto the triangle of grid "name" it projects into (unchanged when none).
proc ::ElemImprint::onto_grid {name p} {
    upvar #0 ::ElemImprint::GD_$name D
    set hit [locate $name $p $D(mean)]
    if {![llength $hit]} {return $p}
    vsub $p [vscale [lindex $D([lindex $hit 0]) 3] [lindex $hit 1]]
}


# 1 when loop a lies inside loop b, seen along n (first node of a tested).
proc ::ElemImprint::loop_inside {a b n} {
    variable P
    set ax [expr {abs([lindex $n 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]
    set e1 [unit [cross $n $ax]]; set e2 [cross $n $e1]
    set f [list $P([lindex $b 0]) $e1 $e2]
    set poly {}; foreach k $b {lappend poly [to2d $f $P($k)]}
    set in 0
    foreach k $a {incr in [point_in_poly [to2d $f $P($k)] $poly]}
    expr {2*$in > [llength $a]}
}
# Triangles of an outline with holes: each hole joined to the outline at its closest node pair,
# then ear clipping. Outline counter-clockwise and holes clockwise along n.
proc ::ElemImprint::fill_with_holes {outer holes n} {
    variable P
    if {![llength $holes]} {return [fill_polygon $outer $n]}
    if {[llength $holes] == 1} {return [ring_fill [lindex $holes 0] $outer $n]}
    if {[loop_area $outer $n] < 0} {set outer [lreverse $outer]}
    foreach h $holes {
        if {[loop_area $h $n] > 0} {set h [lreverse $h]}
        set bi 0; set bj 0; set bd 1e300
        for {set i 0} {$i < [llength $h]} {incr i} {
            for {set j 0} {$j < [llength $outer]} {incr j} {
                set d [norm [vsub $P([lindex $h $i]) $P([lindex $outer $j])]]
                if {$d < $bd} {set bd $d; set bi $i; set bj $j}
            }
        }
        set outer [concat [lrange $outer 0 $bj] [lrange $h $bi end] [lrange $h 0 $bi] [lrange $outer $bj end]]
    }
    fill_polygon $outer $n
}


# Orientation of the new elements (copy rows by config: dict cfg -> full node lists; band
# triangles: node triples): each new element runs an edge it shares with an element already
# oriented the other way round, spread from the seed corner triples (the kept host rows, the sense
# of the host face) through the band to the copy, until nothing more is reached. Elements reached
# from no seed keep their sense. Returns {copy rows by config, band triangles}.
proc ::ElemImprint::orient_new {seeds byCfg bands} {
    # items: {kind cfg full-node-list}; corners are the first three nodes
    set items {}
    dict for {c rows} $byCfg {foreach nl $rows {lappend items [list copy $c $nl]}}
    foreach tr $bands {lappend items [list band 103 $tr]}
    # oriented edges: "a b" (a < b) -> 1 when the oriented element runs a -> b
    set E [dict create]
    foreach cs $seeds {
        lassign $cs a b c
        foreach {x y} [list $a $b $b $c $c $a] {
            set k [expr {$x < $y ? "$x $y" : "$y $x"}]
            if {![dict exists $E $k]} {dict set E $k [expr {$x < $y}]}
        }
    }
    set todo {}; for {set i 0} {$i < [llength $items]} {incr i} {lappend todo $i}
    while {[llength $todo]} {
        set left {}
        foreach i $todo {
            lassign [lindex $items $i] kind c nl
            lassign $nl a b q
            set flip ""
            foreach {x y} [list $a $b $b $q $q $a] {
                set k [expr {$x < $y ? "$x $y" : "$y $x"}]
                if {[dict exists $E $k]} {set flip [expr {[dict get $E $k] == ($x < $y)}]; break}
            }
            if {$flip eq ""} {lappend left $i; continue}
            if {$flip} {
                set nl [expr {[llength $nl] == 6 ? [list $a $q $b [lindex $nl 5] [lindex $nl 4] [lindex $nl 3]] : [list $a $q $b]}]
                lset items $i [list $kind $c $nl]
                lassign $nl a b q
            }
            foreach {x y} [list $a $b $b $q $q $a] {
                set k [expr {$x < $y ? "$x $y" : "$y $x"}]
                if {![dict exists $E $k]} {dict set E $k [expr {$x < $y}]}
            }
        }
        # nothing more reached: the rest keeps its sense
        if {[llength $left] == [llength $todo]} {break}
        set todo $left
    }
    set out [dict create]; set tris {}
    foreach it $items {
        lassign $it kind c nl
        if {$kind eq "copy"} {dict lappend out $c $nl} else {lappend tris $nl}
    }
    list $out $tris
}
# Ring elements from triangles (node triples): tria3, or tria6 with the existing midside nodes on
# shared edges. (A native *defaultremeshelems of the ring crashed HyperMesh 2022.3 with a
# segmentation error, so the ring is laid out in Tcl by ring_fill.) Returns {ids info}.
proc ::ElemImprint::ring_mesh {tris size order midsVar n} {
    variable P
    upvar 1 $midsVar mids
    if {![llength $tris]} {return [list {} [dict create count 0 minInner ""]]}
    set cnt [dict create]
    foreach tr $tris {lassign $tr a b c; foreach {x y} [list $a $b $b $c $c $a] {dict incr cnt [expr {$x < $y ? "$x $y" : "$y $x"}]}}
    set full {}
    foreach tr $tris {
        lassign $tr a b c
        if {$order == 2} {lappend full [list $a $b $c [mid_node mids $a $b] [mid_node mids $b $c] [mid_node mids $c $a]]} else {lappend full $tr}
    }
    set ids [create_rows $full [expr {$order == 2 ? 106 : 103}]]
    # shortest edge inside the ring (outline edges are fixed by the two faces)
    set minInner ""
    foreach tr $tris {
        lassign $tr a b c
        foreach {x y} [list $a $b $b $c $c $a] {
            if {[dict get $cnt [expr {$x < $y ? "$x $y" : "$y $x"}]] == 1} {continue}
            set l [norm [vsub $P($y) $P($x)]]
            if {$minInner eq "" || $l < $minInner} {set minInner $l}
        }
    }
    list $ids [dict create count [llength $tris] minInner $minInner]
}


# Closed outlines (node lists) of a set of free edges (keys "a b"), largest area first; errors "LAYER:" when
# an outline is open or touches itself.
proc ::ElemImprint::outlines {keys N what} {
    variable P
    lassign [edge_chains $keys] chains pinch
    if {[llength $pinch]} {error "LAYER: the outline of the $what touches itself."}
    set out {}
    foreach ch $chains {
        lassign $ch closed nodes
        if {!$closed} {error "LAYER: the outline of the $what is open."}
        set nn {}; foreach n $nodes {lappend nn [lindex [split $n #] 0]}
        lappend out [list [expr {abs([loop_area $nn $N])}] $nn]
    }
    set res {}
    foreach it [lsort -real -decreasing -index 0 $out] {lappend res [lindex $it 1]}
    return $res
}
# Ruled triangles between the outline of the deleted host rows (Rb, edge keys) and the outline of the
# copy (BG), loop to loop in the order of their areas (the outer ones first, then the holes):
#   - a pair is joined by ruled triangles, the smaller loop first (ring_fill takes inner, outer),
#     a copy hole smaller than its host hole as well as a larger one;
#   - a hole of the copy over deleted host material (no host hole to pair with) is filled by a fan;
#   - a host hole with no hole of the copy is covered by the copy: nothing to do.
proc ::ElemImprint::direct_bands {Rb BG N hName} {
    variable P
    set gk {}; dict for {k one} $BG {lappend gk $k}
    set hl [outlines $Rb $N "deleted host elements"]
    set gl [outlines $gk $N "copy"]
    set diag {}
    foreach {kind ls} [list host $hl copy $gl] {foreach l $ls {lappend diag [list $kind [llength $l] [format %.3f [expr {abs([loop_area $l $N])}]]]}}
    set ::ElemImprint::lastLoops [list direct $diag]
    set ::ElemImprint::loopNodes [list $hl $gl]
    set ::ElemImprint::unfilled {}
    set tris {}
    # the largest loop of each side is its outer rim; the others (holes of the copy, rims of what the
    # host keeps inside, e.g. a shaft) are paired with the nearest unused loop of the other side
    set usedH [dict create 0 1]
    set pairs [list [list 0 0]]
    for {set i 1} {$i < [llength $gl]} {incr i} {
        set g [lindex $gl $i]
        set gc {0.0 0.0 0.0}; foreach n $g {set gc [vadd $gc $P($n)]}
        set gc [vscale $gc [expr {1.0/[llength $g]}]]
        set bj -1; set bd 1e300
        for {set j 1} {$j < [llength $hl]} {incr j} {
            if {[dict exists $usedH $j]} {continue}
            set h [lindex $hl $j]
            set hc {0.0 0.0 0.0}; foreach n $h {set hc [vadd $hc $P($n)]}
            set hc [vscale $hc [expr {1.0/[llength $h]}]]
            set d [norm [vsub $hc $gc]]
            if {$d < $bd} {set bd $d; set bj $j}
        }
        if {$bj >= 0} {dict set usedH $bj 1}
        lappend pairs [list $bj $i]
    }
    foreach pr $pairs {
        lassign $pr hj gi
        set g [lindex $gl $gi]
        if {$hj < 0 || $hj >= [llength $hl]} {lappend tris {*}[fill_disk $g $N $hName]; continue}
        set h [lindex $hl $hj]
        set ah [expr {abs([loop_area $h $N])}]; set ag [expr {abs([loop_area $g $N])}]
        # rims and holes alike: one band from the smaller loop to the larger one (a copy hole larger
        # than the host hole: the band rises to it; smaller: it goes down to the host hole edge)
        if {$ag <= $ah} {set in $g; set out $h} else {set in $h; set out $g}
        lappend tris {*}[ring_fill $in $out $N "" $hName]
    }
    # host loops left without a partner stay as free edges of the new mesh (counted, not an error)
    for {set j 0} {$j < [llength $hl]} {incr j} {
        if {[dict exists $usedH $j] && [dict get $usedH $j]} {continue}
        set h [lindex $hl $j]
        for {set q 0} {$q < [llength $h]} {incr q} {
            set a [lindex $h $q]; set b [lindex $h [expr {($q+1)%[llength $h]}]]
            lappend ::ElemImprint::unfilled [expr {$a < $b ? "$a $b" : "$b $a"}]
        }
    }
    return $tris
}

# Smallest corner angle (as its cosine-free measure: sine-based, 0..1) of a 2D triangle.
proc ::ElemImprint::tri_quality2 {a b c} {
    set m 1e300
    foreach {o p q} [list $a $b $c $b $c $a $c $a $b] {
        set ux [expr {[lindex $p 0]-[lindex $o 0]}]; set uy [expr {[lindex $p 1]-[lindex $o 1]}]
        set vx [expr {[lindex $q 0]-[lindex $o 0]}]; set vy [expr {[lindex $q 1]-[lindex $o 1]}]
        set ang [expr {atan2(abs($ux*$vy-$uy*$vx),$ux*$vx+$uy*$vy)}]
        if {$ang < $m} {set m $ang}
    }
    return $m
}
# Smallest corner angle (radians) of a 3D triangle of node ids.
proc ::ElemImprint::tri_min_angle {a b c} {
    variable P
    set m 1e300
    foreach {o p q} [list $a $b $c $b $c $a $c $a $b] {
        set u [vsub $P($p) $P($o)]; set v [vsub $P($q) $P($o)]
        set ang [expr {atan2([norm [cross $u $v]],[dot $u $v])}]
        if {$ang < $m} {set m $ang}
    }
    return $m
}
proc ::ElemImprint::loop_sum {L} {
    variable P
    set s {0.0 0.0 0.0}
    foreach n $L {set s [vadd $s $P($n)]}
    list $s
}
# Triangles closing loop L: a fan from a new node at its centre (on the old face, grid "surf") when
# no triangle of the fan folds, else ear clipping.
proc ::ElemImprint::fill_disk {L n surf} {
    variable P
    set c [vscale [lindex [loop_sum $L] 0] [expr {1.0/[llength $L]}]]
    set c [onto_grid $surf $c]
    set m [llength $L]
    set sign [expr {[loop_area $L $n] > 0 ? 1 : -1}]
    set ok 1
    for {set i 0} {$i < $m} {incr i} {
        set a $P([lindex $L $i]); set b $P([lindex $L [expr {($i+1)%$m}]])
        if {$sign*[dot [cross [vsub $a $c] [vsub $b $c]] $n] <= 0} {set ok 0; break}
    }
    if {!$ok} {return [fill_polygon $L $n]}
    *createnode {*}$c 0 0 0
    set id [hm_latestentityid nodes]
    lappend ::ElemImprint::madeNodes $id
    set P($id) $c
    lappend ::ElemImprint::ringNodes $id
    set tris {}
    for {set i 0} {$i < $m} {incr i} {
        set a [lindex $L $i]; set b [lindex $L [expr {($i+1)%$m}]]
        set t [list $id $a $b]
        if {[dot [cross [vsub $P($a) $c] [vsub $P($b) $c]] $n] < 0} {set t [list $id $b $a]}
        lappend tris $t
    }
    return $tris
}
# Lawson edge flips on triangles (node triples, oriented along n): an interior edge shared by two
# triangles is swapped for the other diagonal of their quad when the quad is convex and the
# smallest angle of the pair grows. Outline edges never change.
proc ::ElemImprint::flip_improve {tris n} {
    variable P
    for {set pass 0} {$pass < 20} {incr pass} {
        set byEdge [dict create]
        for {set i 0} {$i < [llength $tris]} {incr i} {
            lassign [lindex $tris $i] a b c
            foreach {x y} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$x < $y ? "$x $y" : "$y $x"}] $i}
        }
        set done [dict create]; set changed 0
        dict for {k ts} $byEdge {
            if {[llength $ts] != 2} {continue}
            lassign $ts i j
            if {[dict exists $done $i] || [dict exists $done $j]} {continue}
            lassign $k x y
            set ti [lindex $tris $i]; set tj [lindex $tris $j]
            # the R-trias of the native ruled band keep their pattern
            if {[dict exists $::ElemImprint::rtriKeys [lsort -integer $ti]] && [dict exists $::ElemImprint::rtriKeys [lsort -integer $tj]]} {continue}
            set c ""; set d ""
            foreach v $ti {if {$v != $x && $v != $y} {set c $v}}
            foreach v $tj {if {$v != $x && $v != $y} {set d $v}}
            if {$c eq "" || $d eq "" || $c == $d} {continue}
            # the new diagonal must not exist already
            if {[dict exists $byEdge [expr {$c < $d ? "$c $d" : "$d $c"}]]} {continue}
            set before [expr {min([tri_min_angle {*}$ti],[tri_min_angle {*}$tj])}]
            # the pair's own normal (the band also runs down hole walls, nearly along n): both
            # triangles of the quad seen along it; the quad must be convex seen that way
            set ni [cross [vsub $P([lindex $ti 1]) $P([lindex $ti 0])] [vsub $P([lindex $ti 2]) $P([lindex $ti 0])]]
            set nj [cross [vsub $P([lindex $tj 1]) $P([lindex $tj 0])] [vsub $P([lindex $tj 2]) $P([lindex $tj 0])]]
            # same sense for both from the shared edge (a consistent pair runs it opposite ways; on a
            # wall the sign against n says nothing), then the pair turned to face along n
            set ri [lsearch -exact $ti $x]; set rj [lsearch -exact $tj $x]
            set fwdI [expr {[lindex $ti [expr {($ri+1)%3}]] == $y}]
            set fwdJ [expr {[lindex $tj [expr {($rj+1)%3}]] == $y}]
            if {$fwdI == $fwdJ} {set nj [vscale $nj -1]}
            if {[dot [vadd $ni $nj] $n] < 0} {set ni [vscale $ni -1]; set nj [vscale $nj -1]}
            if {[dot [unit $ni] [unit $nj]] < 0.5} {continue}
            set nq [unit [vadd [unit $ni] [unit $nj]]]
            # convex quad along nq: c and d on both sides of x-y, x and y on both sides of c-d
            set sxy [expr {[dot [cross [vsub $P($y) $P($x)] [vsub $P($c) $P($x)]] $nq]*[dot [cross [vsub $P($y) $P($x)] [vsub $P($d) $P($x)]] $nq]}]
            set scd [expr {[dot [cross [vsub $P($d) $P($c)] [vsub $P($x) $P($c)]] $nq]*[dot [cross [vsub $P($d) $P($c)] [vsub $P($y) $P($c)]] $nq]}]
            if {$sxy >= 0 || $scd >= 0} {continue}
            set n1 [list $c $d $x]; if {[dot [cross [vsub $P($d) $P($c)] [vsub $P($x) $P($c)]] $nq] < 0} {set n1 [list $c $x $d]}
            set n2 [list $c $d $y]; if {[dot [cross [vsub $P($d) $P($c)] [vsub $P($y) $P($c)]] $nq] < 0} {set n2 [list $c $y $d]}
            # the new pair must not fold either
            set m1 [cross [vsub $P([lindex $n1 1]) $P([lindex $n1 0])] [vsub $P([lindex $n1 2]) $P([lindex $n1 0])]]
            set m2 [cross [vsub $P([lindex $n2 1]) $P([lindex $n2 0])] [vsub $P([lindex $n2 2]) $P([lindex $n2 0])]]
            if {[dot [unit $m1] [unit $m2]] < 0.5} {continue}
            set after [expr {min([tri_min_angle {*}$n1],[tri_min_angle {*}$n2])}]
            if {$after <= $before + 1e-9} {continue}
            lset tris $i $n1; lset tris $j $n2
            dict set done $i 1; dict set done $j 1
            incr changed
        }
        if {!$changed} {break}
    }
    return $tris
}
# Folded pairs of the fill (two triangles on one edge whose normals, seen with the same sense, point
# more than 107 degrees apart, a bow tie): the other diagonal of their quad is taken when the two new
# triangles then agree (normals within 60 degrees). Outline edges never change.
proc ::ElemImprint::fold_fix {tris} {
    variable P
    set nrm {}
    for {set pass 0} {$pass < 10} {incr pass} {
        set byEdge [dict create]
        for {set i 0} {$i < [llength $tris]} {incr i} {
            lassign [lindex $tris $i] a b c
            foreach {x y} [list $a $b $b $c $c $a] {dict lappend byEdge [expr {$x < $y ? "$x $y" : "$y $x"}] $i}
        }
        set done [dict create]; set changed 0
        dict for {k ts} $byEdge {
            if {[llength $ts] != 2} {continue}
            lassign $ts i j
            if {[dict exists $done $i] || [dict exists $done $j]} {continue}
            lassign $k x y
            set ti [lindex $tris $i]; set tj [lindex $tris $j]
            set c ""; set d ""
            foreach v $ti {if {$v != $x && $v != $y} {set c $v}}
            foreach v $tj {if {$v != $x && $v != $y} {set d $v}}
            if {$c eq "" || $d eq "" || $c == $d} {continue}
            if {[dict exists $byEdge [expr {$c < $d ? "$c $d" : "$d $c"}]]} {continue}
            set ni [cross [vsub $P([lindex $ti 1]) $P([lindex $ti 0])] [vsub $P([lindex $ti 2]) $P([lindex $ti 0])]]
            set nj [cross [vsub $P([lindex $tj 1]) $P([lindex $tj 0])] [vsub $P([lindex $tj 2]) $P([lindex $tj 0])]]
            set ri [lsearch -exact $ti $x]; set rj [lsearch -exact $tj $x]
            if {([lindex $ti [expr {($ri+1)%3}]] == $y) == ([lindex $tj [expr {($rj+1)%3}]] == $y)} {set nj [vscale $nj -1]}
            if {[norm $ni] <= 0 || [norm $nj] <= 0} {continue}
            if {[dot [unit $ni] [unit $nj]] > -0.3} {continue}
            # the new pair c-d-x, d-c-y, in the sense of ti
            set n1 [list $c $x $d]; set n2 [list $d $y $c]
            if {[lindex $ti [expr {($ri+1)%3}]] != $y} {set n1 [list $c $d $x]; set n2 [list $d $c $y]}
            set m1 [cross [vsub $P([lindex $n1 1]) $P([lindex $n1 0])] [vsub $P([lindex $n1 2]) $P([lindex $n1 0])]]
            set m2 [cross [vsub $P([lindex $n2 1]) $P([lindex $n2 0])] [vsub $P([lindex $n2 2]) $P([lindex $n2 0])]]
            if {[norm $m1] <= 0 || [norm $m2] <= 0} {continue}
            if {[dot [unit $m1] [unit $m2]] < 0.5} {continue}
            lset tris $i $n1; lset tris $j $n2
            dict set done $i 1; dict set done $j 1
            incr changed
        }
        if {!$changed} {break}
    }
    return $tris
}
proc ::ElemImprint::tri_area_n {t n} {
    variable P
    lassign $t a b c
    expr {abs([dot [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]] $n])}
}


# 1 when an element outside "inside" (dict of element ids) uses both nodes x and y.
proc ::ElemImprint::edge_used_outside {x y inside} {
    set ex [elems_on_nodes [list $x]]
    set ey [lsort -integer [elems_on_nodes [list $y]]]
    foreach e $ex {
        if {[lsearch -sorted -integer $ey $e] >= 0 && ![dict exists $inside $e]} {return 1}
    }
    return 0
}

# ---------------------------------------------------------------- GUI
# The selection stays highlighted the native way while the window is open: target in the selection
# colour (white, mark 2 "high"), source grey (mark 1 "low"). The highlight lives on the marks, so the
# marks are kept; the imprint uses marks 1 and 2 itself, so the highlight is taken off before and put
# back after, as the last step of refresh (the element reads there reuse mark 1). Runtime picture
# check: tests/explore_highlight.tcl, tests/gui_redo.tcl.
# Element display of the whole model, as the HyperMesh toolbar sets it (command recording of the
# toolbar buttons: *setdisplayattributes style 0, the colouring left as it is): 2 shaded elements and
# mesh lines, 3 shaded elements and feature lines, 1 shaded elements.
proc ::ElemImprint::display_mode {style} {
    if {[catch {*setdisplayattributes $style 0} m]} {set ::ElemImprint::status "Display mode: $m"; return}
    catch {hm_redraw}
}
# A toolbar icon of the HyperMesh install (hw/tcl/hwt/images, GIF: Tk 8.5 reads no PNG), "" when missing.
proc ::ElemImprint::display_icon {file} {
    set img ::ElemImprint::icon_[file rootname $file]
    if {$img in [image names]} {return $img}
    set dirs {}
    if {[info exists ::env(ALTAIR_HOME)]} {lappend dirs [file join $::env(ALTAIR_HOME) hwdesktop hw tcl hwt images]}
    set d [file dirname [info nameofexecutable]]
    for {set i 0} {$i < 6} {incr i} {lappend dirs [file join $d hw tcl hwt images] [file join $d hwdesktop hw tcl hwt images]; set d [file dirname $d]}
    foreach dir $dirs {
        set p [file join $dir $file]
        if {[file exists $p] && ![catch {image create photo $img -file $p}]} {return $img}
    }
    return ""
}
# Preview of the narrow gaps before an imprint: the elements the imprint would delete for being too
# close to the source outline (narrow_gaps, threshold: the Gap L/d field) in the selection colour, the
# source grey. Nothing in the model changes. A second press, a pick or an imprint ends it.
proc ::ElemImprint::preview_gaps {} {
    variable sel; variable opt; variable status; variable W
    if {$::ElemImprint::showGaps} {
        set ::ElemImprint::showGaps 0
        set status ""
    } else {
        if {![llength [existing $sel(target)]] || ![llength [existing $sel(source)]]} {set status "Pick the target and the source first."; return}
        set lim [string trim $opt(gapLim)]
        if {$lim eq "" || ![string is double -strict $lim] || $lim <= 1} {set status "Gap L/d is off (empty); give a number above 1 to preview."; return}
        set t0 [clock milliseconds]
        set tf [target_face $sel(target) $sel(source)]
        set ::ElemImprint::gapIds [narrow_gaps $tf $sel(source) $lim $::ElemImprint::chamferRows]
        set ::ElemImprint::showGaps 1
        set status [format "Narrow gaps: %d elements (gap / edge under 1/%s), %d ms." [llength $::ElemImprint::gapIds] $lim [expr {[clock milliseconds]-$t0}]]
    }
    if {[winfo exists $W.body.opt.gaps]} {$W.body.opt.gaps configure -text [expr {$::ElemImprint::showGaps ? "Hide" : "Preview"}]}
    highlight
}
proc ::ElemImprint::highlight {} {
    variable shown; variable quiet
    clear_highlight
    if {$::ElemImprint::showBad} {highlight_bad; return}
    if {$::ElemImprint::showGaps} {
        set s [existing $shown(source)]
        if {[llength $s]} {*createmark elems 1 {*}$s; catch {hm_highlightmark elems 1 low}}
        set g [existing $::ElemImprint::gapIds]
        if {[llength $g]} {*createmark elems 2 {*}$g; catch {hm_highlightmark elems 2 high}}
        catch {hm_redraw}
        return
    }
    if {$quiet} {catch {hm_redraw}; return}
    foreach {k m mode} {target 2 high source 1 low} {
        set ids [existing $shown($k)]
        if {[llength $ids]} {*createmark elems $m {*}$ids; catch {hm_highlightmark elems $m $mode}}
    }
    catch {hm_redraw}
}
# The new elements failing the 2D criteria, shown after a successful imprint.
proc ::ElemImprint::highlight_bad {} {
    # shown only while Show is on: the failing elements in the selection color (mark 2, as a pick)
    if {!$::ElemImprint::showBad} {err_colors 0; return}
    err_colors 1
    set nids [existing $::ElemImprint::near]
    if {[llength $nids]} {*createmark elems 1 {*}$nids; catch {hm_highlightmark elems 1 low}}
    # the closest pair: the source node in the selection color, the two ends of the edge dark
    if {[llength $::ElemImprint::nearPair] == 3} {
        lassign $::ElemImprint::nearPair q a b
        catch {*createmark nodes 2 $q; hm_highlightmark nodes 2 high}
        catch {*createmark nodes 1 $a $b; hm_highlightmark nodes 1 low}
    }
    catch {hm_redraw}
}
# Error colors: the failing new elements drawn by HyperMesh as a contour (*tablecontour, discrete
# legend), one color per kind: 1 Aspect, 2 Skew, 3 Min length; the other elements "No Result".
# The table lives only for one note-history step that is undone at once: the contour stays and the
# Undo list is as before (runtime: tests/explore_contour.tcl). on=0 gives the color mode back.
proc ::ElemImprint::err_colors {on} {
    set ids [existing $::ElemImprint::bad]
    set key [expr {$on && [llength $ids] ? [lsort -integer $ids] : ""}]
    if {$key ne "" && [info exists ::ElemImprint::errShown] && $::ElemImprint::errShown eq $key} {return}
    if {$key eq ""} {
        if {[info exists ::ElemImprint::errShown]} {
            unset ::ElemImprint::errShown
            if {[info exists ::ElemImprint::errModeBefore]} {catch {*setoption element_color_mode=$::ElemImprint::errModeBefore}; unset ::ElemImprint::errModeBefore}
            catch {hm_redraw}
        }
        return
    }
    if {![info exists ::ElemImprint::errModeBefore]} {catch {set ::ElemImprint::errModeBefore [hm_info elementcolormode]}}
    set label "Element Imprint error colors"
    set t __imprint_errors
    history_begin $label
    set rc [catch {
        if {[hm_entityinfo exist tables $t -byname]} {*createmark tables 1 $t; *deletemark tables 1; *clearmark tables 1}
        *createstringarray 2 INT DOUBLE
        *tablecreate $t 3 1 1 2 0
        *createstringarray 2 IDs Errors
        *tableupdatelabels $t 1 2
        foreach e $ids {
            *createstringarray 2 $e [expr {double([dict get $::ElemImprint::badKind $e])}]
            *tableaddrow $t 1 2
        }
        *tablecontour $t IDs Errors "Errors: 1 Aspect, 2 Skew, 3 Min length"
    } m]
    history_end $label
    # the table step undone at once (only when it is the latest step)
    if {[lindex [undo_actions] 0] eq $label} {catch {*undohistorystate 1}}
    if {[hm_entityinfo exist tables $t -byname]} {catch {*createmark tables 1 $t; *deletemark tables 1; *clearmark tables 1}}
    if {$rc} {set ::ElemImprint::status "Error colors: $m"; return}
    set ::ElemImprint::errShown $key
    catch {hm_redraw}
}
# Show: the failing elements in the error colors, or the normal highlight again.
proc ::ElemImprint::toggle_show {} {
    variable W
    set ::ElemImprint::showBad [expr {!$::ElemImprint::showBad}]
    if {[winfo exists $W.body.chk.nav.show]} {$W.body.chk.nav.show configure -text [expr {$::ElemImprint::showBad ? "Hide" : "Show"}]}
    if {$::ElemImprint::showBad} {near_show} else {
        err_colors 0
        set ::ElemImprint::near {}; set ::ElemImprint::nearPair {}
        set ::ElemImprint::badText [lindex [split $::ElemImprint::badText "\n"] 0]
        highlight
    }
}
# Criteria changed: the new elements of the last imprint are checked again at once.
# Near src (Check field; the imprint option is off in the window): the old target elements next to the new mesh (sharing a
# node with it) with an edge closer than Near src (mm) to a source node (distance from the node to the
# edge segment, the red line, not to its corners). Shown
# with Show (native low highlight); the line says how many and the smallest distance.
proc ::ElemImprint::near_check {} {
    variable sel; variable opt
    set ::ElemImprint::near {}; set ::ElemImprint::nearText ""; set ::ElemImprint::nearPair {}
    set lim [string trim $opt(nearSrc)]
    set newE [existing $::ElemImprint::newElems]
    set preview [expr {![llength $newE]}]
    if {$preview && (![llength [existing $sel(target)]] || ![llength [existing $sel(source)]])} {return}
    # the source outline nodes only, as the imprint rule (its free edges)
    set src {}
    set srcRows [tri_rows [existing $sel(source)]]
    dict for {k one} [boundary_edges $srcRows] {lappend src {*}$k}
    set src [lsort -unique -integer $src]
    if {![llength $src]} {return}
    set SP [node_coords $src]
    set ring {}; if {!$preview} {foreach nl [elem_nodes $newE] {lappend ring {*}[lrange $nl 0 2]}}
    # (not the source elements; a node shared with the source is not measured, it is joined)
    set srcE [dict create]; foreach e [existing $sel(source)] {dict set srcE $e 1}
    set srcN [dict create]; foreach n $src {dict set srcN $n 1}
    set nb {}
    if {$preview} {
        # before the imprint: the target elements around the source (its sphere plus Near src)
        set lim0 [expr {[string is double -strict $lim] ? $lim : 0.0}]
        set c0 {0.0 0.0 0.0}; foreach q $SP {set c0 [vadd $c0 $q]}
        set c0 [vscale $c0 [expr {1.0/[llength $SP]}]]
        set r0 0.0; foreach q $SP {set r0 [expr {max($r0,[norm [vsub $q $c0]])}]}
        set tg [existing $sel(target)]
        foreach e $tg nl [elem_nodes $tg] {
            if {[dict exists $srcE $e]} {continue}
            foreach p [node_coords [lrange $nl 0 2]] {if {[norm [vsub $p $c0]] <= $r0+$lim0+1e-9} {lappend nb $e; break}}
        }
        # one more layer: the shell elements next to them outside the target (a neighbouring face)
        if {[llength $nb]} {
            set inT [dict create]; foreach e $tg {dict set inT $e 1}
            set nn {}; foreach nl [elem_nodes $nb] {lappend nn {*}[lrange $nl 0 2]}
            set more [existing [elems_on_nodes [lsort -unique -integer $nn]]]
            foreach e $more c [configs $more] {
                if {[dict exists $inT $e] || [dict exists $srcE $e] || !($c in {103 106})} {continue}
                lappend nb $e
            }
        }
    } else {
        foreach e [existing [elems_on_nodes [lsort -unique -integer $ring]]] {if {$e <= $::ElemImprint::oldMax && ![dict exists $srcE $e]} {lappend nb $e}}
        # one more layer outside: the shell elements next to those neighbours
        if {[llength $nb]} {
            set have [dict create]; foreach e $nb {dict set have $e 1}
            set nn {}; foreach nl [elem_nodes $nb] {lappend nn {*}[lrange $nl 0 2]}
            set more [existing [elems_on_nodes [lsort -unique -integer $nn]]]
            foreach e $more c [configs $more] {
                if {[dict exists $have $e] || [dict exists $srcE $e] || $e > $::ElemImprint::oldMax || !($c in {103 106})} {continue}
                lappend nb $e; dict set have $e 1
            }
        }
    }
    if {![llength $nb]} {return}
    # distance from each source node to each edge of the element (perpendicular to the segment, not
    # to its corners); a source node that is an end of the edge is not measured
    set dmin 1e300; set hit {}; set best ""
    set SPd [dict create]; foreach n $src q $SP {dict set SPd $n $q}
    # the source as a grid, to leave out the elements lying over it
    set nAll {}; foreach row $srcRows {lappend nAll {*}[lrange $row 1 3]}
    load_xyz [lsort -unique -integer $nAll]
    set srcR [grid_build NSRC $srcRows]
    grid_index NSRC $srcR
    foreach e $nb nl [elem_nodes $nb] {
        set cs [lrange $nl 0 2]
        set CP [dict create]; foreach n $cs p [node_coords $cs] {dict set CP $n $p}
        set de 1e300; set pair ""
        # (speed) only the source nodes within the element's sphere plus the distance kept so far
        set c [vscale [vadd [vadd [dict get $CP [lindex $cs 0]] [dict get $CP [lindex $cs 1]]] [dict get $CP [lindex $cs 2]]] [expr {1.0/3}]]
        set rad 0.0; foreach n $cs {set rad [expr {max($rad,[norm [vsub [dict get $CP $n] $c]])}]}
        set reach [expr {$rad + ($lim ne "" && [string is double -strict $lim] ? max($lim,$dmin) : $dmin)}]
        set near {}; dict for {q pq} $SPd {if {[norm [vsub $pq $c]] <= $reach} {lappend near $q $pq}}
        foreach {i j} {0 1 1 2 2 0} {
            set a [lindex $cs $i]; set b [lindex $cs $j]
            set pa [dict get $CP $a]; set pb [dict get $CP $b]
            set ab [vsub $pb $pa]; set l2 [dot $ab $ab]
            if {$l2 <= 0} {continue}
            foreach {q pq} $near {
                if {$q == $a || $q == $b} {continue}
                set t [expr {max(0.0,min(1.0,[dot [vsub $pq $pa] $ab]/$l2))}]
                set d [norm [vsub $pq [vadd $pa [vscale $ab $t]]]]
                if {$d < $de} {set de $d; set pair "elem $e edge $a-$b <- src node $q"; set pairIds [list $q $a $b]}
            }
        }
        # an element over the source (a corner or its centre on it) is deleted anyway: not counted
        set over 0
        foreach p [concat [list $c] [lrange [dict values $CP] 0 end]] {if {[llength [locate NSRC $p $srcR]]} {set over 1; break}}
        if {$over} {continue}
        if {$de < $dmin} {set dmin $de; set best $pair; set ::ElemImprint::nearPair $pairIds}
        if {$lim ne "" && [string is double -strict $lim] && $de < $lim} {lappend hit $e}
    }
    set ::ElemImprint::near $hit
    # why a hit is still there: outside the target face, or on its free edge (never deleted)
    set why ""
    if {[llength $hit] && [llength $::ElemImprint::lastFace]} {
        set inF [dict create]; foreach e $::ElemImprint::lastFace {dict set inF $e 1}
        set faceRows {}; foreach e [existing $::ElemImprint::lastFace] {lappend faceRows $e}
        set fb [boundary_edges [tri_rows [concat [existing $faceRows] $newE]]]
        set out 0; set edge 0; set other 0
        foreach e $hit nl [elem_nodes $hit] {
            if {![dict exists $inF $e]} {incr out; continue}
            lassign [lrange $nl 0 2] a b c
            set f 0
            foreach {p q} [list $a $b $b $c $c $a] {if {[dict exists $fb [expr {$p < $q ? "$p $q" : "$q $p"}]]} {set f 1}}
            if {$f} {incr edge} else {incr other}
        }
        set why " - kept: $out outside the target face, $edge on its free edge, $other other"
    }
    set ::ElemImprint::nearText [format "Near src: %d of %d%s, closest %.3g" [llength $hit] [llength $nb] [expr {$preview ? " (before imprint)" : ""}] $dmin]
    # the details (which element, edge and source node; why kept) in the Tcl console
    puts [format "Element Imprint, Near src: closest %.4g: %s%s" $dmin $best $why]
}
# A criterion field confirmed (Return, or left): checked again only when a value differs from the last check.
proc ::ElemImprint::criteria_changed {} {
    variable opt
    set now [list $opt(maxAspect) $opt(maxSkew) $opt(minLen)]
    if {[info exists ::ElemImprint::lastCrit] && $now eq $::ElemImprint::lastCrit} {return}
    recheck
}
proc ::ElemImprint::recheck {args} {
    variable W
    variable opt
    set ::ElemImprint::lastCrit [list $opt(maxAspect) $opt(maxSkew) $opt(minLen)]
    if {![llength [existing $::ElemImprint::newElems]]} {
        # before an imprint: nothing to check (Near src is measured by Show)
        set ::ElemImprint::badText ""
        return
    }
    if {[catch {check_2d $::ElemImprint::newElems} bad]} {set ::ElemImprint::badText $bad; return}
    set ::ElemImprint::bad $bad
    set n [llength [existing $::ElemImprint::newElems]]
    set ::ElemImprint::badText [expr {[llength $bad] ? "Errors: [llength $bad] of $n new elements" : "Errors: none ($n new elements)"}]
    if {[llength $bad]} {
        set c {0 0 0}
        foreach e $bad {set k [dict get $::ElemImprint::badKind $e]; lset c [expr {$k-1}] [expr {[lindex $c [expr {$k-1}]]+1}]}
        append ::ElemImprint::badText [format " (Aspect %d, Skew %d, Min length %d)" {*}$c]
    }
    set ::ElemImprint::errIdx -1
    if {$::ElemImprint::showBad} {near_show}
}
# Near src: measured only here, when Show is on (typing in the box does not redraw anything).
proc ::ElemImprint::near_show {} {
    set ::ElemImprint::near {}; set ::ElemImprint::nearText ""; set ::ElemImprint::nearPair {}
    set ::ElemImprint::badText [lindex [split $::ElemImprint::badText "\n"] 0]
    clear_highlight; highlight_bad
}
# ---------------------------------------------------------------- Fix (local, no new imprint)
# A failing triangle is repaired where it is, with the Equiv 2nd operations (sourced from ../Equiv2nd):
#   needle (one edge much shorter than the longest, ratio below 1/Aspect, else 1/3): its two short-edge
#     nodes merged (Replace), the node on the source outline kept where it is; the needle and the
#     triangle across the short edge go;
#   cap (a corner close to the middle of the opposite edge): that edge swapped with the triangle across
#     it (the corner joined to the far corner).
# Nodes of the source elements are never moved. One Undo step per repair.
proc ::ElemImprint::load_equiv {} {
    if {[llength [info commands ::Equiv2nd::plan_pair]]} {return}
    set f [file join [file dirname $::ElemImprint::dir] Equiv2nd equiv_second.tcl]
    if {![file isfile $f]} {error "Fix needs $f (Equiv 2nd tool)."}
    set ::Equiv2nd_load_only 1
    set code [catch {uplevel #0 [list source $f]} e]
    unset -nocomplain ::Equiv2nd_load_only
    if {$code} {error $e}
}
# Worst aspect (longest / shortest edge) over the elements on the nodes.
proc ::ElemImprint::worst_aspect {nodes} {
    set w 0.0
    set es [existing [elems_on_nodes [existing_nodes $nodes]]]
    foreach nl [elem_nodes $es] {
        set ps {}; foreach n [lrange $nl 0 2] {lappend ps [hm_getvalue nodes id=$n dataname=coordinates]}
        set a [lindex [tri_2d {*}$ps] 0]
        if {$a > $w} {set w $a}
    }
    return $w
}
# A repair kept only when the worst aspect around it gets better; else undone.
proc ::ElemImprint::fix_one {e} {
    if {![hm_entityinfo exist elems $e -byid]} {error "element $e is gone"}
    set around [node_set [existing [elems_on_nodes [lrange [hm_getvalue elems id=$e dataname=nodes] 0 2]]]]
    set w0 [worst_aspect $around]
    set h0 [llength [undo_actions]]
    set r [fix_try $e]
    set w1 [worst_aspect $around]
    # undone only when the repair made its own Undo step (never an earlier one)
    if {$w1 >= $w0} {
        if {[llength [undo_actions]] > $h0} {catch {*undohistorystate 1}}
        error "no better ([format %.1f $w0] -> [format %.1f $w1]), left as it was"
    }
    return "$r, worst aspect [format %.1f $w0] -> [format %.1f $w1]"
}
proc ::ElemImprint::fix_try {e} {
    variable sel; variable opt
    load_equiv
    if {![hm_entityinfo exist elems $e -byid]} {error "element $e is gone"}
    set nl [lrange [hm_getvalue elems id=$e dataname=nodes] 0 2]
    set prot [dict create]
    foreach n [node_set [existing $sel(source)]] {dict set prot $n 1}
    set P [dict create]; foreach n $nl {dict set P $n [hm_getvalue nodes id=$n dataname=coordinates]}
    set L {}
    foreach {i j} {0 1 1 2 2 0} {
        set a [lindex $nl $i]; set b [lindex $nl $j]
        lappend L [list [norm [vsub [dict get $P $b] [dict get $P $a]]] $a $b]
    }
    set L [lsort -real -index 0 $L]
    lassign [lindex $L 0] lmin p q
    set lmax [lindex $L end 0]
    set asp [string trim $opt(maxAspect)]
    set lim [expr {[string is double -strict $asp] && $asp > 1 ? 1.0/$asp : 1.0/3}]
    if {$lmax > 0 && $lmin < $lim*$lmax && !([dict exists $prot $p] && [dict exists $prot $q])} {
        # needle: merge the short edge, the source node kept
        if {[dict exists $prot $p]} {set keep $p; set gone $q} elseif {[dict exists $prot $q]} {set keep $q; set gone $p} else {
            set keep [expr {min($p,$q)}]; set gone [expr {max($p,$q)}]
        }
        ::Equiv2nd::apply [::Equiv2nd::plan_pair $gone $keep equiv 2]
        return "merged node $gone into $keep"
    }
    # cap: the corner with the smallest height over its opposite edge, swapped across that edge
    set area [expr {0.5*[norm [cross [vsub [dict get $P [lindex $nl 1]] [dict get $P [lindex $nl 0]]] [vsub [dict get $P [lindex $nl 2]] [dict get $P [lindex $nl 0]]]]]}]
    set bestV ""; set bestH 1e300
    foreach k {0 1 2} {
        set v [lindex $nl $k]; set a [lindex $nl [expr {($k+1)%3}]]; set b [lindex $nl [expr {($k+2)%3}]]
        set lab [norm [vsub [dict get $P $b] [dict get $P $a]]]
        if {$lab <= 0} {continue}
        set h [expr {2.0*$area/$lab/$lab}]
        if {$h < $bestH} {set bestH $h; set bestV [list $v $a $b]}
    }
    lassign $bestV v a b
    set d ""
    foreach x [elems_on_nodes [list $a $b]] {
        if {$x == $e} {continue}
        set xl [lrange [hm_getvalue elems id=$x dataname=nodes] 0 2]
        if {$a in $xl && $b in $xl} {foreach y $xl {if {$y != $a && $y != $b} {set d $y}}; break}
    }
    if {$d eq ""} {error "element $e: no triangle across its long edge (free edge)"}
    ::Equiv2nd::flip_pair $v $d
    return "swapped edge $a-$b to $v-$d"
}
# The new elements after a repair: every element on the nodes the new elements had.
proc ::ElemImprint::fix_region {nodes} {
    # (only elements made by the imprint or the repairs: ids above the largest one before the imprint)
    set out {}; foreach e [existing [elems_on_nodes [existing_nodes $nodes]]] {if {$e > $::ElemImprint::oldMax} {lappend out $e}}
    set ::ElemImprint::newElems $out
    recheck
}
proc ::ElemImprint::fix_nodes {} {
    set n {}; foreach nl [elem_nodes [existing $::ElemImprint::newElems]] {lappend n {*}[lrange $nl 0 2]}
    lsort -unique -integer $n
}
# Fix: Autofix repairs every failing element (a few passes); else the failing elements are shown dark
# (native low highlight) and one is clicked at a time (selection color), repaired, and the next asked
# for; return on the panel stops.
proc ::ElemImprint::do_fix {} {
    variable status; variable W
    set bad [existing $::ElemImprint::bad]
    if {![llength $bad]} {set status "No failing elements."; return}
    if {[catch {load_equiv} e]} {set status $e; return}
    set nodes [fix_nodes]
    if {$::ElemImprint::autoFix} {
        set done 0; set failed 0
        for {set pass 0} {$pass < 3} {incr pass} {
            set before [llength $::ElemImprint::bad]
            foreach e [existing $::ElemImprint::bad] {
                if {![hm_entityinfo exist elems $e -byid]} {continue}
                if {[catch {fix_one $e}]} {incr failed} else {incr done}
            }
            fix_region $nodes
            set nodes [fix_nodes]
            if {[llength $::ElemImprint::bad] >= $before} {break}
        }
        set status "Autofix: $done repaired, [llength $::ElemImprint::bad] still failing."
        return
    }
    set last [hm_info lastselectedentity elems]
    while 1 {
        clear_highlight
        set ids [existing $::ElemImprint::bad]
        if {![llength $ids]} {break}
        *createmark elems 1 {*}$ids; catch {hm_highlightmark elems 1 low}
        catch {hm_redraw}
        if {[catch {::TestToolSession::panel *createentitypanel elems "Fix: click a failing element (return to stop)"}]} {break}
        set e [hm_info lastselectedentity elems]
        if {$e eq "" || $e == 0 || $e eq $last} {break}
        set last $e
        if {!($e in $ids)} {set status "Element $e is not failing."; continue}
        *createmark elems 2 $e; catch {hm_highlightmark elems 2 high}; catch {hm_redraw}
        if {[catch {fix_one $e} r]} {set status "Fix $e: $r"} else {set status "Fix $e: $r."}
        update idletasks
        fix_region $nodes
        set nodes [fix_nodes]
    }
    clear_highlight
    highlight
}
proc ::ElemImprint::clear_highlight {} {
    foreach m {1 2} {catch {hm_highlightmark elems $m norm}; *clearmark elems $m}
    foreach m {1 2} {catch {hm_highlightmark nodes $m norm}; catch {*clearmark nodes $m}}
    catch {hm_redraw}
}

# The imprint made last by this window is kept (Imprint again undoes it first). Picking a new target
# or source keeps it in the model: the other side then becomes the face as it is now.
proc ::ElemImprint::keep_last {} {
    variable last; variable sel; variable shown
    if {![llength $last]} {return}
    foreach k {target source} {set sel($k) [existing $shown($k)]}
    set last {}
}

proc ::ElemImprint::pick {what} {
    variable W; variable sel; variable shown; variable status
    # a new pick starts again with the selection color
    variable quiet
    set quiet 0
    set ::ElemImprint::showGaps 0
    if {[winfo exists $W.body.opt.gaps]} {$W.body.opt.gaps configure -text "Preview"}
    if {[winfo exists $W]} {wm withdraw $W}
    clear_highlight
    keep_last
    set rc [catch {
        if {[llength [existing $sel($what)]]} {*createmark elems 1 {*}[existing $sel($what)]}
        variable opt
        if {$what eq "target" && $opt(targetMode) eq "area"} {
            # the corners of the area, picked in order (nodes); the target = the shell elements inside
            catch {::TestToolSession::panel *createlistpanel nodes 1 "Target area: pick the corner nodes in order (3 or more)"}
            set vn {}
            catch {set vn [hm_getlist nodes 1]}
            catch {*clearlist nodes 1}
            set ids [expr {[llength $vn] ? [by_area $vn [face_angle_value]] : {}}]
        } else {
            if {$what eq "source" && $opt(sourceMode) eq "component"} {
                # the source by component: every tria3/tria6 element of the picked components
                *clearmark comps 1
                catch {::TestToolSession::panel *createmarkpanel comps 1 "Imprint source: components"}
                set cs [hm_getmark comps 1]
                *clearmark comps 1
                set ids {}
                foreach c $cs {
                    *createmark elems 1 "by collector id" $c
                    foreach e [hm_getmark elems 1] {lappend ids $e}
                    *clearmark elems 1
                }
                set ids2 {}; foreach e $ids c [configs $ids] {if {$c in {103 106}} {lappend ids2 $e}}
                set ids $ids2
            } else {
                catch {::TestToolSession::panel *createmarkpanel elems 1 "Imprint $what: tria3/tria6 elements"}
                set ids [hm_getmark elems 1]
                *clearmark elems 1
                # By face (target or source): the whole face around the picked elements (Face angle)
                if {[llength $ids] && (($what eq "target" && $opt(targetMode) eq "face") || ($what eq "source" && $opt(sourceMode) eq "face"))} {set ids [by_face $ids [string trim $opt(faceAngle)]]}
            }
        }
        set ids
    } r]
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {$rc} {set status $r} else {
        set sel($what) $r
        set status ""
        if {![llength $r]} {set status "No $what elements selected."} elseif {[catch {kind $r $what} err]} {set status $err}
    }
    foreach k {target source} {set shown($k) $sel($k)}
    # a new pick: the Near src preview for the target and source as picked (no new elements yet)
    set ::ElemImprint::newElems {}; set ::ElemImprint::bad {}
    catch {recheck}
    refresh
    # Auto select: the target picked, the source pick follows at once
    variable opt
    if {!$rc && $what eq "target" && [llength $sel(target)] && $opt(autoSelect)} {
        after idle [list ::TestToolSession::run "Imprint" {::ElemImprint::pick source}]
    }
}

# The tria3/tria6 elements (of the components the corner nodes belong to) whose centre lies inside
# the polygon of the corner nodes (taken in the given order, seen along the polygon's normal).
# Elements farther from the polygon plane than 0.3 of its size are left out (the far side of a part).
# The Face angle of the window (30 when it is not a number between 0 and 90).
proc ::ElemImprint::face_angle_value {} {
    variable opt
    set a [string trim $opt(faceAngle)]
    if {![string is double -strict $a] || $a <= 0 || $a >= 90} {return 30}
    return $a
}
proc ::ElemImprint::by_area {corners {angle 30}} {
    variable P
    # keep the order picked (a mark would sort the ids)
    set have [dict create]; foreach n [existing_nodes $corners] {dict set have $n 1}
    set c2 {}; foreach n $corners {if {[dict exists $have $n]} {lappend c2 $n}}
    set corners $c2
    if {[llength $corners] < 3} {error "The area needs at least 3 corner nodes."}
    load_xyz $corners
    set c0 {0.0 0.0 0.0}
    foreach n $corners {set c0 [vadd $c0 $P($n)]}
    set c0 [vscale $c0 [expr {1.0/[llength $corners]}]]
    # Newell normal of the polygon
    set nrm {0.0 0.0 0.0}
    set k [llength $corners]
    for {set i 0} {$i < $k} {incr i} {
        set a $P([lindex $corners $i]); set b $P([lindex $corners [expr {($i+1)%$k}]])
        set nrm [vadd $nrm [cross [vsub $a $c0] [vsub $b $c0]]]
    }
    set nl [norm $nrm]
    if {$nl < 1e-12} {error "The corner nodes lie on a line: pick the corners of an area."}
    set nrm [vscale $nrm [expr {1.0/$nl}]]
    set u [cross $nrm [expr {abs([lindex $nrm 0]) < 0.9 ? {1.0 0.0 0.0} : {0.0 1.0 0.0}}]]
    set u [unit $u]; set v [cross $nrm $u]
    set poly {}; set size 0.0
    foreach n $corners {
        set d [vsub $P($n) $c0]
        lappend poly [list [dot $d $u] [dot $d $v]]
        set size [expr {max($size, [norm $d])}]
    }
    # candidates: the shell elements of the components the corners are on
    set seed {}
    foreach e [elems_on_nodes $corners] c [configs [elems_on_nodes $corners]] {if {$c in {103 106}} {lappend seed $e}}
    if {![llength $seed]} {error "The corner nodes are not on tria3/tria6 elements."}
    set all {}
    foreach c [comps_of $seed] {
        *createmark elems 1 "by collector name" $c
        foreach e [hm_getmark elems 1] {lappend all $e}
        *clearmark elems 1
    }
    set rows {}
    foreach e $all nl [elem_nodes $all] c [configs $all] {
        if {$c in {103 106}} {lappend rows [list $e [lindex $nl 0] [lindex $nl 1] [lindex $nl 2]]}
    }
    set nids {}; foreach row $rows {lappend nids {*}[lrange $row 1 3]}
    load_xyz $nids
    set out {}
    foreach row $rows {
        lassign $row e a b c
        set m [vscale [vadd [vadd $P($a) $P($b)] $P($c)] [expr {1.0/3.0}]]
        set d [vsub $m $c0]
        if {abs([dot $d $nrm]) > 0.3*$size} {continue}
        # only the face of the area: an element tilted more than the face angle from the area normal
        # (a chamfer or the wall of a hole inside the area) is left out, as By face would
        set nE [unit [cross [vsub $P($b) $P($a)] [vsub $P($c) $P($a)]]]
        if {acos(min(1.0,abs([dot $nE $nrm])))*180.0/acos(-1) > $angle} {continue}
        if {[in_polygon [dot $d $u] [dot $d $v] $poly]} {lappend out $e}
    }
    if {![llength $out]} {error "No shell element has its centre inside the area."}
    return $out
}
proc ::ElemImprint::in_polygon {x y poly} {
    set inside 0
    set k [llength $poly]
    for {set i 0; set j [expr {$k-1}]} {$i < $k} {set j $i; incr i} {
        lassign [lindex $poly $i] xi yi; lassign [lindex $poly $j] xj yj
        if {(($yi > $y) != ($yj > $y)) && ($x < ($xj-$xi)*($y-$yi)/($yj-$yi)+$xi)} {set inside [expr {!$inside}]}
    }
    return $inside
}

# The whole faces of the picked shells: neighbours across shared edges in the same components while
# the normals differ by at most "angle" degrees (either orientation). Other elements are kept as picked.
proc ::ElemImprint::by_face {ids angle} {
    variable P
    if {![string is double -strict $angle] || $angle < 0 || $angle > 90} {error "Face angle must be a number from 0 to 90."}
    set shells {}; set other {}
    foreach e $ids c [configs $ids] {if {$c in {103 106}} {lappend shells $e} else {lappend other $e}}
    if {![llength $shells]} {return $ids}
    # the same pick asked again (Gap preview, Imprint): the face found last time
    set key [list $angle [lsort -integer -unique $shells]]
    # (picked again, or the face itself passed back), while all its elements still exist
    if {[info exists ::ElemImprint::faceCache]} {
        lassign $::ElemImprint::faceCache k0 f0
        if {([lindex $k0 0] eq $angle && ([lindex $k0 1] eq [lindex $key 1] || [lsort -integer $f0] eq [lindex $key 1])) &&
            [llength [existing $f0]] == [llength $f0]} {
            return [concat $f0 $other]
        }
    }
    # native "by face" (extended selection), the angle from the feature_angle option, put back after;
    # same result as growing across edges within the angle, about ten times faster (test4: 26487
    # elements in 0.25 s against 2.5 s)
    set old [hm_getoption feature_angle]
    *setoption feature_angle=$angle
    set code [catch {
        *createmark elems 1 {*}$shells
        *appendmark elems 1 "by face"
        set got [hm_getmark elems 1]
    } msg]
    *clearmark elems 1
    *setoption feature_angle=$old
    if {$code} {error "By face failed: $msg"}
    # shells of the picked components only
    set inComp [dict create]; foreach c [comps_of $shells] {dict set inComp $c 1}
    set done [dict create]
    if {[llength $got]} {
        foreach e $got c [configs $got] cm [hm_getvalue elems user_ids=$got dataname=collector.name] {
            if {$c in {103 106} && [dict exists $inComp $cm]} {dict set done $e 1}
        }
    }
    foreach e $shells {dict set done $e 1}
    set face [dict keys $done]
    set ::ElemImprint::faceCache [list $key $face]
    concat $face $other
}

proc ::ElemImprint::swap {} {
    variable sel; variable shown; variable status
    lassign [list $sel(target) $sel(source)] a b
    set sel(target) $b; set sel(source) $a
    lassign [list $shown(target) $shown(source)] a b
    set shown(target) $b; set shown(source) $a
    set status ""
    refresh
}

# The window imprints with no extra deletion: automatic distance, no Gap ratio, the hole edges always
# joined by a band and the source always copied whole, joined straight to its inner rim (Join small
# hole). Near src only feeds the Check.
proc ::ElemImprint::gui_options {} {
    dict create holeGap 0 maxDist "" gapRatio 0 joinSmall 1
}

proc ::ElemImprint::undo_actions {} {if {[catch {hm_getundoactions} a]} {return {}}; return $a}

# Undo the imprint this window made last, only while it is still the latest Undo step and the model
# has not changed since; the picked elements must be back afterwards.
# Undo one step at a time until the element and node counts are "before" (max steps at most).
proc ::ElemImprint::undo_to {before max} {
    for {set i 0} {$i < $max} {incr i} {
        if {[list [count elems] [count nodes]] eq $before} {return $i}
        if {![llength [undo_actions]]} {break}
        *undohistorystate 1
    }
    return $i
}
proc ::ElemImprint::undo_last {} {
    variable last; variable sel
    if {[undo_actions] ne [dict get $last history] || [list [count elems] [count nodes]] ne [dict get $last after]} {
        error "The model changed after the last imprint (another edit or an Undo), so nothing was redone. Press Reset to start again."
    }
    # Undo until the counts are those before the imprint (several patches make several steps)
    set steps [expr {[dict exists $last steps] ? [dict get $last steps] : 1}]
    undo_to [dict get $last before] [expr {3*$steps+5}]
    set back [list [count elems] [count nodes]]
    if {$back ne [dict get $last before]} {error "Undoing the last imprint failed ([dict get $last after] -> $back): check the model."}
    foreach k {target source} {
        if {[llength [existing $sel($k)]] != [llength $sel($k)]} {error "Undoing the last imprint did not bring back the $k elements: check the model."}
    }
    set last {}
}

# The face named by the picked target: the picked elements grown over the smooth face (Face angle).
# With the source given, the chamfer rows around a hole of that face under the source are added (see
# face_chamfer): they are then replaced by the imprint like the face itself.
proc ::ElemImprint::target_face {ids {source {}}} {
    set ids [existing $ids]
    if {![llength $ids]} {return {}}
    set face [by_face $ids [face_angle_value]]
    set ::ElemImprint::chamferRows {}
    if {[llength $source]} {
        set ::ElemImprint::chamferRows [face_chamfer $face $source]
        set face [concat $face $::ElemImprint::chamferRows]
    }
    # the source elements stay out of the target, whatever reached them (shared nodes)
    if {[llength $source]} {
        set srcE [dict create]; foreach e $source {dict set srcE $e 1}
        foreach v {face ::ElemImprint::chamferRows} {
            set keep {}; foreach e [set $v] {if {![dict exists $srcE $e]} {lappend keep $e}}
            set $v $keep
        }
    }
    return $face
}
# Chamfer rows of face (element ids) under source: on each closed free-edge loop of the face whose
# centre lies within a source patch (its centre and radius), the elements outside the face sloped
# under 80 degrees to the face next to them (also nearly flat steps), row by row down to the hole wall.
proc ::ElemImprint::face_chamfer {face source} {
    variable P
    set rows [tri_rows $face]
    # the source is never a chamfer row (after an imprint it shares nodes with the target face)
    set srcE [dict create]; foreach e [existing $source] {dict set srcE $e 1}
    set inFace [dict create]; set byNode [dict create]
    foreach row $rows {dict set inFace [lindex $row 0] 1; foreach n [lrange $row 1 3] {dict lappend byNode $n $row}}
    set nids {}; foreach row $rows {lappend nids {*}[lrange $row 1 3]}
    load_xyz [lsort -unique -integer $nids]
    # source patches: centre and radius
    set pats {}
    foreach part [source_patches $source] {
        set sn [node_set $part]
        load_xyz $sn
        set c {0.0 0.0 0.0}; foreach n $sn {set c [vadd $c $P($n)]}
        set c [vscale $c [expr {1.0/[llength $sn]}]]
        set rad 0.0; foreach n $sn {set rad [expr {max($rad,[norm [vsub $P($n) $c]])}]}
        lappend pats $c $rad
    }
    set keys {}; dict for {k one} [boundary_edges $rows] {lappend keys $k}
    set out {}; set seen [dict create]
    foreach ch [lindex [edge_chains $keys] 0] {
        lassign $ch closed nodes
        if {!$closed} {continue}
        set front {}; set lc {0.0 0.0 0.0}
        foreach n $nodes {set n [lindex [split $n #] 0]; lappend front $n; set lc [vadd $lc $P($n)]}
        set lc [vscale $lc [expr {1.0/[llength $front]}]]
        set under 0
        foreach {c rad} $pats {if {[norm [vsub $lc $c]] < $rad} {set under 1; set pc $c; set prad $rad; break}}
        if {!$under} {continue}
        # the face normal along the loop
        set Nf [avg_normal [lmap_rows_on $byNode $front]]
        for {set it 0} {$it < 4 && [llength $front]} {incr it} {
            set es {}
            foreach e [elems_on_nodes $front] {if {![dict exists $inFace $e] && ![dict exists $seen $e] && ![dict exists $srcE $e]} {lappend es $e}}
            if {![llength $es]} {break}
            set nls [elem_nodes $es]
            set all {}; foreach nl $nls {lappend all {*}[lrange $nl 0 2]}
            load_xyz [lsort -unique -integer $all]
            set next {}
            foreach e $es nl $nls c [configs $es] {
                if {$c != 103 && $c != 106} {continue}
                lassign $nl a b cc
                set nE [unit [cross [vsub $P($b) $P($a)] [vsub $P($cc) $P($a)]]]
                set ang [expr {acos(min(1.0,abs([dot $nE $Nf])))*180.0/acos(-1)}]
                if {$ang > 80.0} {continue}
                # only rows reaching under the patch: a corner within its radius (a counterbore floor
                # smaller than the washer: the wall is taken, the top face around it is not)
                set within 0
                foreach n [list $a $b $cc] {if {[norm [vsub $P($n) $pc]] < $prad} {set within 1; break}}
                if {!$within} {continue}
                dict set seen $e 1
                lappend out $e
                lappend next $a $b $cc
            }
            set front [lsort -unique -integer $next]
        }
    }
    return $out
}
proc ::ElemImprint::lmap_rows_on {byNode nodes} {
    set o [dict create]
    foreach n $nodes {if {[dict exists $byNode $n]} {foreach r [dict get $byNode $n] {dict set o [lindex $r 0] $r}}}
    dict values $o
}
# 2D criteria of a triangle (corner coordinates), HyperMesh definitions: aspect = longest edge /
# shortest edge; skew = 90 degrees minus the smallest angle between a median (corner to the middle of
# the opposite edge) and the line joining the middles of the two other edges; length = the smaller of
# the shortest edge and the shortest height times 2/sqrt(3). Returns {aspect skew length}.
proc ::ElemImprint::tri_2d {pa pb pc} {
    set l1 [norm [vsub $pb $pa]]; set l2 [norm [vsub $pc $pb]]; set l3 [norm [vsub $pa $pc]]
    set lmin [expr {min($l1,$l2,$l3)}]; set lmax [expr {max($l1,$l2,$l3)}]
    set area [expr {0.5*[norm [cross [vsub $pb $pa] [vsub $pc $pa]]]}]
    set hmin [expr {$lmax > 0 ? 2.0*$area/$lmax : 0.0}]
    set len [expr {min($lmin,$hmin*2.0/sqrt(3.0))}]
    set asp [expr {$lmin > 0 ? $lmax/$lmin : 1e300}]
    set best 90.0
    foreach {p q r} [list $pa $pb $pc $pb $pc $pa $pc $pa $pb] {
        set m [vscale [vadd $q $r] 0.5]
        set u [vsub $m $p]
        set v [vsub [vscale [vadd $p $r] 0.5] [vscale [vadd $p $q] 0.5]]
        set lu [norm $u]; set lv [norm $v]
        if {$lu <= 0 || $lv <= 0} {set best 0.0; continue}
        set c [expr {abs([dot $u $v])/($lu*$lv)}]
        set ang [expr {acos(min(1.0,$c))*180.0/acos(-1)}]
        if {$ang < $best} {set best $ang}
    }
    list $asp [expr {90.0-$best}] $len
}
# Elements of ids (tria3/tria6) failing the window's Aspect (max), Skew (max, degrees) or Min length;
# an empty field switches that criterion off.
proc ::ElemImprint::check_2d {ids} {
    variable opt
    set ids [existing $ids]
    if {![llength $ids]} {return {}}
    set lim {}
    foreach k {maxAspect maxSkew minLen} {
        set v [string trim $opt($k)]
        if {$v ne "" && ![string is double -strict $v]} {error "$k must be a number or empty."}
        lappend lim $v
    }
    lassign $lim ma ms ml
    # badKind: element -> 1 Aspect, 2 Skew, 3 Min length (the first criterion it fails)
    set out {}; set ::ElemImprint::badKind [dict create]
    foreach e $ids nl [elem_nodes $ids] {
        set ps {}
        foreach n [lrange $nl 0 2] {lappend ps [hm_getvalue nodes id=$n dataname=coordinates]}
        lassign [tri_2d {*}$ps] asp sk len
        set k 0
        if {$ma ne "" && $asp > $ma} {set k 1} elseif {$ms ne "" && $sk > $ms} {set k 2} elseif {$ml ne "" && $len < $ml} {set k 3}
        if {$k} {lappend out $e; dict set ::ElemImprint::badKind $e $k}
    }
    return $out
}
# A tool message cut to its first sentence, "Nothing changed." kept.
proc ::ElemImprint::short_reason {m} {
    set m [string trim $m]
    regsub {^Could not fill the ring between the copy and the host face \((.*)\)\s*} $m {\1 } m
    set first [lindex [split $m .] 0]
    return [string trim "$first."]
}
proc ::ElemImprint::do_imprint {} {
    variable sel; variable shown; variable last; variable status; variable quiet; variable opt
    set status "Imprinting..."
    set t0 [clock milliseconds]
    update idletasks
    clear_highlight
    set redo [llength $last]
    if {$redo && [catch {undo_last} r]} {
        set status $r
        refresh
        return
    }
    set before [list [count elems] [count nodes]]
    # the target picked only names the face to imprint on: the whole face around it (Face angle) is
    # given to the imprint, which takes the elements it needs from it near the source
    set ::ElemImprint::bad {}
    set ::ElemImprint::oldMax [hm_entitymaxid elems]
    if {[catch {
        set tf [target_face $sel(target) $sel(source)]
        set ::ElemImprint::lastFace $tf
        set go [gui_options]
        if {[llength $::ElemImprint::chamferRows]} {dict set go chamferRows $::ElemImprint::chamferRows}
        # the elements too close to the source outline (the same list Preview shows) are deleted too
        set gaps [narrow_gaps $tf $sel(source) [string trim $opt(gapLim)] $::ElemImprint::chamferRows]
        if {[llength $gaps]} {dict set go gapRows $gaps}
        # Gap L/d again when the imprint has to take in rows next to the face (rows_under_source)
        dict set go gapLim [string trim $opt(gapLim)]
        set ::ElemImprint::showGaps 0
        imprint $tf $sel(source) $go
    } r]} {
        if {$redo} {set r "The last imprint was undone. With these options: $r"}
        set status $r
        foreach k {target source} {set shown($k) $sel($k)}
        set quiet 0
        set status [format "Failed (%.1f s): %s" [expr {([clock milliseconds]-$t0)/1000.0}] [short_reason $status]]
        progress 0 0
        set ::ElemImprint::newElems {}; set ::ElemImprint::bad {}; set ::ElemImprint::badText ""
        highlight_bad
        refresh
        return
    }
    set steps [expr {[dict exists $r steps] ? [dict get $r steps] : 1}]
    # 2nd order: the new tria3 made tria6 by HyperMesh (*orderchangetosecond; midside nodes on edges
    # shared with tria6 neighbours are reused), one more Undo step
    set o2 ""
    if {$opt(order2)} {
        set t3 {}
        set nn [existing [dict get $r result]]
        foreach e $nn c [configs $nn] {if {$e > $::ElemImprint::oldMax && $c == 103} {lappend t3 $e}}
        if {[llength $t3]} {
            history_begin "Element imprint 2nd order"
            set rc2 [catch {*createmark elems 1 {*}$t3; *orderchangetosecond 1 0 0; *clearmark elems 1} m2]
            history_end "Element imprint 2nd order"
            incr steps
            set o2 [expr {$rc2 ? " 2nd order failed: $m2" : " [llength $t3] made 2nd order."}]
        }
    }
    set last [dict create before $before after [list [count elems] [count nodes]] history [undo_actions] steps $steps]
    if {[dict exists $r twoWay]} {
        set shown(target) [dict get $r result]; set shown(source) [dict get $r sourceResult]
    } elseif {[dict get $r shared] && [dict get $r swapped]} {
        set shown(target) [existing $sel(target)]; set shown(source) [dict get $r result]
    } elseif {[dict get $r shared]} {
        set shown(target) [dict get $r result]; set shown(source) [existing $sel(source)]
    } else {
        set shown(target) [existing $sel(target)]; set shown(source) [existing $sel(source)]
    }
    # new elements failing the 2D criteria (Aspect, Skew, Min length): highlighted, kept in
    # ::ElemImprint::bad for a later step
    set old [dict create]; foreach e $tf {dict set old $e 1}
    set new {}; foreach e [existing [dict get $r result]] {if {![dict exists $old $e]} {lappend new $e}}
    set chkErr ""
    if {[catch {check_2d $new} bad]} {set chkErr " (2D check failed: $bad)"; set bad {}}
    set ::ElemImprint::bad $bad
    set ::ElemImprint::newElems $new
    # short status: done / failed
    set np [expr {[dict exists $r patches] ? [dict get $r patches] : 1}]
    set nf [expr {[dict exists $r failed] ? [llength [dict get $r failed]] : 0}]
    set text "Done: [expr {$np-$nf}]/$np patches, [dict get $r removed] replaced."
    if {$nf} {append text " Failed $nf: [short_reason [lindex [dict get $r failed] 0 1]]"}
    if {[dict get $r overhang]} {append text " [dict get $r overhang] source elements left off the target."}
    if {[dict get $r crack]} {append text " [dict get $r crack] open edges."}
    set status [format "%s%s%s Time %.1f s." $text $o2 $chkErr [expr {([clock milliseconds]-$t0)/1000.0}]]
    progress 0 0
    set quiet 1
    refresh
    recheck
}


proc ::ElemImprint::delete_covered {} {
    variable sel; variable shown; variable last; variable status; variable opt
    if {![llength [existing $sel(target)]] || ![llength [existing $sel(source)]]} {set status "Pick the target and the source first."; return}
    set t0 [clock milliseconds]
    clear_highlight
    set ::ElemImprint::showGaps 0
    set tf [target_face $sel(target) $sel(source)]
    lassign [covered_layer $tf $sel(source) $opt(delGap) $::ElemImprint::chamferRows] ids layer
    set ids [existing $ids]
    if {![llength $ids]} {set status "Nothing under the source to delete."; refresh; return}
    history_begin "Element imprint delete covered"
    set rc [catch {delete_elems $ids} m]
    history_end "Element imprint delete covered"
    if {$rc} {set status "Delete failed: $m"; refresh; return}
    # an imprint after this is a new one: it must not undo the delete as if it were the last imprint
    set last {}
    foreach k {target source} {set sel($k) [existing $sel($k)]; set shown($k) $sel($k)}
    set status [format "Deleted %d elements (%d covered, %d in the layer closer than %s mm), %d ms." [llength $ids] [expr {[llength $ids]-[llength $layer]}] [llength $layer] [string trim $opt(delGap)] [expr {[clock milliseconds]-$t0}]]
    refresh
}
proc ::ElemImprint::reset {} {
    variable quiet
    set quiet 0
    variable sel; variable shown; variable last; variable status
    clear_highlight
    foreach k {target source} {set sel($k) {}; set shown($k) {}}
    set last {}
    set ::ElemImprint::newElems {}; set ::ElemImprint::bad {}; set ::ElemImprint::badText ""
    highlight_bad
    set status ""
    refresh
}

proc ::ElemImprint::close {} {
    variable W
    set ::ElemImprint::showBad 0
    set ::ElemImprint::near {}; set ::ElemImprint::nearPair {}
    err_colors 0
    quality_view 0
    reset
    clear_highlight
    catch {*clearmark elems 1; *clearmark elems 2; *clearmark nodes 1; *clearmark nodes 2}
    catch {hm_redraw}
    destroy $W
}
# Native element quality colors (the view's color mode "Element Quality", criteria of HyperMesh):
# drawn by HyperMesh itself, so they follow every later change of the mesh, by any tool. on=0 gives
# the previous color mode back.
proc ::ElemImprint::quality_view {on} {
    if {$on} {
        if {![info exists ::ElemImprint::colorModeBefore]} {catch {set ::ElemImprint::colorModeBefore [hm_info elementcolormode]}}
        if {[catch {*setelementcolormode 17} e]} {set ::ElemImprint::status "Quality colors: $e"; set ::ElemImprint::opt(qview) 0}
    } elseif {[info exists ::ElemImprint::colorModeBefore]} {
        catch {*setelementcolormode $::ElemImprint::colorModeBefore}
        unset ::ElemImprint::colorModeBefore
    }
    catch {hm_redraw}
}
# Prev / Next: the failing elements one by one, the view fitted to it and its neighbours, the element
# in the selection color.
proc ::ElemImprint::goto_err {step} {
    variable status
    set ids [existing $::ElemImprint::bad]
    if {![llength $ids]} {set status "No errors."; return}
    if {![info exists ::ElemImprint::errIdx]} {set ::ElemImprint::errIdx -1}
    set i [expr {($::ElemImprint::errIdx + $step) % [llength $ids]}]
    if {$i < 0} {set i [expr {$i + [llength $ids]}]}
    set ::ElemImprint::errIdx $i
    set e [lindex $ids $i]
    set nl [lrange [hm_getvalue elems id=$e dataname=nodes] 0 2]
    set around [existing [elems_on_nodes $nl]]
    clear_highlight
    *createmark elems 1 {*}$around; catch {*window_entitymark elems 1}; *clearmark elems 1
    # the element shown: native low highlight (dark grey), as asked
    *createmark elems 2 $e; catch {hm_highlightmark elems 2 low}
    set ps {}; foreach n $nl {lappend ps [hm_getvalue nodes id=$n dataname=coordinates]}
    lassign [tri_2d {*}$ps] asp sk len
    set status [format "Error %d/%d: elem %d (aspect %.1f, skew %.0f, length %.3g)" [expr {$i+1}] [llength $ids] $e $asp $sk $len]
    catch {hm_redraw}
}

proc ::ElemImprint::describe {ids} {
    variable names
    set ids [existing $ids]
    if {![llength $ids]} {return "Nothing selected"}
    set cs [lsort -unique [configs $ids]]
    set types {}
    foreach c $cs {lappend types [expr {[dict exists $names $c] ? [dict get $names $c] : "config $c"}]}
    set comps [comps_of $ids]
    set t "[llength $ids] [join $types /]"
    if {[llength $comps] == 1} {append t " in [lindex $comps 0]"} else {append t " in [llength $comps] comps"}
    return $t
}

# A split button: the main part runs command, the arrow opens a menu of radio entries ($items = label
# value ...) on the variable var (as the Import button of the Material Manager).
proc ::ElemImprint::bad_row {args} {
    variable W
    set l $W.body.chk.bad
    if {![winfo exists $l]} {return}
    if {[string trim $::ElemImprint::badText] eq ""} {grid remove $l} else {grid $l}
}
proc ::ElemImprint::combo_button {path text width command var items} {
    frame $path
    button $path.main -text $text -width $width -command [list ::TestToolSession::run "Imprint" $command]
    button $path.arrow -text "▾" -width 2 -command [list ::ElemImprint::combo_post $path]
    pack $path.main -side left
    pack $path.arrow -side left -fill y
    menu $path.menu -tearoff 0
    foreach {label value} $items {$path.menu add radiobutton -label $label -value $value -variable $var}
    return $path
}
proc ::ElemImprint::combo_post {path} {
    tk_popup $path.menu [winfo rootx $path.main] [expr {[winfo rooty $path.main]+[winfo height $path.main]}]
}

proc ::ElemImprint::refresh {} {
    variable W; variable sel; variable shown; variable last; variable opt
    if {![winfo exists $W]} {return}
    foreach k {target source} {set opt(info,$k) [describe $shown($k)]}
    set ok [expr {[llength $last] || ([llength [existing $sel(target)]] && [llength [existing $sel(source)]])}]
    $W.foot.run configure -state [expr {$ok ? "normal" : "disabled"}] -text [expr {[llength $last] ? "Re-imprint" : "Imprint"}]
    # last: the reads above reuse mark 1
    highlight
}

# Progress of a long step in the status row (patch i of n): bar and caption instead of "Ready";
# redrawn at most every 80 ms (HyperMesh is busy meanwhile). n = 0 ends it.
proc ::ElemImprint::progress {i n {label "Imprint"}} {
    variable W
    if {![info exists W] || ![winfo exists $W.bar.progress]} {return}
    if {$n <= 0} {
        grid forget $W.bar.progress $W.bar.task
        grid $W.bar.ready -row 0 -column 0 -sticky nw -padx {0 12}
        set ::ElemImprint::progressValue 0; set ::ElemImprint::progressTask ""
        update idletasks
        return
    }
    $W.bar.progress configure -maximum $n
    set ::ElemImprint::progressValue $i
    set ::ElemImprint::progressTask "$label $i/$n"
    if {[winfo manager $W.bar.progress] eq ""} {
        grid forget $W.bar.ready
        grid $W.bar.progress -row 0 -column 0 -sticky w
        grid $W.bar.task -row 0 -column 1 -sticky w -padx {6 12}
    }
    set now [clock milliseconds]
    if {![info exists ::ElemImprint::progressDrawn] || $now-$::ElemImprint::progressDrawn >= 80 || $i == 0} {
        set ::ElemImprint::progressDrawn $now
        update idletasks
    }
}

# Keys B / N in the window: previous / next error (not inside an entry field).
proc ::ElemImprint::nav_key {w step} {
    if {[winfo class $w] eq "Entry"} {return}
    ::TestToolSession::run "Imprint" [list ::ElemImprint::goto_err $step]
}

# Change order: the elements the last imprint made to 1st order (tria6 -> tria3) or 2nd order
# (tria3 -> tria6, midside nodes on edges shared with tria6 neighbours reused), one Undo step that
# the next Re-imprint undoes with the imprint.
proc ::ElemImprint::change_order {to} {
    variable status; variable last; variable opt
    set opt(order) $to; set opt(order2) [expr {$to == 2}]
    set ids [existing $::ElemImprint::newElems]
    if {![llength $ids]} {set status "The next imprint makes order $to elements."; return}
    set from [expr {$to == 2 ? 103 : 106}]
    set pick {}
    foreach e $ids c [configs $ids] {if {$c == $from} {lappend pick $e}}
    if {![llength $pick]} {set status "The [llength $ids] new elements are already order $to."; return}
    set label "Element imprint order $to"
    history_begin $label
    if {$to == 2} {
        set rc [catch {*createmark elems 1 {*}$pick; *orderchangetosecond 1 0 0; *clearmark elems 1} m]
    } else {
        set rc [catch {*createmark elems 1 {*}$pick; *orderchangetofirst 1; *clearmark elems 1} m]
    }
    history_end $label
    if {$rc} {set status "Order change failed: $m"; return}
    set ::ElemImprint::newElems [existing $ids]
    if {[llength $last]} {
        dict set last after [list [count elems] [count nodes]]
        dict set last history [undo_actions]
        dict set last steps [expr {([dict exists $last steps] ? [dict get $last steps] : 1)+1}]
    }
    set status "[llength $pick] new elements made order $to."
    recheck
    catch {hm_redraw}
}

proc ::ElemImprint::show {} {
    variable W; variable status; variable opt
    # opened again: the color modes this window set are given back first
    catch {err_colors 0}
    catch {quality_view 0}
    if {[winfo exists $W]} {destroy $W}
    reset
    toplevel $W
    wm withdraw $W
    wm title $W "Element Imprint"
    wm resizable $W 0 0
    frame $W.body -padx 8 -pady 6
    pack $W.body -fill both -expand 1

    # Elements: what is imprinted on what; Face angle and Auto select in one column right of them
    set s [labelframe $W.body.sel -text "Elements" -padx 6 -pady 3]
    # Select target / source: split buttons, the arrow picks how the elements are selected
    combo_button $s.target "Select target" 12 {::ElemImprint::pick target} ::ElemImprint::opt(targetMode)         {"By face" face "By area" area "Elements" elements}
    label $s.i_target -textvariable ::ElemImprint::opt(info,target) -anchor w -width 19
    combo_button $s.source "Select source" 12 {::ElemImprint::pick source} ::ElemImprint::opt(sourceMode)         {"Elements" elements "By face" face "By component" component}
    label $s.i_source -textvariable ::ElemImprint::opt(info,source) -anchor w -width 19
    label $s.l_face -text "Face angle" -anchor w
    # 5 degrees up or down from the value in the box
    spinbox $s.face -width 4 -justify right -from 0 -to 90 -increment 5 -textvariable ::ElemImprint::opt(faceAngle)
    checkbutton $s.auto -text "Auto select" -variable ::ElemImprint::opt(autoSelect)
    grid $s.target $s.i_target $s.l_face $s.face -sticky w -pady 1 -padx {0 4}
    grid $s.source $s.i_source $s.auto - -sticky w -pady 1 -padx {0 4}
    grid columnconfigure $s 1 -weight 1
    grid $s -row 0 -column 0 -columnspan 2 -sticky ew

    # Imprint (left) and Change order (right), side by side, two rows each
    # Imprint: the source is always copied whole and joined straight to its rims (gui_options)
    set f [labelframe $W.body.opt -text "Imprint" -padx 6 -pady 2]
    # Gap L/d: target elements whose band to the source outline would be thinner than 1/(L/d) of its
    # length are deleted too (narrow_gaps; empty = off); Preview gaps shows them before the imprint
    label $f.l_gap -text "Gap L/d >" -anchor w
    entry $f.gap -width 5 -justify right -textvariable ::ElemImprint::opt(gapLim)
    button $f.gaps -text "Preview" -width 8 -command [list ::TestToolSession::run "Imprint" ::ElemImprint::preview_gaps]
    grid $f.l_gap $f.gap $f.gaps -sticky w -pady 2 -padx {0 4}
    grid configure $f.gaps -sticky e -padx {6 0}
    # Delete covered: only deletes the elements under the source and the layer next to them closer
    # than Gap (mm) to its outline (covered_layer); no copy, no join, no check
    label $f.l_dgap -text "Gap (mm) <" -anchor w
    entry $f.dgap -width 5 -justify right -textvariable ::ElemImprint::opt(delGap)
    button $f.del -text "Delete covered" -width 13 -command [list ::TestToolSession::run "Imprint" ::ElemImprint::delete_covered]
    grid $f.l_dgap $f.dgap $f.del -sticky w -pady 2 -padx {0 4}
    grid configure $f.del -sticky e -padx {6 0}
    grid columnconfigure $f 2 -weight 1
    # Change order: the order of the new elements; changes the elements the last imprint made at once
    # (one Undo step) and is used by the next imprint
    set o [labelframe $W.body.ord -text "Change order" -padx 6 -pady 2]
    set opt(order) [expr {$opt(order2) ? 2 : 1}]
    ttk::radiobutton $o.first -text "1st" -value 1 -variable ::ElemImprint::opt(order) -command [list ::TestToolSession::run "Imprint" {::ElemImprint::change_order 1}]
    ttk::radiobutton $o.second -text "2nd" -value 2 -variable ::ElemImprint::opt(order) -command [list ::TestToolSession::run "Imprint" {::ElemImprint::change_order 2}]
    grid $o.first $o.second -sticky w -pady 2 -padx {0 14}
    grid $f -row 1 -column 0 -sticky nsew -pady {4 0} -padx {0 2}
    grid $o -row 1 -column 1 -sticky nsew -pady {4 0} -padx {2 0}

    # Check: 2D criteria on the new elements (an element fails above / below the value) on one row,
    # the colours and display modes, then browse the errors (B = previous, N = next)
    set c [labelframe $W.body.chk -text "Check" -padx 6 -pady 2]
    frame $c.crit
    label $c.l_asp -text "Aspect >" -anchor w
    entry $c.asp -width 5 -justify right -textvariable ::ElemImprint::opt(maxAspect)
    label $c.l_skew -text "Skew (deg) >" -anchor w
    entry $c.skew -width 5 -justify right -textvariable ::ElemImprint::opt(maxSkew)
    label $c.l_len -text "Length <" -anchor w
    entry $c.len -width 5 -justify right -textvariable ::ElemImprint::opt(minLen)
    pack $c.l_asp $c.asp -in $c.crit -side left -padx {0 3}
    pack $c.l_skew -in $c.crit -side left -padx {10 3}
    pack $c.skew -in $c.crit -side left -padx {0 3}
    pack $c.l_len -in $c.crit -side left -padx {10 3}
    pack $c.len -in $c.crit -side left
    # Quality check: the native element quality colors while ticked (quality_view)
    checkbutton $c.qview -text "Quality check" -variable ::ElemImprint::opt(qview) -command [list ::TestToolSession::run "Imprint" {::ElemImprint::quality_view $::ElemImprint::opt(qview)}]
    # View: the element display modes of the HyperMesh toolbar, with its own icons (in the foot)
    frame $W.foot
    frame $W.foot.disp
    set c2 $c; set c $W.foot
    foreach {name icon style tip} {
        mesh elemsShadedWithMesh-24.gif 2 "Shaded elements and mesh lines"
        feat elemsShadedWithFeatures-24.gif 3 "Shaded elements and feature lines"
        shade elemsShaded-24.gif 1 "Shaded elements"
    } {
        set img [display_icon $icon]
        if {$img ne ""} {
            button $c.disp.$name -image $img -command [list ::TestToolSession::run "Imprint" [list ::ElemImprint::display_mode $style]]
        } else {
            button $c.disp.$name -text $tip -command [list ::TestToolSession::run "Imprint" [list ::ElemImprint::display_mode $style]]
        }
        bind $c.disp.$name <Enter> [list set ::ElemImprint::status $tip]
        pack $c.disp.$name -side left -padx {2 0}
    }
    set c $c2
    set ::ElemImprint::showBad 0
    frame $c.nav
    label $c.nav.l -text "Errors"
    button $c.nav.show -text "Show" -width 6 -command [list ::TestToolSession::run "Imprint" ::ElemImprint::toggle_show]
    button $c.nav.prev -text "< Prev (B)" -width 9 -command [list ::TestToolSession::run "Imprint" {::ElemImprint::goto_err -1}]
    button $c.nav.next -text "Next (N) >" -width 9 -command [list ::TestToolSession::run "Imprint" {::ElemImprint::goto_err 1}]
    pack $c.nav.l -side left -padx {0 6}
    pack $c.nav.show $c.nav.prev $c.nav.next -side left -padx {0 4}
    pack $c.qview -in $c.nav -side left -padx {8 0}
    raise $c.qview
    label $c.bad -textvariable ::ElemImprint::badText -anchor w -justify left -wraplength 380
    grid $c.crit - -sticky w -pady {1 3}
    grid $c.nav - -sticky w -pady {1 1}
    grid $c.bad - -sticky w
    grid columnconfigure $c 1 -weight 1
    # no empty row: the error text takes room only when it says something
    trace remove variable ::ElemImprint::badText write ::ElemImprint::bad_row
    trace add variable ::ElemImprint::badText write ::ElemImprint::bad_row
    bad_row
    # criteria are checked again on Return or when the field is left, not at every key typed (traces of
    # an older version, still on the variables in a running session, are removed)
    foreach k {nearSrc maxAspect maxSkew minLen} {trace remove variable ::ElemImprint::opt($k) write ::ElemImprint::recheck}
    foreach e [list $c.asp $c.skew $c.len] {
        bind $e <Return> [list ::TestToolSession::run "Imprint" ::ElemImprint::criteria_changed]
        bind $e <FocusOut> [list ::TestToolSession::run "Imprint" ::ElemImprint::criteria_changed 0 0]
    }
    grid $c -row 2 -column 0 -columnspan 2 -sticky ew -pady {4 0}
    grid columnconfigure $W.body {0 1} -weight 1 -uniform half

    # Reset (light red) then Imprint (light green), on the right
    $W.foot configure -padx 8 -pady 5
    frame $W.foot.buttons
    button $W.foot.run -text "Imprint" -foreground black -disabledforeground #505050 -width 10 -background #A8DDB0 -activebackground #8FD19E -command [list ::TestToolSession::run "Imprint" ::ElemImprint::do_imprint]
    button $W.foot.reset -text "Reset" -width 8 -background #F2B8B5 -activebackground #E89E9A -command [list ::TestToolSession::run "Imprint" ::ElemImprint::reset]
    pack $W.foot.run $W.foot.reset -in $W.foot.buttons -side left -padx {0 6}
    pack $W.foot.disp -in $W.foot.buttons -side right
    # made before the buttons frame: raised, or that frame would hide it
    raise $W.foot.disp
    pack $W.foot.buttons -side top -fill x
    pack $W.foot -fill x
    # status row at the bottom, as the Material Manager: "Ready" or the progress bar with its caption,
    # then the last message (with the time an imprint took)
    frame $W.sep -height 1 -background #AFBAC2
    pack $W.sep -fill x
    frame $W.bar -padx 8 -pady 3
    label $W.bar.ready -text "Ready" -anchor w
    label $W.bar.task -textvariable ::ElemImprint::progressTask -foreground #555555
    if {[catch {hwtk::progressbar $W.bar.progress -mode determinate -length 110 -variable ::ElemImprint::progressValue}]} {
        ttk::progressbar $W.bar.progress -mode determinate -length 110 -variable ::ElemImprint::progressValue
    }
    label $W.bar.status -textvariable ::ElemImprint::status -anchor nw -justify left -wraplength 300
    grid $W.bar.ready -row 0 -column 0 -sticky nw -padx {0 12}
    grid $W.bar.status -row 0 -column 2 -sticky nw
    grid columnconfigure $W.bar 2 -weight 1
    pack $W.bar -fill x
    # B / N: previous / next error, except while typing in a field
    foreach {key step} {b -1 B -1 n 1 N 1} {
        bind $W <KeyPress-$key> [list ::ElemImprint::nav_key %W $step]
    }
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Imprint" ::ElemImprint::close]
    set status "Pick the target, then the source."
    # quality colors only while Quality check is ticked (off when the window opens)
    set opt(qview) 0
    refresh
    place_center
    wm deiconify $W
    keep_above_host
}

# Center over the HyperMesh main window on the monitor it is on, while withdrawn; negative screen
# coordinates kept (a monitor left of or above the primary one: the former max(x,0) moved the window
# to the primary monitor). In 2022.3 [wm frame .] is the HyperWorks top-level window: its Win32
# rectangle (twapi), the window kept inside the work area of that monitor; without twapi the area of ".".
proc ::ElemImprint::place_center {} {
    variable W
    update idletasks
    $W.bar.status configure -wraplength [expr {max(160,[winfo reqwidth $W.body]-70)}]
    update idletasks
    set w [winfo reqwidth $W]; set h [winfo reqheight $W]
    set l [winfo rootx .]; set t [winfo rooty .]
    set r [expr {$l+[winfo width .]}]; set b [expr {$t+[winfo height .]}]
    set work {}
    catch {
        package require twapi
        set host [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $host] l t r b
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $host]] -workarea]
    }
    set x [expr {($l+$r-$w)/2}]; set y [expr {($t+$b-$h)/2}]
    if {[llength $work] == 4} {
        lassign $work wl wt wr wb
        set x [expr {max($wl,min($x,$wr-$w))}]; set y [expr {max($wt,min($y,$wb-$h))}]
    }
    wm geometry $W +$x+$y
}

# HyperMesh main window as Win32 owner: above HyperMesh only.
proc ::ElemImprint::keep_above_host {} {
    variable W
    catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $W]}] HWND] -8 [expr {[wm frame .]}]
    }
}

if {![info exists ::ElemImprint_no_gui]} {
    ::ElemImprint::show
}
