# Marks, the native pick panel, and history recording are shared by the HyperMesh interpreter.
namespace eval ::TestToolSession {
    variable active ""
    variable reservedTool ""
    variable reservedWindow ""
    variable pauseReservation ""
    variable panelOpen 0
    variable cancelled 0
    variable pending ""
}

proc ::TestToolSession::owner {} {
    variable active; variable reservedTool; variable reservedWindow
    if {$active ne ""} {return $active}
    if {$reservedWindow ne "" && [winfo exists $reservedWindow]} {return $reservedTool}
    return ""
}

proc ::TestToolSession::reserve {tool window pause} {
    variable reservedTool $tool
    variable reservedWindow $window
    variable pauseReservation $pause
}

proc ::TestToolSession::yield_reservation {} {
    variable active; variable reservedTool; variable reservedWindow; variable pauseReservation
    if {$active ne "" || $pauseReservation eq ""} {return 0}
    if {[catch {run $reservedTool $pauseReservation} message]} {
        puts "Toolbox: $message"
        return 0
    }
    set reservedWindow ""
    return 1
}

proc ::TestToolSession::report {tool} {
    # Report inside the Tcl event loop without re-entering a native panel.
    puts "Toolbox: Finish or cancel the current operation in $tool before switching tools."
}

proc ::TestToolSession::cancelled {} {variable cancelled; return $cancelled}

proc ::TestToolSession::handoff {script} {
    variable panelOpen; variable cancelled; variable pending
    if {!$panelOpen} {return 0}
    set pending $script
    if {!$cancelled} {
        set cancelled 1
        if {[catch {hm_exitpanel}]} {set cancelled 0; set pending ""; return 0}
    }
    return 1
}

proc ::TestToolSession::panel {command args} {
    variable active; variable panelOpen; variable cancelled
    if {$active eq ""} {return [uplevel #0 [list $command {*}$args]]}
    if {$cancelled} {return -code error 0}
    set panelOpen 1
    set code [catch {uplevel #0 [list $command {*}$args]} value options]
    set panelOpen 0
    if {$cancelled} {
        switch -- $command {
            *createmarkpanel -
            *editmarkpanel {*clearmark {*}[lrange $args 0 1]}
            *createlistpanel -
            *createlistbypathpanel {*clearlist {*}[lrange $args 0 1]}
        }
        return -code error 0
    }
    if {$code} {return -options $options $value}
    return $value
}

proc ::TestToolSession::can_open {path} {
    set current [owner]
    if {$current eq ""} {return 1}
    if {[yield_reservation]} {return 1}
    if {![handoff [list *evaltclscript $path 0]]} {report $current}
    return 0
}

proc ::TestToolSession::run {tool script {allowControl 0} {allowHandoff 1}} {
    variable active; variable cancelled; variable pending
    set current [owner]
    if {$active ne ""} {
        if {$allowControl && $active eq $tool} {return [uplevel #0 $script]}
        if {$allowHandoff && $active ne $tool && [handoff [list ::TestToolSession::run $tool $script $allowControl]]} {return}
        if {$allowHandoff} {report $active}
        return
    }
    if {$current ne "" && $current ne $tool} {
        if {!$allowHandoff} {return}
        if {![yield_reservation]} {report $current; return}
    }
    set active $tool
    set code [catch {uplevel #0 $script} value options]
    set active ""
    set cancelled 0
    if {$pending ne ""} {
        after idle $pending
        set pending ""
    }
    if {$code} {return -options $options $value}
    return $value
}
