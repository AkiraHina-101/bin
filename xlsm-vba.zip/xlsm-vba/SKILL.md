---
name: xlsm-vba
description: Safely read, edit, compile and run VBA macros inside Excel workbooks (.xlsm, .xlsb, .xls, .xlam) on Windows. Use whenever the task involves VBA code, macros, modules, UserForm code or sheet event code in an Excel file - writing or fixing macros, debugging "Compile error" or "Run-time error", running a macro to test it, or exporting VBA to text. Captures the text and exact module/line of compile and run-time error dialogs, dismisses them automatically, and never touches the user's other open Excel windows. Dùng khi cần viết, sửa, biên dịch, chạy thử hoặc gỡ lỗi code VBA / macro trong file Excel.
---

# Làm việc với VBA trong file Excel (.xlsm / .xlsb / .xls / .xlam)

Mọi thao tác đọc – sửa – biên dịch – chạy VBA **phải đi qua** `scripts/xlvba.py` nằm trong thư mục của skill này.
Công cụ tự mở một tiến trình Excel riêng (ẩn), đọc và đóng mọi hộp thoại lỗi, trả kết quả dạng JSON
kèm **module / dòng / cột / đoạn code** của lỗi, rồi chỉ đóng đúng tiến trình nó đã mở.

Khi gọi, thay `scripts/xlvba.py` bằng **đường dẫn tuyệt đối** tới file đó trong thư mục skill (thư mục chứa SKILL.md này),
đặt trong dấu nháy kép. Đường dẫn workbook cũng nên là đường dẫn tuyệt đối trong nháy kép.

```
python scripts/xlvba.py export  <file.xlsm>                 # xuất code ra <file>_vba\*.bas|.cls|.frm (UTF-8)
python scripts/xlvba.py push    <file.xlsm> [--module M]    # lint -> nạp -> compile -> chỉ lưu khi compile sạch
python scripts/xlvba.py compile <file.xlsm>                 # chỉ biên dịch, báo lỗi kèm vị trí
python scripts/xlvba.py run     <file.xlsm> Module.Macro [tham số...] [--timeout 120] [--save] [--answer safe|accept]
python scripts/xlvba.py status                              # Excel nào của tool, Excel nào của người dùng
python scripts/xlvba.py cleanup                             # dọn Excel do tool mở bị kẹt (không đụng Excel người dùng)
```

Mã thoát: `0` ok · `1` lỗi môi trường · `2` lỗi lint/biên dịch · `3` lỗi run-time · `4` timeout.

---

## 1. Tuyệt đối không đụng vào Excel của người dùng

1. **CẤM** mọi lệnh kill theo tên: `taskkill /IM excel.exe`, `Stop-Process -Name EXCEL`, `Get-Process excel | Stop-Process`, `pkill excel`.
2. **CẤM** bám vào Excel đang chạy rồi đóng nó: không dùng `GetActiveObject`, `GetObject(, "Excel.Application")`,
   `win32com.client.Dispatch("Excel.Application")`, `xlwings.apps.active`, rồi gọi `.Quit()`, `Workbooks.Close`,
   hay lặp `For Each wb In Workbooks: wb.Close`.
3. Không tự viết script COM/PowerShell/VBScript riêng để mở Excel. Nếu `xlvba.py` thiếu chức năng, hãy **bổ sung vào
   `xlvba.py`** (dùng lại lớp `Session`), không viết đường tắt.
4. Nếu buộc phải kill: chỉ kill **đúng PID** mà `status` ghi `owner: xlvba-tool`, hoặc dùng `cleanup`.
5. Gặp lỗi `FILE_LOCKED` (file đang mở ở Excel của người dùng): **dừng lại và nhờ người dùng đóng file**. Không tự đóng,
   không kill, không copy file ra chỗ khác để làm lén rồi ghi đè.
6. Không sửa cài đặt bảo mật / registry của Office (Trust Center, `AccessVBOM`, `VBAWarnings`). Gặp `NO_VBOM_ACCESS`
   thì báo người dùng tự bật.
7. Gặp `PROJECT_LOCKED` (project VBA có mật khẩu): cả `export`, `push`, `compile`, `run` đều bị từ chối. Nhờ người dùng
   mở khoá và lưu lại. Không dò, không gỡ, không sửa nhị phân để vượt mật khẩu.

## 2. Vòng lặp làm việc bắt buộc

```
export  ->  sửa file trong <file>_vba\  ->  push  ->  (exit 0)  ->  run  ->  đọc JSON  ->  lặp lại
```

1. **Bắt đầu phiên luôn `export`** để có code mới nhất (người dùng có thể đã sửa trong VBE).
2. Chỉ sửa code trong thư mục `<file>_vba\` bằng công cụ sửa file thông thường. Không sửa trực tiếp trong workbook,
   không giải nén/sửa `vbaProject.bin`, không dùng openpyxl để ghi file có macro (sẽ hỏng/mất VBA).
3. `push` sau mỗi cụm thay đổi nhỏ. **Thay đổi nhỏ – push thường xuyên**: compile chỉ báo *lỗi đầu tiên*, nên sửa
   500 dòng một lần sẽ phải lặp rất nhiều vòng.
4. `push` thất bại (`exit 2`) ⇒ workbook **không được lưu**, file trên đĩa vẫn là bản cũ chạy được. Sửa đúng dòng
   được báo trong file nguồn rồi push lại. Không bao giờ `run` khi push/compile chưa sạch.
5. Gặp `CONFLICT` (code trong workbook khác với lần export gần nhất): người dùng đã sửa trong VBE. `export` lại hoặc hỏi
   người dùng. Chỉ dùng `--force` khi người dùng đồng ý ghi đè.
6. Mỗi lần push thành công có bản sao lưu ở `_backup\`. Không xoá thư mục này.

## 3. Đọc lỗi: lỗi ở đâu, lỗi gì

Không bao giờ đoán. Luôn đọc JSON mà công cụ in ra:

| Trường | Ý nghĩa |
|---|---|
| `lint_errors` | Lỗi bắt được trước khi vào Excel (ký tự Unicode, sót ``` , dòng quá dài…) – có `file:dòng` |
| `compile_error.message` | Nguyên văn hộp thoại "Compile error: …" |
| `compile_error.location` | `module`, `line`, `col`, `token` (từ bị bôi đen), `procedure`, `context` (±3 dòng, `>>` là dòng lỗi) |
| `runtime_error.message` | Nguyên văn "Run-time error 'N': …" |
| `runtime_error.location` | Dòng đang thực thi khi lỗi xảy ra (dòng vàng trong VBE) |
| `dialogs[]` | **Mọi** hộp thoại đã hiện ra (kể cả MsgBox của macro): `title`, `text`, `buttons`, `action` công cụ đã bấm |
| `stuck_windows` | Khi timeout: cửa sổ đang chờ người dùng (UserForm, InputBox, hộp chọn file…) |

- Số dòng trong `location` khớp với số dòng trong file `<file>_vba\<module>` (file không có header `Attribute`).
- Compile chỉ báo **một** lỗi mỗi lần. Sửa → push → đọc lỗi kế tiếp. Trước khi push lại, tự rà cùng kiểu lỗi ở chỗ khác.
- **Lỗi khối lệnh được báo ở dòng khác với chỗ sai.** Thiếu `End If` bên trong vòng `For` sẽ báo "Next without For" tại
  dòng `Next`; thiếu `Next` sẽ báo "For without Next" tại `End Sub`. Gặp các thông báo "X without Y" / "Expected End …"
  thì rà **ngược lên** trong cùng thủ tục (`procedure`) để tìm khối chưa đóng, đừng sửa dòng được chỉ.
- "Syntax error" trên một câu lệnh nhiều dòng (` _`) được báo ở **dòng đầu** của câu lệnh đó.
- Lỗi được ném lại bằng `Err.Raise` trong nhãn xử lý lỗi sẽ có `location` là dòng `Err.Raise`, không phải dòng gốc.
  Muốn biết dòng gốc: tạm bỏ `On Error` của thủ tục đó rồi `run` lại.
- Lỗi xảy ra **bên trong code của UserForm hoặc class** được báo ở dòng gọi nó trong module thường (ví dụ dòng
  `frmX.Show`), không phải dòng thật trong form. Thấy `location` trỏ vào `.Show` / lời gọi phương thức của class thì
  lỗi nằm trong `UserForm_Initialize`, `UserForm_Activate` hoặc phương thức đó – đọc code ở đấy.
- Lỗi trong thủ tục sự kiện của sheet (`Worksheet_Change`…) được báo đúng module sheet và đúng dòng. Sự kiện **có chạy**
  trong lúc `run`, nên macro ghi vào ô có thể kích hoạt code ở module sheet.
- Lỗi "ngay khi mo workbook" (chỉ gặp khi dùng `--fire-open`): lỗi nằm trong `Workbook_Open` / `Auto_Open`, macro được
  yêu cầu chưa hề chạy.
- `error: RUN_FAILED` kèm "ket thuc bat thuong": macro gọi `End`, hoặc truyền sai số lượng/kiểu tham số.
- "Macro dung o break mode": code còn lệnh `Stop` hoặc `Debug.Assert` sai – `location` chỉ đúng dòng đó.
- VBE **tự đổi hoa/thường** tên định danh trên toàn project (khai báo `Dim Fail` sẽ biến mọi nhãn `fail:` thành `Fail:`).
  Sau `export` thấy khác biệt chỉ về hoa/thường thì đó không phải ai sửa code; công cụ đã bỏ qua khác biệt này.
- `runtime_error` không có `location` (project bị khoá hoặc lỗi trong add-in): thêm ghi log theo mục 5 rồi chạy lại.
- Công cụ **đã tự đóng** hộp thoại. Nếu nghi còn Excel kẹt: `status` → `cleanup`. Không dùng SendKeys, không chụp màn hình để đọc lỗi.

## 4. Quy tắc viết VBA để ít lỗi cú pháp / biên dịch

1. Mọi module bắt đầu bằng `Option Explicit`; khai báo `Dim` cho **mọi** biến, mỗi biến một kiểu
   (`Dim a As Long, b As Long` – không viết `Dim a, b As Long`).
2. File nguồn chỉ chứa code. **Không** thêm `Attribute VB_Name…`, `VERSION 1.0 CLASS`, `BEGIN…END`, không để sót ``` markdown.
   Tên module = tên file. `.bas` = module thường, `.cls` = class / ThisWorkbook / Sheet, `.frm` = code của UserForm có sẵn.
3. **Chỉ dùng ký tự thuộc bảng mã ANSI của máy** trong code (kể cả chú thích và chuỗi). Tiếng Việt/Nhật có dấu sẽ thành `?`.
   Cần chuỗi Unicode: ghép bằng `ChrW(&H…)` hoặc đọc từ ô tính. Dùng `"` thẳng, không dùng “ ”.
4. Gán đối tượng phải có `Set`; gọi Sub không lấy kết quả thì **không** dùng ngoặc: `Foo a, b` hoặc `Call Foo(a, b)`
   (không viết `Foo(a, b)`).
5. Đóng đủ khối: `If…End If`, `For…Next`, `Do…Loop`, `With…End With`, `Select Case…End Select`, `Sub…End Sub`.
   `If` một dòng thì không có `End If`. VBA không có `Continue`, không có `+=`, không có `Try/Catch`, không có `Return x`
   (gán `TênHàm = x`).
6. Nối dòng bằng ` _` (có dấu cách phía trước), tối đa 24 lần mỗi câu lệnh, không đặt chú thích sau ` _`.
7. Dùng `Long` thay `Integer` (tránh tràn số với số dòng), `LongPtr` + `PtrSafe` cho `Declare` API trên Office 64-bit.
8. Ưu tiên late binding (`CreateObject("Scripting.Dictionary")`) để không phụ thuộc Tools > References.
   Thiếu reference sẽ gây "Can't find project or library" ở những chỗ không liên quan.
9. Không dùng `Select`/`Activate`/`ActiveSheet`/`Selection`; luôn chỉ rõ `ThisWorkbook.Worksheets("Tên").Range(...)`.
   Dùng `ThisWorkbook`, không dùng `ActiveWorkbook` hay `Workbooks(1)`.
10. Trong macro **không** gọi `Application.Quit`, không `Workbooks.Close` những workbook không do macro tự mở,
    không `End` trần, không để lại `Stop`. Nếu tắt `ScreenUpdating/EnableEvents/Calculation/DisplayAlerts` thì phải bật lại ở nhãn dọn dẹp.
11. Không đặt tên biến trùng (khác hoa/thường) với thuộc tính hay nhãn đã có (`value`, `name`, `count`, `fail`…),
    vì VBE sẽ đổi hoa/thường ở mọi module khác.
12. Không đặt tên macro trùng dạng địa chỉ ô (`Add2`, `ABC1`, `R1C1`…); khi `run` luôn ghi đủ `Module.Macro`.

## 5. Quy tắc để code chạy được không cần người ngồi bấm

1. Tách phần xử lý ra `Function`/`Sub` **Public nhận tham số, trả kết quả**; phần hỏi người dùng (`MsgBox`, `InputBox`,
   `GetOpenFilename`, `UserForm.Show`) chỉ nằm ở lớp ngoài cùng. Khi kiểm thử, `run` hàm lõi và truyền tham số trực tiếp.
2. Hộp thoại trong lúc `run` được trả lời tự động và ghi vào `dialogs[]`: mặc định `--answer safe` chọn Cancel/No trước;
   `--answer accept` chọn OK/Yes trước. UserForm / InputBox bị đóng ngay. Đọc `dialogs[]` để biết macro đã rẽ nhánh nào.
   UserForm hiện ra trong lúc `run` bị đóng ngay bằng nút X (code sau `.Show` vẫn chạy tiếp, `UserForm_Initialize` đã chạy),
   công cụ **không bấm được nút trên form**. Vì vậy logic của nút phải nằm trong `Sub` Public ở module thường để `run`
   trực tiếp; thủ tục `btn_Click` chỉ gọi sang đó. Công cụ chỉ sửa code của form có sẵn, không tạo form hay sửa bố cục.
3. Khi cần `On Error`, không nuốt lỗi (`On Error Resume Next` chỉ bao quanh đúng một lệnh rồi `On Error GoTo 0`).
   Mẫu chuẩn – ghi log rồi ném lỗi lại để công cụ bắt được:
   ```vb
   Public Sub DoWork()
       On Error GoTo Fail
       ' ... xu ly ...
       Exit Sub
   Fail:
       LogLine "DoWork failed: " & Err.Number & " " & Err.Description
       Err.Raise Err.Number, Err.Source, Err.Description
   End Sub
   ```
4. `Debug.Print` không đọc được từ bên ngoài. Muốn xem giá trị trung gian: trả về qua `Function`, hoặc ghi vào file log
   cạnh workbook (`Open ThisWorkbook.Path & "\vba_debug.log" For Append As #f`) rồi đọc file đó.
5. `run` mặc định **không lưu** workbook (dữ liệu macro thay đổi bị bỏ). Chỉ thêm `--save` khi người dùng muốn giữ kết quả.
   `Workbook_Open`/`Auto_Open` không chạy trừ khi thêm `--fire-open`.
6. Macro lâu hơn 120 giây: tăng `--timeout`. Gặp `TIMEOUT`: xem `stuck_windows` (đang chờ nhập liệu?) hoặc tìm vòng lặp vô hạn.

## 6. Trước khi báo "xong"

- [ ] `push` trả `ok: true`, `compiles: true`.
- [ ] Đã `run` ít nhất macro vừa sửa, `ok: true`, đã đọc `dialogs[]` và `return`.
- [ ] `status` không còn tiến trình `xlvba-tool` nào; các Excel `USER` vẫn nguyên.
- [ ] Báo cho người dùng: sửa module nào, đã chạy thử gì, kết quả ra sao, điều gì **chưa** kiểm chứng được
      (ví dụ nhánh cần người dùng chọn file).

## Yêu cầu môi trường

Đã kiểm chứng trên Excel 64-bit giao diện tiếng Anh. Với Office ngôn ngữ khác: nút của hộp thoại lỗi được nhận theo ID
nên vẫn đọc và đóng được, nhưng lệnh `Stop` có thể chỉ được báo là `TIMEOUT` (xem tiêu đề cửa sổ VBE trong `stuck_windows`).

Windows + Excel bản desktop, Python có `pywin32` (`python -m pip install pywin32`), và Excel đã bật
*File > Options > Trust Center > Trust Center Settings > Macro Settings > Trust access to the VBA project object model*.
