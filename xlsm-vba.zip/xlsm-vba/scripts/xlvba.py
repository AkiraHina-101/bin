#!/usr/bin/env python
"""xlvba - cong cu an toan de AI doc / sua / bien dich / chay VBA trong file Excel (.xlsm/.xlsb/.xls/.xlam).

Nguyen tac thiet ke:
  * Moi lenh tu mo MOT tien trinh Excel rieng (an), lam xong thi dong dung tien trinh do (theo PID).
    Khong bao gio dung den Excel / workbook cua nguoi dung.
  * Mot luong canh gac (watchdog) doc noi dung moi hop thoai cua tien trinh do, ghi lai, roi tu dong.
  * Loi bien dich va loi run-time deu duoc tra ve kem module / dong / cot / doan code.
  * Ket qua in ra stdout dang JSON. Ma thoat: 0 ok, 1 loi moi truong, 2 loi bien dich, 3 loi run-time, 4 timeout.

Lenh:  export | push | compile | run | status | cleanup      (xem `xlvba.py <lenh> -h`)
"""
import argparse, ctypes, datetime, gc, hashlib, json, os, re, shutil, sys, threading, time

try:
    import pythoncom, win32api, win32con, win32gui, win32process
    import win32com.client
except ImportError:
    print(json.dumps({"ok": False, "error": "ENV", "message": "Thieu pywin32. Cai: python -m pip install pywin32"}))
    sys.exit(1)

EXT = {1: ".bas", 2: ".cls", 3: ".frm", 100: ".cls"}
KIND = {1: "standard", 2: "class", 3: "form", 100: "document"}
RT_END, RT_DEBUG = 4800, 4801                       # ID nut End / Debug cua hop thoai run-time error (khong phu thuoc ngon ngu)
SAFE_ORDER = [2, 7, 1, 3, 6, 5, 4]                  # Cancel, No, OK, Abort, Yes, Ignore, Retry
ACCEPT_ORDER = [1, 6, 4, 5, 2, 7, 3]                # OK, Yes, Retry, Ignore, ...
BLOCKING_CLASSES = {"#32770", "ThunderDFrame", "ThunderXFrame", "bosa_sdm_XL9", "NUIDialog"}
OWNED = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "xlvba", "owned.json")
u32 = ctypes.windll.user32


class Fail(Exception):
    def __init__(self, code, message, exit_code=1, **extra):
        super().__init__(message)
        self.payload = dict(ok=False, error=code, message=message, **extra)
        self.exit_code = exit_code


# ---------------------------------------------------------------- tien trinh
def excel_pids():
    out = {}
    def cb(h, _):
        try:
            if win32gui.GetClassName(h) == "XLMAIN":
                _, pid = win32process.GetWindowThreadProcessId(h)
                out.setdefault(pid, []).append(win_text(h))
        except Exception:
            pass
        return True
    win32gui.EnumWindows(cb, None)
    return out


def proc_start(pid):
    try:
        h = win32api.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    except Exception:
        return None
    try:
        return str(win32process.GetProcessTimes(h)["CreationTime"])
    finally:
        win32api.CloseHandle(h)


def kill_pid(pid):
    try:
        h = win32api.OpenProcess(0x0001, False, pid)
        win32api.TerminateProcess(h, 1)
        win32api.CloseHandle(h)
        return True
    except Exception:
        return False


def owned_load():
    try:
        with open(OWNED, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def owned_save(d):
    os.makedirs(os.path.dirname(OWNED), exist_ok=True)
    with open(OWNED, "w", encoding="utf-8") as f:
        json.dump(d, f)


# ---------------------------------------------------------------- cua so / hop thoai
def win_text(h):
    buf = ctypes.create_unicode_buffer(4096)
    res = ctypes.c_size_t()
    u32.SendMessageTimeoutW(h, 0x000D, 4096, buf, 2, 500, ctypes.byref(res))
    return buf.value


def describe(h):
    texts, buttons = [], []
    def cb(c, _):
        try:
            cls, t = win32gui.GetClassName(c), win_text(c)
            if cls == "Button" and t:
                buttons.append({"id": win32gui.GetDlgCtrlID(c), "text": t.replace("&", ""),
                                "enabled": bool(win32gui.IsWindowEnabled(c))})
            elif cls in ("Static", "Edit", "RichEdit20W") and t.strip():
                texts.append(t.strip())
        except Exception:
            pass
        return True
    try:
        win32gui.EnumChildWindows(h, cb, None)
    except Exception:
        pass
    return {"class": win32gui.GetClassName(h), "title": win_text(h),
            "text": re.sub(r"\s*\n\s*", " | ", "\n".join(texts)), "buttons": buttons}


def blocking_windows(pid):
    out = []
    def cb(h, _):
        try:
            if win32gui.IsWindowVisible(h) and win32process.GetWindowThreadProcessId(h)[1] == pid \
                    and win32gui.GetClassName(h) in BLOCKING_CLASSES:
                out.append(h)
        except Exception:
            pass
        return True
    win32gui.EnumWindows(cb, None)
    return out


def click(dlg, ctrl_id):
    win32gui.PostMessage(dlg, win32con.WM_COMMAND, ctrl_id, win32gui.GetDlgItem(dlg, ctrl_id))


def location(vbe, with_context=True):
    """Vi tri con tro cua VBE: sau loi bien dich hoac o break mode, day chinh la dong loi."""
    cp = vbe.ActiveCodePane
    if cp is None:
        return None
    l1, c1, l2, c2 = cp.GetSelection()
    cm = cp.CodeModule
    loc = {"module": cm.Parent.Name, "line": l1, "col": c1, "code": cm.Lines(l1, 1) if cm.CountOfLines >= l1 else ""}
    if (l2, c2) != (l1, c1) and l2 == l1:
        loc["token"] = loc["code"][c1 - 1:c2 - 1]
    try:
        loc["procedure"] = cm.ProcOfLine(l1, 0)[0]
    except Exception:
        pass
    if with_context:
        a, b = max(1, l1 - 3), min(cm.CountOfLines, l1 + 3)
        loc["context"] = ["%s%4d| %s" % (">>" if n == l1 else "  ", n, cm.Lines(n, 1)) for n in range(a, b + 1)]
    return loc


class Watchdog(threading.Thread):
    """Doc + dong moi hop thoai cua DUNG tien trinh Excel do tool mo. Het gio thi kill dung PID do."""

    def __init__(self, pid, answer):
        super().__init__(daemon=True)
        self.pid, self.order = pid, (ACCEPT_ORDER if answer == "accept" else SAFE_ORDER)
        self.dialogs, self.runtime_error, self.timed_out, self.stuck = [], None, False, []
        self.deadline, self.vbe_stream = None, None
        self._stop_evt, self._seen = threading.Event(), {}

    def arm(self, seconds):
        self.deadline = time.time() + seconds if seconds else None

    def stop(self):
        self._stop_evt.set()

    def run(self):
        pythoncom.CoInitialize()
        while not self._stop_evt.is_set():
            try:
                for h in blocking_windows(self.pid):
                    if time.time() - self._seen.get(h, 0) > 3:      # xu ly lai neu 3s sau van con
                        self._seen[h] = time.time()
                        self.handle(h)
                if self.vbe_stream is not None and not self.runtime_error:
                    h = self.break_window()
                    if h and time.time() - self._seen.get(h, 0) > 3:   # Stop / breakpoint: break mode khong co hop thoai
                        self._seen[h] = time.time()
                        err = {"message": "Macro dung o break mode ma khong co hop thoai loi: lenh Stop, Debug.Assert sai, hoac breakpoint."}
                        loc = self.read_break_location()
                        if loc:
                            err["location"] = loc
                        self.runtime_error = err
            except Exception as e:
                self.dialogs.append({"kind": "watchdog-error", "text": repr(e)})
            if self.deadline and time.time() > self.deadline:
                self.timed_out = True
                self.stuck = [describe(h) for h in blocking_windows(self.pid)]
                self.stuck += [{"class": "VBE", "title": t} for t in self.vbe_titles()]
                kill_pid(self.pid)
                return
            time.sleep(0.15)

    def vbe_titles(self, want_hwnd=False):
        out = []
        def cb(h, _):
            try:
                if win32gui.IsWindowVisible(h) and win32process.GetWindowThreadProcessId(h)[1] == self.pid                         and win32gui.GetClassName(h) == "wndclass_desked_gsk":
                    out.append((h, win_text(h)))
            except Exception:
                pass
            return True
        win32gui.EnumWindows(cb, None)
        return out if want_hwnd else [t for _, t in out]

    def break_window(self):
        for h, t in self.vbe_titles(True):
            if "[break]" in t or "[中断]" in t:
                return h
        return None

    def handle(self, h):
        d = describe(h)
        ids = {b["id"]: b for b in d["buttons"]}
        if d["class"] != "#32770":
            d.update(kind="window", action="WM_CLOSE")           # UserForm / hop thoai Excel
            self.dialogs.append(d)
            win32gui.PostMessage(h, win32con.WM_CLOSE, 0, 0)
            return
        if RT_END in ids:                                        # hop thoai run-time error cua VBA
            d["kind"] = "runtime-error"
            self.dialogs.append(d)
            err = {"message": d["text"]}
            if ids.get(RT_DEBUG, {}).get("enabled") and self.vbe_stream is not None:
                d["action"] = "Debug -> doc dong loi -> Reset"
                click(h, RT_DEBUG)
                loc = self.read_break_location()
                if loc:
                    err["location"] = loc
            else:
                d["action"] = "End"
                click(h, RT_END)
            self.runtime_error = self.runtime_error or err
            return
        d["kind"] = "dialog"
        pick = next((i for i in self.order if i in ids and ids[i]["enabled"]), None)
        if pick is None and d["buttons"]:
            pick = d["buttons"][0]["id"]
        self.dialogs.append(d)
        if pick is None:
            d["action"] = "WM_CLOSE"
            win32gui.PostMessage(h, win32con.WM_CLOSE, 0, 0)
        else:
            d["action"] = "click: " + ids[pick]["text"]
            click(h, pick)

    def read_break_location(self):
        vbe, loc = None, None
        for _ in range(25):                                      # doi Excel vao break mode
            time.sleep(0.2)
            try:
                if vbe is None:
                    vbe = win32com.client.Dispatch(
                        pythoncom.CoGetInterfaceAndReleaseStream(self.vbe_stream, pythoncom.IID_IDispatch))
                    self.vbe_stream = None
                loc = location(vbe)
                break
            except Exception:
                continue
        for _ in range(25):                                      # Run > Reset de thoat break mode
            try:
                if vbe is not None:
                    r = vbe.CommandBars.FindControl(1, 228)
                    if r.Enabled:
                        r.Execute()
                    break
            except Exception:
                time.sleep(0.2)
        return loc


# ---------------------------------------------------------------- phien lam viec voi Excel
class Session:
    def __init__(self, path, run_macros=False, timeout=120, answer="safe", fire_open=False):
        self.path = os.path.abspath(path)
        self.run_macros, self.timeout, self.answer, self.fire_open = run_macros, timeout, answer, fire_open
        self.xl = self.wb = self.wd = self.pid = None

    def __enter__(self):
        try:
            return self._enter()
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def _enter(self):
        p = self.path
        if not os.path.isfile(p):
            raise Fail("NOT_FOUND", "Khong tim thay file: " + p)
        if os.path.splitext(p)[1].lower() not in (".xlsm", ".xlsb", ".xls", ".xlam", ".xltm"):
            raise Fail("BAD_TYPE", "File khong chua duoc macro (can .xlsm/.xlsb/.xls/.xlam): " + p)
        try:
            with open(p, "r+b"):
                pass
        except OSError:
            raise Fail("FILE_LOCKED", "File dang mo o Excel khac (hoac chi-doc). KHONG tu dong/kill Excel do. "
                       "Hay nho nguoi dung dong file nay roi chay lai.", file=p)
        before = set(excel_pids())
        pythoncom.CoInitialize()
        self.xl = xl = win32com.client.DispatchEx("Excel.Application")
        self.pid = win32process.GetWindowThreadProcessId(xl.Hwnd)[1]
        if self.pid in before:                                   # COM tra ve Excel cua nguoi dung -> buong ra, khong Quit
            self.xl = None
            raise Fail("SHARED_INSTANCE", "Khong tao duoc tien trinh Excel rieng; dung lai de khong anh huong Excel dang mo.")
        owned = owned_load()
        owned[str(self.pid)] = proc_start(self.pid)
        owned_save(owned)
        self.wd = Watchdog(self.pid, self.answer)
        self.wd.arm(self.timeout + 60)
        if self.run_macros:
            self.wd.vbe_stream = pythoncom.CoMarshalInterThreadInterfaceInStream(pythoncom.IID_IDispatch, xl.VBE._oleobj_)
        self.wd.start()
        xl.Visible = False
        xl.DisplayAlerts = False
        xl.AskToUpdateLinks = False
        xl.EnableEvents = bool(self.fire_open)
        xl.AutomationSecurity = 1 if self.run_macros else 3      # 3 = khong chay macro nao khi chi sua code
        self.wb = xl.Workbooks.Open(p, UpdateLinks=0, AddToMru=False)
        if self.wb.ReadOnly:
            raise Fail("READ_ONLY", "Workbook mo ra o che do chi-doc; khong the luu.", file=p)
        try:
            self.vbp = self.wb.VBProject
            locked = self.vbp.Protection == 1
        except Exception:
            raise Fail("NO_VBOM_ACCESS", "Excel chua bat 'Trust access to the VBA project object model' "
                       "(File > Options > Trust Center > Macro Settings). Nguoi dung phai tu bat; AI khong duoc sua registry.")
        if locked:
            raise Fail("PROJECT_LOCKED", "VBA project co mat khau (Lock project for viewing). Nho nguoi dung mo khoa "
                       "(VBE > Tools > VBAProject Properties > Protection) roi luu lai; khong tim cach vuot mat khau.", file=p)
        self.vbe = xl.VBE
        return self

    def __exit__(self, *exc):
        pid, wd = self.pid, self.wd
        try:                                                     # nha stream chua dung, neu khong Excel se khong thoat
            if wd is not None and wd.vbe_stream is not None:
                st, wd.vbe_stream = wd.vbe_stream, None
                pythoncom.CoGetInterfaceAndReleaseStream(st, pythoncom.IID_IDispatch)
        except Exception:
            pass
        for step in ("close", "quit"):
            try:
                if step == "close" and self.wb is not None:
                    self.wb.Close(False)
                if step == "quit" and self.xl is not None:
                    self.xl.Quit()
            except Exception:
                pass
        self.vbp = self.vbe = self.wb = self.xl = None
        gc.collect()
        if pid:
            for _ in range(20):
                if proc_start(pid) is None:
                    break
                time.sleep(0.2)
            else:
                kill_pid(pid)                                    # chi kill PID do chinh tool tao ra
            owned = owned_load()
            owned.pop(str(pid), None)
            owned_save(owned)
        if wd:
            wd.stop()
        return False

    # -- code
    def components(self):
        return {c.Name: c for c in self.vbp.VBComponents}

    @staticmethod
    def code_of(comp):
        cm = comp.CodeModule
        return cm.Lines(1, cm.CountOfLines) if cm.CountOfLines else ""

    def compile(self):
        """Debug > Compile VBAProject. Tra ve None neu sach, nguoc lai dict loi kem vi tri."""
        try:
            self.vbe.ActiveVBProject = self.vbp
        except Exception:
            pass
        ctl = self.vbe.CommandBars.FindControl(1, 578)
        if not ctl.Enabled:
            return None
        n = len(self.wd.dialogs)
        ctl.Execute()                                            # neu loi: hop thoai hien ra, watchdog doc + dong
        new = []
        for _ in range(8):                                       # Execute co the tra ve truoc khi hop thoai kip hien
            time.sleep(0.25)
            still = self.vbe.CommandBars.FindControl(1, 578).Enabled   # bi chan cho toi khi hop thoai duoc dong
            new = [d for d in self.wd.dialogs[n:] if d.get("kind") == "dialog"]
            if new or not still:
                break
        if not new and not still:
            return None
        err = {"message": new[0]["text"] if new else "Compile that bai (khong doc duoc hop thoai)"}
        try:
            err["location"] = location(self.vbe)
        except Exception:
            pass
        return err


def norm(text):
    return text.replace("\r\n", "\n").replace("\r", "\n").rstrip("\n")


def sha(text):
    return hashlib.sha1(norm(text).encode("utf-8")).hexdigest()[:16]


def sha_ci(text):
    """Hash bo qua hoa/thuong ben ngoai chuoi "...": VBE tu doi hoa-thuong ten bien tren toan project,
    khong coi do la thay doi. Noi dung trong chuoi van phan biet hoa/thuong."""
    parts = norm(text).split('"')
    return sha('"'.join(x if k % 2 else x.lower() for k, x in enumerate(parts)))


def src_dir(args):
    return os.path.abspath(args.src) if args.src else os.path.splitext(os.path.abspath(args.workbook))[0] + "_vba"


def manifest_path(d):
    return os.path.join(d, "_manifest.json")


def load_manifest(d):
    try:
        with open(manifest_path(d), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_manifest(d, m):
    with open(manifest_path(d), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=1, ensure_ascii=False)


# ---------------------------------------------------------------- kiem tra tinh truoc khi nap
def ansi_ok(ch):
    try:
        return ch.encode("mbcs", "strict").decode("mbcs") == ch
    except UnicodeError:
        return False


def lint(name, text):
    """Tra ve (code_sach, warnings, errors). Bat cac loi AI hay mac truoc khi dung den Excel."""
    warns, errs, out, depth, head = [], [], [], 0, True
    for i, line in enumerate(norm(text).lstrip("﻿").split("\n"), 1):
        s = line.strip()
        if head:                                                 # bo header cua file .bas/.cls/.frm export
            if depth:
                depth += bool(re.match(r"(?i)begin\b", s)) - (s.upper() == "END")
                continue
            if re.match(r"(?i)version \d", s) or re.match(r"(?i)attribute vb_", s) or s == "":
                if s:
                    warns.append("%s:%d bo dong header '%s'" % (name, i, s[:40]))
                continue
            if re.match(r"(?i)begin\b", s):
                depth = 1
                continue
            head = False
        if re.match(r"(?i)attribute \w+(\.\w+)? *=", s):
            warns.append("%s:%d bo dong Attribute (khong hop le trong cua so code)" % (name, i))
            continue
        if s.startswith("```"):
            errs.append("%s:%d con sot dau ``` cua markdown" % (name, i))
        if len(line) > 1023:
            errs.append("%s:%d dong dai qua 1023 ky tu" % (name, i))
        bad = [(k, ch) for k, ch in enumerate(line, 1) if ord(ch) > 127 and not ansi_ok(ch)]
        if bad:
            errs.append("%s:%d cot %d: ky tu %s khong thuoc bang ma ANSI cua may, VBA se bien thanh '?'. Dung ChrW(&H%04X) "
                        "hoac doc chuoi tu o tinh." % (name, i, bad[0][0], " ".join(sorted({c for _, c in bad})), ord(bad[0][1])))
        if re.search("[“”‘’]", line.split("'")[0]):
            warns.append("%s:%d co dau nhay cong (smart quote) - VBA chi nhan \" thang" % (name, i))
        out.append(line)
    body = "\n".join(out).strip("\n")
    if body and not re.search(r"(?im)^\s*Option\s+Explicit\b", body):
        warns.append("%s: thieu Option Explicit" % name)
    cont = max((len(m.group(0).split("\n")) - 1 for m in re.finditer(r"(?:[^\n]* _\n)+", body + "\n")), default=0)
    if cont > 24:
        errs.append("%s: mot cau lenh co %d dau noi dong ' _' (toi da 24)" % (name, cont))
    return body.replace("\n", "\r\n"), warns, errs


# ---------------------------------------------------------------- cac lenh
def cmd_export(args):
    d = src_dir(args)
    os.makedirs(d, exist_ok=True)
    with Session(args.workbook, timeout=60) as s:
        man, mods = {}, []
        for name, comp in s.components().items():
            code, t = s.code_of(comp), comp.Type
            fn = name + EXT.get(t, ".bas")
            if code.strip() or t != 100 or os.path.exists(os.path.join(d, fn)):
                with open(os.path.join(d, fn), "w", encoding="utf-8", newline="") as f:
                    f.write(norm(code).replace("\n", "\r\n") + "\r\n")
            man[name] = {"type": KIND.get(t, str(t)), "file": fn, "sha": sha_ci(code)}
            mods.append({"module": name, "type": KIND.get(t, str(t)), "lines": comp.CodeModule.CountOfLines})
        save_manifest(d, man)
        err = s.compile()
        return {"ok": True, "src": d, "modules": mods, "compiles": err is None, "compile_error": err, "dialogs": s.wd.dialogs}


def cmd_push(args):
    d = src_dir(args)
    if not os.path.isdir(d):
        raise Fail("NO_SRC", "Chua co thu muc code %s. Chay `export` truoc." % d)
    files = {}
    for fn in sorted(os.listdir(d)):
        stem, ext = os.path.splitext(fn)
        if ext.lower() in (".bas", ".cls", ".frm") and (not args.module or stem in args.module):
            files[stem] = os.path.join(d, fn)
    missing = [m for m in (args.module or []) if m not in files]
    if missing:
        raise Fail("NO_FILE", "Khong thay file nguon cho module: " + ", ".join(missing))
    warns, errs, clean = [], [], {}
    for name, fp in files.items():
        with open(fp, encoding="utf-8-sig") as f:
            clean[name], w, e = lint(os.path.basename(fp), f.read())
        warns += w
        errs += e
    if errs:
        raise Fail("LINT", "Code bi chan truoc khi nap vao Excel. Sua cac loi nay roi push lai.", exit_code=2,
                   lint_errors=errs, warnings=warns)
    man = load_manifest(d)
    with Session(args.workbook, timeout=90) as s:
        comps, changed, conflicts = s.components(), [], []
        for name, code in clean.items():
            if name in comps:
                cur = s.code_of(comps[name])
                if sha_ci(cur) == sha_ci(code):
                    continue
                if not args.force and name in man and man[name]["sha"] != sha_ci(cur):
                    conflicts.append(name)
                changed.append(name)
            else:
                changed.append(name)
        if conflicts:
            raise Fail("CONFLICT", "Code trong workbook da bi sua ngoai (trong VBE) ke tu lan export/push gan nhat: %s. "
                       "Chay `export` de lay ban moi (se ghi de file nguon) hoac hoi nguoi dung; chi dung --force khi da duoc dong y."
                       % ", ".join(conflicts), modules=conflicts)
        removed = []
        if args.prune and not args.module:
            for name, comp in comps.items():
                if comp.Type in (1, 2) and name not in clean:
                    s.vbp.VBComponents.Remove(comp)
                    removed.append(name)
        for name in changed:
            comp = comps.get(name)
            if comp is None:
                ext = os.path.splitext(files[name])[1].lower()
                if ext == ".frm":
                    raise Fail("NO_FORM", "UserForm '%s' chua ton tai; tool chi sua code cua form co san." % name)
                comp = s.vbp.VBComponents.Add(1 if ext == ".bas" else 2)
                comp.Name = name
            cm = comp.CodeModule
            if cm.CountOfLines:
                cm.DeleteLines(1, cm.CountOfLines)
            if clean[name]:
                cm.AddFromString(clean[name])
        res = {"changed": changed, "removed": removed, "warnings": warns}
        err = s.compile()
        if err:
            raise Fail("COMPILE", "Loi bien dich - workbook KHONG duoc luu (file tren dia van la ban cu chay duoc). "
                       "Sua dung dong duoc chi ra trong file nguon roi push lai.", exit_code=2,
                       compile_error=err, saved=False, dialogs=s.wd.dialogs, **res)
        if changed or removed:
            bdir = os.path.join(os.path.dirname(s.path), "_backup")
            os.makedirs(bdir, exist_ok=True)
            base, ext = os.path.splitext(os.path.basename(s.path))
            bk = os.path.join(bdir, "%s.%s%s" % (base, datetime.datetime.now().strftime("%Y%m%d-%H%M%S"), ext))
            shutil.copy2(s.path, bk)
            for old in sorted(f for f in os.listdir(bdir) if f.startswith(base + "."))[:-10]:
                os.remove(os.path.join(bdir, old))
            s.wb.Save()
            res["backup"] = bk
        for name, comp in s.components().items():
            if name in clean or name not in man:
                man[name] = {"type": KIND.get(comp.Type, "?"), "file": name + EXT.get(comp.Type, ".bas"), "sha": sha_ci(s.code_of(comp))}
        for name in removed:
            man.pop(name, None)
        save_manifest(d, man)
        return dict(ok=True, saved=bool(changed or removed), compiles=True, dialogs=s.wd.dialogs, **res)


def cmd_compile(args):
    with Session(args.workbook, timeout=60) as s:
        err = s.compile()
        if err:
            raise Fail("COMPILE", "Loi bien dich.", exit_code=2, compile_error=err, dialogs=s.wd.dialogs)
        return {"ok": True, "compiles": True, "dialogs": s.wd.dialogs}


def parse_arg(a):
    try:
        return json.loads(a)
    except Exception:
        return a


def jsonable(v):
    try:
        json.dumps(v)
        return v
    except Exception:
        if isinstance(v, (tuple, list)):
            return [jsonable(x) for x in v]
        return str(v)


def cmd_run(args):
    with Session(args.workbook, run_macros=True, timeout=args.timeout, answer=args.answer, fire_open=args.fire_open) as s:
        wd = s.wd
        if wd.runtime_error:
            raise Fail("RUNTIME", "Loi run-time ngay khi mo workbook (Workbook_Open / Auto_Open), chua chay toi macro %s." % args.macro,
                       exit_code=3, runtime_error=wd.runtime_error, dialogs=wd.dialogs, saved=False)
        err = s.compile()
        if err:
            raise Fail("COMPILE", "Khong chay: project chua bien dich duoc. Sua loi bien dich truoc.", exit_code=2,
                       compile_error=err, dialogs=wd.dialogs)
        s.xl.EnableEvents = True
        if wd.vbe_stream is None:
            wd.vbe_stream = pythoncom.CoMarshalInterThreadInterfaceInStream(pythoncom.IID_IDispatch, s.vbe._oleobj_)
        wd.arm(args.timeout)
        macro = args.macro
        if "!" not in macro:
            if "." not in macro:                                 # ten nhu Add2/ABC1 trung dia chi o -> phai kem ten module
                pat = re.compile(r"(?im)^\s*(?:Public\s+)?(?:Static\s+)?(?:Sub|Function)\s+%s\b" % re.escape(macro))
                hits = [n for n, c in s.components().items() if c.Type == 1 and pat.search(s.code_of(c))]
                if len(hits) == 1:
                    macro = hits[0] + "." + macro
            macro = "'%s'!%s" % (s.wb.Name.replace("'", "''"), macro)
        t0, value, com_err = time.time(), None, None
        try:
            value = s.xl.Run(macro, *[parse_arg(a) for a in args.args])
        except pythoncom.com_error as e:
            com_err = e
        secs = round(time.time() - t0, 2)
        if wd.timed_out:
            raise Fail("TIMEOUT", "Macro chay qua %ss -> da kill dung tien trinh Excel cua tool (PID %s). Kha nang: vong lap vo han, "
                       "hoac cua so dang cho nhap lieu (xem 'stuck_windows')." % (args.timeout, s.pid), exit_code=4,
                       stuck_windows=wd.stuck, dialogs=wd.dialogs, seconds=secs)
        wd.arm(60)
        time.sleep(0.3)
        if wd.runtime_error:
            raise Fail("RUNTIME", "Loi run-time khi chay %s." % args.macro, exit_code=3, runtime_error=wd.runtime_error,
                       dialogs=wd.dialogs, saved=False, seconds=secs)
        if com_err is not None:
            info = com_err.excepinfo[2] if com_err.excepinfo and com_err.excepinfo[2] else str(com_err)
            if "annot run the macro" in info:
                msg = "Excel khong tim thay macro: %s Kiem tra ten: phai la Sub/Function Public trong module thuong, ghi dang Module.Macro." % info
            else:
                msg = ("Macro ket thuc bat thuong ma khong co hop thoai loi (thuong do lenh End, hoac sai so luong/kieu tham so "
                       "truyen vao). Chi tiet COM: %s" % info)
            raise Fail("RUN_FAILED", msg, exit_code=3, dialogs=wd.dialogs, seconds=secs)
        saved = False
        if args.save:
            s.wb.Save()
            saved = True
        return {"ok": True, "macro": args.macro, "return": jsonable(value), "seconds": secs, "saved": saved, "dialogs": wd.dialogs}


def cmd_status(args):
    owned = owned_load()
    rows = [{"pid": pid, "windows": titles, "owner": "xlvba-tool" if owned.get(str(pid)) == proc_start(pid) else "USER - khong duoc dung"}
            for pid, titles in excel_pids().items()]
    return {"ok": True, "excel_processes": rows}


def cmd_cleanup(args):
    owned, killed = owned_load(), []
    for pid, started in list(owned.items()):
        if started and proc_start(int(pid)) == started and kill_pid(int(pid)):
            killed.append(int(pid))
        owned.pop(pid)
    owned_save(owned)
    return {"ok": True, "killed_tool_instances": killed, "note": "Chi kill Excel do tool tao ra va bi ket lai."}


def main():
    for st in (sys.stdout, sys.stderr):
        st.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def wbcmd(name, fn, hlp, src=False):
        p = sub.add_parser(name, help=hlp)
        p.add_argument("workbook")
        if src:
            p.add_argument("--src", help="thu muc code (mac dinh: <ten workbook>_vba canh file)")
        p.set_defaults(fn=fn)
        return p

    wbcmd("export", cmd_export, "Xuat code moi module ra file UTF-8 de doc/sua", src=True)
    p = wbcmd("push", cmd_push, "Nap file nguon vao workbook -> compile -> chi luu khi compile sach", src=True)
    p.add_argument("--module", action="append", help="chi nap module nay (lap lai duoc)")
    p.add_argument("--prune", action="store_true", help="xoa module thuong/class khong con file nguon")
    p.add_argument("--force", action="store_true", help="ghi de ca khi code trong workbook da bi sua ngoai")
    wbcmd("compile", cmd_compile, "Chi bien dich va bao loi kem vi tri")
    p = wbcmd("run", cmd_run, "Bien dich roi chay 1 macro; bat loi run-time kem dong loi")
    p.add_argument("macro", help="Ten Sub/Function, vd Module1.Main")
    p.add_argument("args", nargs="*", help="tham so (so/true/false/chuoi; hoac JSON)")
    p.add_argument("--timeout", type=int, default=120, help="giay (mac dinh 120)")
    p.add_argument("--save", action="store_true", help="luu workbook sau khi macro chay xong khong loi")
    p.add_argument("--answer", choices=["safe", "accept"], default="safe",
                   help="cach tra loi MsgBox: safe = Cancel/No truoc (mac dinh), accept = OK/Yes truoc")
    p.add_argument("--fire-open", action="store_true", help="cho Workbook_Open/Auto_Open chay khi mo file")
    sub.add_parser("status", help="Liet ke tien trinh Excel (cua tool / cua nguoi dung)").set_defaults(fn=cmd_status)
    sub.add_parser("cleanup", help="Don Excel do tool tao ra bi ket (khong dung Excel nguoi dung)").set_defaults(fn=cmd_cleanup)
    args = ap.parse_args()
    try:
        out, code = args.fn(args), 0
    except Fail as f:
        out, code = f.payload, f.exit_code
    except pythoncom.com_error as e:
        info = e.excepinfo[2] if e.excepinfo and e.excepinfo[2] else str(e)
        out, code = {"ok": False, "error": "COM", "message": str(info)}, 1
    print(json.dumps(out, ensure_ascii=False, indent=1))
    sys.exit(code)


if __name__ == "__main__":
    main()
