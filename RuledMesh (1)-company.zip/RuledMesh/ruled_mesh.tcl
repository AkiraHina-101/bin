# HyperMesh 2022.3 / Nastran. Fill or bridge shell edges on a local support surface.
source [file join [file dirname [info script]] paths.tcl]
source [file join [file dirname [info script]] selection.tcl]
source [file join [file dirname [info script]] patch_surface.tcl]
source [file join [file dirname [info script]] constrained_patch.tcl]

namespace eval ::RuledMesh {
    variable window .ruledMesh
    variable busy
    if {![info exists busy]} {set busy 0}
    variable path
    variable model
    variable count
    variable extraLoops
    if {![info exists extraLoops]} {set extraLoops {}}
    variable edgeElements
    if {![array exists path]} {array set path {A {} B {}}}
    if {![array exists model]} {array set model {A {} B {}}}
    if {![array exists count]} {array set count {A "0 nodes" B "0 nodes"}}
    if {![array exists edgeElements]} {array set edgeElements {A {} B {}}}
    variable previewElements
    variable savedElementMark
    variable savedNodeMark
    variable circlePreviewNodes
    if {![info exists circlePreviewNodes]} {set circlePreviewNodes {}}
    variable circlePreviewHistory
    if {![info exists circlePreviewHistory]} {set circlePreviewHistory {}}
    variable lastBridge
    if {![info exists lastBridge]} {set lastBridge {}}
    if {![info exists previewElements]} {set previewElements {}}
    variable previewModel
    variable previewNodes
    if {![info exists previewNodes]} {set previewNodes {}}
    if {![info exists previewModel]} {set previewModel {}}
    variable closed 1
    variable pickMode
    if {![array exists pickMode]} {array set pickMode {A edge B edge}}
    variable size 10.0
    variable elementStyle
    if {![info exists elementStyle]} {set elementStyle R-trias}
    variable secondOrder
    if {![info exists secondOrder]} {set secondOrder 0}
    variable lastCircleCount
    if {![info exists lastCircleCount]} {set lastCircleCount {}}
    variable status Ready
    variable checkSpec {
        aspect        "Max aspect"     above
        skew          "Max skew"       above
        minlength     "Min length"     below
        jacobian      "Min Jacobian"   below
        mininterangle "Min tria angle" below
        maxinterangle "Max tria angle" above
    }
}

proc ::RuledMesh::coordinates {ids} {
    set result {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set batch [lrange $ids $i $i+1023]
        foreach axis {x y z} {
            set $axis [hm_getvalue nodes user_ids=$batch dataname=global$axis]
            if {[llength [set $axis]] != [llength $batch]} {error "Some selected nodes no longer exist."}
        }
        foreach id $batch px $x py $y pz $z {dict set result $id [list $px $py $pz]}
    }
    return $result
}

proc ::RuledMesh::tria_rows {ids {style 3}} {
    if {![llength $ids]} {error "HyperMesh did not create a mesh for this patch."}
    set rows {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set batch [lrange $ids $i $i+1023]
        set configs [hm_getvalue elems user_ids=$batch dataname=config]
        set connectivity [hm_getvalue elems user_ids=$batch dataname=nodes]
        if {[llength $configs] != [llength $batch] || [llength $connectivity] != [llength $batch]} {
            error "HyperMesh did not return all generated elements."
        }
        foreach cfg $configs nodes $connectivity {
            if {$cfg == 103 && [llength $nodes] == 3 && $style != 4} {
                lappend rows $nodes
            } elseif {$cfg == 104 && [llength $nodes] == 4 && $style in {1 2 4}} {
                # Split for projection and edge-incidence checks only.
                lassign $nodes a b c d
                lappend rows [list $a $b $c] [list $a $c $d]
            } else {
                error "The native mesher returned an element outside the requested style."
            }
        }
    }
    return $rows
}

proc ::RuledMesh::meshing_density {u v coordinates size {surface {}} {spacing 0}} {
    set a [dict get $coordinates $u]
    set b [dict get $coordinates $v]
    set width [expr {sqrt([distance2 $a $b])}]
    if {$width <= 0} {error "Connecting nodes $u and $v occupy the same point."}
    set density [expr {max(1, round($width / $size))}]
    if {$surface ne {}} {
        # For a quadratic profile, chordal error scales with the square of
        # the segment length. Use the fitted curvature to size the connector.
        set sag [connector_sag $surface $a $b]
        set density [expr {max($density,ceil(sqrt($sag/(0.03*$spacing))))}]
    }
    if {$density > 2147483647} {error "Element size is too small for HyperMesh edge density."}
    return [expr {int($density)}]
}

# In the node-list ruled workflow, edges 1 and 3 are the end and start
# connectors. The existing node lists control edges 0 and 2.
proc ::RuledMesh::mesh_patch {a b coordinates size elemsVar nodesVar {surface {}} {spacing 0} {style 3}} {
    upvar 1 $elemsVar allElems $nodesVar allNodes
    set start [meshing_density [lindex $a 0] [lindex $b 0] $coordinates $size $surface $spacing]
    set end [meshing_density [lindex $a end] [lindex $b end] $coordinates $size $surface $spacing]
    hm_entityrecorder elems on
    hm_entityrecorder nodes on
    set code [catch {
        *surfacemode 2
        *createlist nodes 1 {*}$a
        *createlist nodes 2 {*}$b
        *linearsurfacebetweennodes 1 2 0
        *set_meshedgeparams 1 $end 1 0 0 0 0 0 0
        *set_meshedgeparams 3 $start 1 0 0 0 0 0 0
        *set_meshfaceparams 0 1 $style 0 0 1 0.5 1 1
        *automesh 0 1 $style
        *storemeshtodatabase 0
    } result options]
    set clearCode [catch {*ameshclearsurface} clearResult clearOptions]
    hm_entityrecorder nodes off
    hm_entityrecorder elems off
    set elems [hm_entityrecorder elems ids]
    lappend allElems {*}$elems
    lappend allNodes {*}[hm_entityrecorder nodes ids]
    if {$code} {return -options $options $result}
    if {$clearCode} {return -options $clearOptions $clearResult}
    set seams [seam_paths $a $b [tria_rows $elems $style]]
    foreach seam $seams density [list $start $end] {
        if {[llength $seam] != $density + 1} {error "HyperMesh changed a connecting edge density."}
    }
    return $seams
}

proc ::RuledMesh::join_seams {first second newNodes} {
    set generated {}
    foreach id $newNodes {dict set generated $id 1}
    set source {}
    set target {}
    foreach a $first b [lreverse $second] {
        if {[llength $a] != [llength $b] || [lindex $a 0] != [lindex $b 0] ||
            [lindex $a end] != [lindex $b end]} {
            error "The two Ruled passes did not produce matching seams."
        }
        set positions [coordinates [lsort -integer -unique [concat $a $b]]]
        set start [dict get $positions [lindex $a 0]]
        set end [dict get $positions [lindex $a end]]
        set tolerance2 [expr {[distance2 $start $end] * 1.0e-12}]
        foreach u [lrange $a 1 end-1] v [lrange $b 1 end-1] {
            if {$u == $v} {continue}
            if {![dict exists $generated $u] || ![dict exists $generated $v] ||
                [distance2 [dict get $positions $u] [dict get $positions $v]] > $tolerance2} {
                error "Ruled seam nodes do not match. No existing node will be replaced."
            }
            lappend source $v
            lappend target $u
        }
    }
    if {[llength $source] == 1} {
        *replacenodes [lindex $source 0] [lindex $target 0] 1 0
    } elseif {[llength $source] > 1} {
        *createlist nodes 1 {*}$source
        *createlist nodes 2 {*}$target
        *replacenodes_multiple 1 2 1 0
    }
}

proc ::RuledMesh::quality_counts {elems limits} {
    variable checkSpec
    set result {}
    *createmark elems 1 "by id only" {*}$elems
    foreach {key label method} $checkSpec {
        set failures [hm_getelemcheckelems 1 2 $key $method [dict get $limits $key]]
        dict set result $key [llength $failures]
    }
    return $result
}

proc ::RuledMesh::number {value label min max} {
    if {![string is double -strict $value] || [catch {expr {double($value)}} parsed] ||
        $parsed < $min || $parsed > $max || $parsed == Inf} {
        error "Enter a valid $label."
    }
    return $parsed
}

proc ::RuledMesh::nested_boundaries {a b points} {
    if {abs([polygon_area2 [polygon_points $a $points]]) < abs([polygon_area2 [polygon_points $b $points]])} {
        lassign [list $b $a] a b
    }
    set outer [polygon_points $a $points]
    set outerScan [polygon_scan_index $outer]
    foreach id $b {
        lassign [dict get $points $id] x y
        if {![point_in_polygon $outerScan $x $y]} {return {}}
    }
    set inner [polygon_points $b $points]
    set outerNext [concat [lrange $outer 1 end] [list [lindex $outer 0]]]
    set innerNext [concat [lrange $inner 1 end] [list [lindex $inner 0]]]
    foreach u $outer v $outerNext {
        foreach p $inner q $innerNext {
            if {[segments_intersect $u $v $p $q]} {
                error "The projected inner and outer boundaries cross."
            }
        }
    }
    return [list $a $b]
}

proc ::RuledMesh::remesh_patch_to_size {seed size boundary surface spacing {style 3} {plane 0} {requiredPaths {}}} {
    set seedInterior {}
    foreach id [lsort -integer -unique [concat {*}[tria_rows $seed]]] {
        if {![dict exists $boundary $id]} {lappend seedInterior $id}
    }
    *createmark elems 1 "by id only" {*}$seed
    set order [hm_getoption element_order]
    if {$order != 1} {*setoption element_order=1}
    hm_entityrecorder elems on
    # 14 enables Flow align and size control. 2 keeps boundary connectivity.
    set code [catch {*defaultremeshelems 1 $size $style $style 0 1 1 14 0 0 0 0 2 30} result options]
    hm_entityrecorder elems off
    set elems [hm_entityrecorder elems ids]
    if {$order != 1} {*setoption element_order=$order}
    if {$code} {return -options $options $result}

    set rows [tria_rows $elems $style]
    set liveNodes [lsort -integer -unique [concat {*}$rows]]
    set points [coordinates $liveNodes]
    set code [catch {
        validate_projection $rows $points $surface
        if {[llength $requiredPaths]} {
            set free [free_edges $rows]
            if {[catch {
                foreach path $requiredPaths {remove_path_edges free $path}
            }] || [dict size $free]} {
                error "Native remesh changed a selected loop." {} {RULEDMESH REMESH_BOUNDARY}
            }
        }
    } result options]
    if {$code} {
        if {[dict get $options -errorcode] ni {{RULEDMESH FOLDED_PROJECTION} {RULEDMESH REMESH_BOUNDARY}}} {
            return -options $options $result
        }
        *createmark elems 1 "by id only" {*}$elems
        *deletemark elems 1
        set orphans {}
        foreach id [lsort -integer -unique [concat $seedInterior $liveNodes]] {
            if {![dict exists $boundary $id] && [hm_entityinfo exist nodes $id -byid]} {lappend orphans $id}
        }
        if {[llength $orphans]} {
            *createmark nodes 1 "by id only" {*}$orphans
            *nodemarkcleartempmark 1
        }
        return {}
    }
    set live {}
    foreach id $liveNodes {dict set live $id 1}
    set stale {}
    foreach id $seedInterior {
        if {![dict exists $live $id] && [hm_entityinfo exist nodes $id -byid]} {lappend stale $id}
    }
    if {[llength $stale]} {
        *createmark nodes 1 "by id only" {*}$stale
        *nodemarkcleartempmark 1
    }
    if {$plane} {
        lassign [lindex $surface 0] origin u v normal scale
        set targets {}
        dict for {id point} $points {
            if {![dict exists $boundary $id] && abs([dot [difference $point $origin] $normal]) > 1.0e-9*$scale} {
                lappend targets $id
            }
        }
        if {[llength $targets]} {
            *createmark nodes 1 "by id only" {*}$targets
            *createplane 1 {*}$normal {*}$origin
            *createvector 1 {*}$normal
            *projectmarktoplane nodes 1 1 1 1
        }
    } elseif {[surface_is_curved $surface $spacing]} {
        set support [build_support_surface $surface $boundary]
        project_patch $rows $points $surface $support $spacing $boundary
        delete_support_surface $support
    }
    return $elems
}

proc ::RuledMesh::create {a b closed size {limits {}} {style 3} {inferClosed {}} {trustedLoop 0} {quadratic 0} {extraHoles {}}} {
    variable checkSpec
    set size [number $size "element size" 0 Inf]
    if {$size <= 0 || $size >= Inf} {error "Element size must be a finite positive number."}
    if {[dict size $limits]} {
        foreach {key label method} $checkSpec {
            set max Inf
            if {$key eq "jacobian"} {set max 1.0}
            if {$key in {skew mininterangle maxinterangle}} {set max 180.0}
            dict set limits $key [number [dict get $limits $key] $label 0 $max]
        }
        if {[dict get $limits mininterangle] > [dict get $limits maxinterangle]} {
            error "Minimum tria angle exceeds the maximum."
        }
    }
    set a [corner_nodes $a]
    set b [corner_nodes $b]
    if {![llength $a] && ![llength $b]} {error "Select one closed edge or two paths."}
    set hole [expr {![llength $a] || ![llength $b]}]
    if {$hole && !$closed} {error "A single edge must form a closed loop."}
    set xyz [coordinates [lsort -integer -unique [concat $a $b]]]
    if {$hole} {
        set loop [concat $a $b]
        if {[lindex $loop 0] eq [lindex $loop end]} {set loop [lrange $loop 0 end-1]}
        if {[llength [lsort -integer -unique $loop]] != [llength $loop]} {
            error "The closed edge visits a node more than once."
        }
        if {[llength $loop] < 3} {error "Select a free-edge path with enough corner nodes."}
        set paths [list [concat $loop [lindex $loop 0]]]
    } else {
        set paths {}
        foreach selected [list $a $b] {
            if {[llength [lsort -integer -unique $selected]] < 2 + $closed} {
                error "Select enough corner nodes on both paths."
            }
            if {$closed && [lindex $selected 0] ne [lindex $selected end]} {lappend selected [lindex $selected 0]}
            lappend paths $selected
        }
    }
    if {[llength $extraHoles]} {
        if {!$closed || $hole} {error "Multiple inner loops require closed Edge 1 and Edge 2."}
        set rings {}
        set used {}
        foreach ring [concat [list $a $b] $extraHoles] {
            set ring [corner_nodes $ring]
            if {[lindex $ring 0] eq [lindex $ring end]} {set ring [lrange $ring 0 end-1]}
            if {[llength $ring] < 3} {error "Each loop requires at least three corner nodes."}
            foreach node $ring {
                if {[dict exists $used $node]} {error "Selected loops must use distinct corner nodes."}
                dict set used $node 1
            }
            lappend rings $ring
        }
        lassign $rings a b
        set extraHoles [lrange $rings 2 end]
        set xyz [coordinates [dict keys $used]]
        set paths {}
        foreach ring $rings {lappend paths [concat $ring [lindex $ring 0]]}
    }
    set spacing [path_spacing $paths $xyz]
    if {![llength $extraHoles] && $closed && [llength $inferClosed]} {
        set neighbors [shell_neighborhood $xyz $spacing]
        foreach side $inferClosed {
            set $side [complete_free_loop [set $side] $neighbors]
        }
        set xyz [coordinates [lsort -integer -unique [concat $a $b]]]
        foreach node $a {
            if {$node in $b} {
                error "Both selections use the same free-edge loop. Keep one Edge to fill it, or select two open paths."
            }
        }
        if {$hole} {
            set loop [concat $a $b]
            if {[lindex $loop 0] eq [lindex $loop end]} {set loop [lrange $loop 0 end-1]}
            set paths [list [concat $loop [lindex $loop 0]]]
        }
    }
    set collector [hm_info currentcollector comps]
    if {$collector eq "" || $collector eq "0"} {error "Set a current component for the new elements."}

    set oldList1 [hm_getlist nodes 1]
    set oldList2 [hm_getlist nodes 2]
    set oldElems [hm_getmark elems 1]
    set oldNodes [hm_getmark nodes 1]
    set oldSurfs [hm_getmark surfs 1]
    set initialCounts [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]]
    set elems {}
    set nodes {}
    set seams {}
    set fallback 0
    set label "Ruled mesh [clock clicks]"
    hm_private_frwk enablehistoryfromtcl 1
    if {[catch {*startnotehistorystate $label} result options]} {
        catch {hm_private_frwk enablehistoryfromtcl 0}
        return -options $options $result
    }
    set code [catch {
        set shells [shell_neighborhood $xyz $spacing]
        if {!$hole && ![llength $extraHoles]} {
            set a [order_selected_path $a $closed $shells $xyz]
            set b [order_selected_path $b $closed $shells $xyz]
            set plan [plan $a $b $closed $xyz]
            set start [list [lindex [dict get $plan a] 0] [lindex [dict get $plan b] 0]]
            set paths [list [dict get $plan a] [dict get $plan b]]
            set spacing [path_spacing $paths $xyz]
        }
        set surface {}
        if {$hole || [llength $extraHoles]} {set surface [boundary_plane $xyz $spacing]}
        set plane [expr {$surface ne {}}]
        if {!$plane} {set surface [reference_surface $xyz $shells $spacing [expr {!$closed}]]}
        if {$surface eq {} && [llength $extraHoles]} {
            set frame [rim_projection_frame [polygon_points $a $xyz]]
            if {$frame ne {}} {
                set surface [fit_reference_normal [lindex $frame 3] {} $xyz $xyz [dict keys $xyz] $spacing]
            }
        }
        set projected {}
        set region {}
        if {$surface ne {}} {
            dict for {id point} $xyz {dict set projected $id [project [lindex $surface 0] $point]}
        }
        if {[llength $extraHoles]} {
            if {$surface eq {}} {error "No common support surface fits the selected loops."}
            set start [list [lindex $a 0] [lindex $b 0]]
            set region [list $a $b]
        } elseif {$hole} {
            lassign [selected_shell_edges $loop $shells] counts directed touches
            if {!$touches} {
                set loop [order_planar_ring $loop $xyz]
            } else {
                if {[catch {order_shell_boundary $loop 1 $shells} traced options]} {
                    if {!$trustedLoop} {return -options $options $traced}
                    # The exact PLOTEL cycle was already checked before meshing.
                } else {
                    set loop $traced
                }
            }
            if {$surface eq {}} {
                # At a countersink or tube mouth, wall normals can span the
                # full rim while the opening itself still defines a plane.
                set rimPoints [polygon_points $loop $xyz]
                set frame [rim_projection_frame $rimPoints]
                if {$frame eq {}} {error "The selected rim does not define a meshing plane."}
                set tolerance [expr {$touches ? 0.1*$spacing/[lindex $frame end] : 1.0e-7}]
                set locals {}
                foreach point $rimPoints {
                    set local [project $frame $point]
                    if {abs([lindex $local 2]) > $tolerance} {
                        error "No usable support surface. The rim is too far from a plane."
                    }
                    lappend locals $local
                }
                if {[polygon_area2 $locals] < 0} {
                    lassign $frame origin u v normal scale
                    set frame [list $origin $u [difference {0 0 0} $v] \
                        [difference {0 0 0} $normal] $scale]
                }
                set surface [list $frame {0.0 0.0 0.0}]
                dict for {id point} $xyz {dict set projected $id [project $frame $point]}
            }
            set start [list [lindex $loop 0]]
            set paths [list [concat $loop [lindex $loop 0]]]
            set region [list $loop {}]
        } elseif {$closed && $surface ne {}} {
            set region [nested_boundaries [lrange [lindex $paths 0] 0 end-1] \
                [lrange [lindex $paths 1] 0 end-1] $projected]
            if {[llength $region]} {
                lassign $region outer inner
                set region [list [order_shell_boundary $outer 1 $shells 1] [order_shell_boundary $inner 1 $shells 1]]
            }
        }
        if {[llength $region]} {
            lassign $region outer inner
            # Give the native remesher the same seed sequence for either pick order.
            foreach name {outer inner} {
                set loopNodes [set $name]
                if {[llength $loopNodes]} {
                    set first [lindex [lsort -integer $loopNodes] 0]
                    set $name [rotate $loopNodes [lsearch -exact $loopNodes $first]]
                }
            }
            lassign [constrained_patch $outer $inner $projected $surface $spacing $extraHoles] rows points
            set patchSize [expr {$size/[lindex [lindex $surface 0] end]}]
            set fitsSize [expr {$style == 3 && $hole && [patch_within_size $rows $points $patchSize]}]
            if {!$fitsSize} {
                set seed [store_constrained_patch $rows $points $surface]
                set requiredPaths [expr {[llength $extraHoles] ? $paths : {}}]
                set elems [remesh_patch_to_size $seed $size $xyz $surface $spacing $style $plane $requiredPaths]
            }
            if {![llength $elems]} {
                if {$style in {1 2 4}} {error "HyperMesh could not fit the requested mesh style to this boundary."}
                set fallback 1
                if {!$fitsSize} {set rows [refine_patch_size $rows points $patchSize]}
                set elems [store_constrained_patch $rows $points $surface]
                set rows [tria_rows $elems $style]
                validate_projection $rows [coordinates [lsort -integer -unique [concat {*}$rows]]] $surface
            }
            set passes [expr {$hole || [llength $extraHoles] ? 1 : 2}]
        } else {
            set curved [expr {$surface ne {} && [surface_is_curved $surface $spacing]}]
            set connectorSurface {}
            if {$curved} {
                set support [build_support_surface $surface $xyz]
                set connectorSurface $surface
            }
            foreach patch [dict get $plan patches] {
                lassign $patch pa pb
                lappend seams [mesh_patch $pa $pb $xyz $size elems nodes $connectorSurface $spacing $style]
            }
            if {$closed} {
                join_seams {*}$seams $nodes
            } else {
                lappend paths {*}[lindex $seams 0]
            }
            set passes [llength $seams]
            if {$curved} {
                set rows [tria_rows $elems $style]
                set points [coordinates [lsort -integer -unique [concat {*}$rows]]]
                project_patch $rows $points $surface $support $spacing $xyz
                delete_support_surface $support
            } elseif {$surface ne {}} {
                set rows [tria_rows $elems $style]
                validate_projection $rows [coordinates [lsort -integer -unique [concat {*}$rows]]] $surface
            }
        }
        set rows [tria_rows $elems $style]
        set free [free_edges $rows]
        foreach path $paths {remove_path_edges free $path}
        if {[dict size $free]} {error "The new mesh has an open seam or unexpected free edges."}
        if {[hm_count elems all 0 0] != [lindex $initialCounts 0] + [llength $elems] ||
            [coordinates [dict keys $xyz]] ne $xyz} {
            error "Meshing changed existing elements or boundary nodes."
        }
        if {[lsort -unique [hm_getvalue elems user_ids=$elems dataname=collector.id]] ne [list $collector]} {
            error "The mesh was not created in the current component."
        }
        if {[hm_count surfs all 0 0] != [lindex $initialCounts 2]} {error "The surface count changed after meshing."}
        set failed {}
        if {[dict size $limits]} {set failed [quality_counts $elems $limits]}
        if {$quadratic} {
            set expected {}
            foreach config [hm_getvalue elems user_ids=$elems dataname=config] {
                lappend expected [dict get {103 106 104 108} $config]
            }
            *createmark elems 1 "by id only" {*}$elems
            *orderchangetosecond 1 0 0
            if {[hm_getvalue elems user_ids=$elems dataname=config] ne $expected ||
                    [hm_count elems all 0 0] != [lindex $initialCounts 0]+[llength $elems] ||
                    [coordinates [dict keys $xyz]] ne $xyz} {
                error "The native order change did not preserve the new mesh and its corner nodes."
            }
        }
    } result options]
    set closeCode [catch {*endnotehistorystate $label} closeResult closeOptions]
    if {$closeCode && !$code} {
        set code $closeCode
        set result $closeResult
        set options $closeOptions
    }
    if {!$code && [lindex [hm_getundoactions] 0] ne $label} {
        set code 1
        set options {-code error}
        set result "HyperMesh did not record the mesh as the latest undo action."
    }
    if {$code && !$closeCode} {
        if {[catch {
            undo_owned_action $label
            set counts [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]]
            if {$counts ne $initialCounts || [coordinates [dict keys $xyz]] ne $xyz} {
                error "The mesh or input nodes changed."
            }
        } cleanup]} {
            append result "\nRollback failed: $cleanup"
        }
    } elseif {$closeCode} {
        append result "\nUnable to close the Ruled mesh undo state."
    }
    catch {hm_private_frwk enablehistoryfromtcl 0}
    foreach slot {1 2} saved [list $oldList1 $oldList2] {
        if {[hm_getlist nodes $slot] eq $saved} {continue}
        if {[llength $saved]} {
            catch {*createlist nodes $slot {*}$saved}
        } else {
            catch {*clearlist nodes $slot}
        }
    }
    foreach kind {elems nodes surfs} saved [list $oldElems $oldNodes $oldSurfs] {
        if {[hm_getmark $kind 1] eq $saved} {continue}
        if {[llength $saved]} {
            catch {*createmark $kind 1 "by id only" {*}$saved}
        } else {
            catch {*clearmark $kind 1}
        }
    }
    if {$code} {return -options $options $result}
    return [dict create elements $elems passes $passes start $start quality $failed hole $hole \
        surface [expr {$surface ne {}}] fallback $fallback history $label]
}

proc ::RuledMesh::refresh_preview {{editing {}} {force 0}} {
    variable path
    variable model
    variable edgeElements
    variable previewModel
    variable pendingPlotel
    set active [hm_getcurrentmodel]
    set desiredNodes {}
    set desiredElements {}
    foreach label {Edge\ 1 Edge\ 2} {
        if {[info exists pendingPlotel($label)] && [lindex $pendingPlotel($label) 0] eq $active} {
            lappend desiredElements [lindex $pendingPlotel($label) 1]
        }
    }
    foreach side {A B} {
        if {$side eq $editing || $model($side) ne $active} {continue}
        if {[llength $edgeElements($side)]} {
            lappend desiredElements {*}$edgeElements($side)
        } else {
            lappend desiredNodes {*}$path($side)
        }
    }
    variable extraLoops
    if {$editing ne "B" && $model(B) eq $active} {
        foreach loop $extraLoops {lappend desiredElements {*}[dict get $loop elements]}
    }
    set desiredNodes [lsort -integer -unique $desiredNodes]
    set desiredElements [lsort -integer -unique $desiredElements]
    variable previewNodes
    variable previewElements
    if {$desiredNodes ne $previewNodes || $desiredElements ne $previewElements} {catch {hm_redraw}}
    foreach kind {nodes elems} wanted [list $desiredNodes $desiredElements] \
            cache {previewNodes previewElements} savedName {savedNodeMark savedElementMark} {
        upvar 0 ::RuledMesh::$cache previous ::RuledMesh::$savedName saved
        set old {}
        if {$previewModel eq $active} {set old $previous}
        if {(!$force && $wanted eq $old) || ($wanted eq {} && $old eq {})} {
            set previous $old
            continue
        }
        set mark [lsort -integer -unique [hm_getmark $kind 2]]
        if {$force && $wanted ne {} && $mark eq $wanted && $old eq $wanted} {
            hm_highlightmark $kind 2 lowlight
            continue
        }
        if {$old eq {} || ![info exists saved]} {set saved $mark}
        set keep {}
        foreach id $wanted {dict set keep $id 1}
        set removed {}
        foreach id $old {
            if {![dict exists $keep $id]} {lappend removed $id}
        }
        if {[llength $removed]} {
            *createmark $kind 2 "by id only" {*}$removed
            if {[llength [hm_getmark $kind 2]]} {hm_highlightmark $kind 2 norm}
        }
        if {[llength $wanted]} {
            *createmark $kind 2 "by id only" {*}$wanted
            set previous [lsort -integer -unique [hm_getmark $kind 2]]
            if {[llength $previous]} {hm_highlightmark $kind 2 lowlight}
        } else {
            *clearmark $kind 2
            if {[llength $saved]} {*createmark $kind 2 "by id only" {*}$saved}
            set previous {}
        }
    }
    set previewModel $active
}

proc ::RuledMesh::repeat_selection_preview {side} {
    variable selectorPreviewTimer
    set timer $selectorPreviewTimer
    catch {refresh_preview $side 1}
    if {$timer eq $selectorPreviewTimer && $timer ne {}} {
        set selectorPreviewTimer [after 180 [list ::RuledMesh::repeat_selection_preview $side]]
    }
}

proc ::RuledMesh::store_edge_selection {side origin selection} {
    variable path
    variable model
    variable count
    variable edgeElements
    variable extraLoops
    if {$side eq "B"} {set extraLoops {}}
    set path($side) [dict get $selection nodes]
    set edgeElements($side) [dict get $selection elements]
    set model($side) $origin
    set count($side) "[llength [lsort -integer -unique $path($side)]] nodes"
}

proc ::RuledMesh::ask_next_edge {side} {
    variable path
    variable busy
    variable window
    variable closed
    variable status
    if {$side ne "A" || ![llength $path(A)] || [llength $path(B)]} {return}
    set busy 1
    set code [catch {
        tk_messageBox -parent $window -title "Ruled Mesh" -icon question -type yesno \
            -default yes -message "Select Edge 2 as well?"
    } answer options]
    set busy 0
    if {$code} {return -options $options $answer}
    if {$answer eq "yes"} {
        pick B
    } else {
        set status [expr {$closed ? "Edge 1 selected. Click Create to fill." : "Select Edge 2 to bridge open paths."}]
    }
}

proc ::RuledMesh::store_inner_loops {origin selections} {
    variable extraLoops
    variable path
    variable model
    variable count
    variable edgeElements
    set loops {}
    if {$origin eq $model(B) && [llength $path(B)]} {
        set loops [linsert $extraLoops 0 [dict create nodes $path(B) elements $edgeElements(B)]]
    }
    set keys {}
    set used {}
    foreach loop $loops {
        set nodes [dict get $loop nodes]
        dict set keys [lsort -integer $nodes] 1
        foreach node $nodes {dict set used $node 1}
    }
    set added 0
    foreach loop $selections {
        set nodes [dict get $loop nodes]
        set key [lsort -integer $nodes]
        if {[dict exists $keys $key]} {continue}
        foreach node $nodes {
            if {[dict exists $used $node]} {error "Edge 2 loops must not share corner nodes."}
            dict set used $node 1
        }
        dict set keys $key 1
        lappend loops $loop
        incr added
    }
    if {$added} {
        store_edge_selection B $origin [lindex $loops 0]
        set extraLoops [lrange $loops 1 end]
        set count(B) "[llength $loops] loops"
    }
    return $added
}

proc ::RuledMesh::pick {side {addLoop 0}} {
    variable selectorPreviewTimer {}
    variable window
    variable path
    variable model
    variable status
    variable busy
    variable closed
    variable pickMode
    variable edgeElements
    if {$busy} {return}
    if {$addLoop && (!$closed || $pickMode(B) ne "edge")} {
        set status "Add loop requires Closed loops and Edge 2 By edge."
        return
    }
    if {$pickMode($side) eq "circle"} {
        show_circle $side
        return
    }
    set busy 1
    set label [expr {$side eq "A" ? "Edge 1" : "Edge 2"}]
    wm withdraw $window
    set code [catch {
        set origin [hm_getcurrentmodel]
        set previousNodes {}
        set previousElements {}
        if {!$addLoop && $origin eq $model($side)} {
            set previousNodes $path($side)
            set previousElements $edgeElements($side)
        }
        set editing [expr {$addLoop ? {} : $side}]
        refresh_preview $editing 1
        set selectorPreviewTimer [after 40 [list ::RuledMesh::repeat_selection_preview $editing]]
        set multiple [expr {$side eq "B" && $closed && $pickMode(B) eq "edge" &&
            ($addLoop || ![llength $previousElements])}]
        if {$multiple} {
            set selection [pick_inner_loops]
        } else {
            set selection [pick_selection $pickMode($side) $label $closed $previousNodes $previousElements]
        }
        if {$origin ne [hm_getcurrentmodel]} {error "The current model changed during selection."}
        if {$multiple && [llength $selection]} {set added [store_inner_loops $origin $selection]}
    } result]
    after cancel $selectorPreviewTimer
    set selectorPreviewTimer {}
    set busy 0
    wm deiconify $window
    if {$code} {
        set status $result
        puts stderr "Ruled Mesh: $result"
    } elseif {$selection eq {}} {
        set status "Selection cancelled."
    } elseif {$multiple} {
        set status [expr {$added ? "Edge 2: $added loop(s) added." : "These Edge 2 loops are already selected."}]
    } elseif {[dict exists $selection pending]} {
        set status [dict get $selection pending]
        set selection {}
    } else {
        if {[dict get $selection nodes] eq {} && [dict get $selection elements] eq {}} {
            if {[tk_messageBox -parent $window -title "Ruled Mesh" -icon question -type yesno \
                    -default no -message "Clear $label selection?"] ne "yes"} {
                set selection {}
            }
        }
        if {$selection ne {}} {
            store_edge_selection $side $origin $selection
            set status [expr {[llength $path($side)] ? "$label selected." : "$label cleared."}]
        } else {
            set status "Selection kept."
        }
    }
    if {[catch {refresh_preview {} 1} message]} {
        append status "\nPreview: $message"
        puts stderr "Ruled Mesh preview: $message"
    }
    if {!$code && $selection ne {}} {ask_next_edge $side}
}

proc ::RuledMesh::run {} {
    variable extraLoops
    variable path
    variable model
    variable status
    variable busy
    variable closed
    variable size
    variable edgeElements
    variable lastBridge
    variable elementStyle
    variable secondOrder
    variable pickMode
    if {$busy} {return}
    if {![llength $path(A)] && ![llength $path(B)]} {
        set status "Select one closed edge or two paths."
        return
    }
    set active [hm_getcurrentmodel]
    foreach side {A B} {
        if {([llength $path($side)] || [llength $edgeElements($side)]) && $model($side) ne $active} {
            set status "The model changed. Select the edges again."
            return
        }
    }
    set signature [list $active $closed [lsort -integer -unique $path(A)] [lsort -integer -unique $path(B)] \
        [lsort -integer -unique $edgeElements(A)] [lsort -integer -unique $edgeElements(B)]]
    if {[llength $extraLoops]} {
        set loopKeys {}
        foreach loop $extraLoops {lappend loopKeys [lsort -integer [dict get $loop nodes]]}
        lappend signature [lsort $loopKeys]
    }
    if {[catch {number $size "element size" 0 Inf} requestedSize]} {
        set status $requestedSize
        return
    }
    if {$requestedSize <= 0} {
        set status "Enter a positive element size."
        return
    }
    set settings [list $elementStyle $secondOrder]
    set replace {}
    if {[llength $lastBridge] && [lindex $lastBridge 0] eq $signature} {
        lassign $lastBridge previousSignature previousHistory previousStyle previousArgs previousCollector
        if {$previousHistory in [set history [hm_getundoactions]]} {
            if {$settings eq $previousStyle && $requestedSize == [lindex $previousArgs 3]} {
                set status "Change element size, type or order, or undo the previous mesh."
                return
            }
            if {[lindex $history 0] ne $previousHistory ||
                    [hm_info currentcollector comps] ne $previousCollector} {
                set status "The previous mesh is no longer the latest action in this component."
                return
            }
            set replace $previousHistory
        }
    }
    set busy 1
    set status "Creating mesh..."
    update idletasks
    set replaced 0
    set code [catch {
        set inputs {}
        set inferClosed {}
        foreach side {A B} {
            set nodes $path($side)
            if {[llength $edgeElements($side)]} {set nodes [path_from_plotels $edgeElements($side) $closed]}
            if {$pickMode($side) eq "nodes" && [llength $nodes]} {lappend inferClosed [string tolower $side]}
            lappend inputs $nodes
        }
        set style [dict get {quads 1 trias 0 mixed 2 R-trias 3 {quads only} 4} $elementStyle]
        set args [list {*}$inputs $closed $requestedSize]
        set trustedLoop [expr {$closed && (([llength $edgeElements(A)] && ![llength [lindex $inputs 1]]) ||
            ([llength $edgeElements(B)] && ![llength [lindex $inputs 0]]))}]
        if {$style != 3 || [llength $inferClosed] || $trustedLoop || $secondOrder || [llength $extraLoops]} {
            lappend args {} $style $inferClosed $trustedLoop $secondOrder
        }
        if {[llength $extraLoops]} {
            set holes {}
            foreach loop $extraLoops {lappend holes [path_from_plotels [dict get $loop elements] 1]}
            lappend args $holes
        }
        set collector [hm_info currentcollector comps]
        if {$replace ne {}} {
            if {[hm_getcurrentmodel] ne $active || [lindex [hm_getundoactions] 0] ne $replace ||
                    $collector ne $previousCollector} {
                error "The previous mesh can no longer be replaced automatically."
            }
            *undohistorystate 1
            set replaced 1
            set baseCounts [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]]
        }
        create {*}$args
    } result]
    if {$code} {
        if {$replaced} {
            if {[catch {
                if {[hm_getcurrentmodel] ne $active || [hm_info currentcollector comps] ne $previousCollector ||
                    [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]] ne $baseCounts} {
                    error "The model changed while building the replacement."
                }
                if {[lindex [hm_getredoactions] 0] eq $replace} {
                    *redohistorystate 1
                } else {
                    set restored [create {*}$previousArgs]
                    set lastBridge [list $previousSignature [dict get $restored history] $previousStyle \
                        $previousArgs $previousCollector]
                }
            } recovery]} {
                append result "\nPrevious mesh could not be restored: $recovery"
            } else {
                append result "\nPrevious mesh restored."
            }
        }
        set busy 0
        catch {refresh_preview {} 1}
        set status $result
        puts stderr "Ruled Mesh: $result"
        return
    }
    set busy 0
    if {[dict exists $result history]} {
        set lastBridge [list $signature [dict get $result history] $settings $args $collector]
    }
    catch {refresh_preview {} 1}
    set unit [expr {$secondOrder ? "second-order elements" : ($elementStyle in {trias R-trias} ? "trias" : "elements")}]
    if {[dict get $result hole]} {
        set status "Hole filled with [llength [dict get $result elements]] $unit."
    } else {
        set status "Created [llength [dict get $result elements]] $unit."
        if {![dict get $result surface]} {append status "\nNo shared shell surface for fitting."}
    }
    set details "start nodes [dict get $result start], passes [dict get $result passes]"
    if {[dict exists $result fallback] && [dict get $result fallback]} {append details ", fitted-surface sizing"}
    puts "Ruled Mesh: $details. $status"
}

proc ::RuledMesh::clear {} {
    variable extraLoops
    variable path
    variable model
    variable count
    variable status
    variable busy
    variable edgeElements
    variable pendingPlotel
    if {$busy} {return}
    array set path {A {} B {}}
    array set model {A {} B {}}
    array set count {A "0 nodes" B "0 nodes"}
    array set edgeElements {A {} B {}}
    array unset pendingPlotel
    set extraLoops {}
    set status Ready
    catch {refresh_preview}
}

proc ::RuledMesh::close {} {
    variable window
    variable busy
    if {!$busy} {
        clear
        destroy $window
    }
}

proc ::RuledMesh::undo_owned_action {label} {
    set history [hm_getundoactions]
    if {[lindex $history 0] eq $label} {
        *undohistorystate 1
    } elseif {$label in $history} {
        error "A later action prevents undoing $label."
    }
}

proc ::RuledMesh::create_circle_nodes {anchors count angle {radius {}}} {
    if {[llength [lsort -integer -unique $anchors]] != 3 || [llength $anchors] != 3} {
        error "Select exactly three distinct nodes on the circle."
    }
    if {[corner_nodes $anchors] ne $anchors} {error "Select three corner nodes on the circle."}
    set original [coordinates $anchors]
    set positions [circle_points [polygon_points $anchors $original] $count $angle $radius]
    set saved [hm_getmark nodes 1]
    set initialCount [hm_count nodes all 0 0]
    set label "Circle nodes [clock clicks]"
    hm_private_frwk enablehistoryfromtcl 1
    if {[catch {*startnotehistorystate $label} result options]} {
        catch {hm_private_frwk enablehistoryfromtcl 0}
        return -options $options $result
    }
    set code [catch {
        set created {}
        foreach point $positions {
            *createnode {*}$point 0 0 0
            lappend created [hm_latestentityid nodes]
        }
        *createmark nodes 1 "by id only" {*}$created
        *makepreservednodes 1
        # Preserve controls lifetime. The temporary mark displays the free ring nodes.
        *createmark nodes 1 "by id only" {*}[lrange $created 1 end]
        *nodemarkaddtempmark 1
        if {[dict size [coordinates $created]] != $count+1 || [coordinates $anchors] ne $original} {
            error "HyperMesh did not preserve the circle nodes."
        }
    } result options]
    set endCode [catch {*endnotehistorystate $label} endMessage endOptions]
    if {$endCode && !$code} {
        set code $endCode
        set result $endMessage
        set options $endOptions
    }
    if {!$code && [lindex [hm_getundoactions] 0] ne $label} {
        set code 1
        set result "HyperMesh did not record the circle as the latest undo action."
        set options {-code error}
    }
    if {$code && [catch {
        if {!$endCode} {undo_owned_action $label}
        if {[hm_count nodes all 0 0] != $initialCount || [coordinates $anchors] ne $original} {
            error "Circle nodes or anchors changed."
        }
    } cleanup]} {
        append result "\nRollback failed: $cleanup"
    }
    catch {hm_private_frwk enablehistoryfromtcl 0}
    *clearmark nodes 1
    if {[llength $saved]} {*createmark nodes 1 "by id only" {*}$saved}
    if {$code} {return -options $options $result}
    return [dict create center [lindex $created 0] nodes [lrange $created 1 end] elements {} history $label]
}

proc ::RuledMesh::center_dialog {dialog host} {
    update idletasks
    set x [expr {[winfo rootx $host]+([winfo width $host]-[winfo reqwidth $dialog])/2}]
    set y [expr {[winfo rooty $host]+([winfo height $host]-[winfo reqheight $dialog])/2}]
    # A leading + keeps negative coordinates absolute on a monitor to the left.
    wm geometry $dialog "+$x+$y"
    wm deiconify $dialog
}

proc ::RuledMesh::circle_preview_changed {args} {
    variable circlePreviewTimer
    variable circleArrowHeld
    after cancel $circlePreviewTimer
    set circlePreviewTimer {}
    if {!$circleArrowHeld} {
        set circlePreviewTimer [after 120 ::RuledMesh::update_circle_preview]
    }
}

proc ::RuledMesh::circle_arrow_press {widget x y} {
    variable circleArrowHeld
    if {[$widget identify $x $y] in {buttonup buttondown}} {
        set circleArrowHeld 1
        circle_preview_changed
    }
}

proc ::RuledMesh::circle_arrow_release {} {
    variable circleArrowHeld
    if {$circleArrowHeld} {
        set circleArrowHeld 0
        circle_preview_changed
    }
}

proc ::RuledMesh::replace_circle_preview {points} {
    variable circlePreviewNodes
    variable circlePreviewHistory
    variable circleModel
    if {![llength $circlePreviewNodes] && ![llength $points]} {return}
    if {[hm_getcurrentmodel] ne $circleModel} {error "Return to the original model to clear the preview."}
    set saved [hm_getmark nodes 1]
    set code [catch {
        if {$circlePreviewHistory ne {}} {
            set actions [hm_getundoactions]
            if {[lindex $actions 0] eq $circlePreviewHistory} {
                *createmark nodes 1 "by id only" {*}$circlePreviewNodes
                hm_highlightmark nodes 1 norm
                *undohistorystate 1
            } elseif {$circlePreviewHistory in $actions} {
                error "Undo the later model changes before editing the circle preview."
            }
            *clearmark nodes 1
            *createmark nodes 1 "by id only" {*}$circlePreviewNodes
            if {[llength [hm_getmark nodes 1]]} {
                error "The previous preview nodes are still present."
            }
            set circlePreviewNodes {}
            set circlePreviewHistory {}
        }
        if {[llength $points]} {
            set redo [hm_getredoactions]
            if {[llength $redo] && ![string match {Ruled circle preview *} [lindex $redo 0]]} {
                error "Preview paused while the model has pending Redo actions."
            }
            set label "Ruled circle preview [clock clicks]"
            hm_private_frwk enablehistoryfromtcl 1
            set started [catch {*startnotehistorystate $label} message options]
            if {!$started} {
                set started [catch {
                    foreach point $points {
                        *createnode {*}$point 0 0 0
                        lappend circlePreviewNodes [hm_latestentityid nodes]
                    }
                } message options]
                set ended [catch {*endnotehistorystate $label} endMessage endOptions]
                if {$label in [hm_getundoactions]} {set circlePreviewHistory $label}
            }
            hm_private_frwk enablehistoryfromtcl 0
            if {$started} {return -options $options $message}
            if {$ended} {return -options $endOptions $endMessage}
            *createmark nodes 1 "by id only" {*}$circlePreviewNodes
            hm_highlightmark nodes 1 high
        }
    } result options]
    *clearmark nodes 1
    if {[llength $saved]} {*createmark nodes 1 "by id only" {*}$saved}
    catch {hm_redraw}
    if {$code} {return -options $options $result}
}

proc ::RuledMesh::update_circle_preview {} {
    variable window
    variable circleModel
    variable circleAnchors
    variable circleCount
    variable circleAngle
    variable circleRadius
    variable circleStatus
    variable circlePreviewUpdating
    variable circleArrowHeld
    variable circlePreviewTimer {}
    if {![winfo exists $window.circle] || [wm state $window.circle] eq "withdrawn"} {return}
    if {[llength $circleAnchors] != 3} {return}
    if {$circleArrowHeld} {return}
    if {$circlePreviewUpdating} {
        circle_preview_changed
        return
    }
    set count $circleCount
    set circlePreviewUpdating 1
    set code [catch {
        if {[hm_getcurrentmodel] ne $circleModel} {error "The current model changed."}
        set anchors [polygon_points $circleAnchors [coordinates $circleAnchors]]
        set positions [circle_points $anchors $count $circleAngle $circleRadius]
        replace_circle_preview [lrange $positions 1 end]
    } message]
    if {$code} {
        catch {replace_circle_preview {}}
    }
    set circlePreviewUpdating 0
    set circleStatus [expr {$code ? $message : "$count ring nodes in preview."}]
}

proc ::RuledMesh::finish_circle_preview {widget} {
    variable window
    variable circlePreviewTimer
    if {$widget ne "$window.circle"} {return}
    after cancel $circlePreviewTimer
    foreach name {circleCount circleAngle circleRadius} {
        trace remove variable ::RuledMesh::$name write ::RuledMesh::circle_preview_changed
    }
    if {[catch {replace_circle_preview {}} message]} {puts stderr "Ruled Mesh: $message"}
}

proc ::RuledMesh::show_circle {side} {
    variable window
    variable busy
    variable circlePreviewNodes
    variable circlePreviewHistory
    variable status
    if {([llength $circlePreviewNodes] || $circlePreviewHistory ne {}) &&
            [catch {replace_circle_preview {}} message]} {
        set status $message
        return
    }
    variable circleSide $side
    variable circleModel [hm_getcurrentmodel]
    variable circleAnchors {}
    variable lastCircleCount
    variable circleCount $lastCircleCount
    variable circleAngle 0
    variable circleRadius {}
    variable circleStatus "Select 3 nodes on the circle."
    variable circlePreviewTimer {}
    variable circleArrowHeld 0
    variable circlePreviewUpdating 0
    set busy 1
    set dialog [toplevel $window.circle]
    wm withdraw $dialog
    wm transient $dialog $window
    wm title $dialog [expr {$side eq "A" ? "Edge 1 - Circle" : "Edge 2 - Circle"}]
    wm resizable $dialog 0 0
    wm protocol $dialog WM_DELETE_WINDOW ::RuledMesh::close_circle
    bind $dialog <Escape> {::RuledMesh::close_circle}
    bind $dialog <Destroy> [list ::RuledMesh::finish_circle_preview %W]
    foreach name {circleCount circleAngle circleRadius} {
        trace add variable ::RuledMesh::$name write ::RuledMesh::circle_preview_changed
    }
    set body [ttk::frame $dialog.body -padding 8]
    pack $body -fill both -expand 1
    grid columnconfigure $body {0 1} -weight 1 -minsize 112 -uniform circleFields
    grid rowconfigure $body {1 2 3} -uniform circleInputs
    ttk::button $body.pick -text "Pick 3 nodes..." -command ::RuledMesh::pick_circle_anchors
    grid $body.pick -row 0 -column 0 -columnspan 2 -sticky ew -pady {0 5}
    ttk::label $body.countLabel -text "Ring nodes"
    ttk::entry $body.count -width 10 -justify center -textvariable ::RuledMesh::circleCount
    ttk::label $body.angleLabel -text "Rotation (\u00B0)"
    spinbox $body.angle -from -360 -to 360 -increment 1 -wrap 1 -width 10 -justify center \
        -textvariable ::RuledMesh::circleAngle
    bind $body.angle <ButtonPress-1> {::RuledMesh::circle_arrow_press %W %x %y}
    bind $body.angle <ButtonRelease-1> ::RuledMesh::circle_arrow_release
    bind $body.angle <FocusOut> ::RuledMesh::circle_arrow_release
    ttk::label $body.radiusLabel -text "Radius"
    ttk::entry $body.radius -width 10 -justify center -textvariable ::RuledMesh::circleRadius
    foreach field {count angle radius} row {1 2 3} {
        grid $body.${field}Label -row $row -column 0 -sticky w -padx {0 6} -pady 2
        grid $body.$field -row $row -column 1 -sticky nsew -pady 2
    }
    ttk::button $body.cancel -text Cancel -command ::RuledMesh::close_circle
    ttk::button $body.create -text Select -command ::RuledMesh::finish_circle
    grid $body.cancel -row 4 -column 0 -sticky ew -padx {0 3} -pady {6 0}
    grid $body.create -row 4 -column 1 -sticky ew -padx {3 0} -pady {6 0}
    frame $body.line -height 1 -background #AFBAC2
    grid $body.line -row 5 -column 0 -columnspan 2 -sticky ew -pady {4 1}
    label $body.status -textvariable ::RuledMesh::circleStatus -width 1 -height 0 -wraplength 224 \
        -font TkDefaultFont -anchor nw -justify left -borderwidth 0 -pady 0
    foreach {option style} {-background TFrame -foreground TLabel} {
        set color [ttk::style lookup $style $option]
        if {$color ne {}} {$body.status configure $option $color}
    }
    grid $body.status -row 6 -column 0 -columnspan 2 -sticky ew
    bind $body.status <Configure> {if {%w > 32} {%W configure -wraplength %w}}
    bind $body.status <Double-Button-1> {
        tk_messageBox -parent [winfo toplevel %W] -title "Circle" -message $::RuledMesh::circleStatus
    }
    center_dialog $dialog $window
    pick_circle_anchors
}

proc ::RuledMesh::close_circle {} {
    variable circlePreviewUpdating
    if {$circlePreviewUpdating} {return}
    variable window
    variable busy
    variable circleStatus
    if {[catch {replace_circle_preview {}} message]} {
        set circleStatus $message
        return
    }
    destroy $window.circle
    set busy 0
    catch {refresh_preview {} 1}
}

proc ::RuledMesh::pick_circle_anchors {} {
    variable selectorPreviewTimer {}
    variable circlePreviewUpdating
    if {$circlePreviewUpdating} {return}
    variable window
    variable circleSide
    variable circleModel
    variable circleAnchors
    variable circleRadius
    variable circleStatus
    variable circlePreviewTimer
    set dialog $window.circle
    after cancel $circlePreviewTimer
    if {[catch {replace_circle_preview {}} message]} {
        set circleStatus $message
        return
    }
    wm withdraw $dialog
    wm withdraw $window
    set code [catch {
        if {[hm_getcurrentmodel] ne $circleModel} {error "The current model changed."}
        refresh_preview $circleSide 1
        set selectorPreviewTimer [after 40 [list ::RuledMesh::repeat_selection_preview $circleSide]]
        set ids [corner_nodes [pick_node_list *createlistpanel "Pick three corner nodes on the circle."]]
        if {[hm_getcurrentmodel] ne $circleModel} {error "The current model changed."}
    } message]
    after cancel $selectorPreviewTimer
    set selectorPreviewTimer {}
    wm deiconify $window
    wm deiconify $dialog
    catch {refresh_preview {} 1}
    if {$code} {
        set circleStatus $message
    } elseif {[llength $ids] == 3 && [llength [lsort -integer -unique $ids]] == 3} {
        set circleAnchors $ids
        if {[catch {
            lindex [circle_frame {*}[polygon_points $ids [coordinates $ids]]] end
        } value]} {
            set circleRadius {}
            set circleStatus $value
        } else {
            set circleRadius [format %.15g $value]
            set circleStatus "3 reference nodes selected."
        }
    } elseif {[llength $ids]} {
        set circleStatus "Select exactly 3 distinct nodes."
    }
    if {!$code && [llength $circleAnchors] == 3} {circle_preview_changed}
}

proc ::RuledMesh::finish_circle {} {
    variable circlePreviewUpdating
    if {$circlePreviewUpdating} {return}
    variable circleSide
    variable circleModel
    variable circleAnchors
    variable circleCount
    variable circleAngle
    variable circleRadius
    variable circleStatus
    variable closed
    variable status
    if {[catch {
        if {[hm_getcurrentmodel] ne $circleModel} {error "The current model changed."}
        replace_circle_preview {}
        set selection [create_circle_nodes $circleAnchors $circleCount $circleAngle $circleRadius]
    } message]} {
        set circleStatus $message
        return
    }
    variable lastCircleCount $circleCount
    set closed 1
    store_edge_selection $circleSide $circleModel $selection
    close_circle
    set label [expr {$circleSide eq "A" ? "Edge 1" : "Edge 2"}]
    set status "$label: $circleCount ring nodes. Center: [dict get $selection center]."
    ask_next_edge $circleSide
}

proc ::RuledMesh::show {} {
    variable window
    variable busy
    if {[winfo exists $window]} {
        if {$busy} {return}
        if {[winfo exists $window.footer.highlight]} {
            wm deiconify $window
            raise $window
            return
        }
        destroy $window
    }
    clear
    toplevel $window
    wm withdraw $window
    wm title $window "Ruled Mesh"
    wm resizable $window 0 0
    wm transient $window .
    wm protocol $window WM_DELETE_WINDOW ::RuledMesh::close
    bind $window <Escape> {::RuledMesh::close}
    bind $window <FocusIn> {
        if {"%W" eq $::RuledMesh::window && !$::RuledMesh::busy} {
            catch {::RuledMesh::refresh_preview {} 1}
        }
    }

    set footer [ttk::frame $window.footer]
    pack $footer -side bottom -fill x
    frame $footer.line -height 1 -background #AFBAC2
    frame $footer.highlight -height 1 -background #FFFFFF
    pack $footer.line -side top -fill x
    pack $footer.highlight -side top -fill x
    label $footer.status -textvariable ::RuledMesh::status -font TkDefaultFont \
        -anchor nw -justify left -height 0 -width 1 -wraplength 340 -padx 5 -pady 1 -borderwidth 0
    foreach {option style} {-background TFrame -foreground TLabel} {
        set color [ttk::style lookup $style $option]
        if {$color ne ""} {$footer.status configure $option $color}
    }
    pack $footer.status -fill x
    bind $footer.status <Configure> {if {%w > 32} {%W configure -wraplength [expr {%w-10}]}}
    bind $footer.status <Double-Button-1> {
        if {$::RuledMesh::status ne "Ready"} {
            tk_messageBox -parent $::RuledMesh::window -title "Ruled Mesh" -message $::RuledMesh::status
        }
    }

    set body [ttk::frame $window.body -padding 5]
    pack $body -fill both -expand 1
    set buttons [ttk::frame $body.buttons]
    pack $buttons -side bottom -fill x -pady {4 0}
    foreach {id label command} {close Close close create Create run clear Clear clear} {
        ttk::button $buttons.$id -text $label -width 7 -command ::RuledMesh::$command
        pack $buttons.$id -side right -padx {3 0}
    }

    set paths [labelframe $body.paths -text "Boundary selection" -relief groove \
        -borderwidth 2 -padx 4 -pady 1 -font TkDefaultFont]
    pack $paths -fill x
    grid columnconfigure $paths 1 -weight 1
    foreach side {A B} number {1 2} row {0 2} {
        ttk::button $paths.pick$side -text "Edge $number..." -width 8 -command [list ::RuledMesh::pick $side]
        ttk::label $paths.count$side -textvariable ::RuledMesh::count($side)
        grid $paths.pick$side $paths.count$side -row $row -sticky w -padx {0 5} -pady 1
        set modes [ttk::frame $paths.modes$side]
        grid $modes -row [expr {$row+1}] -column 0 -columnspan 3 -sticky w -pady {0 2}
        foreach {mode label} {edge "By edge" path "By path" nodes "By node" circle "By circle"} {
            ttk::radiobutton $modes.$mode -text $label -variable ::RuledMesh::pickMode($side) -value $mode
            pack $modes.$mode -side left -padx {0 3}
        }
    }
    ttk::button $paths.addLoop -text "Add loop" -command [list ::RuledMesh::pick B 1]
    grid $paths.addLoop -row 2 -column 2 -sticky e -padx {0 4}
    ttk::checkbutton $paths.closed -text "Closed loops" -variable ::RuledMesh::closed
    grid $paths.closed -row 4 -column 0 -columnspan 2 -sticky w

    set settings [labelframe $body.mesh -text "Mesh, delete surface" -relief groove \
        -borderwidth 2 -padx 4 -pady 2 -font TkDefaultFont]
    set background [ttk::style lookup TFrame -background]
    set foreground [ttk::style lookup TLabel -foreground]
    foreach panel [list $paths $settings] {
        if {$background ne {}} {$panel configure -background $background}
        if {$foreground ne {}} {$panel configure -foreground $foreground}
    }
    pack $settings -fill x -pady {4 0}
    ttk::label $settings.label -text "Element size"
    ttk::entry $settings.size -width 9 -justify center -textvariable ::RuledMesh::size
    grid $settings.label -row 0 -column 0 -sticky w -padx {0 8}
    grid $settings.size -row 0 -column 1 -sticky ew
    ttk::label $settings.target -text "Current component"
    grid $settings.target -row 0 -column 2 -sticky w -padx {8 0}
    ttk::label $settings.styleLabel -text "Element type"
    ttk::combobox $settings.style -width 12 -state readonly -justify center -values {quads trias mixed R-trias {quads only}} \
        -textvariable ::RuledMesh::elementStyle
    grid $settings.styleLabel -row 1 -column 0 -sticky w -padx {0 8} -pady {2 0}
    grid $settings.style -row 1 -column 1 -sticky ew -pady {2 0}
    ttk::checkbutton $settings.order -text "2nd order" -variable ::RuledMesh::secondOrder
    grid $settings.order -row 1 -column 2 -sticky w -padx {8 0} -pady {2 0}

    center_dialog $window .
}

if {![info exists ::RuledMesh_no_gui]} {::RuledMesh::show}
