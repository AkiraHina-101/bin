# Triangulate in the fitted shell frame. The original rim segments are hard constraints.
proc ::RuledMesh::polygon_area2 {polygon} {
    set area 0.0
    set previous [lindex $polygon end]
    foreach point $polygon {
        set area [expr {$area+[signed_area2 {0 0} $previous $point]}]
        set previous $point
    }
    return $area
}

proc ::RuledMesh::polygon_scan_index {polygon} {
    if {![llength $polygon]} {return {}}
    set ymin Inf
    set ymax -Inf
    foreach point $polygon {
        set y [lindex $point 1]
        set ymin [expr {min($ymin,$y)}]
        set ymax [expr {max($ymax,$y)}]
    }
    if {$ymin == $ymax} {return {}}
    set count [expr {max(1,int(sqrt([llength $polygon])))}]
    set scale [expr {$count/($ymax-$ymin)}]
    set bins {}
    set previous [lindex $polygon end]
    foreach point $polygon {
        lassign $previous ax ay
        lassign $point bx by
        set previous $point
        if {$ay == $by} {continue}
        set low [expr {min($count-1,int((min($ay,$by)-$ymin)*$scale))}]
        set high [expr {min($count-1,int((max($ay,$by)-$ymin)*$scale))}]
        set edge [list $ax $ay $bx $by]
        for {set slot $low} {$slot <= $high} {incr slot} {dict lappend bins $slot $edge}
    }
    return [list $ymin $ymax $scale $count $bins]
}

proc ::RuledMesh::point_in_polygon {index x y} {
    if {$index eq {}} {return 0}
    lassign $index ymin ymax scale count bins
    if {$y < $ymin || $y >= $ymax} {return 0}
    set slot [expr {min($count-1,int(($y-$ymin)*$scale))}]
    if {![dict exists $bins $slot]} {return 0}
    set inside 0
    foreach edge [dict get $bins $slot] {
        lassign $edge ax ay bx by
        if {($ay > $y) != ($by > $y) && $x < $ax+($y-$ay)*($bx-$ax)/($by-$ay)} {
            set inside [expr {!$inside}]
        }
    }
    return $inside
}

proc ::RuledMesh::segments_intersect {a b c d} {
    lassign $a ax ay
    lassign $b bx by
    lassign $c cx cy
    lassign $d dx dy
    set eps 1.0e-10
    if {max($ax,$bx)+$eps < min($cx,$dx) || max($cx,$dx)+$eps < min($ax,$bx) ||
        max($ay,$by)+$eps < min($cy,$dy) || max($cy,$dy)+$eps < min($ay,$by)} {
        return 0
    }
    set u [signed_area2 $a $b $c]
    set v [signed_area2 $a $b $d]
    set s [signed_area2 $c $d $a]
    set t [signed_area2 $c $d $b]
    return [expr {!(min($u,$v)>$eps || max($u,$v)<-$eps || min($s,$t)>$eps || max($s,$t)<-$eps)}]
}

proc ::RuledMesh::xy_distance2 {a b} {
    lassign $a ax ay
    lassign $b bx by
    return [expr {($ax-$bx)**2+($ay-$by)**2}]
}

proc ::RuledMesh::polygon_points {loop points} {
    set polygon {}
    foreach id $loop {lappend polygon [dict get $points $id]}
    return $polygon
}

proc ::RuledMesh::visible_connector {a b points edges outside island} {
    set p [dict get $points $a]
    set q [dict get $points $b]
    lassign $p px py
    lassign $q qx qy
    set x [expr {($px+$qx)*0.5}]
    set y [expr {($py+$qy)*0.5}]
    if {![point_in_polygon $outside $x $y] || [point_in_polygon $island $x $y]} {return 0}
    foreach edge $edges {
        lassign $edge u v
        if {$a in $edge || $b in $edge} {continue}
        if {[segments_intersect $p $q [dict get $points $u] [dict get $points $v]]} {return 0}
    }
    return 1
}

# Two non-crossing segments split the annulus into simple polygons. They are
# internal edges and can be flipped later to improve the triangulation.
proc ::RuledMesh::annular_polygons {outer inner points outside island {obstacles {}}} {
    if {[polygon_area2 $outside]*[polygon_area2 $island] < 0} {set inner [lreverse $inner]}
    set outside [polygon_scan_index $outside]
    set island [polygon_scan_index $island]
    set edges [concat [path_edges [concat $outer [lindex $outer 0]]] \
        [path_edges [concat $inner [lindex $inner 0]]] $obstacles]
    set pairs {}
    foreach a $outer {
        foreach b $inner {lappend pairs [list [xy_distance2 [dict get $points $a] [dict get $points $b]] $a $b]}
    }
    set first {}
    foreach pair [lsort -real -index 0 $pairs] {
        lassign $pair width a b
        if {[visible_connector $a $b $points $edges $outside $island]} {
            set first [list $a $b]
            break
        }
    }
    if {![llength $first]} {error "There is no visible connector between the selected loops."}
    lassign $first a b
    set outer [rotate $outer [lsearch -exact $outer $a]]
    set inner [rotate $inner [lsearch -exact $inner $b]]
    set p [dict get $points $a]
    set q [dict get $points $b]
    set indexA {}
    set indexB {}
    set i 0
    foreach id $outer {dict set indexA $id [incr i]}
    set j 0
    foreach id $inner {dict set indexB $id [incr j]}
    set ranked {}
    foreach pair $pairs {
        lassign $pair width u v
        if {$u == $a || $v == $b} {continue}
        set i [expr {[dict get $indexA $u]-1}]
        set j [expr {[dict get $indexB $v]-1}]
        set offset [expr {abs(double($i)/[llength $outer]-0.5)+abs(double($j)/[llength $inner]-0.5)}]
        lappend ranked [list [expr {$offset+0.25*$width}] $i $j $u $v]
    }
    foreach item [lsort -real -index 0 $ranked] {
        lassign $item score i j u v
        if {[segments_intersect $p $q [dict get $points $u] [dict get $points $v]] ||
            ![visible_connector $u $v $points $edges $outside $island]} {continue}
        set left [concat [lrange $outer 0 $i] [lreverse [lrange $inner 0 $j]]]
        set right [concat [lrange $outer $i end] $a $b [lreverse [lrange $inner $j end]]]
        return [list $left $right]
    }
    error "The selected loops do not have two non-crossing connectors."
}

proc ::RuledMesh::triangle_quality {a b c} {
    set length [expr {[xy_distance2 $a $b]+[xy_distance2 $b $c]+[xy_distance2 $c $a]}]
    if {$length <= 0} {return 0}
    return [expr {[signed_area2 $a $b $c]/$length}]
}

proc ::RuledMesh::inside_triangle {p a b c threshold} {
    expr {[signed_area2 $a $b $p] > $threshold && [signed_area2 $b $c $p] > $threshold &&
        [signed_area2 $c $a $p] > $threshold}
}

proc ::RuledMesh::ear_triangles {loop points} {
    if {[polygon_area2 [polygon_points $loop $points]] < 0} {set loop [lreverse $loop]}
    set rows {}
    while {[llength $loop] > 3} {
        set candidates {}
        set i 0
        set from [lindex $loop end]
        foreach node $loop to [concat [lrange $loop 1 end] [lindex $loop 0]] {
            set ear [list $from $node $to]
            lassign [polygon_points $ear $points] a b c
            if {[signed_area2 $a $b $c] > 1.0e-10} {
                lappend candidates [list [triangle_quality $a $b $c] $i $ear $a $b $c]
            }
            set from $node
            incr i
        }
        set best -1
        foreach candidate [lsort -real -decreasing -index 0 $candidates] {
            lassign $candidate score i ear a b c
            lassign $a ax ay
            lassign $b bx by
            lassign $c cx cy
            set span [expr {max(max($ax,$bx,$cx)-min($ax,$bx,$cx),max($ay,$by,$cy)-min($ay,$by,$cy))}]
            set margin [expr {1.0e-10+2.0e-10*$span/[signed_area2 $a $b $c]}]
            set xmin [expr {min($ax,$bx,$cx)-$margin}]
            set xmax [expr {max($ax,$bx,$cx)+$margin}]
            set ymin [expr {min($ay,$by,$cy)-$margin}]
            set ymax [expr {max($ay,$by,$cy)+$margin}]
            set valid 1
            foreach other $loop {
                if {$other in $ear} {continue}
                set p [dict get $points $other]
                lassign $p x y
                if {$x < $xmin || $x > $xmax || $y < $ymin || $y > $ymax} {continue}
                if {[inside_triangle $p $a $b $c -1.0e-10]} {
                    set valid 0
                    break
                }
            }
            if {$valid} {
                set best $i
                set face $ear
                break
            }
        }
        if {$best < 0} {error "The projected boundary is not a simple meshable polygon."}
        lappend rows $face
        set loop [lreplace $loop $best $best]
    }
    lappend rows $loop
    return $rows
}

proc ::RuledMesh::improve_triangles {rows points} {
    # Flip internal diagonals if both resulting triangles are valid and the
    # worse triangle improves. No original boundary edge is eligible.
    set scores {}
    foreach row $rows {lappend scores [triangle_quality {*}[polygon_points $row $points]]}
    for {set pass 0} {$pass < 24} {incr pass} {
        set edges {}
        set i 0
        foreach row $rows {
            lassign $row a b c
            foreach u [list $a $b $c] v [list $b $c $a] w [list $c $a $b] {
                dict lappend edges [edge_key $u $v] [list $i $u $v $w]
            }
            incr i
        }
        set used {}
        dict for {edge sides} $edges {
            if {[llength $sides] != 2} {continue}
            lassign [lindex $sides 0] i a b c
            lassign [lindex $sides 1] j b2 a2 d
            if {$a != $a2 || $b != $b2 || [dict exists $used $i] || [dict exists $used $j] ||
                [dict exists $edges [edge_key $c $d]]} {continue}
            lassign [polygon_points [list $a $b $c $d] $points] pa pb pc pd
            set before [expr {min([lindex $scores $i],[lindex $scores $j])}]
            set scoreI [triangle_quality $pc $pd $pb]
            set scoreJ [triangle_quality $pd $pc $pa]
            if {min($scoreI,$scoreJ) <= $before+1.0e-9} {continue}
            lset rows $i [list $c $d $b]
            lset rows $j [list $d $c $a]
            lset scores $i $scoreI
            lset scores $j $scoreJ
            dict set used $i 1
            dict set used $j 1
        }
        if {![dict size $used]} {break}
    }
    return $rows
}

proc ::RuledMesh::refine_triangles {rows pointsVar surface spacing} {
    upvar 1 $pointsVar points
    set rows [improve_triangles $rows $points]
    if {![surface_is_curved $surface $spacing]} {return $rows}
    lassign $surface frame coefficients
    set scale [lindex $frame end]
    lassign [lrange $coefficients 3 5] xx xy yy
    set curvature [expr {max(2*abs($xx)+abs($xy),2*abs($yy)+abs($xy))/$scale}]
    set step [expr {sqrt(8.0*0.012*$spacing/$curvature)/$scale}]
    # Insert a node only where this triangle's interior has room at the
    # curvature spacing. HyperMesh applies the requested element size later.
    set id 0
    set refined {}
    foreach row $rows {
        lassign $row u v w
        lassign [polygon_points $row $points] a b c
        set area [signed_area2 $a $b $c]
        set longest [expr {sqrt(max([xy_distance2 $a $b],[xy_distance2 $b $c],[xy_distance2 $c $a]))}]
        if {$area <= 1.0e-10 || $longest <= 0 || ($area/$longest < 0.40*$step ||
            $area < 0.75*$step*$step)} {
            lappend refined $row
            continue
        }
        set point [center_of [list $a $b $c]]
        dict set points [incr id -1] $point
        lappend refined [list $u $v $id] [list $v $w $id] [list $w $u $id]
    }
    if {!$id && [llength $rows] > 0} {
        set largest 0.0
        set chosen -1
        set i 0
        foreach row $rows {
            lassign [polygon_points $row $points] a b c
            set area [signed_area2 $a $b $c]
            if {$area > $largest} {
                set largest $area
                set chosen $i
                set point [center_of [list $a $b $c]]
            }
            incr i
        }
        if {$chosen >= 0} {
            dict set points -1 $point
            lassign [lindex $rows $chosen] u v w
            set refined [lreplace $rows $chosen $chosen [list $u $v -1] [list $v $w -1] [list $w $u -1]]
        }
    }
    return [improve_triangles $refined $points]
}

proc ::RuledMesh::patch_within_size {rows points size} {
    set boundary [free_edges $rows]
    set limit2 [expr {(1.2*$size)**2}]
    foreach row $rows {
        lassign $row a b c
        foreach u [list $a $b $c] v [list $b $c $a] {
            if {![dict exists $boundary [edge_key $u $v]] &&
                [xy_distance2 [dict get $points $u] [dict get $points $v]] > $limit2} {
                return 0
            }
        }
    }
    return 1
}

proc ::RuledMesh::refine_patch_size {rows pointsVar size} {
    upvar 1 $pointsVar points
    # A boundary edge may be longer than the target size. Keep it intact
    # and use its length as a local floor for splitting its triangle.
    set boundary [free_edges $rows]
    set nextId [expr {min(0,[lindex [lsort -integer [dict keys $points]] 0])}]
    set size2 [expr {$size*$size}]
    set direction [expr {[polygon_area2 [polygon_points [lindex $rows 0] $points]] > 0 ? 1 : -1}]
    if {$direction < 0} {
        set flipped {}
        foreach row $rows {lappend flipped [lreverse $row]}
        set rows $flipped
    }
    for {set pass 0} {$pass < 8} {incr pass} {
        set candidates {}
        set incidence {}
        set i 0
        foreach row $rows {
            lassign $row a b c
            set area [signed_area2 {*}[polygon_points $row $points]]
            set limit $size2
            set lengths {}
            foreach u [list $a $b $c] v [list $b $c $a] w [list $c $a $b] {
                set key [edge_key $u $v]
                set length [xy_distance2 [dict get $points $u] [dict get $points $v]]
                if {[dict exists $boundary $key]} {set limit [expr {max($limit,$length)}]}
                lappend lengths [list $key $length $u $v $w]
            }
            foreach item $lengths {
                lassign $item key length u v w
                dict lappend incidence $key [list $i $u $v $w $area]
                if {$length > 1.20*$limit && abs($area) >= $size2 &&
                    ![dict exists $boundary $key]} {
                    dict set candidates $key 1
                }
            }
            incr i
        }
        set splits {}
        foreach key [dict keys $candidates] {
            lassign [dict get $incidence $key] first second
            lassign $first i a b c areaI
            lassign $second j d e f areaJ
            if {$second eq {} || [dict exists $splits $i] || [dict exists $splits $j]} {continue}
            if {min(abs($areaI),abs($areaJ)) < $size2} {continue}
            set id [incr nextId -1]
            dict set points $id [center_of [polygon_points $key $points]]
            dict set splits $i [list [list $a $id $c] [list $id $b $c]]
            dict set splits $j [list [list $d $id $f] [list $id $e $f]]
        }
        if {![dict size $splits]} {break}
        set refined {}
        set i 0
        foreach row $rows {
            if {[dict exists $splits $i]} {
                lappend refined {*}[dict get $splits $i]
            } else {
                lappend refined $row
            }
            incr i
        }
        set rows $refined
    }
    set rows [improve_triangles $rows $points]
    if {$direction < 0} {
        set flipped {}
        foreach row $rows {lappend flipped [lreverse $row]}
        return $flipped
    }
    return $rows
}

proc ::RuledMesh::split_patch_holes {outer holes points} {
    set polygons [list $outer]
    set boundaries [list $outer]
    foreach hole $holes {
        set loop [polygon_points $hole $points]
        foreach boundary $boundaries {
            set other [polygon_points $boundary $points]
            lassign [lindex $loop 0] x y
            set inside [point_in_polygon [polygon_scan_index $other] $x $y]
            lassign [lindex $other 0] x y
            if {$inside != ($boundary eq $outer) ||
                    ($boundary ne $outer && [point_in_polygon [polygon_scan_index $loop] $x $y])} {
                error "Edge 2 loops must be separate and inside Edge 1."
            }
            foreach edge [path_edges [concat $hole [lindex $hole 0]]] {
                lassign [polygon_points $edge $points] a b
                foreach side [path_edges [concat $boundary [lindex $boundary 0]]] {
                    lassign [polygon_points $side $points] c d
                    if {[segments_intersect $a $b $c $d]} {error "Selected loops touch or cross."}
                }
            }
        }
        lappend boundaries $hole
    }
    foreach hole $holes {
        lassign [dict get $points [lindex $hole 0]] x y
        set index 0
        foreach polygon $polygons {
            set outside [polygon_points $polygon $points]
            if {[point_in_polygon [polygon_scan_index $outside] $x $y]} {break}
            incr index
        }
        if {$index == [llength $polygons]} {error "Could not locate an inner loop inside the patch."}
        set obstacles {}
        foreach other $holes {
            if {$other ne $hole} {lappend obstacles {*}[path_edges [concat $other [lindex $other 0]]]}
        }
        set split [annular_polygons $polygon $hole $points $outside [polygon_points $hole $points] $obstacles]
        set polygons [lreplace $polygons $index $index {*}$split]
    }
    return $polygons
}

proc ::RuledMesh::constrained_patch {outer inner points surface spacing {extraHoles {}}} {
    set outside [polygon_points $outer $points]
    set island [polygon_points $inner $points]
    set area [expr {abs([polygon_area2 $outside])-abs([polygon_area2 $island])}]
    set polygons [list $outer]
    if {[llength $extraHoles]} {
        set polygons [split_patch_holes $outer [linsert $extraHoles 0 $inner] $points]
        foreach loop $extraHoles {set area [expr {$area-abs([polygon_area2 [polygon_points $loop $points]])}]}
    } elseif {[llength $inner]} {
        set polygons [annular_polygons $outer $inner $points $outside $island]
    }
    set rows {}
    foreach polygon $polygons {lappend rows {*}[ear_triangles $polygon $points]}
    set rows [refine_triangles $rows points $surface $spacing]

    set actual 0.0
    foreach row $rows {
        lassign [polygon_points $row $points] a b c
        set face [signed_area2 $a $b $c]
        if {$face <= 1.0e-10} {error "The triangulation contains a degenerate triangle."}
        set actual [expr {$actual+$face}]
    }
    if {$area <= 0 || abs($actual-$area) > 1.0e-7*$area} {error "The triangulation does not cover the selected region."}
    set free [free_edges $rows]
    foreach loop [concat [list $outer $inner] $extraHoles] {
        if {[llength $loop]} {remove_path_edges free [concat $loop [lindex $loop 0]]}
    }
    if {[dict size $free]} {error "The triangulation did not preserve the selected boundary."}
    if {[polygon_area2 $outside] < 0} {
        set reversed {}
        foreach row $rows {lappend reversed [lreverse $row]}
        set rows $reversed
    }
    return [list $rows $points]
}

proc ::RuledMesh::store_constrained_patch {rows points surface} {
    lassign $surface frame coefficients
    lassign $frame center u v normal scale
    set ids {}
    dict for {id point} $points {
        if {$id >= 0} {continue}
        lassign $point x y
        set z [height_at $coefficients $x $y]
        set xyz {}
        foreach p $center a $u b $v c $normal {
            lappend xyz [expr {$p+$scale*($a*$x+$b*$y+$c*$z)}]
        }
        *createnode {*}$xyz 0 0 0
        dict set ids $id [hm_latestentityid nodes]
    }
    hm_entityrecorder elems on
    set code [catch {
        # Verified for config 103 in HyperMesh 2022.3/Nastran.
        for {set i 0} {$i < [llength $rows]} {incr i 1024} {
            set flat {}
            foreach row [lrange $rows $i $i+1023] {
                foreach n $row {
                    if {$n < 0} {set n [dict get $ids $n]}
                    lappend flat $n
                }
            }
            *createarray [llength $flat] {*}$flat
            *createelements 103 1 1 [llength $flat]
        }
    } result options]
    hm_entityrecorder elems off
    if {$code} {return -options $options $result}
    return [hm_entityrecorder elems ids]
}
