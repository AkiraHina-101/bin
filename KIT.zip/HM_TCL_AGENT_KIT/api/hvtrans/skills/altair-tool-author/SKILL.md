---
name: altair-tool-author
description: Build or modify Tcl tools for HyperMesh Classic, HyperView and related Altair workflows using exact API contracts, focused local sources and separate validation stages. Applies to tool implementation, not documentation-only collection.
---

## Scoped package precedence

When MODULE_INDEX.md exists, use it and the package README/AI_TOOL_AUTHORING_GUIDE first. These scoped instructions override older broad-catalog paths below. API_INDEX.md and API_SOURCE_MAP.md are package entry aliases; no other software directory or archive is required. Missing from the index means outside package scope, not absence in Altair. Skills may be read from this bundle without installation. Never load all source files into context.



## Python helper runtime on a receiving machine

Bundled Python helpers target Python 3.8+ and use the standard library. Before the first Python helper invocation on a receiving machine, ask the user: "Please provide the full path to the Python 3.8 python.exe you want this project to use." If the user already supplied it in this session or receiving-project private configuration, reuse it without asking again. Do not substitute python from PATH, py, a bundled app interpreter or a newly installed interpreter. While waiting, continue reading Markdown and doing work that does not require Python.

Verify the supplied executable with `--version`; use that exact executable for subsequent helpers. Keep its real path in receiving-project private configuration/session only, never in shared api_hm or skills. In PowerShell use the call operator and quoted paths: `& "<PYTHON_EXE>" "<SKILL_DIR>/scripts/<HELPER>.py" ...`. If it is unavailable or below 3.8, report the issue and ask for a suitable executable; do not silently switch or install Python. Python version is separate from the target Tcl/Tk version. The Tcl parser also requires a compatible Tcl 8.5/8.6 library with the same architecture as the selected Python process.

# Build a source-grounded Altair tool

Discover the API library from the task/project configuration; start with AI_TOOL_AUTHORING_GUIDE.md. Use established user requirements for product/release, Classic/new UI, target Tcl/Tk, GUI/batch/client and solver profile. Resolve missing machine facts from configuration/confirmed launchers; do not silently choose the newest installation or repeatedly ask for established details.

Choose the relevant workflow and exact source contracts before writing external calls. If available, altair-api-lookup reduces routing work; the library's indexes and literal searches are sufficient without that skill. Map each external call to identity/source, arguments/options, prerequisites and task-specific gaps. Read only needed contracts and examples, not the whole library/history.

Prefer documented current generic interfaces over deprecated commands with missing legacy signatures. Preserve positional order, selectors, Tcl list expansion and option grouping. For hm_info, templatefilename is a top-level option, not an -appinfo key. For HWI, obtain handles from the matching client/window/model; do not borrow another class's method. For solver fields, use the active profile/template and documented data names; internal IDs, solver IDs and material assignment are separate. A zero material readback is not solver-deck validity.

Implement the user's requested behavior, including explicit selection semantics, validation, state cleanup and meaningful failure reporting. GUI callbacks and dynamic bodies are script dependencies, not just visual code. Use the GUI authoring supplement/altair-tcl-gui when applicable. Performance changes should reduce redundant model calls/refreshes while preserving recovery of modified state; do not hide failed APIs in catch and call the operation successful.

Run a non-executing matching Tcl parser when available, then compare actual API call forms to source. If altair-tcl-check is available, report its PARSE/CALL_FORM/CONTEXT/BEHAVIOR layers; otherwise report precisely the checking capability available. Dynamic expansion or unknown receiver/reader settings stay partial until resolved. Runtime/GUI tests must be appropriate to the tool and existing authorization, with isolated fixtures; respect user constraints.

Automatic knowledge improvement applies during Tcl tool work: if an essential contract is missing or new bounded evidence is obtained, add a precise additive reference/evidence record when the library is writable and this work is within scope. Follow REFERENCE_FORMAT.md and preservation rules; altair-api-maintain provides the procedure if available. No document deletion without specific user approval. A read-only/upload-only environment should emit a proposed patch and gap report rather than pretend publication.

Deliver the working artifact plus concise validation, source/target mismatch, unresolved constraints and usage. Keep actual machine configuration outside shared API docs. Do not expand the task into a runtime audit of the entire API inventory.

## Active modular packages

If MODULE_INDEX.md exists at the reader root, it is the scoped lookup authority; do not search an archive or outside the supplied package. Use README.md and AI_TOOL_AUTHORING_GUIDE.md first. Read exact matched bodies only. An absent record means outside this package scope, not absent from Altair; request the appropriate package from PACKAGES.md in the source hub. Skills and dependencies in a ready bundle may be read directly, without requiring their original installation path.

For documentation publication, MODULE_RULES.md overrides older supplement-routing guidance: new records belong to modules/<module>/records/<surface>, with API_RECORD metadata. Rebuild packages and update builder STATUS after publication. Retained official_help source bodies remain valid provenance. Preserve source product/owner/release labels; routing is not Classic/runtime certification.
