---
name: altair-api-lookup
description: Locate exact Altair API contracts in a portable local library for HyperMesh, HyperView, shared HWI, GUI and batch workflows. Use when choosing a command or class method; distinguish route-only entries from full contracts.
---

## Scoped package precedence

When MODULE_INDEX.md exists, use it and the package README/AI_TOOL_AUTHORING_GUIDE first. These scoped instructions override older broad-catalog paths below. In a source hub, --module <MODULE_ID> scopes exact lookup to a product module; transferable bundles already restrict the record inventory. API_INDEX.md and API_SOURCE_MAP.md are package entry aliases; no other software directory or archive is required. Missing from the index means outside package scope, not absence in Altair. Skills may be read from this bundle without installation. Never load all source files into context.



## Python helper runtime on a receiving machine

Bundled Python helpers target Python 3.8+ and use the standard library. Before the first Python helper invocation on a receiving machine, ask the user: "Please provide the full path to the Python 3.8 python.exe you want this project to use." If the user already supplied it in this session or receiving-project private configuration, reuse it without asking again. Do not substitute python from PATH, py, a bundled app interpreter or a newly installed interpreter. While waiting, continue reading Markdown and doing work that does not require Python.

Verify the supplied executable with `--version`; use that exact executable for subsequent helpers. Keep its real path in receiving-project private configuration/session only, never in shared api_hm or skills. In PowerShell use the call operator and quoted paths: `& "<PYTHON_EXE>" "<SKILL_DIR>/scripts/<HELPER>.py" ...`. If it is unavailable or below 3.8, report the issue and ask for a suitable executable; do not silently switch or install Python. Python version is separate from the target Tcl/Tk version. The Tcl parser also requires a compatible Tcl 8.5/8.6 library with the same architecture as the selected Python process.

# Find the right contract

Resolve the library from the user's supplied folder, project configuration or ALTAIR_API_ROOT. Confirm API_INDEX.md and AI_TOOL_AUTHORING_GUIDE.md exist. If absent, search the workspace for those filenames; never infer an install from examples in shared documents. Read the authoring guide once and only the relevant workflow thereafter.

Use [scripts/find_api.py](scripts/find_api.py) for exact scoped source transcripts:

```text
"<PYTHON_EXE>" "<SKILL_DIR>/scripts/find_api.py" --root <API_ROOT> --name <EXACT_NAME> [--owner <CLASS>] [--product <PRODUCT>] [--module <MODULE_ID>]
```

The helper reads Markdown only. It reports unique or ambiguous; a modular-package miss is not_in_package_scope (legacy reviewed-only mode: not_in_scoped_contracts). An ambiguous result requires the actual receiver class/client; do not pick the first result. A missing result is not proof that the API does not exist. Use API_SOURCE_MAP.md and exact-name searches in official_help for route-only entries, release-specific references and documented successors. Read the source transcript and linked caveats before creating a call; the returned signature is source notation, not executable Tcl.

When official_help/supplements/source_depth/LOOKUP.md exists, the helper also searches that broad source-body library if the reviewed subset has no match; use --broad to include all same-name records. It then reports not_in_local_source_records on a miss. Match the full source title for namespaced HWAT commands when appropriate. Read source_flags and the complete body: a unique route can still be a class/workflow page, contain source conflicts, adapted example paths or lack necessary sections. Owner routing from a title is not a documented handle acquisition chain. Unversioned/current-release catalogs remain outside the 2022.3 depth manifest.

Match product, surface, class/namespace and source release separately from the user's installed release. Keep deprecated commands, Tcl native commands, private installed helpers, solver template functions and same-name HWI methods distinct. Determine HWI receiver ownership from an explicit acquisition chain, not spelling similarity.

Do not invent parameters from index labels or flattened examples. Respect alternative syntax branches and definition-term grouping. Source typos and defaults in conflict stay visible. Consult release-matched installed Help/scripts/templates for an essential unresolved gap, using configured/discovered machine roots; official web sources are fallback when local material is insufficient and browsing is available.

Return the exact identity, relative reader pointer, source release/URL, applicable form and unresolved task-specific constraints. Do not claim runtime availability or behavior from documentation alone.

When present, official_help/supplements/web_completion/LOOKUP.md is also searched alongside source_depth. It contains live TOC/search/link-discovered additions, including explicitly labeled HWX UI and HyperView Player pages. A same-release HWX source does not certify Classic compatibility. Prefer exact product/client context and inspect any duplicate-name results.

## Active modular packages

If MODULE_INDEX.md exists at the reader root, it is the scoped lookup authority; do not search an archive or outside the supplied package. Use README.md and AI_TOOL_AUTHORING_GUIDE.md first. Read exact matched bodies only. An absent record means outside this package scope, not absent from Altair; request the appropriate package from PACKAGES.md in the source hub. Skills and dependencies in a ready bundle may be read directly, without requiring their original installation path.

For documentation publication, MODULE_RULES.md overrides older supplement-routing guidance: new records belong to modules/<module>/records/<surface>, with API_RECORD metadata. Rebuild packages and update builder STATUS after publication. Retained official_help source bodies remain valid provenance. Preserve source product/owner/release labels; routing is not Classic/runtime certification.
