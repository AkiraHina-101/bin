"""Read-only exact API lookup using reviewed and broad portable Markdown indexes.
Python compatibility: 3.8+, standard library only.
"""
import argparse,json,re
from functools import lru_cache
from pathlib import Path

@lru_cache(maxsize=4)
def _indexed_rows(path, modified_ns, size):
    content=Path(path).read_text(encoding='utf-8-sig')
    block=re.search(r'```json\s*\n(.*?)\n```',content,re.S)
    if not block:raise ValueError('Module index lacks JSON records')
    by_name={}
    for row in json.loads(block.group(1)):
        for name in set(v for v in (row.get('name'),row.get('title')) if v):
            by_name.setdefault(name,[]).append(row)
    return by_name

def lookup(root,name,owner=None,product=None,broad=False,module=None):
    root=Path(root)
    if not (root/'AI_TOOL_AUTHORING_GUIDE.md').is_file():
        raise ValueError('API root must contain AI_TOOL_AUTHORING_GUIDE.md')
    modular=root/'MODULE_INDEX.md'
    if modular.is_file():
        stat=modular.stat()
        indexed=_indexed_rows(str(modular.resolve()),stat.st_mtime_ns,stat.st_size)
        matches=[]
        for row in indexed.get(name,()):
            if module is not None and row.get('module')!=module:continue
            if name not in (row.get('name'),row.get('title')):continue
            if owner is not None and row.get('owner')!=owner:continue
            if product is not None and row.get('product')!=product:continue
            for key in ('reader_pointer','reused_body_pointer'):
                pointer=row.get(key)
                if not pointer:continue
                path=(root/pointer).resolve()
                try:path.relative_to(root.resolve())
                except ValueError:raise ValueError('Reader pointer escapes package')
                if not path.is_file():raise ValueError('Module reader pointer is missing')
            result=dict(row);result['syntax']=row.get('signature');result['source_url']=row['url']
            matches.append(result)
        reviewed=[m for m in matches if m.get('status')=='existing_reviewed_transcript']
        if reviewed and not broad:matches=reviewed
        return {'status':'unique' if len(matches)==1 else 'ambiguous' if matches else 'not_in_package_scope',
                'matches':matches,'limits':'Scoped source-only lookup. Missing from this index is not absence in Altair; request a relevant package. Source labels/routing are not target-context or runtime certification.'}
    if module is not None:raise ValueError('--module requires MODULE_INDEX.md')
    folder=root/'official_help/supplements/tool_contracts'
    matches=[]
    for path in sorted(folder.rglob('*.md')):
        body=path.read_text(encoding='utf-8-sig')
        head=re.search(r'^# ([^\n]+)',body,re.M)
        meta=re.search(r'^Product: (.*?)\. Owner/surface: (.*?)\. Source release: (.*?)\. Target',body,re.M)
        if not head or not meta:continue
        actual_product,actual_owner,release=meta.groups()
        if head.group(1)!=actual_owner+' '+name:continue
        if owner is not None and actual_owner!=owner:continue
        if product is not None and actual_product!=product:continue
        syntax=re.search(r'## Syntax\s+```text\n(.*?)\n```',body,re.S)
        source=re.search(r'\[Official Altair source\]\((https?://[^)]+)\)',body)
        matches.append({'product':actual_product,'owner':actual_owner,'name':name,'source_release':release,'reader_pointer':path.relative_to(root).as_posix(),'syntax':syntax.group(1) if syntax else None,'source_url':source.group(1) if source else None})
    depths=[root/'official_help/supplements'/folder/'LOOKUP.md' for folder in ('source_depth','web_completion')]
    depths=[path for path in depths if path.is_file()]
    if depths and (broad or not matches):
        for depth in depths:
            content=depth.read_text(encoding='utf-8')
            block=re.search(r'```json\s*\n(.*?)\n```',content,re.S)
            if not block:raise ValueError('Source-depth routing index lacks its JSON block')
            for row in json.loads(block.group(1)):
                if name not in (row.get('name'),row.get('title')):continue
                if owner is not None and row.get('owner')!=owner:continue
                if product is not None and row.get('product')!=product:continue
                if any(m.get('source_url') in (row['url'],row.get('canonical_source_url')) for m in matches):continue
                if not (root/row['reader_pointer']).is_file():raise ValueError('Source-depth reader pointer is missing')
                matches.append({'product':row['product'],'owner':row['owner'],'name':row['name'],
                                'source_release':row['source_release'],'reader_pointer':row['reader_pointer'],
                                'syntax':row.get('signature'),'source_url':row['url'],
                                'record_status':row['status'],'canonical_source_url':row.get('canonical_source_url'),'reused_body_pointer':row.get('reused_body_pointer'),'source_flags':row.get('source_flags',[]),
                                'owner_evidence':'source/title routing; actual receiver provenance still required'})
    return {'status':'unique' if len(matches)==1 else 'ambiguous' if matches else 'not_in_local_source_records' if depths else 'not_in_scoped_contracts','matches':matches,'limits':'Exact source lookup only; missing is not absence. Reviewed subset takes priority unless --broad; source-body records can be workflow/class pages or have explicit omissions/conflicts. Syntax is source notation, target/runtime not checked.'}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--name',required=True);p.add_argument('--owner');p.add_argument('--product');p.add_argument('--module',help='Restrict to one source module in a modular library/package');p.add_argument('--broad',action='store_true',help='Include all exact same-name source records, beyond the preferred reviewed subset');a=p.parse_args()
    try: result=lookup(a.root,a.name,a.owner,a.product,a.broad,a.module)
    except (ValueError,OSError) as e:p.exit(2,str(e)+'\n')
    print(json.dumps(result,ensure_ascii=True,indent=2))
