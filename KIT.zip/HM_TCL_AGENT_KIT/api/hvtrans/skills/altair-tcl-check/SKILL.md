---
name: altair-tcl-check
description: Review or validate Tcl scripts for HyperMesh, HyperView and related Altair tool workflows using exact API contracts and available local runtimes. Distinguish language parsing, API call forms, target-context availability and fixture behavior.
---

## Scoped package precedence

When MODULE_INDEX.md exists, use it and the package README/AI_TOOL_AUTHORING_GUIDE first. These scoped instructions override older broad-catalog paths below. API_INDEX.md and API_SOURCE_MAP.md are package entry aliases; no other software directory or archive is required. Missing from the index means outside package scope, not absence in Altair. Skills may be read from this bundle without installation. Never load all source files into context.



## Python helper runtime on a receiving machine

Bundled Python helpers target Python 3.8+ and use the standard library. Before the first Python helper invocation on a receiving machine, ask the user: "Please provide the full path to the Python 3.8 python.exe you want this project to use." If the user already supplied it in this session or receiving-project private configuration, reuse it without asking again. Do not substitute python from PATH, py, a bundled app interpreter or a newly installed interpreter. While waiting, continue reading Markdown and doing work that does not require Python.

Verify the supplied executable with `--version`; use that exact executable for subsequent helpers. Keep its real path in receiving-project private configuration/session only, never in shared api_hm or skills. In PowerShell use the call operator and quoted paths: `& "<PYTHON_EXE>" "<SKILL_DIR>/scripts/<HELPER>.py" ...`. If it is unavailable or below 3.8, report the issue and ask for a suitable executable; do not silently switch or install Python. Python version is separate from the target Tcl/Tk version. The Tcl parser also requires a compatible Tcl 8.5/8.6 library with the same architecture as the selected Python process.

# Altair Tcl checking

Bundled [non-executing Tcl parser](scripts/check_tcl.py) uses Tcl_ParseCommand/Tcl_ParseExpr through the Tcl 8.5/8.6 C ABI. It reads a script without evaluating it or loading its dependencies. It checks top-level commands, recognized literal control/procedure bodies, expressions and callbacks; dynamic dispatch, switch list bodies and source dependencies remain gaps. Tcl 9 libraries are unavailable for this binding, not silently treated as compatible. API semantics and target runtime still require the separate protocol.

Run the selected executable with `"<SKILL_DIR>/scripts/check_tcl.py" "<SCRIPT>" --target-tcl <confirmed_version>` (PowerShell: `& "<PYTHON_EXE>"` before these arguments). Resolve a parser DLL/shared library from `--tcl-library`, `ALTAIR_TCL_LIBRARY`, or a matching Python Tcl runtime. Omitting an unconfirmed target version is allowed and reports partial. Output is JSON; exit 1 means parse errors, 2 means parser unavailable, 0 may mean pass or partial: inspect PARSE and gaps, never infer pass from exit code alone.

For a combined read-only syntax pass and exact literal-name routing, run `audit_tcl_calls.py --root <API_ROOT> --script <SCRIPT> [--module hypermesh|hyperview] [--target-tcl <confirmed_version>]`. Add `--tcl-library <matching_library>` only when the parser does not discover a compatible Tcl library. This wrapper calls the non-executing parser and the local contract lookup; it does not source/evaluate the script, compare argument values to signatures, validate dynamic calls, or prove client availability. Review every candidate pointer and any ambiguous/out-of-scope name manually. `CALL_FORM` stays `partial` by design until those checks are complete.

Discover the API library from the task or project configuration. Begin with its AI_TOOL_AUTHORING_GUIDE.md. Use the established product/release, Classic/new UI, Tcl/Tk version, profile and GUI/batch/client context; discover missing facts rather than choosing the newest install.

Read [check protocol](references/CHECK_PROTOCOL.md) when doing a check.

## Workflow

1. Locate exact source contracts for external calls. Preserve syntax/case/options and source release. Match HWI method to its class/client.
2. Identify standard Tcl commands, local procedures, native Altair commands, handle methods, source dependencies and dynamic callsites. A regex inventory is a lead list, not proof of exhaustiveness.
3. Use a trustworthy non-executing parser/analyzer when available. Record nested-body and callback coverage. info complete or successful disassembly alone yields partial, never syntax passed.
4. Compare static call forms to contracts. Variable expansion, optional forms and overloaded calls may require task/context evidence; report unresolved cases.
5. Check availability only in the correct installed context when that access is available and needed. Don't call native APIs just to inspect arity.
6. Run bounded behavior tests only when needed for the script task and authorized by its scope, using separate fixtures/processes. Respect GUI-test constraints. Don't attach to or mutate an active user model as a syntax test.
7. Report PARSE, CALL_FORM, CONTEXT and BEHAVIOR separately, with pass/failed/partial/not_run/unavailable. State actual checker/runtime version and limitations.

Never source an entire unknown script, execute syntax placeholders, mock every unknown command to return success, or equate registration with call/behavior correctness. Documentation-only collection does not require runtime verification of all clear public APIs.

For Tcl tool work, add an exact missing reference or new fixture evidence when useful, following library preservation/portable-path rules. Keep runtime evidence separate from published contracts and update the builder handoff when the library changes.

## Wrapper result handling

`audit_tcl_calls.py` preserves unavailable parser reasons and returns exit 2 with CALL_FORM=not_run when parsing cannot run. Parse errors return exit 1. Exit 0 can still mean partial. The report retains handle_method_candidates with receiver/line/method and unknown owner; resolve the documented acquisition chain manually, never by method spelling alone. The exact lookup helper reuses a stat-keyed index within the same process.
