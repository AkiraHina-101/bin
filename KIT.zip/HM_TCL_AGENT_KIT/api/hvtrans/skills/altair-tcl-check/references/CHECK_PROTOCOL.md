# Tcl/API checking protocol

The bundled parser implements the PARSE layer; the protocol reports evidence at four levels. It does not guarantee correct physics, geometry, solver decks or GUI behavior from static syntax.

## PARSE — Tcl language

- Record the target application's actual Tcl/Tk version; do not infer it from the product year.
- info complete can detect unclosed delimiters, but a return value of 1 does not validate every command or argument. [Tcl 8.5 info manual](https://www.tcl-lang.org/man/tcl8.5/TclCmd/info.htm)
- Preferred implementation: use a non-executing Tcl parser aligned with the target grammar, such as a small binding/helper around Tcl_ParseCommand, or a maintained analyzer with its version and scope declared. The bundled check_tcl.py implements Tcl 8.5/8.6 bindings; other grammar/ABI versions remain unavailable. [Tcl_ParseCommand](https://www.tcl-lang.org/man/tcl8.5/TclLib/ParseCmd.htm)
- Recurse into statically identified script bodies: proc, conditional/loop bodies, literal namespace eval, and recognized literal callbacks. Expressions and switch/list/option forms have their own grammar/command semantics; one generic brace scan does not validate them.
- Braced words may be data or deferred scripts. No exhaustive recursive parse is possible for all runtime-generated Tcl strings. Track dynamic/unclassified bodies as partial.
- Compilation/disassembly may defer syntax errors; do not treat a successful operation as a pass. Don't rely on unsupported compiler interfaces as stable compatibility contracts.
- Parser host must not eval/source user input or load user dependencies. Reading a file and calling the parse API must remain separate from execution.
- If only a structural check exists, report PARSE=partial and identify the checker gap.

## CALL_FORM — application API

Compare each call with exact owner/name/release/signature, required arguments/options, enums/units, profile and preconditions. Use a literal-name search, then read the full relevant local record. Dynamic arguments/command names cannot be validated solely by static arity.

The optional `audit_tcl_calls.py` helper joins the non-executing parser inventory to exact local name lookup. It is a candidate router: it does not compare word counts with signature syntax, does not resolve variable-based HWI receivers, and intentionally reports `CALL_FORM=partial`. Read each returned source body and perform the argument/context comparison yourself.

Mark private installed helpers as installed-source; mark Tcl core and project procs separately. A missing lookup is not a native API error. Don't obtain C-native signatures with info args; registration is presence only. Do not convert Help optional placeholders into executable syntax mechanically.

Examples flattened by the collector require original source retrieval or explicit treatment as non-runnable. All proposed examples should identify source-verbatim versus derived code and whether they ran.

## CONTEXT — availability

Use project configuration and confirmed installation. Record product/build, Classic/new UI, Tcl/Tk, GUI/batch/client, solver profile and relevant packages. Inspect known APIs in a bounded query-only probe or relevant source/Help; do not execute model-changing commands just to see if they are present.

A GUI-only method missing in hmbatch is a context limitation. HWI handles must come from a matching active client/model; creating a handle does not validate all its method arguments. If an alternate release is the only available installation, report target unavailable and do not count the run as target verification.

Machine paths and credentials stay outside shared API docs. An installed application can still be inaccessible to the AI or require a license. A Python Tcl wrapper may lack init.tcl even when Altair is installed.

## BEHAVIOR — task-specific fixture

When the task needs runtime verification, create a small scratch model/input and suitable assertions. Use an isolated process/fixture; coordinate license/model access according to the user's existing authorization. Pure documentation tasks do not initiate model tests.

For a solid/RBE2/renumber tool, meaningful outcomes may include connectivity/element type, positive valid element volumes, the intended dependent-node ring, property/card assignment and renumber collision handling. Choose assertions that reflect the actual script change. GUI-render testing is a separate scope; if not requested/allowed, report not_run.

Pass means only the recorded fixture/context. Catching an error, creating an output file, or obtaining an element count is not sufficient proof of intended behavior. Keep probe name, version, operation and result in portable evidence summaries; local log locations belong to machine configuration.

## Report template

- Target: product/build, surface/context/profile; source release.
- PARSE: status, checker/version, checked bodies, dynamic gaps.
- CALL_FORM: status, matched contract count, unresolved calls/options.
- CONTEXT: status, observed availability and exact runtime context.
- BEHAVIOR: status, fixture operation/readback, limits.
- Next action: smallest missing source/check needed for this tool.

Statuses: pass, failed, partial, not_run, unavailable. An aggregate 'fully checked' statement requires all task-required gates to pass. A partial/not_run gate must remain visible.

## Wrapper result handling

`audit_tcl_calls.py` preserves unavailable parser reasons and returns exit 2 with CALL_FORM=not_run when parsing cannot run. Parse errors return exit 1. Exit 0 can still mean partial. The report retains handle_method_candidates with receiver/line/method and unknown owner; resolve the documented acquisition chain manually, never by method spelling alone. The exact lookup helper reuses a stat-keyed index within the same process.
