"""Run the non-executing Tcl parser and route literal Altair call names to local source contracts.
Python 3.8+, standard library. Routing is not argument validation or runtime proof.
"""
import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path


def load_lookup():
    for base in Path(__file__).resolve().parents:
        helper = base / 'skills' / 'altair-api-lookup' / 'scripts' / 'find_api.py'
        if helper.is_file():
            spec = importlib.util.spec_from_file_location('altair_api_lookup_find_api', str(helper))
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module.lookup
    raise RuntimeError('Could not locate bundled altair-api-lookup/scripts/find_api.py')


PREFIXES = ('hm_', '*', 'hwi', 'hwI', 'hwc', 'poI')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, help='API reader root containing AI_TOOL_AUTHORING_GUIDE.md')
    parser.add_argument('--script', required=True, help='Tcl script to parse without executing')
    parser.add_argument('--module', help='Optional exact source module, e.g. hypermesh or hyperview')
    parser.add_argument('--target-tcl', help='Confirmed Tcl version, such as 8.5')
    parser.add_argument('--tcl-library', help='Compatible Tcl parser library path')
    args = parser.parse_args()

    checker = Path(__file__).with_name('check_tcl.py')
    command = [sys.executable, str(checker), args.script]
    if args.target_tcl:
        command += ['--target-tcl', args.target_tcl]
    if args.tcl_library:
        command += ['--tcl-library', args.tcl_library]
    try:
        completed = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   universal_newlines=True, timeout=180)
        parsed = json.loads(completed.stdout)
    except (OSError, subprocess.TimeoutExpired, ValueError) as exc:
        parsed = {'PARSE':'unavailable', 'reason':str(exc)}
    if parsed.get('PARSE') == 'unavailable':
        print(json.dumps({
            'PARSE':'unavailable', 'reason':parsed.get('reason','Parser unavailable'),
            'target_tcl':args.target_tcl, 'CALL_FORM':'not_run',
            'CONTEXT':'not_run', 'BEHAVIOR':'not_run',
            'script':Path(args.script).name, 'calls':[],
            'handle_method_candidates':parsed.get('handle_method_candidates',[])
        }, ensure_ascii=False, indent=2))
        return 2
    lookup = load_lookup()

    call_sites = {}
    for call in parsed.get('calls', []):
        name = call.get('name', '')
        if not name.startswith(PREFIXES):
            continue
        call_sites.setdefault(name, []).append({
            'line': call.get('line'),
            'word_count': call.get('word_count'),
            'dynamic_words': call.get('dynamic_words'),
        })

    routed = []
    for name in sorted(call_sites):
        result = lookup(Path(args.root), name, broad=False, module=args.module)
        matches = []
        for row in result.get('matches', []):
            matches.append({key: row.get(key) for key in (
                'product', 'owner', 'source_release', 'syntax', 'signature',
                'reader_pointer', 'source_url', 'status', 'record_status',
                'source_flags', 'runtime'
            ) if row.get(key) is not None})
        routed.append({
            'name': name,
            'callsites': call_sites[name],
            'lookup_status': result['status'],
            'candidates': matches,
        })

    unresolved = [row['name'] for row in routed if row['lookup_status'] != 'unique']
    dynamic_sites = sum(site.get('dynamic_words', 0) for sites in call_sites.values() for site in sites)
    output = {
        'checker': parsed.get('checker'),
        'parser_version': parsed.get('parser_version'),
        'target_tcl': parsed.get('target_tcl'),
        'PARSE': parsed.get('PARSE'),
        'parse_errors': parsed.get('errors', []),
        'parse_gaps': parsed.get('gaps', []),
        'handle_method_candidates': parsed.get('handle_method_candidates', []),
        'handle_method_limits': 'Receiver owner remains unknown until an explicit acquisition chain establishes it; no same-name owner is inferred.',
        'coverage': parsed.get('coverage', {}),
        'CALL_FORM': 'partial',
        'CALL_FORM_limits': [
            'Exact name routing only; Tcl argument/option values are not compared with source forms.',
            'Dynamic command names and variable-based handle methods need manual review.',
            'A unique source match does not establish the correct client, target availability or behavior.',
        ],
        'literal_api_names': len(routed),
        'unresolved_or_ambiguous_names': unresolved,
        'dynamic_words_in_literal_calls': dynamic_sites,
        'calls': routed,
        'CONTEXT': 'not_run',
        'BEHAVIOR': 'not_run',
        'script': Path(args.script).name,
    }
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 1 if parsed.get('PARSE') == 'failed' or parsed.get('errors') else 0


if __name__ == '__main__':
    sys.exit(main())
