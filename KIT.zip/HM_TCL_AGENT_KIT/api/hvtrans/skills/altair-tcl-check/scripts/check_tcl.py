"""Non-executing Tcl 8.5/8.6 parser. No Tcl_Eval/Tcl_Init/source calls.
Python compatibility: 3.8+, standard library only.
ABI: https://github.com/tcltk/tcl/blob/core-8-5-9/generic/tcl.h
     https://github.com/tcltk/tcl/blob/core-8-6-15/generic/tcl.h
API: https://www.tcl-lang.org/man/tcl8.6/TclLib/ParseCmd.htm
"""
import argparse
import ctypes as C
import ctypes.util
import json
import os
from pathlib import Path
import sys

class Token(C.Structure):
    _fields_=[('type',C.c_int),('start',C.c_void_p),('size',C.c_int),('numComponents',C.c_int)]
class Parse(C.Structure):
    _fields_=[('commentStart',C.c_void_p),('commentSize',C.c_int),('commandStart',C.c_void_p),('commandSize',C.c_int),('numWords',C.c_int),('tokenPtr',C.POINTER(Token)),('numTokens',C.c_int),('tokensAvailable',C.c_int),('errorType',C.c_int),('string',C.c_void_p),('end',C.c_void_p),('interp',C.c_void_p),('term',C.c_void_p),('incomplete',C.c_int),('staticTokens',Token*20)]

class Parser:
    def __init__(self,library):
        self.lib=C.CDLL(str(library))
        self.lib.Tcl_GetVersion.argtypes=[C.POINTER(C.c_int)]*4
        versions=[C.c_int() for _ in range(4)]
        self.lib.Tcl_GetVersion(*[C.byref(x) for x in versions])
        self.version='.'.join(str(x.value) for x in versions[:3])
        if tuple(x.value for x in versions[:2]) not in ((8,5),(8,6)):
            raise ValueError('This binding supports Tcl 8.5/8.6 ABI only; target library unsupported')
        self.lib.Tcl_CreateInterp.restype=C.c_void_p
        self.lib.Tcl_DeleteInterp.argtypes=[C.c_void_p]
        self.lib.Tcl_GetStringResult.argtypes=[C.c_void_p]; self.lib.Tcl_GetStringResult.restype=C.c_char_p
        self.lib.Tcl_ParseCommand.argtypes=[C.c_void_p,C.c_void_p,C.c_int,C.c_int,C.POINTER(Parse)]
        self.lib.Tcl_ParseCommand.restype=C.c_int
        self.lib.Tcl_ParseExpr.argtypes=[C.c_void_p,C.c_void_p,C.c_int,C.POINTER(Parse)]
        self.lib.Tcl_ParseExpr.restype=C.c_int
        self.lib.Tcl_FreeParse.argtypes=[C.POINTER(Parse)]
        self.interp=self.lib.Tcl_CreateInterp()
        if not self.interp: raise RuntimeError('Cannot allocate parser interpreter')
        self.errors=[]; self.gaps=[]; self.calls=[]; self.handle_calls=[]; self.sites=set(); self.commands=0; self.bodies=0; self.expressions=0
    def close(self):
        if self.interp: self.lib.Tcl_DeleteInterp(self.interp); self.interp=None
    def line(self,offset): return self.data[:max(0,offset)].count(b'\n')+1
    def gap(self,offset,reason): self.gaps.append({'line':self.line(offset),'reason':reason})
    def error(self,offset,kind):
        msg=self.lib.Tcl_GetStringResult(self.interp)
        self.errors.append({'line':self.line(offset),'kind':kind,'message':msg.decode('utf-8','replace') if msg else 'parse error'})
    def read_tokens(self,p):
        return [{'type':t.type,'start':t.start-self.base,'size':t.size,'components':t.numComponents} for t in [p.tokenPtr[i] for i in range(p.numTokens)]]
    def substitutions(self,tokens,depth):
        for t in tokens:
            if t['type']==16:
                self.script(t['start']+1,t['size']-2,depth+1)
    def expr(self,w,depth):
        if w is None or not w['literal']:
            self.gap(w['start'] if w else 0,'dynamic expression'); return
        start,size=w['content_start'],w['content_size']; p=Parse()
        rc=self.lib.Tcl_ParseExpr(self.interp,self.base+start,size,C.byref(p))
        if rc:
            self.error(start,'expression'); self.lib.Tcl_FreeParse(C.byref(p)); return
        try: self.expressions+=1; self.substitutions(self.read_tokens(p),depth)
        finally: self.lib.Tcl_FreeParse(C.byref(p))
    def body(self,w,depth,label):
        if w and w['literal']:
            self.bodies+=1; self.script(w['content_start'],w['content_size'],depth+1)
        else: self.gap(w['start'] if w else 0,'dynamic '+label)
    def process(self,words,depth):
        if not words: return
        for i,w in enumerate(words[:-1]):
            if w['value'] in ('-command','-postcommand','-validatecommand','-invalidcommand','-xscrollcommand','-yscrollcommand'):
                self.body(words[i+1],depth,'widget callback')
        name=words[0]['value']
        if name is None:
            if len(words)>1 and words[1]['literal'] and words[1]['value'] and words[1]['value'][0].isupper():
                self.handle_calls.append({'line':self.line(words[0]['start']),'method':words[1]['value'],'owner':'unknown','receiver':self.data[words[0]['start']:words[0]['start']+words[0]['content_size']].decode('utf-8','replace'),'word_count':len(words)})
            self.gap(words[0]['start'],'dynamic command/handle dispatch'); return
        name=name[2:] if name.startswith('::') else name
        if name.startswith('*') or name.startswith('hm_') or name=='hwi':
            self.calls.append({'line':self.line(words[0]['start']),'name':name,'word_count':len(words),'dynamic_words':sum(not w['literal'] for w in words)})
        get=lambda i: words[i] if i<len(words) else None
        if name=='proc': self.body(get(3),depth,'proc body')
        elif name=='namespace' and get(1) and get(1)['value']=='eval':
            if len(words)==4: self.body(get(3),depth,'namespace body')
            else: self.gap(words[0]['start'],'namespace script concatenation')
        elif name=='if':
            i=1
            while i<len(words):
                value=get(i)['value']
                if value=='else': self.body(get(i+1),depth,'else body'); break
                if value=='elseif': i+=1
                self.expr(get(i),depth); i+=1
                if get(i) and get(i)['value']=='then': i+=1
                self.body(get(i),depth,'if body'); i+=1
        elif name=='while': self.expr(get(1),depth); self.body(get(2),depth,'while body')
        elif name=='for':
            self.body(get(1),depth,'for start'); self.expr(get(2),depth); self.body(get(3),depth,'for next'); self.body(get(4),depth,'for body')
        elif name in ('foreach','lmap'): self.body(get(len(words)-1),depth,name+' body')
        elif name=='catch': self.body(get(1),depth,'catch body')
        elif name=='try':
            self.body(get(1),depth,'try body'); i=2
            while i<len(words):
                if get(i)['value']=='finally': self.body(get(i+1),depth,'finally body'); i+=2
                elif get(i)['value'] in ('on','trap'): self.body(get(i+3),depth,'try handler'); i+=4
                else: self.gap(get(i)['start'],'unrecognized try handler'); break
        elif name=='expr':
            if len(words)==2: self.expr(get(1),depth)
            else: self.gap(words[0]['start'],'expression concatenation')
        elif name=='eval':
            if len(words)==2: self.body(get(1),depth,'eval script')
            else: self.gap(words[0]['start'],'eval concatenation')
        elif name=='uplevel':
            if len(words)==2: self.body(get(1),depth,'uplevel body')
            elif len(words)==3 and get(1)['literal']: self.body(get(2),depth,'uplevel body')
            else: self.gap(words[0]['start'],'uplevel dynamic/concatenated script')
        elif name=='bind' and len(words)>=4: self.body(get(3),depth,'bind callback')
        elif name=='after' and len(words)>=3:
            if len(words)==3 and get(1)['value'] not in ('cancel','info'): self.body(get(2),depth,'after callback')
            elif get(1)['value'] not in ('cancel','info'): self.gap(words[0]['start'],'after concatenation')
        elif name=='switch': self.gap(words[0]['start'],'switch body/list semantics not yet analyzed')
        elif name=='source': self.gap(words[0]['start'],'source dependency not executed or expanded')
    def script(self,start,size,depth=0):
        if depth>80: self.gap(start,'maximum nesting depth'); return
        if (start,size) in self.sites: return
        self.sites.add((start,size)); end=start+size; offset=start
        while offset<end:
            p=Parse(); rc=self.lib.Tcl_ParseCommand(self.interp,self.base+offset,end-offset,0,C.byref(p))
            if rc:
                self.error(offset,'command'); self.lib.Tcl_FreeParse(C.byref(p)); return
            try:
                if not p.commandStart or p.commandSize<=0: break
                next_offset=p.commandStart-self.base+p.commandSize
                if next_offset<=offset or next_offset>end: self.gap(offset,'parser boundary anomaly'); return
                tokens=self.read_tokens(p); words=[]; i=0
                while i<len(tokens):
                    t=tokens[i]
                    if t['type'] not in (1,2,256): self.gap(offset,'unrecognized word token'); break
                    raw=self.data[t['start']:t['start']+t['size']]
                    literal=t['type']==2 and t['components']==1 and i+1<len(tokens) and tokens[i+1]['type']==4
                    child=tokens[i+1] if literal else None
                    words.append({'start':t['start'],'literal':literal,'value':self.data[child['start']:child['start']+child['size']].decode('utf-8','replace') if child else None,'content_start':child['start'] if child else t['start'],'content_size':child['size'] if child else t['size']})
                    if t['type']==256: self.gap(t['start'],'runtime argument expansion')
                    i+=1+t['components']
                if words: self.commands+=1
                self.substitutions(tokens,depth); self.process(words,depth)
                offset=next_offset
            finally: self.lib.Tcl_FreeParse(C.byref(p))
    def check(self,text,target=None):
        self.data=text.encode('utf-8'); self.buffer=C.create_string_buffer(self.data); self.base=C.addressof(self.buffer)
        self.script(0,len(self.data))
        if target is None: self.gap(0,'target Tcl grammar version not supplied')
        elif not self.version.startswith(target+'.') and self.version!=target: self.gap(0,'parser/target Tcl version mismatch')
        return {'checker':'Tcl_ParseCommand/Tcl_ParseExpr binding v2','parser_version':self.version,'target_tcl':target,'PARSE':'failed' if self.errors else ('partial' if self.gaps else 'pass'),'errors':self.errors,'gaps':self.gaps,'coverage':{'commands':self.commands,'literal_bodies':self.bodies,'literal_expressions':self.expressions,'expressions_evaluated':0,'scripts_executed':0},'calls':self.calls,'handle_method_candidates':self.handle_calls,'CALL_FORM':'not_run','CONTEXT':'not_run','BEHAVIOR':'not_run','limits':['Checks selected literal bodies/callbacks; switch/list forms, dynamic dispatch and sourced dependencies remain explicit gaps.','Does not validate all Tcl core command arity or API contract semantics.']}

def discover(explicit,target=None):
    selected=explicit or os.environ.get('ALTAIR_TCL_LIBRARY')
    if selected: return selected
    pattern='tcl'+target.replace('.','')[:2]+'*.dll' if target else 'tcl8[56]*.dll'
    candidates=list((Path(sys.base_prefix)/'DLLs').glob(pattern))
    if len(candidates)==1: return str(candidates[0])
    if os.name!='nt':
        candidate=ctypes.util.find_library('tcl'+(target or '8.6'))
        if candidate: return candidate
    raise ValueError('Supply --tcl-library or ALTAIR_TCL_LIBRARY; no unique matching Tcl 8.5/8.6 parser library found')

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('script',type=Path); ap.add_argument('--tcl-library'); ap.add_argument('--target-tcl'); args=ap.parse_args()
    parser=None
    try:
        parser=Parser(discover(args.tcl_library,args.target_tcl)); report=parser.check(args.script.read_text(encoding='utf-8-sig'),args.target_tcl); report['script']=args.script.name
    except (OSError,ValueError) as e: report={'PARSE':'unavailable','reason':str(e),'CALL_FORM':'not_run','CONTEXT':'not_run','BEHAVIOR':'not_run'}
    finally:
        if parser: parser.close()
    print(json.dumps(report,ensure_ascii=True,indent=2))
    raise SystemExit(1 if report['PARSE']=='failed' else 2 if report['PARSE']=='unavailable' else 0)
if __name__=='__main__': main()
