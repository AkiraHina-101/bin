---
name: altair-runtime-check
description: Verify target-context availability and bounded behavior of Altair Tcl tools in the correct installed product using isolated fixtures. Use when an implementation needs software checks; does not audit all documented APIs or substitute runtime tests for parsing.
---


## Python helper runtime on a receiving machine

Bundled Python helpers target Python 3.8+ and use the standard library. Before the first Python helper invocation on a receiving machine, ask the user: "Please provide the full path to the Python 3.8 python.exe you want this project to use." If the user already supplied it in this session or receiving-project private configuration, reuse it without asking again. Do not substitute python from PATH, py, a bundled app interpreter or a newly installed interpreter. While waiting, continue reading Markdown and doing work that does not require Python.

Verify the supplied executable with `--version`; use that exact executable for subsequent helpers. Keep its real path in receiving-project private configuration/session only, never in shared api_hm or skills. In PowerShell use the call operator and quoted paths: `& "<PYTHON_EXE>" "<SKILL_DIR>/scripts/<HELPER>.py" ...`. If it is unavailable or below 3.8, report the issue and ask for a suitable executable; do not silently switch or install Python. Python version is separate from the target Tcl/Tk version. The Tcl parser also requires a compatible Tcl 8.5/8.6 library with the same architecture as the selected Python process.

# Verify in the intended application context

Start from the tool's API mapping and the user's established product/release/profile/GUI-test constraints. Resolve actual executable, runtime and template roots from project configuration or a confirmed launcher. Multiple installations must not silently select the newest one. A source release is not an installed availability assertion.

Define the smallest operation and observable result that resolve the implementation uncertainty. Prefer read-only context discovery; execute mutations only when necessary and authorized by task scope. Existing authorization persists. Use a separate scratch model/process when available; never use the user's active model as a generic syntax fixture. Stop on an unexpected model change, license/context failure or crash; preserve evidence and do not retry blindly.

Read the library's exact contract and context notes. Registration proves presence only in that context; info args is valid for Tcl procedures, not native command arity. HyperMesh Batch cannot validate GUI-only behavior: its documented Tk/display restrictions apply. A mocked success value is not API validation.

For a model mutation, record preconditions and readback of the relevant entity/relation/IDs after the operation. For a result workflow, confirm the intended client/model/result selection. For a GUI callback, check only the requested behavior in an appropriate test window when authorized. Do not infer solver-deck validity from property materialid=0, component assignment, parser success or process exit0.

Separate PARSE, CALL_FORM, CONTEXT and BEHAVIOR. Report software/runtime, exact form, fixture, actions, observed result and limitations. No operation means not_run, not pass. A failed probe does not prove a command unsupported everywhere. Clear public docs do not require a mass runtime audit.

Keep actual executable/log/model paths in machine configuration or private test storage. Shared evidence contains portable probe name, version, action and result, with placeholders/relative locators. Publish a new bounded fact only with its source/context; use additive documentation and update handoff. If software access is absent, provide a concrete probe plan and mark context/behavior unavailable rather than claim tests ran.
