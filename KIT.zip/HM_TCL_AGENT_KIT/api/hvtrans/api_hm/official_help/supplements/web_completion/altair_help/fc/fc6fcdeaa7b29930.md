# HvTrans

Product/source label: HyperWorks Desktop / supporting or other source-labeled client. Owner/title-derived routing: Not stated by source. Application/Type: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_intro_r.htm). Source body only; navigation excluded. Evidence: source-derived structured transcription. Owner routing from explicit title/source label is not proof of a production receiver acquisition chain.

Source SHA256: `99c0191f39317c3fdf8dd08b9b7c7d6e6d42234a7b0cde18097574a4f93a6f94`. Record: `fc6fcdeaa7b29930`.

## Sufficiency and omissions

Syntax, Inputs, Returns/Outputs and Errors exist only where the source body states them. Missing sections are not unsupported behavior; no defaults, substitutions or call forms inferred. This is source detail, not a semantic/runtime certification.

- Syntax not stated by source; may be workflow/class/navigation rather than callable API

## Original topic body (structured)

## HvTrans


HvTrans is a result translator for HyperView that translates solver result files to .h3d files.


HvTrans runs in two modes, GUI or BatchMode.
