# Launch HvTrans

Product/source label: HyperWorks Desktop / supporting or other source-labeled client. Owner/title-derived routing: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_launch_t.htm). Source SHA256: `28bde9b0fa9939c1a7935c409c22169fc3e628ab4443a1db9006ab23f7f88cf6`.

## Reused exact topic body

The parsed topic HTML, title, product and owner match an existing local record exactly. Reuse its structured text instead of duplicating the full document. This comparison does not certify image bytes, installed behavior or Classic/new UI equivalence.

[Read retained topic body](../../altair_help/1a/1a7d23b7fa3f531b.md). [Canonical source](https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_launch_t.htm). Exact parsed topic SHA256: `5b6e21d4047f4b2bd68d6e1cf6f2b44557e4dcaf606112bef57477e57b8f2b9d`.

Source flags:
- Syntax not stated by source; may be workflow/class/navigation rather than callable API
