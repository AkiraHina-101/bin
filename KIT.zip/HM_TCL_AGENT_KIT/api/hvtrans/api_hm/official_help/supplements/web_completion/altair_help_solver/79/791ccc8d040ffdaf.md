# HvTrans

Product/source label: HyperWorks Desktop / supporting or other source-labeled client. Owner/title-derived routing: Not stated by source. Source release: 2022.3. Target compatibility: not checked. Runtime: not_run.

[Official source](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_intro_r.htm). Source SHA256: `99c0191f39317c3fdf8dd08b9b7c7d6e6d42234a7b0cde18097574a4f93a6f94`.

## Reused exact topic body

The parsed topic HTML, title, product and owner match an existing local record exactly. Reuse its structured text instead of duplicating the full document. This comparison does not certify image bytes, installed behavior or Classic/new UI equivalence.

[Read retained topic body](../../altair_help/fc/fc6fcdeaa7b29930.md). [Canonical source](https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_intro_r.htm). Exact parsed topic SHA256: `5b8c1e526fded9e39f841b9f6f44ad9e3d5ba3fd48df846ac600e8e6ea8a552a`.

Source flags:
- Syntax not stated by source; may be workflow/class/navigation rather than callable API
