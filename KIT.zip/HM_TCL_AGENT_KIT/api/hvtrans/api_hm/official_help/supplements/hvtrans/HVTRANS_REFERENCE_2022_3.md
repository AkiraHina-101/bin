# HvTrans reference (Altair Simulation Help 2022.3)

HvTrans is Altair's result translator for HyperView. It writes solver result data to H3D and provides a GUI and a batch mode. This page summarizes the public 2022.3 Help; it does not establish undocumented Tcl commands or behavior in another release.

## Choose a translation workflow

In the GUI, load the result file, choose subcases, simulations, result types/components and optional model data, then translate to H3D. Simulation selection can be by individual list or by a From/To/By step range. “Output H3D for every step” can split a large translation into separate H3D files. Model information may come from the result file or an input deck. The Help lists Abaqus, ANSYS, LS-DYNA, Nastran/OptiStruct, PAM-CRASH and Radioss Block input decks for model information. [Translate a Solver Results File to an H3D File](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_translate_results_file_t.htm)

Subcases determine which simulations and result types appear in the dialog. Tensor output can preserve the full component stress data for later derived-stress evaluation in HyperView; selecting individual components writes selected scalar data. The GUI page also describes layer and model-component filters. [Translate a Solver Results File to an H3D File](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_translate_results_file_t.htm)

## Batch mode

Altair documents this command-line form:

```text
hvtrans.exe -c<config file> <result file> <model file> -o<output file> -z[percent]
```

The model file is optional: omit it to leave model information out of H3D; if model data is in the result file, pass that same result file as the model file. The documented options are:

| Option | Documented purpose |
|---|---|
| `-a` | Translate all results without a configuration file. |
| `-ar` | Translate results only, without model information. |
| `-c<config>` | Read one or more comma-separated configuration files. |
| `-help`, `-h` | Show help. |
| `-m` | Translate model only. |
| `-o<output>` | Set the H3D output filename. |
| `-ns` | Export the model without sets. |
| `-xml<FATXML>` | Embed a FATXML file in H3D. |
| `-xmlfile<file>` | Create a file from FATXML contents in the result file. |
| `-z [percent]` | Enable result compression; documented default allowable error is 0.01 percent. |

Compression can delay translation. The Help's examples demonstrate extracting all results and model data, choosing a separate model deck, and extracting result-only H3D. [Batch Mode](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_batch_mode_r.htm)

The Help gives the executable's installation location as a release-specific example. To keep this library portable, resolve it at runtime under `<ALTAIR_INSTALL_DIR>` rather than copying a machine-specific path into a script or reference.

## Configuration files

Configurations can be authored manually or saved from the GUI. To reapply configured result-type selections, first load the result file and then load the configuration. A configuration can select parts, subcases, simulations, result data requests, readers and compression settings. `ResultReader` and `ModelReader` can force a reader; otherwise HvTrans detects it. A command-line `-z` error setting takes precedence over the configuration's compression setting. A configuration containing derived “Linear Superposition” or “Envelope” subcases produces a warning because those derived subcases are ignored in translation. [Configuration Files](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_configuration_files_r.htm)

## API boundary and useful routes

The public pages document GUI operations, configuration-file structure and the `hvtrans.exe` command line. They do not document Tcl calls such as `hvtrans control ...`, `hvtrans result ...`, or `::hw::RunHVTrans` as a public API contract. Treat those names as installation/source-derived unless separately confirmed by a public Altair contract for the target release. The older mixed workflow note is preserved in `legacy_material` (outside this package; choose another package if needed) with its provenance intact.

- [HvTrans overview](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_intro_r.htm)
- [Launch HvTrans](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_launch_t.htm)
- [Translate a subcase](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_result_file_open_t.htm)
- [Translate results to H3D](https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_translate_results_file_t.htm)
