# HvTrans lookup

Machine routing records; source identity is retained. Module classification is a routing aid, not proof of runtime availability.

```json
[
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "HWD-0050: Translating Results - HvTrans",
    "title": "HWD-0050: Translating Results - HvTrans",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/source_depth/hwd/3f/3fc7c9689bc0d461.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/hwd/topics/tutorials/hwd/hwd_0050_translating_results_hvtrans_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 2,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 2,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
      "Source images linked but not mirrored; textual record is not a complete copy of graphical instructions",
      "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
        "Source images linked but not mirrored; textual record is not a complete copy of graphical instructions",
        "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Batch Mode",
    "title": "Batch Mode",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/78/781a575460fe49bb.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_batch_mode_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 1,
    "code_blocks": 1,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
      "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
        "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Configuration Files",
    "title": "Configuration Files",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/8a/8afab1f590782b7d.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_configuration_files_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 6,
    "code_blocks": 2,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
      "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
        "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Derived Subcases",
    "title": "Derived Subcases",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/6e/6ea8e1581ca94118.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_derived_subcase_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "HvTrans",
    "title": "HvTrans",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/fc/fc6fcdeaa7b29930.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_intro_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Launch HvTrans",
    "title": "Launch HvTrans",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/1a/1a7d23b7fa3f531b.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_launch_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Translate a Subcase",
    "title": "Translate a Subcase",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/1e/1eeedd860245f75b.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_result_file_open_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Translate a Solver Results File to an H3D File",
    "title": "Translate a Solver Results File to an H3D File",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help/5f/5fd53e38762c2c5f.md",
    "url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_translate_results_file_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Batch Mode",
    "title": "Batch Mode",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/0c/0cc00e5c4a4f543c.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_batch_mode_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 1,
    "code_blocks": 1,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
      "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/78/781a575460fe49bb.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_batch_mode_r.htm",
    "same_topic_sha256": "444360bc3ddcab6fd43a96bb5d493311498d206d3d0ae3f76f2ee09b305d2b0d",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
        "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Configuration Files",
    "title": "Configuration Files",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/18/189a7578977e8e32.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_configuration_files_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 6,
    "code_blocks": 2,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
      "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
    ],
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API",
        "Source absolute-path examples adapted to <SOURCE_PATH>; this is an annotated portable adaptation, not byte-verbatim code"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Derived Subcases",
    "title": "Derived Subcases",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/10/10c97b35e3754a62.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_derived_subcase_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/6e/6ea8e1581ca94118.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_derived_subcase_r.htm",
    "same_topic_sha256": "3169393de43c2fc9382d6779ed9482488e81951f17238d070427b1f475a047c4",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "HvTrans",
    "title": "HvTrans",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/79/791ccc8d040ffdaf.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_intro_r.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/fc/fc6fcdeaa7b29930.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_intro_r.htm",
    "same_topic_sha256": "5b8c1e526fded9e39f841b9f6f44ad9e3d5ba3fd48df846ac600e8e6ea8a552a",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Launch HvTrans",
    "title": "Launch HvTrans",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/7d/7db0252eb2adbec6.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_launch_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/1a/1a7d23b7fa3f531b.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_launch_t.htm",
    "same_topic_sha256": "5b6e21d4047f4b2bd68d6e1cf6f2b44557e4dcaf606112bef57477e57b8f2b9d",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Translate a Subcase",
    "title": "Translate a Subcase",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/74/749393cb4fc27151.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_result_file_open_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/1e/1eeedd860245f75b.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_result_file_open_t.htm",
    "same_topic_sha256": "67e6daa4e9b8c28df17e4eec39ef812391f0daf91889b419d3cd71c1d557f5e0",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  },
  {
    "product": "HyperWorks Desktop / supporting or other source-labeled client",
    "owner": "Not stated by source",
    "name": "Translate a Solver Results File to an H3D File",
    "title": "Translate a Solver Results File to an H3D File",
    "signature": "",
    "syntax_heading": "not_stated",
    "application": "Not stated by source",
    "source_release": "2022.3",
    "reader_pointer": "official_help/supplements/web_completion/altair_help_solver/d5/d56a5938364e584b.md",
    "url": "https://2022.help.altair.com/2022.3/hwsolvers/altair_help/topics/tools/hvtrans_translate_results_file_t.htm",
    "status": "structured_source_body",
    "path_adaptations": 0,
    "code_blocks": 0,
    "code_preserved": true,
    "image_count": 0,
    "source_flags": [
      "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
    ],
    "reused_body_pointer": "official_help/supplements/web_completion/altair_help/5f/5fd53e38762c2c5f.md",
    "canonical_source_url": "https://2022.help.altair.com/2022.3/hwdesktop/altair_help/topics/tools/hvtrans_translate_results_file_t.htm",
    "same_topic_sha256": "8f0e402d92bedbf5c807e660563e7cc1b0d246fbe1fbc4b4c66999910c19b281",
    "module": "hvtrans",
    "surface": "reference",
    "routing_basis": "HvTrans source URL/title",
    "contract_assessment": {
      "source_status": "structured_source_body",
      "call_form_state": "source_explicitly_not_stated",
      "target_compatibility": "not_checked",
      "runtime_behavior": "not_run",
      "source_flags": [
        "Syntax not stated by source; may be workflow/class/navigation rather than callable API"
      ]
    }
  }
]
```
