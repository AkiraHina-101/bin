# Contract quality in this package

Counts are source records in this package, not unique callable commands. Field presence is only source structure; it does not establish semantic correctness or target availability. Source product/owner metadata remains visible in MODULE_INDEX.

| Routed source module | Records | Exact source transcript | Signature present | Syntax explicitly not stated | Non-empty source flags |
|---|---:|---:|---:|---:|---:|
| hvtrans | 15 | 0 | 0 | 15 | 15 |

Reviewed source transcripts are not runtime/API-behavior certificates. An empty source flag list is not proof of completeness. Missing source detail stays unknown; consult the exact source body and CONTRACT_STANDARD.md.
