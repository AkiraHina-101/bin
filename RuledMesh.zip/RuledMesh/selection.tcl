# Extract corner-node paths from native node and PLOTEL selection.
proc ::RuledMesh::corner_nodes {nodes} {
    set result {}
    foreach node $nodes {
        if {![hm_nodeismidnode $node]} {lappend result $node}
    }
    return $result
}

proc ::RuledMesh::edge_adjacency {edges} {
    set adjacent {}
    foreach edge [lsort -unique $edges] {
        lassign $edge a b
        if {$a == $b} {error "A selected edge has coincident node IDs."}
        dict lappend adjacent $a $b
        dict lappend adjacent $b $a
    }
    return $adjacent
}

proc ::RuledMesh::trace_edge_path {edges start closed} {
    set adjacent [edge_adjacency $edges]
    if {![dict exists $adjacent $start]} {error "The selection did not contain an edge path."}

    set visited {}
    set queue [list $start]
    set ends {}
    for {set i 0} {$i < [llength $queue]} {incr i} {
        set node [lindex $queue $i]
        if {[dict exists $visited $node]} {continue}
        dict set visited $node 1
        set next [dict get $adjacent $node]
        if {[llength $next] > 2} {error "The picked edge connects to a branch. Select an unbranched rim."}
        if {[llength $next] == 1} {lappend ends $node}
        lappend queue {*}$next
    }
    if {$closed && [llength $ends]} {error "This rim is open. Complete the selection or clear Closed loops."}
    if {!$closed && [llength $ends] != 2} {error "This rim is closed. Enable Closed loops."}
    if {!$closed} {set start [lindex $ends 0]}

    set result {}
    set previous {}
    set node $start
    while {$node ne {}} {
        lappend result $node
        set next {}
        foreach other [dict get $adjacent $node] {
            if {$other ne $previous && $other ne $start} {set next $other; break}
        }
        set previous $node
        set node $next
    }
    if {[llength $result] != [dict size $visited]} {error "The edge path is incomplete."}
    return $result
}

proc ::RuledMesh::path_between {adjacent start stop excluded} {
    set parent [dict create $start {}]
    set queue [list $start]
    for {set i 0} {$i < [llength $queue]} {incr i} {
        set node [lindex $queue $i]
        if {$node == $stop} {
            set path [list $node]
            while {$node != $start} {
                set node [dict get $parent $node]
                lappend path $node
            }
            return [lreverse $path]
        }
        foreach next [dict get $adjacent $node] {
            if {![dict exists $parent $next] && [edge_key $node $next] ni $excluded} {
                dict set parent $next $node
                lappend queue $next
            }
        }
    }
    return {}
}

proc ::RuledMesh::cycle_from_edge {edges a b} {
    set adjacent [edge_adjacency $edges]
    set seed [edge_key $a $b]
    if {$seed ni $edges} {error "The selected PLOTEL segment is unavailable."}
    set path [path_between $adjacent $a $b [list $seed]]
    if {![llength $path]} {error "This rim is open. Complete the selection or clear Closed loops."}
    # A second path would produce a different cycle through the exact picked segment.
    # This allows another rim to meet at one node without following that rim.
    foreach node [lrange $path 0 end-1] edge [path_edges $path] {
        if {[llength [dict get $adjacent $node]] > 2 &&
            [llength [path_between $adjacent $a $b [list $seed $edge]]]} {
            error "More than one rim passes through this PLOTEL segment."
        }
    }
    return $path
}

proc ::RuledMesh::loop_from_plotel {seed {closed 1} {segmentsVar {}}} {
    if {[hm_getvalue elems id=$seed dataname=typename] ne "PLOTEL"} {
        error "Pick one red PLOTEL free-edge segment."
    }
    set collector [hm_getvalue elems id=$seed dataname=collector.id]
    set ids [hm_getentityarray comps $collector elements -byid]
    set segments {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set chunk [lrange $ids $i $i+1023]
        set types [hm_getvalue elems user_ids=$chunk dataname=typename]
        set rows [hm_getvalue elems user_ids=$chunk dataname=nodes]
        foreach id $chunk type $types nodes $rows {
            if {$type eq "PLOTEL" && [llength $nodes] == 2} {
                dict lappend segments [edge_key {*}$nodes] $id
            }
        }
    }
    set edges [dict keys $segments]
    lassign [hm_getvalue elems id=$seed dataname=nodes] a b
    # Walk the raw segments first, since a quadratic edge can be two PLOTELs.
    if {$closed} {
        set rawPath [cycle_from_edge $edges $a $b]
    } else {
        set rawPath [trace_edge_path $edges $a 0]
    }
    set path [corner_nodes $rawPath]
    if {[llength $path] < 2 + $closed} {error "The selected rim has too few corner nodes."}
    if {$segmentsVar ne {}} {
        upvar 1 $segmentsVar pickedSegments
        if {$closed} {lappend rawPath [lindex $rawPath 0]}
        set pickedSegments {}
        foreach edge [path_edges $rawPath] {lappend pickedSegments {*}[dict get $segments $edge]}
    }
    return $path
}

proc ::RuledMesh::order_shell_boundary {nodes closed shells} {
    if {[llength $nodes] < 2 + $closed} {error "Select a free-edge path with enough corner nodes."}
    set selected {}
    foreach node $nodes {dict set selected $node 1}
    set counts {}
    set directed {}
    dict for {id shell} $shells {
        set corners [lindex $shell 0]
        foreach a $corners b [concat [lrange $corners 1 end] [lindex $corners 0]] {
            if {[dict exists $selected $a] && [dict exists $selected $b]} {
                set key [edge_key $a $b]
                dict incr counts $key
                dict set directed $key [list $a $b]
            }
        }
    }
    set edges {}
    dict for {edge count} $counts {
        if {$count == 1} {lappend edges $edge}
    }
    set path [trace_edge_path $edges [lindex $nodes 0] $closed]
    if {[llength $path] != [dict size $selected]} {error "Select one connected free-edge path."}
    if {$closed} {
        lassign $path a b
        if {[dict get $directed [edge_key $a $b]] eq [list $a $b]} {
            set path [linsert [lreverse [lrange $path 1 end]] 0 $a]
        }
    }
    return $path
}

proc ::RuledMesh::pick_selection {mode label closed} {
    if {$mode in {path nodes}} {
        if {$mode eq "path"} {
            set panel *createlistbypathpanel
            set prompt "$label: pick nodes along the path."
        } else {
            set panel *createlistpanel
            set prompt "$label: pick corner nodes in order."
        }
        set saved [hm_getlist nodes 1]
        *clearlist nodes 1
        set panelCode [catch {$panel nodes 1 $prompt} panelError]
        set ids [hm_getlist nodes 1]
        *clearlist nodes 1
        if {[llength $saved]} {*createlist nodes 1 {*}$saved}
        if {$panelCode && $panelError ne "0"} {error $panelError}
        set nodes [corner_nodes $ids]
        if {![llength $nodes]} {return {}}
        return [dict create nodes $nodes elements {}]
    }
    set saved [hm_getmark elems 1]
    *clearmark elems 1
    set panelCode [catch {*createmarkpanel elems 1 "$label: pick one red PLOTEL segment." 0 1} panelError]
    set ids [hm_getmark elems 1]
    *clearmark elems 1
    if {[llength $saved]} {*createmark elems 1 "by id only" {*}$saved}
    if {$panelCode && $panelError ne "0"} {error $panelError}
    if {![llength $ids]} {return {}}
    if {[llength $ids] != 1} {error "Pick exactly one red PLOTEL segment."}
    set nodes [loop_from_plotel [lindex $ids 0] $closed elements]
    return [dict create nodes $nodes elements $elements]
}
