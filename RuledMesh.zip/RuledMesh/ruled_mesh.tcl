# HyperMesh 2022.3 / Nastran. Fill or bridge shell edges on a local support surface.
source [file join [file dirname [info script]] paths.tcl]
source [file join [file dirname [info script]] selection.tcl]
source [file join [file dirname [info script]] patch_surface.tcl]
source [file join [file dirname [info script]] constrained_patch.tcl]

namespace eval ::RuledMesh {
    variable window .ruledMesh
    variable busy
    if {![info exists busy]} {set busy 0}
    variable path
    variable model
    variable count
    variable edgeElements
    if {![array exists path]} {array set path {A {} B {}}}
    if {![array exists model]} {array set model {A {} B {}}}
    if {![array exists count]} {array set count {A "0 nodes" B "0 nodes"}}
    if {![array exists edgeElements]} {array set edgeElements {A {} B {}}}
    variable previewElements
    variable savedElementMark
    if {![info exists previewElements]} {set previewElements {}}
    variable previewModel
    variable previewNodes
    if {![info exists previewNodes]} {set previewNodes {}}
    if {![info exists previewModel]} {set previewModel {}}
    variable closed 1
    variable selectMode edge
    variable size 10.0
    variable status "Select one closed edge or two paths."
    variable checkSpec {
        aspect        "Max aspect"     above 5.0
        skew          "Max skew"       above 60.0
        minlength     "Min length"     below 6.5
        jacobian      "Min Jacobian"   below 0.7
        mininterangle "Min tria angle" below 20.0
        maxinterangle "Max tria angle" above 120.0
    }
}

proc ::RuledMesh::coordinates {ids} {
    set result {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set batch [lrange $ids $i $i+1023]
        foreach axis {x y z} {
            set $axis [hm_getvalue nodes user_ids=$batch dataname=global$axis]
            if {[llength [set $axis]] != [llength $batch]} {error "Some selected nodes no longer exist."}
        }
        foreach id $batch px $x py $y pz $z {dict set result $id [list $px $py $pz]}
    }
    return $result
}

proc ::RuledMesh::tria_rows {ids} {
    if {![llength $ids]} {error "HyperMesh did not create a mesh for this patch."}
    set rows {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set batch [lrange $ids $i $i+1023]
        set configs [hm_getvalue elems user_ids=$batch dataname=config]
        set connectivity [hm_getvalue elems user_ids=$batch dataname=nodes]
        if {[llength $configs] != [llength $batch] || [llength $connectivity] != [llength $batch]} {
            error "HyperMesh did not return all generated elements."
        }
        foreach cfg $configs nodes $connectivity {
            if {$cfg != 103 || [llength $nodes] != 3} {error "The mesher returned a non-TRIA3 element."}
            lappend rows $nodes
        }
    }
    return $rows
}

proc ::RuledMesh::meshing_density {u v coordinates size} {
    set width [expr {sqrt([distance2 [dict get $coordinates $u] [dict get $coordinates $v]])}]
    if {$width <= 0} {error "Connecting nodes $u and $v occupy the same point."}
    set density [expr {max(1, round($width / $size))}]
    if {$density > 2147483647} {error "Element size is too small for HyperMesh edge density."}
    return $density
}

# In the node-list ruled workflow, edges 1 and 3 are the end and start
# connectors. The existing node lists control edges 0 and 2.
proc ::RuledMesh::mesh_patch {a b coordinates size elemsVar nodesVar} {
    upvar 1 $elemsVar allElems $nodesVar allNodes
    set start [meshing_density [lindex $a 0] [lindex $b 0] $coordinates $size]
    set end [meshing_density [lindex $a end] [lindex $b end] $coordinates $size]
    hm_entityrecorder elems on
    hm_entityrecorder nodes on
    set code [catch {
        *surfacemode 2
        *createlist nodes 1 {*}$a
        *createlist nodes 2 {*}$b
        *linearsurfacebetweennodes 1 2 0
        *set_meshedgeparams 1 $end 1 0 0 0 0 0 0
        *set_meshedgeparams 3 $start 1 0 0 0 0 0 0
        *set_meshfaceparams 0 1 3 0 0 1 0.5 1 1
        *automesh 0 1 3
        *storemeshtodatabase 0
    } result options]
    set clearCode [catch {*ameshclearsurface} clearResult clearOptions]
    hm_entityrecorder nodes off
    hm_entityrecorder elems off
    set elems [hm_entityrecorder elems ids]
    lappend allElems {*}$elems
    lappend allNodes {*}[hm_entityrecorder nodes ids]
    if {$code} {return -options $options $result}
    if {$clearCode} {return -options $clearOptions $clearResult}
    set seams [seam_paths $a $b [tria_rows $elems]]
    foreach seam $seams density [list $start $end] {
        if {[llength $seam] != $density + 1} {error "HyperMesh changed a connecting edge density."}
    }
    return $seams
}

proc ::RuledMesh::join_seams {first second newNodes} {
    set generated {}
    foreach id $newNodes {dict set generated $id 1}
    set source {}
    set target {}
    foreach a $first b [lreverse $second] {
        if {[llength $a] != [llength $b] || [lindex $a 0] != [lindex $b 0] ||
            [lindex $a end] != [lindex $b end]} {
            error "The two Ruled passes did not produce matching seams."
        }
        set positions [coordinates [lsort -integer -unique [concat $a $b]]]
        set start [dict get $positions [lindex $a 0]]
        set end [dict get $positions [lindex $a end]]
        set tolerance2 [expr {[distance2 $start $end] * 1.0e-12}]
        foreach u [lrange $a 1 end-1] v [lrange $b 1 end-1] {
            if {$u == $v} {continue}
            if {![dict exists $generated $u] || ![dict exists $generated $v] ||
                [distance2 [dict get $positions $u] [dict get $positions $v]] > $tolerance2} {
                error "Ruled seam nodes do not match. No existing node will be replaced."
            }
            lappend source $v
            lappend target $u
        }
    }
    if {[llength $source] == 1} {
        *replacenodes [lindex $source 0] [lindex $target 0] 1 0
    } elseif {[llength $source] > 1} {
        *createlist nodes 1 {*}$source
        *createlist nodes 2 {*}$target
        *replacenodes_multiple 1 2 1 0
    }
}

proc ::RuledMesh::quality_counts {elems limits} {
    variable checkSpec
    set result {}
    *createmark elems 1 "by id only" {*}$elems
    foreach {key label method default} $checkSpec {
        set failures [hm_getelemcheckelems 1 2 $key $method [dict get $limits $key]]
        dict set result $key [llength $failures]
    }
    return $result
}

proc ::RuledMesh::number {value label min max} {
    if {![string is double -strict $value] || [catch {expr {double($value)}} parsed] ||
        $parsed < $min || $parsed > $max || $parsed == Inf} {
        error "Enter a valid $label."
    }
    return $parsed
}

proc ::RuledMesh::check_region_occupancy {outside island shells surface spacing existingPoints} {
    set frame [lindex $surface 0]
    set tolerance2 [expr {(0.1*$spacing)**2}]
    set outside [polygon_scan_index $outside]
    set island [polygon_scan_index $island]
    set nodeIds {}
    dict for {id shell} $shells {lappend nodeIds {*}[lindex $shell 0]}
    set missing {}
    foreach n [lsort -integer -unique $nodeIds] {
        if {![dict exists $existingPoints $n]} {lappend missing $n}
    }
    set existingPoints [dict merge $existingPoints [coordinates $missing]]
    dict for {id shell} $shells {
        set points [polygon_points [lindex $shell 0] $existingPoints]
        set center [center_of $points]
        lassign [project $frame $center] x y z
        if {![point_in_polygon $outside $x $y] || [point_in_polygon $island $x $y]} {continue}
        set gap [expr {($z-[height_at [lindex $surface 1] $x $y])*[lindex $frame end]}]
        if {$gap*$gap <= $tolerance2} {
            error "The closed region already contains shell element $id."
        }
    }
}

proc ::RuledMesh::nested_boundaries {a b points} {
    if {abs([polygon_area2 [polygon_points $a $points]]) < abs([polygon_area2 [polygon_points $b $points]])} {
        lassign [list $b $a] a b
    }
    set outer [polygon_points $a $points]
    set outerScan [polygon_scan_index $outer]
    foreach id $b {
        lassign [dict get $points $id] x y
        if {![point_in_polygon $outerScan $x $y]} {return {}}
    }
    set inner [polygon_points $b $points]
    set outerNext [concat [lrange $outer 1 end] [list [lindex $outer 0]]]
    set innerNext [concat [lrange $inner 1 end] [list [lindex $inner 0]]]
    foreach u $outer v $outerNext {
        foreach p $inner q $innerNext {
            if {[segments_intersect $u $v $p $q]} {
                error "The projected inner and outer boundaries cross."
            }
        }
    }
    return [list $a $b]
}

proc ::RuledMesh::remesh_patch_to_size {seed size boundary surface spacing} {
    set seedInterior {}
    foreach id [lsort -integer -unique [concat {*}[tria_rows $seed]]] {
        if {![dict exists $boundary $id]} {lappend seedInterior $id}
    }
    *createmark elems 1 "by id only" {*}$seed
    set order [hm_getoption element_order]
    if {$order != 1} {*setoption element_order=1}
    hm_entityrecorder elems on
    # 14 enables Flow align and size control. 2 keeps boundary connectivity.
    set code [catch {*defaultremeshelems 1 $size 3 3 0 1 1 14 0 0 0 0 2 30} result options]
    hm_entityrecorder elems off
    set elems [hm_entityrecorder elems ids]
    if {$order != 1} {*setoption element_order=$order}
    if {$code} {return -options $options $result}

    set rows [tria_rows $elems]
    set liveNodes [lsort -integer -unique [concat {*}$rows]]
    set live {}
    foreach id $liveNodes {dict set live $id 1}
    set stale {}
    foreach id $seedInterior {
        if {![dict exists $live $id] && [hm_entityinfo exist nodes $id -byid]} {lappend stale $id}
    }
    if {[llength $stale]} {
        *createmark nodes 1 "by id only" {*}$stale
        *nodemarkcleartempmark 1
    }
    set points [coordinates $liveNodes]
    if {[surface_is_curved $surface $spacing]} {
        set support [build_support_surface $surface $boundary]
        project_patch $rows $points $surface $support $spacing
        delete_support_surface $support
    } else {
        validate_projection $rows $points $surface
    }
    return $elems
}

proc ::RuledMesh::create {a b closed size {limits {}}} {
    variable checkSpec
    set size [number $size "element size" 0 Inf]
    if {$size <= 0 || $size >= Inf} {error "Element size must be a finite positive number."}
    if {[dict size $limits]} {
        foreach {key label method default} $checkSpec {
            set max Inf
            if {$key eq "jacobian"} {set max 1.0}
            if {$key in {skew mininterangle maxinterangle}} {set max 180.0}
            dict set limits $key [number [dict get $limits $key] $label 0 $max]
        }
        if {[dict get $limits mininterangle] > [dict get $limits maxinterangle]} {
            error "Minimum tria angle exceeds the maximum."
        }
    }
    set a [corner_nodes $a]
    set b [corner_nodes $b]
    if {![llength $a] && ![llength $b]} {error "Select one closed edge or two paths."}
    set hole [expr {![llength $a] || ![llength $b]}]
    if {$hole && !$closed} {error "A single edge must form a closed loop."}
    set xyz [coordinates [lsort -integer -unique [concat $a $b]]]
    if {$hole} {
        set loop [concat $a $b]
        if {[lindex $loop 0] eq [lindex $loop end]} {set loop [lrange $loop 0 end-1]}
        if {[llength [lsort -integer -unique $loop]] != [llength $loop]} {
            error "The closed edge visits a node more than once."
        }
        if {[llength $loop] < 3} {error "Select a free-edge path with enough corner nodes."}
        set paths [list [concat $loop [lindex $loop 0]]]
    } else {
        set plan [plan $a $b $closed $xyz]
        set start [list [lindex [dict get $plan a] 0] [lindex [dict get $plan b] 0]]
        set paths [list [dict get $plan a] [dict get $plan b]]
    }
    set length 0.0
    set edgeCount 0
    foreach path $paths {
        set length [expr {$length+[lindex [arc_lengths $path $xyz] end]}]
        incr edgeCount [expr {[llength $path]-1}]
    }
    set spacing [expr {$length/$edgeCount}]
    set collector [hm_info currentcollector comps]
    if {$collector eq "" || $collector eq "0"} {error "Set a current component for the new elements."}

    set oldList1 [hm_getlist nodes 1]
    set oldList2 [hm_getlist nodes 2]
    set oldElems [hm_getmark elems 1]
    set oldNodes [hm_getmark nodes 1]
    set oldSurfs [hm_getmark surfs 1]
    set initialCounts [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]]
    set elems {}
    set nodes {}
    set seams {}
    set label "Ruled mesh [clock clicks]"
    hm_private_frwk enablehistoryfromtcl 1
    if {[catch {*startnotehistorystate $label} result options]} {
        catch {hm_private_frwk enablehistoryfromtcl 0}
        return -options $options $result
    }
    set code [catch {
        set shells [shell_neighborhood $xyz $spacing]
        set surface [reference_surface $xyz $shells $spacing supportPoints]
        set projected {}
        set region {}
        if {$surface ne {}} {
            dict for {id point} $xyz {dict set projected $id [project [lindex $surface 0] $point]}
        }
        if {$hole} {
            set loop [order_shell_boundary $loop 1 $shells]
            if {$surface eq {}} {error "The neighboring shell does not define one usable surface for this hole."}
            set start [list [lindex $loop 0]]
            set paths [list [concat $loop [lindex $loop 0]]]
            set region [list $loop {}]
        } elseif {$closed && $surface ne {}} {
            set region [nested_boundaries [lrange [lindex $paths 0] 0 end-1] \
                [lrange [lindex $paths 1] 0 end-1] $projected]
            if {[llength $region]} {
                lassign $region outer inner
                set region [list [order_shell_boundary $outer 1 $shells] [order_shell_boundary $inner 1 $shells]]
            }
        }
        if {[llength $region]} {
            lassign $region outer inner
            # Give the native remesher the same seed sequence for either pick order.
            foreach name {outer inner} {
                set loopNodes [set $name]
                if {[llength $loopNodes]} {
                    set first [lindex [lsort -integer $loopNodes] 0]
                    set $name [rotate $loopNodes [lsearch -exact $loopNodes $first]]
                }
            }
            check_region_occupancy [polygon_points $outer $projected] [polygon_points $inner $projected] \
                $shells $surface $spacing $supportPoints
            lassign [constrained_patch $outer $inner $projected $surface $spacing] rows points
            set seed [store_constrained_patch $rows $points $surface]
            set elems [remesh_patch_to_size $seed $size $xyz $surface $spacing]
            set passes [expr {$hole ? 1 : 2}]
        } else {
            set curved [expr {$surface ne {} && [surface_is_curved $surface $spacing]}]
            set ruledSize $size
            if {$curved} {
                set support [build_support_surface $surface $xyz]
                set ruledSize [expr {min($size,0.45*$spacing)}]
            }
            foreach patch [dict get $plan patches] {
                lassign $patch pa pb
                lappend seams [mesh_patch $pa $pb $xyz $ruledSize elems nodes]
            }
            if {$closed} {
                join_seams {*}$seams $nodes
            } else {
                lappend paths {*}[lindex $seams 0]
            }
            set passes [llength $seams]
            if {$curved} {
                set rows [tria_rows $elems]
                set points [coordinates [lsort -integer -unique [concat {*}$rows]]]
                project_patch $rows $points $surface $support $spacing
                delete_support_surface $support
            }
        }
        set free [free_edges [tria_rows $elems]]
        foreach path $paths {remove_path_edges free $path}
        if {[dict size $free]} {error "The new mesh has an open seam or unexpected free edges."}
        if {[hm_count elems all 0 0] != [lindex $initialCounts 0] + [llength $elems] ||
            [coordinates [dict keys $xyz]] ne $xyz} {
            error "Meshing changed existing elements or boundary nodes."
        }
        if {[lsort -unique [hm_getvalue elems user_ids=$elems dataname=collector.id]] ne [list $collector]} {
            error "The mesh was not created in the current component."
        }
        if {[hm_count surfs all 0 0] != [lindex $initialCounts 2]} {error "The surface count changed after meshing."}
        set failed {}
        if {[dict size $limits]} {set failed [quality_counts $elems $limits]}
    } result options]
    set closeCode [catch {*endnotehistorystate $label} closeResult closeOptions]
    if {$closeCode && !$code} {
        set code $closeCode
        set result $closeResult
        set options $closeOptions
    }
    if {$code && !$closeCode} {
        if {[catch {
            if {$label in [hm_getundoactions]} {*undohistorystate 1}
            set counts [list [hm_count elems all 0 0] [hm_count nodes all 0 0] [hm_count surfs all 0 0]]
            if {$counts ne $initialCounts || [coordinates [dict keys $xyz]] ne $xyz} {
                error "The mesh or input nodes changed."
            }
        } cleanup]} {
            append result "\nRollback failed: $cleanup"
        }
    } elseif {$closeCode} {
        append result "\nUnable to close the Ruled mesh undo state."
    }
    catch {hm_private_frwk enablehistoryfromtcl 0}
    foreach slot {1 2} saved [list $oldList1 $oldList2] {
        if {[hm_getlist nodes $slot] eq $saved} {continue}
        if {[llength $saved]} {
            catch {*createlist nodes $slot {*}$saved}
        } else {
            catch {*clearlist nodes $slot}
        }
    }
    foreach kind {elems nodes surfs} saved [list $oldElems $oldNodes $oldSurfs] {
        if {[hm_getmark $kind 1] eq $saved} {continue}
        if {[llength $saved]} {
            catch {*createmark $kind 1 "by id only" {*}$saved}
        } else {
            catch {*clearmark $kind 1}
        }
    }
    if {$code} {return -options $options $result}
    return [dict create elements $elems passes $passes start $start quality $failed hole $hole surface [expr {$surface ne {}}]]
}

proc ::RuledMesh::refresh_preview {} {
    variable path
    variable model
    variable previewNodes
    variable edgeElements
    variable previewElements
    variable savedElementMark
    variable previewModel
    if {![llength $previewNodes] && ![llength $previewElements] &&
        ![llength $path(A)] && ![llength $path(B)]} {return}

    set active [hm_getcurrentmodel]
    set nodes {}
    set elements {}
    foreach side {A B} {
        if {$model($side) ne $active} {continue}
        if {[llength $edgeElements($side)]} {
            lappend elements {*}$edgeElements($side)
        } else {
            lappend nodes {*}$path($side)
        }
    }
    set elements [lsort -integer -unique $elements]
    # Keep the element mark while the preview is visible, including during the other picker.
    if {[llength $elements] || ($previewModel eq $active && [llength $previewElements])} {
        set mark [lsort -integer -unique [hm_getmark elems 2]]
        if {$previewModel ne $active || ![llength $previewElements] || $mark ne $previewElements} {
            set savedElementMark $mark
        }
        if {$previewModel eq $active && [llength $previewElements]} {
            *createmark elems 2 "by id only" {*}$previewElements
            hm_highlightmark elems 2 norm
        }
        if {[llength $elements]} {
            *createmark elems 2 "by id only" {*}$elements
            hm_highlightmark elems 2 lowlight
        } else {
            *clearmark elems 2
            if {[llength $savedElementMark]} {*createmark elems 2 "by id only" {*}$savedElementMark}
        }
    }
    set previewElements $elements
    set nodes [lsort -integer -unique $nodes]
    if {[llength $nodes] || ($previewModel eq $active && [llength $previewNodes])} {
        set saved [hm_getmark nodes 2]
        set code [catch {
            if {$previewModel eq $active && [llength $previewNodes]} {
                *createmark nodes 2 "by id only" {*}$previewNodes
                hm_highlightmark nodes 2 norm
            }
            if {[llength $nodes]} {
                *createmark nodes 2 "by id only" {*}$nodes
                hm_highlightmark nodes 2 lowlight
            }
        } result options]
        *clearmark nodes 2
        if {[llength $saved]} {*createmark nodes 2 "by id only" {*}$saved}
        if {$code} {return -options $options $result}
    }
    set previewNodes $nodes
    set previewModel $active
    catch {hm_redraw}
}

proc ::RuledMesh::pick {side} {
    variable window
    variable path
    variable model
    variable count
    variable status
    variable busy
    variable closed
    variable selectMode
    variable edgeElements
    if {$busy} {return}
    set busy 1
    set label [expr {$side eq "A" ? "Edge 1" : "Edge 2"}]
    wm withdraw $window
    set code [catch {
        set origin [hm_getcurrentmodel]
        set selection [pick_selection $selectMode $label $closed]
        if {$origin ne [hm_getcurrentmodel]} {error "The current model changed during selection."}
    } result]
    set busy 0
    wm deiconify $window
    if {$code} {
        set status $result
        puts stderr "Ruled Mesh: $result"
    } elseif {$selection eq {}} {
        set status "Selection cancelled."
    } else {
        set ids [dict get $selection nodes]
        set path($side) $ids
        set edgeElements($side) [dict get $selection elements]
        set model($side) $origin
        set count($side) "[llength [lsort -integer -unique $ids]] nodes"
        set status "$label selected."
    }
    if {[catch {refresh_preview} message]} {
        append status "\nPreview: $message"
        puts stderr "Ruled Mesh preview: $message"
    }
    if {!$code && $selection ne {} && $side eq "A" && ![llength $path(B)]} {
        set busy 1
        set promptCode [catch {
            tk_messageBox -parent $window -title "Ruled Mesh" -icon question -type yesno \
                -default yes -message "Select Edge 2 as well?"
        } answer options]
        set busy 0
        if {$promptCode} {return -options $options $answer}
        if {$answer eq "yes"} {
            pick B
        } else {
            set status [expr {$closed ? "Edge 1 selected. Click Create to fill." : "Select Edge 2 to bridge open paths."}]
        }
    }
}

proc ::RuledMesh::run {} {
    variable path
    variable model
    variable status
    variable busy
    variable closed
    variable size
    if {$busy} {return}
    if {![llength $path(A)] && ![llength $path(B)]} {
        set status "Select one closed edge or two paths."
        return
    }
    set active [hm_getcurrentmodel]
    foreach side {A B} {
        if {[llength $path($side)] && $model($side) ne $active} {
            set status "The model changed. Select the edges again."
            return
        }
    }
    set busy 1
    set status "Creating mesh..."
    update idletasks
    set code [catch {create $path(A) $path(B) $closed $size} result]
    set busy 0
    if {$code} {
        catch {refresh_preview}
        set status $result
        puts stderr "Ruled Mesh: $result"
        return
    }
    clear
    if {[dict get $result hole]} {
        set status "Hole filled with [llength [dict get $result elements]] trias."
    } else {
        set status "Created [llength [dict get $result elements]] trias."
        if {![dict get $result surface]} {append status "\nNo shared shell surface for fitting."}
    }
    puts "Ruled Mesh: start nodes [dict get $result start], passes [dict get $result passes]. $status"
}

proc ::RuledMesh::clear {} {
    variable path
    variable model
    variable count
    variable status
    variable busy
    variable edgeElements
    if {$busy} {return}
    array set path {A {} B {}}
    array set model {A {} B {}}
    array set count {A "0 nodes" B "0 nodes"}
    array set edgeElements {A {} B {}}
    set status "Select one closed edge or two paths."
    catch {refresh_preview}
}

proc ::RuledMesh::close {} {
    variable window
    variable busy
    if {!$busy} {
        clear
        destroy $window
    }
}

proc ::RuledMesh::show {} {
    variable window
    variable busy
    if {[winfo exists $window]} {
        if {$busy} {return}
        if {![winfo exists $window.body.quality] && [$window.body.paths.pickA cget -text] eq "Edge 1..."} {
            wm deiconify $window
            raise $window
            return
        }
        destroy $window
    }
    clear
    toplevel $window
    wm withdraw $window
    wm title $window "Ruled Mesh"
    wm resizable $window 0 0
    wm transient $window .
    wm protocol $window WM_DELETE_WINDOW ::RuledMesh::close
    bind $window <Escape> {::RuledMesh::close}
    set body [ttk::frame $window.body -padding 12]
    pack $body -fill both -expand 1
    set buttons [ttk::frame $body.buttons]
    pack $buttons -side bottom -fill x -pady {6 0}
    foreach {id label command} {close Close close create Create run clear Clear clear} {
        ttk::button $buttons.$id -text $label -command ::RuledMesh::$command
        pack $buttons.$id -side right -padx {5 0}
    }

    set paths [ttk::labelframe $body.paths -text "Boundary selection" -padding 8]
    pack $paths -fill x
    set modes [ttk::frame $paths.modes]
    grid $modes -row 0 -column 0 -columnspan 2 -sticky w -pady {0 4}
    foreach {mode label} {edge "By edge" path "By path" nodes "By node"} {
        ttk::radiobutton $modes.$mode -text $label -variable ::RuledMesh::selectMode -value $mode
        pack $modes.$mode -side left -padx {0 10}
    }
    foreach side {A B} row {1 2} {
        ttk::button $paths.pick$side -text "Edge $row..." -command [list ::RuledMesh::pick $side]
        ttk::label $paths.count$side -textvariable ::RuledMesh::count($side)
        grid $paths.pick$side $paths.count$side -row $row -sticky w -padx {0 10} -pady 2
    }
    ttk::checkbutton $paths.closed -text "Closed loops" -variable ::RuledMesh::closed
    grid $paths.closed -row 3 -column 0 -columnspan 2 -sticky w -pady {4 0}

    set settings [ttk::labelframe $body.mesh -text "Mesh, dele surf / R-trias" -padding 8]
    pack $settings -fill x -pady {8 0}
    ttk::label $settings.label -text "Element size"
    ttk::entry $settings.size -width 9 -textvariable ::RuledMesh::size
    grid $settings.label $settings.size -sticky w -padx {0 8}
    ttk::label $settings.target -text "Current component"
    grid $settings.target -row 0 -column 2 -sticky w -padx {8 0}

    label $body.status -textvariable ::RuledMesh::status -font TkDefaultFont \
        -anchor nw -justify left -height 2 -width 40 -wraplength 280 -borderwidth 0
    foreach {option style} {-background TFrame -foreground TLabel} {
        set color [ttk::style lookup $style $option]
        if {$color ne ""} {$body.status configure $option $color}
    }
    pack $body.status -fill x -pady {8 0}

    update idletasks
    set width [winfo reqwidth $window]
    set height [winfo reqheight $window]
    set x [expr {[winfo rootx .] + ([winfo width .] - $width)/2}]
    set y [expr {[winfo rooty .] + ([winfo height .] - $height)/2}]
    # The leading + keeps a negative coordinate absolute on a monitor left of the primary.
    wm geometry $window "+$x+$y"
    wm deiconify $window
}

if {![info exists ::RuledMesh_no_gui]} {::RuledMesh::show}
