# AI Memory Kit — Setup & Usage

Lets your desktop AI remember what it was doing, even after you press Stop.
Memory lives in files, not in the model, so it works with GPT, Claude, and Gemini alike.

## Files
| File        | Purpose                                                        |
|-------------|----------------------------------------------------------------|
| RULES.md    | Instructions for the AI. Put into the system prompt / custom instructions. |
| MEMORY.md   | Short current state. The AI rewrites it as it works.           |
| LOG.md      | Append-only history of steps and commands.                     |

## Setup
1. Copy MEMORY.md and LOG.md into the root of your project folder
   (a folder the AI can read and write).
2. Paste the full content of RULES.md into the AI tool's system prompt /
   custom instructions (or its permanent instruction file, if it has one).
3. If the tool asks for permission on every file write, allow MEMORY.md and LOG.md.

## Daily use
- Give a task as usual. Stop whenever you want.
- Next run: just type **continue**. The AI reads MEMORY.md and resumes.
- When a chat gets long, open a NEW chat and type **continue**.
  Nothing is lost (state is in the files), and each run becomes much lighter,
  because the tool no longer resends a long chat history.
- Use a cheaper model for simple steps and a stronger one for hard steps;
  memory is shared through the files.

## Test it once
1. Ask the AI to do a small multi-step task.
2. Press Stop in the middle.
3. Open a new chat and type "continue".
4. It should say "Resuming from: ..." with the correct step.

## Maintenance (weekly)
- Ask the AI: "Compress old LOG.md entries into MEMORY.md, then move the
  old lines to LOG_archive.md."
- If you use git, commit MEMORY.md and LOG.md regularly as a backup.

## Optional: auto-pause after each step
Add this to RULES.md if you want the AI to stop by itself after every step:

    After finishing each step and updating the files, STOP.
    Report in at most 2 lines and wait for me to type "continue".
