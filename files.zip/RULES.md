# WORKING RULES

Paste this into the system prompt / custom instructions of your AI tool,
or keep it as the tool's permanent instruction file.

## 1. Start of every session
- Always read MEMORY.md first, before doing anything else.
- Read LOG.md only if MEMORY.md shows "Status: RUNNING", or when I ask.
- If Status is RUNNING, the previous session was interrupted:
  1. Read the last 10 lines of LOG.md.
  2. Check the real state of the unfinished step (Was the file edited? Did the command run?).
  3. Tell me in one line where you are resuming from, then continue.

## 2. Record state before every action
- Before EVERY action (editing a file, running a command, creating a file):
  - Update MEMORY.md: set "Status: RUNNING" and write the action under "In progress".
  - Append one line to LOG.md: "[time] START: <action>".
  - If running a command, also append:
    "[time] COMMAND: <exact command> (dir: <path>)".
- Never batch several actions and log them afterwards.

## 3. After every action
- Append to LOG.md: "[time] DONE: <one-line result>".
  For commands: "[time] RESULT: <success/error + 1-2 line summary>".
- Update MEMORY.md: "Done", "Next step", and set "Status: PAUSED"
  (or "Status: DONE" if the whole task is finished).

## 4. Write long content in chunks
- When creating a long file or document, write it to the file section by section
  (one heading, one function, one block at a time). Save each section immediately.
- Never compose the whole thing in a reply first and write it at the end.
- After each section, update MEMORY.md: "Written up to: <last section/function>".

## 5. Never duplicate work when resuming
- Before redoing an unfinished step, check the actual result:
  - Already done -> skip it and move to the next step.
  - Partly done -> finish only the missing part.
- Dangerous commands (delete, move, overwrite, migrate, deploy):
  if unsure whether it already ran, ASK ME before running it again.

## 6. When I type "continue"
1. Read MEMORY.md.
2. If Status is RUNNING, follow the recovery steps in section 1.
3. Reply with one line: "Resuming from: <step>", then work without asking again.

## 7. Saving tokens
- Keep replies short. Do not repeat what is already in MEMORY.md.
- Do not print whole files; edit files by replacing specific sections.
- Do not re-read files unrelated to the current step.
- Keep MEMORY.md under 60 lines. When it grows, compress the "Done" section.
- Keep LOG.md lean: no long outputs, only key lines (errors, important numbers).

## 8. Safety
- Never write passwords, tokens, or API keys into any file. Replace them with ***.
- LOG.md is append-only: never edit or delete existing lines.
- Important decisions and my preferences go into MEMORY.md as soon as they are stated.
