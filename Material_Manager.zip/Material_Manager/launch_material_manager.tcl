# Material Manager, portable copy: the one file to attach to a MAC button. Example MAC lines (use the real path of this file):
#   *createbutton(1, "Material Manager", 0, 0, 10, BUTTON, "Open Material Manager", "Run_Material_Manager", "D:/Tools/Material_Manager/launch_material_manager.tcl")
#   *beginmacro("Run_Material_Manager")
#   *evaltclscript($1,0)
#   *endmacro()
# It opens the manager from the folder it sits in; nothing outside that folder is read or written.
# In the workspace this file is a template in portable/: export_material_manager_portable.py copies it beside the sources.
if {[catch {
    set ::hmm_portable_launcher [file normalize [info script]]
    source -encoding utf-8 [file join [file dirname $::hmm_portable_launcher] launch_review.tcl]
    ::hmm_launch::request $::hmm_portable_launcher portable
} message]} {
    catch {puts stderr "Material Manager entry failed: $message"}
    catch {set ::hmm::status "Launch failed: $message"}
    catch {tk_messageBox -icon error -title "Material Manager" -message "Material Manager could not open:\n$message"}
}
