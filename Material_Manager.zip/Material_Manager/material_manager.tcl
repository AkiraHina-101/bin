# Tcl 8.5 / Tk 8.5. Stage edits locally; explicit Apply writes supported assignments.
namespace eval ::hmm {
    variable projectDir [file dirname [file normalize [info script]]]
    variable window .hmm_material_manager
    variable components {}
    variable properties {}
    variable materials {}
    variable status ""
    variable selectedProperty
    variable selectedMaterial
    variable selectedRow
    variable filterText ""
    variable sortColumn id
    variable sortReverse 0
    variable dragAnchor ""
}

# Fixture of the offline tests (tests/test_*.tcl): a small in-memory model. Not used by the tool itself.
proc ::hmm::reset_data {} {
    variable components
    variable properties
    variable materials
    set materials [dict create 0 {Unassigned} 1 {Steel} 2 {Aluminium} 3 {Rubber}]
    set properties [dict create 0 [dict create name {Unassigned} material 0] 101 [dict create name {Shell 1.2 mm} material 1] 102 [dict create name {Shell 2.0 mm} material 2] 103 [dict create name {Solid} material 1]]
    set components [dict create 1 [dict create name {Body left} property 101] 2 [dict create name {Body right} property 101] 3 [dict create name {Cover} property 102] 4 [dict create name {Bracket} property 103] 5 [dict create name {Unassigned part} property 0]]
}

proc ::hmm::choices {kind} {
    variable properties
    variable materials
    set result {}
    if {$kind eq "property"} {
        dict for {id data} $properties {lappend result "$id | [dict get $data name]"}
    } else {
        dict for {id name} $materials {lappend result "$id | $name"}
    }
    return $result
}


proc ::hmm::assign_property {cid pid} {
    variable components
    variable properties
    if {![dict exists $components $cid] || ![dict exists $properties $pid]} {error "Unknown component or property"}
    dict set components $cid property $pid
}

proc ::hmm::assign_material {pid mid} {
    variable properties
    variable materials
    if {$pid == 0 || ![dict exists $properties $pid] || ![dict exists $materials $mid]} {error "Select a valid property first"}
    dict set properties $pid material $mid
    return [property_users $pid]
}

proc ::hmm::property_users {pid} {
    variable components
    set users {}
    dict for {cid data} $components {
        if {[dict get $data property] == $pid} {lappend users $cid}
    }
    return $users
}




proc ::hmm::row_values {cid} {
    variable components
    variable properties
    variable materials
    set data [dict get $components $cid]
    set pid [dict get $data property]
    set mid [dict get $properties $pid material]
    set users [expr {$pid == 0 ? 0 : [llength [property_users $pid]]}]
    set materialName [dict get $materials $mid]
    if {[dict exists $::hmm_props::cards $pid] && [dict get $::hmm_props::cards $pid] eq "PBUSH"} {set materialName "Not used"}
    return [list $cid [dict get $data name] $pid [dict get $properties $pid name] $mid $materialName $users]
}

proc ::hmm::sync_rows {} {
    variable window
    variable components
    variable filterText
    set tree $window.table.tree
    set selected [$tree selection]
    set needle [string tolower [string trim $filterText]]
    set existing [$tree children {}]
    if {[llength $existing]} {$tree delete $existing}
    set rowIndex 0
    dict for {cid data} $components {
        set values [row_values $cid]
        set column [expr {[llength [info commands ::hmm_ui::filter_index]] ? [::hmm_ui::filter_index] : -1}]
        if {$column == -2 && [dict get $data property] != 0} {continue}
        set text [expr {$column >= 0 ? [lindex $values $column] : [join $values " "]}]
        if {$needle ne "" && [string first $needle [string tolower $text]] < 0} {continue}
        if {[info exists ::hmm::unassignedOnly] && $::hmm::unassignedOnly && [dict get $data property] != 0} {continue}
        set tag [expr {$rowIndex % 2 ? "alternate" : "normal"}]
        $tree insert {} end -id $cid -values $values -tags [list $tag] -image [::hmm_images::photo $cid]
        incr rowIndex
    }
    foreach cid $selected {if {[$tree exists $cid]} {$tree selection add $cid}}
    sort_rows 0
    fit_table_layout
}

proc ::hmm::fit_table_layout {} {
    variable window
    set tree $window.table.tree
    set bodyFont [ttk::style lookup HMM.Treeview -font]
    if {$bodyFont eq ""} {set bodyFont TkDefaultFont}
    set headerFont [ttk::style lookup HMM.Treeview.Heading -font]
    if {$headerFont eq ""} {set headerFont TkDefaultFont}
    foreach column {id property_id material_id} index {0 2 4} {
        set width [font measure $headerFont [$tree heading $column -text]]
        dict for {cid data} $::hmm::components {
            set width [expr {max($width, [font measure $bodyFont [lindex [row_values $cid] $index]])}]
        }
        $tree heading $column -anchor e
        $tree column $column -anchor e -stretch 0 -minwidth 24 -width [expr {$width + 24}]
    }
    set height [expr {[font metrics $bodyFont -linespace] + 8}]
    foreach row [$tree children {}] {
        set photo [$tree item $row -image]
        if {$photo ne ""} {set height [expr {max($height, [image height $photo] + 4)}]}
    }
    ttk::style configure HMM.Treeview -rowheight $height
    schedule_column_lines $tree
}

proc ::hmm::sort_rows {toggle} {
    variable window
    variable sortColumn
    variable sortReverse
    set tree $window.table.tree
    set entries {}
    set indices [dict create id 0 name 1 property_id 2 property_name 3 material_id 4 material_name 5 shared 6 mass 7 property_card 8 property_t 9 property_nsm 10 material_e 11 material_nu 12 material_rho 13 material_ge 14]
    set index [dict get $indices $sortColumn]
    foreach cid [$tree children {}] {
        set value [lindex [$tree item $cid -values] $index]
        if {$sortColumn in {mass property_t property_nsm material_e material_nu material_rho material_ge} && ![string is double -strict $value]} {set value -1}
        lappend entries [list $value $cid]
    }
    set mode [expr {$sortColumn eq "id" || $sortColumn eq "property_id" || $sortColumn eq "material_id" || $sortColumn eq "shared" ? "-integer" : $sortColumn in {mass property_t property_nsm material_e material_nu material_rho material_ge} ? "-real" : "-dictionary"}]
    set direction [expr {$sortReverse ? "-decreasing" : "-increasing"}]
    foreach entry [lsort $mode $direction -index 0 $entries] {$tree move [lindex $entry 1] {} end}
    if {[info exists ::hmm_tree::state($tree,native)]} {::hmm_tree::renumber $tree}
}

proc ::hmm::sort_by {column} {
    variable sortColumn
    variable sortReverse
    if {$sortColumn eq $column} {set sortReverse [expr {!$sortReverse}]} else {set sortColumn $column; set sortReverse 0}
    sort_rows 0
}

# Tk 8.5 Treeview has no body grid option; use one-pixel Tk borders at column edges.
proc ::hmm::column_lines {tree} {
    if {![winfo exists $tree]} {return}
    if {[info exists ::hmm_tree::state($tree,native)]} {return}
    set x 1
    set index 0
    if {"tree" in [$tree cget -show]} {
        incr x [$tree column #0 -width]
        set line $tree.gridlineImage
        if {![winfo exists $line]} {frame $line -background #c8cdd2 -borderwidth 0 -highlightthickness 0}
        place $line -x $x -y 1 -width 1 -relheight 1 -height -2
    }
    set columns [$tree cget -columns]
    foreach column [lrange $columns 0 end-1] {
        incr x [$tree column $column -width]
        set line $tree.gridline$index
        if {$column in {id property_id material_id}} {
            if {[winfo exists $line]} {place forget $line}
            incr index
            continue
        }
        if {![winfo exists $line]} {frame $line -background #c8cdd2 -borderwidth 0 -highlightthickness 0}
        place $line -x $x -y 1 -width 1 -relheight 1 -height -2
        incr index
    }
}

proc ::hmm::schedule_column_lines {tree} {
    if {[winfo exists $tree] && [info exists ::hmm_tree::state([winfo parent $tree],native)]} {set tree [winfo parent $tree]}
    variable lineTimer
    if {[info exists lineTimer]} {after cancel $lineTimer}
    set lineTimer [after idle [list ::hmm::column_lines $tree]]
}

proc ::hmm::select_shared {} {
    variable window
    variable components
    variable filterText
    variable status
    set tree $window.table.tree
    set selected [$tree selection]
    if {[llength $selected] != 1} {set status "Select one component to show shared property users."; return}
    set cid [lindex $selected 0]
    set pid [dict get $components $cid property]
    if {$pid == 0} {set status "This component has no property."; return}
    set users [property_users $pid]
    # Show all affected rows, including rows hidden by a previous filter.
    set filterText ""
    sync_rows
    $tree selection set $users
    $tree see $cid
    set status "Property $pid is shared by [llength $users] components."
}

proc ::hmm::drag_start {tree x y} {
    variable dragAnchor
    set dragAnchor ""
    if {[$tree identify region $x $y] in {cell tree}} {set dragAnchor [$tree identify row $x $y]}
}

proc ::hmm::drag_select {tree x y} {
    variable dragAnchor
    if {$dragAnchor eq ""} {return}
    set last [$tree identify row $x $y]
    if {$last eq ""} {return}
    set rows [$tree children {}]
    set a [lsearch -exact $rows $dragAnchor]
    set b [lsearch -exact $rows $last]
    if {$a < 0 || $b < 0} {return}
    if {$a > $b} {set tmp $a; set a $b; set b $tmp}
    $tree selection set [lrange $rows $a $b]
}

proc ::hmm::stage_cell {cid field value} {
    variable components
    variable properties
    variable materials
    set value [string trim $value]
    if {$value eq ""} {error "Value cannot be empty"}
    set pid [dict get $components $cid property]
    set mid [dict get $properties $pid material]
    if {$field in {id property_id material_id}} {
        if {![string is integer -strict $value] || $value <= 0} {error "ID must be a positive integer"}
    }
    switch -- $field {
        id {
            if {$value != $cid && [dict exists $components $value]} {error "Component ID already exists"}
            if {$value != $cid} {set data [dict get $components $cid]; dict unset components $cid; dict set components $value $data}
        }
        name {dict set components $cid name $value}
        property_id {
            if {$pid == 0} {error "No property assigned"}
            if {$value != $pid && [dict exists $properties $value]} {error "Property ID already exists"}
            if {$value != $pid} {
                set data [dict get $properties $pid]; dict unset properties $pid; dict set properties $value $data
                dict for {key data} $components {if {[dict get $data property] == $pid} {dict set components $key property $value}}
            }
        }
        property_name {if {$pid == 0} {error "No property assigned"}; dict set properties $pid name $value}
        material_id {
            if {$mid == 0} {error "No material assigned"}
            if {$value != $mid && [dict exists $materials $value]} {error "Material ID already exists"}
            if {$value != $mid} {
                set data [dict get $materials $mid]; dict unset materials $mid; dict set materials $value $data
                dict for {key data} $properties {if {[dict get $data material] == $mid} {dict set properties $key material $value}}
            }
        }
        material_name {if {$mid == 0} {error "No material assigned"}; dict set materials $mid $value}
        default {error "Column cannot be edited"}
    }
}

proc ::hmm::finish_edit {tree entry row field} {
    variable status
    if {![winfo exists $entry]} {return}
    set value [$entry get]
    destroy $entry
    if {[catch {stage_cell $row $field $value} message]} {set status "Error: $message"} else {set status "Pending: $field changed (not applied)."}
    sync_rows
}

proc ::hmm::double_click {tree x y} {
    if {$::hmm_images::busy} {return}
    if {[$tree identify region $x $y] eq "separator"} {
        set column [$tree identify column $x $y]
        if {$column eq "#0"} {$tree column #0 -width 104; return -code break}
        set width [font measure TkDefaultFont [$tree heading $column -text]]
        foreach row [$tree children {}] {
            set index [expr {[string range $column 1 end] - 1}]
            set width [expr {max($width, [font measure TkDefaultFont [lindex [$tree item $row -values] $index]])}]
        }
        $tree column $column -width [expr {$width + 30}]
        schedule_column_lines $tree
        return -code break
    }
    if {[$tree identify column $x $y] eq "#0"} {
        set row [$tree identify row $x $y]
        if {$row ne "" && [catch {::hmm_images::preview $row} message]} {set ::hmm::status "Preview failed: $message"}
        return -code break
    }
    if {[$tree identify region $x $y] ne "cell"} {return}
    set row [$tree identify row $x $y]
    set column [$tree identify column $x $y]
    set index [expr {[string range $column 1 end] - 1}]
    set field [lindex [$tree cget -columns] $index]
    if {$field eq "shared"} {return}
    set box [$tree bbox $row $column]
    if {[llength $box] != 4} {return}
    set entry $tree.editor
    if {[winfo exists $entry]} {destroy $entry}
    ttk::entry $entry
    $entry insert 0 [lindex [$tree item $row -values] $index]
    place $entry -x [lindex $box 0] -y [lindex $box 1] -width [lindex $box 2] -height [lindex $box 3]
    $entry selection range 0 end
    focus $entry
    bind $entry <Return> [list ::hmm::finish_edit $tree $entry $row $field]
    bind $entry <Escape> [list destroy $entry]
    return -code break
}

# Make the HyperMesh main window the Win32 owner: the tool stays above it (not above other
# applications) while keeping its own minimize and maximize buttons.
proc ::hmm::keep_above_host {} {
    variable window
    variable ownerError ""
    if {[catch {
        package require twapi
        # twapi handles are {decimal HWND}; GWLP_HWNDPARENT takes the owner as a plain integer.
        set child [list [expr {[wm frame $window]}] HWND];set host [list [expr {[wm frame .]}] HWND]
        twapi::SetWindowLongPtr $child -8 [lindex $host 0]
        if {[twapi::get_owner_window $child] ne $host} {error "owner was not applied"}
    } message]} {set ownerError $message}
}

proc ::hmm::open {} {
    variable window
    variable components
    variable status
    variable filterText
    package require Tk 8.5
    package require Ttk
    if {[winfo exists $window]} {::hmm_props::sidebar_destroy;catch ::hmm_ui::release_splits;destroy $window}
    if {![dict size $components]} {error "No model data loaded"}
    toplevel $window
    wm withdraw $window
    wm title $window "Material Manager"
    wm protocol $window WM_DELETE_WINDOW ::hmm::close
    wm geometry $window 1420x720
    wm minsize $window 1200 560
    set filterText ""
    ttk::frame $window.bottom -padding 12
    pack $window.bottom -side bottom -fill x
    ttk::button $window.bottom.reset -text "Reload" -width 15 -command ::hmm::open_live
    ttk::button $window.bottom.close -text "Close" -width 15 -command ::hmm::close
    pack $window.bottom.close $window.bottom.reset -side right -padx 5
    ttk::label $window.bottom.status -textvariable ::hmm::status -wraplength 650
    pack $window.bottom.status -side left -fill x -expand 1
    ttk::panedwindow $window.content -orient horizontal
    pack $window.content -fill both -expand 1
    ttk::frame $window.table -padding 10
    ttk::frame $window.sidebar -width 420 -padding {0 10 10 10}
    pack propagate $window.sidebar 0
    $window.content add $window.table -weight 3
    $window.content add $window.sidebar -weight 0
    ::hmm_props::sidebar_create $window.sidebar
    ttk::style configure HMM.Treeview -background white -fieldbackground white -indent 0
    # A flat image column needs no tree disclosure indicator or text reservation.
    # An unpacked image element is centered in the complete row/column parcel.
    ttk::style layout HMM.Treeview.Item {
        Treeitem.padding -sticky nswe -children {
            Treeitem.image -sticky {}
        }
    }
    ttk::style configure HMM.Treeview.Heading -borderwidth 1 -relief flat -padding {4 1}
    ::hmm_tree::create $window.table.tree
    ttk::scrollbar $window.table.scroll -orient vertical -command [list $window.table.tree yview]
    grid $window.table.tree -row 0 -column 0 -sticky nsew
    grid $window.table.scroll -row 0 -column 1 -sticky ns
    grid rowconfigure $window.table 0 -weight 1
    grid columnconfigure $window.table 0 -weight 1
    foreach {column title width} {id ID 60 name Component 105 property_id ID 60 property_name Property 105 material_id ID 60 material_name Material 105 shared Shared 60} {
        $window.table.tree heading $column -text $title -anchor center -command [list ::hmm::sort_by $column]
        $window.table.tree column $column -width $width -stretch 1 -anchor w
    }
    foreach column {id property_id material_id} {
        $window.table.tree heading $column -anchor e
        $window.table.tree column $column -anchor e -stretch 0
    }
    bind $window.table.tree <ButtonPress-1> {::hmm::drag_start %W %x %y}
    bind $window.table.tree <B1-Motion> {::hmm::drag_select %W %x %y}
    bind $window.table.tree <Double-Button-1> {::hmm::double_click %W %x %y}
    bind $window.table.tree <Configure> {::hmm::schedule_column_lines %W}
    bind $window.table.tree <ButtonRelease-1> {::hmm::schedule_column_lines %W}
    bind $window.table.tree <<TreeviewSelect>> {::hmm_props::sidebar_schedule}
    sync_rows
    if {[llength [info commands ::hmm_ui::install]]} {::hmm_ui::install}
    set status "[dict size $components] components"
    # Position while withdrawn; mapping and moving again can split the host window.
    update idletasks
    set x [expr {[winfo rootx .] + ([winfo width .] - 1420) / 2}]
    set y [expr {[winfo rooty .] + ([winfo height .] - 720) / 2}]
    wm geometry $window [format "1420x720%+d%+d" $x $y]
    wm deiconify $window
    update idletasks
    keep_above_host
    ::hmm_props::consume_review_layout
    return $window
}


# The adapter uses documented queries only. It never creates marks or writes entities.
# With the window open, the read shows its progress in the footer bar (one step per entity).
proc ::hmm::read_model {} {
    variable readStep 0
    set ui [expr {[llength [info commands ::hmm_ui::progress_step]] && [llength [info commands winfo]] && [info exists ::hmm::window] && [winfo exists $::hmm::window]}]
    if {$ui} {
        set total 0
        foreach kind {mats props comps} {
            if {[catch {hm_entitycount $kind} n]} {set n [llength [hm_entitylist $kind id all]]}
            incr total $n
        }
        ::hmm_ui::progress_begin $total "Reading model" read
    }
    catch read_model_entities result options
    if {$ui} {::hmm_ui::progress_end read}
    return -options $options $result
}
proc ::hmm::read_tick {} {
    variable readStep
    if {[incr readStep] % 10 == 0 && [llength [info commands ::hmm_ui::progress_step]]} {catch {::hmm_ui::progress_step $readStep read}}
}
proc ::hmm::read_model_entities {} {
    if {![llength [info commands hm_getvalue]] || ![llength [info commands hm_entitylist]]} {
        error "Open this tool inside HyperMesh (hm_getvalue and hm_entitylist are not available here)"
    }
    set newMaterials [dict create 0 {Unassigned}]
    foreach mid [hm_entitylist mats id all] {
        read_tick
        dict set newMaterials $mid [hm_getvalue mats id=$mid dataname=name]
    }
    set newProperties [dict create 0 [dict create name {Unassigned} material 0]]
    foreach pid [hm_entitylist props id all] {
        read_tick
        set name [hm_getvalue props id=$pid dataname=name]
        set mid [hm_getvalue props id=$pid dataname=materialid]
        if {$mid eq ""} {set mid 0}
        if {![string is integer -strict $mid]} {error "Invalid material reference on property $pid"}
        if {![dict exists $newMaterials $mid]} {dict set newMaterials $mid "Unresolved material"}
        dict set newProperties $pid [dict create name $name material $mid]
    }
    set newComponents {}
    foreach cid [hm_entitylist comps id all] {
        read_tick
        set name [hm_getvalue comps id=$cid dataname=name]
        set pid [hm_getvalue comps id=$cid dataname=propertyid]
        if {$pid eq ""} {set pid 0}
        if {![string is integer -strict $pid]} {error "Invalid property reference on component $cid"}
        if {![dict exists $newProperties $pid]} {
            dict set newProperties $pid [dict create name {Unresolved property} material 0]
        }
        dict set newComponents $cid [dict create name $name property $pid]
    }
    return [list $newComponents $newProperties $newMaterials]
}

# ---- Undo history ----------------------------------------------------------------------------------------------------------
# HyperMesh puts commands run from Tcl into its undo history only while "history from Tcl" is on: the model browser switches it on
# around its own rename and dataname edits (hm/scripts/br/common/helpers.tcl ::hm::br::startNoteHistory). Without it a step note is
# empty and Ctrl+Z skips the change. Every model change of the tool runs inside history_begin/history_end, or native_edit for one
# value (that gives the same step HyperMesh's own editors write, e.g. "Modified Name of Property from A to B").
proc ::hmm::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1};*startnotehistorystate $label}
proc ::hmm::history_end {label} {catch {*endnotehistorystate $label};catch {hm_private_frwk enablehistoryfromtcl 0}}
proc ::hmm::native_edit {script} {
    catch {hm_private_frwk enablehistoryfromtcl 1}
    set code [catch {uplevel 1 $script} result options]
    catch {hm_private_frwk enablehistoryfromtcl 0}
    return -options $options $result
}
# Several changes as one undo step; the step is closed even when the script fails.
proc ::hmm::undoable {label script} {
    history_begin $label
    set code [catch {uplevel 1 $script} result options]
    history_end $label
    return -options $options $result
}


proc ::hmm::load_model {} {
    set snapshot [read_model]
    foreach name {components properties materials} value $snapshot {set ::hmm::$name $value}
    set ::hmm_apply::baseline $snapshot
    set ::hmm_apply::baselineModel [hm_info currentfile]
    set ::hmm_apply::blocked 0
    set ::hmm_props::cards [dict create]
    foreach pid [dict keys $::hmm::properties] {
        if {$pid > 0 && ![catch {hm_getvalue props id=$pid dataname=cardimage} card]} {dict set ::hmm_props::cards $pid $card}
    }
    return [dict size $::hmm::components]
}

proc ::hmm::open_live {} {
    variable status
    set status "Reading model..."
    if {[catch {load_model} message options]} {
        set status "Read failed: $message"
        return -options $options $message
    }
    # The readback file is evidence only: a failure to write it must not keep the window from opening.
    set readbackError ""
    if {[catch {write_readback} message]} {set readbackError $message}
    ::hmm_images::clear
    open
    set status "[dict size $::hmm::components] components"
    if {$readbackError ne ""} {append status "; readback file not saved: $readbackError"}
    # The images of this model (its own folder, or the folder shown in the Image folder box).
    if {[catch {::hmm_images::load_saved} error]} {set status "Images not loaded: $error"}
}

proc ::hmm::tsv_value {value} {
    return [string map [list "\t" {\t} "\r" {\r} "\n" {\n}] $value]
}

# Folder for the evidence of one read or write. In the workspace it is 02_HM_MCP/evidence; a portable copy (opened by its own
# launcher, which sets ::hmm::portable) keeps it in an evidence folder beside the tool.
proc ::hmm::evidence_folder {kind} {
    if {[info exists ::hmm::portable] && $::hmm::portable} {
        set root [file join $::hmm::projectDir evidence]
    } else {
        set root [file join [file dirname [file dirname $::hmm::projectDir]] 02_HM_MCP evidence]
    }
    return [file join $root $kind "[pid]_[clock seconds]_[clock clicks]"]
}

# Local evidence contains queried names, references, runtime identity and source hash input.
# No model data is saved or modified by this routine.
proc ::hmm::write_readback {} {
    variable projectDir
    variable components
    variable properties
    variable materials
    set folder [evidence_folder material_manager_reads]
    file mkdir $folder
    set f [::open [file join $folder components.tsv] {WRONLY CREAT EXCL}]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f "component_id\tcomponent_name\tproperty_id\tproperty_name\tmaterial_id\tmaterial_name"
    dict for {cid data} $components {
        set pid [dict get $data property]
        set mid [dict get $properties $pid material]
        set fields {}
        foreach value [list $cid [dict get $data name] $pid [dict get $properties $pid name] $mid [dict get $materials $mid]] {
            lappend fields [tsv_value $value]
        }
        puts $f [join $fields "\t"]
    }
    ::close $f
    set f [::open [file join $folder runtime.tsv] {WRONLY CREAT EXCL}]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f "pid\t[pid]"
    puts $f "build\t[hm_info -appinfo DISPLAYVERSION]"
    puts $f "tcl\t[info patchlevel]"
    puts $f "component_count\t[dict size $components]"
    puts $f "epoch\t[clock seconds]"
    puts $f "operation\tread_component_property_material"
    if {[llength [info commands hm_getcurrentview]]} {puts $f "current_view\t[tsv_value [hm_getcurrentview]]"}
    puts $f "source\t[tsv_value [file join $projectDir material_manager.tcl]]"
    ::close $f
    file copy [file join $projectDir material_manager.tcl] [file join $folder source_snapshot.tcl]
    set f [::open [file join $projectDir LAST_MODEL_READ.txt] w]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f $folder
    ::close $f
    return $folder
}

proc ::hmm::set_image_busy {busy} {
    variable window
    set state [expr {$busy ? "disabled" : "!disabled"}]
    foreach container [list $window.bottom] {
        foreach child [winfo children $container] {
            if {[winfo class $child] in {TButton TCombobox TEntry}} {$child state $state}
        }
    }
}

proc ::hmm::close {} {
    if {$::hmm_images::busy} {::hmm_images::cancel; return}
    # Isolate only ends with the window (the display stays as it is)
    set ::hmm_ui::isolateOn 0
    ::hmm_props::sidebar_destroy
    catch ::hmm_ui::release_splits
    destroy $::hmm::window
}

source -encoding utf-8 [file join $::hmm::projectDir component_images.tcl]
source -encoding utf-8 [file join $::hmm::projectDir assignments.tcl]
source -encoding utf-8 [file join $::hmm::projectDir property_tools.tcl]
source -encoding utf-8 [file join $::hmm::projectDir material_library.tcl]

source -encoding utf-8 [file join $::hmm::projectDir workflow.tcl]
source -encoding utf-8 [file join $::hmm::projectDir component_table.tcl]
source -encoding utf-8 [file join $::hmm::projectDir workspace.tcl]
