# Four model/library views with independent selection and assignment queues.
namespace eval ::hmm_ui {
    variable selection
    if {![array exists selection]} {array set selection {components {} properties {} materials {} library {}}}
    variable query;variable notice
    foreach name {query notice} {if {![array exists $name]} {array set $name {components {} properties {} materials {} library {}}}}
    variable active components
    variable previous components
    variable detailType components
    variable splitRatio
    if {![info exists splitRatio]} {set splitRatio 0.53}
    variable installed 0
}
proc ::hmm_ui::page {type} {
    if {$type eq "components"} {return $::hmm::window.primary}
    return $::hmm::window.sidebar.split.tabs.$type
}
proc ::hmm_ui::activate {type} {
    if {$type eq "components"} {selected components;return}
    $::hmm::window.sidebar.split.tabs select [page $type]
    changed
}
# Status line labels: "Error:" (red) for a refused action, "Warning:" (orange) for something to look at, a check mark (green) for a
# finished action; no label for progress and plain information. Messages say what happened in a few words.
proc ::hmm_ui::run {command} {
    updated_clear
    if {[catch {uplevel #0 $command} message options]} {set ::hmm::status "\u26a0 Error: $message";return 0}
    return 1
}
proc ::hmm_ui::warn {text} {set ::hmm::status "\u26a0 Warning: $text"}
# A finished action is shown in green, without a sign; the next message (of any kind) takes the colour away again.
set ::hmm_ui::statusDone 0
proc ::hmm_ui::done {text} {set ::hmm_ui::statusDone 1;set ::hmm::status $text}
proc ::hmm_ui::status_colour {args} {
    set ok $::hmm_ui::statusDone;set ::hmm_ui::statusDone 0
    if {![info exists ::hmm::window]} {return}
    set label [statusbar].status
    if {![winfo exists $label]} {return}
    set colour ""
    if {[string match "\u26a0 Error*" $::hmm::status]} {set colour #c00000} elseif {[string match "\u26a0*" $::hmm::status]} {set colour #b35c00} elseif {$ok} {set colour #1a7f37}
    $label configure -foreground $colour
    # The message is shown without its sign: the native icon (error, warning, done) stands in front of it instead.
    set ::hmm_ui::statusText [regsub "^\u26a0 " $::hmm::status ""]
    set icon [expr {$colour eq "#c00000" ? "messageError" : $colour eq "#b35c00" ? "messageWarning" : $ok ? "check" : ""}]
    catch {$label configure -image [expr {$icon eq "" ? "" : [icon $icon]}]}
}
trace remove variable ::hmm::status write ::hmm_ui::status_colour
trace add variable ::hmm::status write ::hmm_ui::status_colour
proc ::hmm_ui::create_pages {parent} {
    ::hmm_props::table_preferences
    # The library stays in memory while HyperMesh runs. One read by an older build lacks the columns added since (Units, Group, JP name,
    # extra columns): read it again from its file, or Save would write those columns empty.
    set stale 0
    if {[dict size $::hmm_lib::records]} {set stale [expr {![dict exists $::hmm_lib::records [lindex [dict keys $::hmm_lib::records] 0] Extra]}]}
    if {![dict size $::hmm_lib::records] || ($stale && !$::hmm_lib::dirty)} {
        set source [expr {$stale && $::hmm_lib::path ne "" && [file isfile $::hmm_lib::path] ? $::hmm_lib::path : [file join $::hmm::projectDir library jis_23_N_mm_s_tonne.csv]}]
        ::hmm_lib::load $source
    }
    hwtk::splitframe $parent.split -orient vertical -refreshondrag 0 -showbutton 1
    guard_split $parent.split
    pack $parent.split -fill both -expand 1
    bind $parent.split <ButtonRelease-1> {+::hmm_ui::remember_split}
    ttk::notebook $parent.split.tabs -width 620 -height 320
    # No top padding: the sash already separates the table from the Entity title.
    ttk::frame $parent.split.lower -height 260 -padding 0
    # Native editors request their full content height; panes must not inherit it.
    pack propagate $parent.split.lower 0
    $parent.split add $parent.split.tabs
    $parent.split add $parent.split.lower
    thin_sashes $parent.split;after idle ::hmm_ui::thin_retry
    foreach type {properties materials library names} {
        ttk::frame $parent.split.tabs.$type
        $parent.split.tabs add $parent.split.tabs.$type -text [expr {$type eq "names" ? "Part name" : [string totitle $type]}]
    }
    bind $parent.split.tabs <<NotebookTabChanged>> {::hmm_ui::run ::hmm_ui::changed}
    bind $parent <Destroy> [list ::hmm_props::sidebar_destroy_event %W]
}
proc ::hmm_ui::install {} {
    variable installed 1
    # A tool that has just been opened has calculated no mass (see mass_auto_run).
    set ::hmm_ui::massRequested 0
    set w $::hmm::window
    $w.content forget $w.table
    $w.content forget $w.sidebar
    destroy $w.content
    hwtk::splitframe $w.content -orient horizontal -refreshondrag 0 -showbutton 1
    guard_split $w.content
    # Placed (not packed) so the contents can be held at their old size while the window border is dragged.
    place $w.content -x 0 -y 0 -relwidth 1 -relheight 1
    bind $w <Configure> {::hmm_ui::window_resized %W %w %h}
    set ::hmm_ui::frozen 0;set ::hmm_ui::sizeW 0;set ::hmm_ui::sizeH 0
    frame $w.content.primaryPane
    frame $w.content.sidebarPane
    # Sidebar (tabs + Entity) on the left, main table on the right: the sash position is the sidebar width.
    $w.content add $w.content.sidebarPane
    $w.content add $w.content.primaryPane
    thin_sashes $w.content;after idle ::hmm_ui::thin_retry
    # No padding on the sash side: the visible gap between the two regions is the splitframe's own 12 px.
    ttk::frame $w.primary -padding {0 4 8 4}
    $w.sidebar configure -padding {8 4 0 4} -width 620
    $w.table configure -padding 0
    pack propagate $w.sidebar 0
    pack $w.primary -in $w.content.primaryPane -fill both -expand 1
    pack $w.sidebar -in $w.content.sidebarPane -fill both -expand 1
    raise $w.primary;raise $w.sidebar
    bind $w.content <ButtonRelease-1> {+::hmm_ui::sash_released}
    set lower $w.sidebar.split.lower
    # The lower region has no tab (as the Entity Editor under HyperMesh's own browser): the editor sits right under the sash.
    # strip.e holds the Entity editor or the read-only preview; the New panel takes its place while it is open.
    ttk::frame $lower.strip -width 1 -height 1
    ttk::frame $lower.strip.e
    pack $lower.strip.e -fill both -expand 1
    pack $lower.strip -side top -fill both -expand 1
    ttk::frame $lower.entity
    pack $lower.entity -in $lower.strip.e -fill both -expand 1
    set details $lower.entity
    # Uncreated library entries have no native entity ID. Show their proposed fields read-only.
    ttk::frame $lower.proposed
    hwtk::propertysheet $lower.proposed.sheet -showheader 1
    pack $lower.proposed.sheet -side top -fill both -expand 1
    build_footer
    set key hmm_material_sidebar
    ::hm::PropertyAreaViewManager::AddKey $key
    ::hm::PropertyAreaViewManager::UpdateData $key 1 contextmenustatus
    array set ::hm::notebooktab::panedwindow::${key} [list propertyarea:frame $details propertyarea:status 1]
    set ::hm::paController::funcs::_paControllerVars(${key}|bbcreate) 0
    ::hm::paController::funcs::CreatePropertyAreaWidget $key
    foreach {name value} {sidebarIds {} editorTarget {} targetSelection {} sidebarKind components sidebarTimer {}} {set ::hmm_props::$name $value}
    components_controls
    action_buttons
    pack $w.table -in [page components] -side top -fill both -expand 1
    # The table is a root sibling managed inside the pane; keep it above that pane.
    raise $w.table $w.primary
    bind $w.table.tree <ButtonRelease-3> {::hmm_ui::context components %W %x %y %X %Y}
    bind $w.table.tree <<TreeviewSelect>> {::hmm_ui::components_select_event}
    # The new assignment queue owns edits; native details own direct field editing.
    bind $w.table.tree <Double-Button-1> {::hmm_ui::component_double %W %x %y}
    $w.bottom.reset configure -command {::hmm_ui::run {::hmm_ui::refresh all}}
    catch ::hmm_ui::apply_icons
    changed
    if {[lsearch -exact [trace info variable ::hmm::status] [list write ::hmm_ui::status_changed]] < 0} {trace add variable ::hmm::status write ::hmm_ui::status_changed}
    after idle ::hmm_props::review_sash
    after 250 ::hmm_props::review_sash
    foreach delay {200 600 1200} {after $delay ::hmm_ui::align_regions}
    bind $w.table <Map> {+::hmm_ui::align_later}
    bind $w.content <Configure> {after idle {::hmm_ui::ensure_main_pane 0}}
    foreach event {<ButtonRelease-1> <KeyRelease> <FocusOut>} {bind $w $event {+::hmm_props::model_check_later %W}}
    # Diagnosis only: an empty window to drag next to the tool (tests/bare_drag_window.tcl).
    if {[file exists [file join $::hmm::projectDir settings bare_drag.on]]} {after 3000 [list catch [list source [file join $::hmm::projectDir tests bare_drag_window.tcl]]]}
}
# Bottom of the window, as in HyperMesh's own windows: the status row spans the full width under a separator ("Ready", or the bar
# of a running operation, then the summary and the last message). The button row belongs to the main region only: a separator
# line above it runs from the Entity region's edge (a vertical separator) to the right, and the Entity region goes down to the
# status row.
proc ::hmm_ui::statusbar {} {return $::hmm::window.foot.bar}
# A 1 px line drawn as a plain Tk frame in the colour of HyperMesh's separator (#AFBAC2 on #F1F1F1, read from a capture).
# Not ttk::separator: under HyperMesh's hwunity theme each one costs about 0.4-2.7 s of painting at every window resize step
# (measured 06/11/2026 on the 153-Component model, tests/native_resize_model_probe.tcl), which made dragging the border lag.
proc ::hmm_ui::line {path orient} {
    if {$orient eq "vertical"} {set size [list -width 1]} else {set size [list -height 1]}
    frame $path -background #AFBAC2 -borderwidth 0 -highlightthickness 0 {*}$size
    return $path
}
proc ::hmm_ui::build_footer {} {
    set w $::hmm::window
    foreach old [list $w.foot $w.btnarea] {if {[winfo exists $old]} {destroy $old}}
    pack forget $w.bottom.status
    pack forget $w.bottom $w.bottom.close $w.bottom.reset
    ttk::frame $w.btnarea
    line $w.btnarea.v vertical
    line $w.btnarea.h horizontal
    pack $w.btnarea.v -side left -fill y
    pack $w.btnarea.h -side top -fill x -padx {6 0} -pady {4 0}
    $w.bottom configure -padding {8 6 0 2}
    pack $w.bottom -in $w.btnarea -side top -fill x
    pack $w.bottom.close -side right
    pack $w.bottom.reset -side right -padx {0 6}
    set first [lindex [pack slaves $w.primary] 0]
    if {$first ne ""} {pack $w.btnarea -in $w.primary -side bottom -fill x -before $first} else {pack $w.btnarea -in $w.primary -side bottom -fill x}
    ttk::frame $w.foot
    line $w.foot.sep horizontal
    pack $w.foot.sep -side top -fill x
    set bar $w.foot.bar
    ttk::frame $bar -padding {8 0}
    ttk::label $bar.ready -text Ready
    ttk::label $bar.pending -textvariable ::hmm_ui::pendingText
    ttk::label $bar.task -textvariable ::hmm_ui::progressTask -foreground #555555
    hwtk::progressbar $bar.progress -mode determinate -length 160 -variable ::hmm_ui::progressValue
    set ::hmm_ui::statusText [regsub "^\u26a0 " $::hmm::status ""]
    ttk::label $bar.status -textvariable ::hmm_ui::statusText -justify left -compound left
    pack $bar.ready -side left -padx {0 16}
    pack $bar.pending -side left
    pack $bar.status -side left -padx {16 0} -fill x -expand 1
    # One fixed height, so the row does not grow while the bar is shown.
    pack propagate $bar 0
    $bar configure -height [expr {max([winfo reqheight $bar.progress], [winfo reqheight $bar.status]) + 8}]
    pack $bar -side top -fill x
    place $w.foot -relx 0 -rely 1 -anchor sw -relwidth 1
    # The button row was created before the regions: lift it above them.
    raise $w.foot;raise $w.btnarea;raise $w.bottom
    update idletasks
    content_place
}
proc ::hmm_ui::footer_height {} {
    set w $::hmm::window
    if {![winfo exists $w.foot]} {return 0}
    return [winfo reqheight $w.foot]
}
# The regions fill the window above the footer; while the window border is dragged they are held at their size (see window_resized).
proc ::hmm_ui::content_place {} {
    set w $::hmm::window
    set fh [footer_height]
    if {$::hmm_ui::frozen} {
        # (Measured 05/11/2026 in a user session, 153 Components with images: while the border is dragged each step still blocks
        # the main thread 100-280 ms painting the held contents. Hiding them does not help: unmapping breaks the hwtk splitframes,
        # and a frame laid over them makes it worse, because uncovering paints everything again: 1.3-1.8 s.)
        place configure $w.content -relwidth 0 -relheight 0 -width $::hmm_ui::sizeW -height [expr {max(1, $::hmm_ui::sizeH - $fh)}]
    } else {
        place configure $w.content -relwidth 1 -relheight 1 -width 0 -height [expr {-$fh}]
    }
}
# Neither pane may be dragged out of reach: a collapsed or tiny pane returns to the default split,
# an out-of-range one is clamped. The splitframe has no minimum size of its own.
# A splitframe can still get <Configure> while its window is being torn down and then fails on a
# missing hull. Its events are bound on a per-widget tag; run them inside catch so that race is silent.
proc ::hmm_ui::guard_split {path} {
    foreach event {<Configure> <Expose> <Map>} {
        set script [bind HWSplitframe-$path $event]
        if {$script ne "" && ![string match {catch *} $script]} {bind HWSplitframe-$path $event "catch {$script}"}
    }
}
# A splitframe still handles <Configure> while its window is torn down and then fails on a missing hull.
proc ::hmm_ui::release_splits {} {
    foreach path [list $::hmm::window.content $::hmm::window.sidebar.split] {
        # The splitframe binds its events on a per-widget tag, HWSplitframe-<path>.
        if {[winfo exists $path]} {foreach event {<Configure> <Expose> <Map>} {catch {bind HWSplitframe-$path $event {}}}}
    }
}
# The sashes are HyperMesh's own (size, grip and the collapse button of hwtk::splitframe, as between its browser and the Entity
# Editor): nothing is restyled. The splitframe keeps 12 px between its two panes.
set ::hmm_ui::sashGap 12
# The sash widgets appear only after the first layout, so this runs again from the layout handlers: it only watches each sash
# once, to keep the regions within their limits after a move.
proc ::hmm_ui::thin_sashes {split} {
    if {![winfo exists $split]} {return}
    foreach sash [winfo children $split] {
        if {![string match *.__sash?__ $sash]} {continue}
        if {[bind $sash <Configure>] eq ""} {bind $sash <Configure> {+after idle ::hmm_ui::limit_sashes}}
    }
}
# A region folded away with the collapse button of the sash (its pane is then unmapped) is left folded.
proc ::hmm_ui::collapsed {split} {
    if {![winfo exists $split] || ![winfo ismapped $split]} {return 0}
    foreach pane [$split panes] {if {[winfo exists $pane] && ![winfo ismapped $pane]} {return 1}}
    return 0
}
# ---- Resizing the window: the contents follow the border at a steady pace ----
# Between two layouts the contents are held at their size (place with a fixed width/height); a layout runs at most every
# ::hmm_ui::settleMs while the border is dragged (throttled: an event does not push the pending layout back), and one more after
# the last size change. Measured 06/11/2026 on the 153-Component model: one layout 120-150 ms, a held step 40-50 ms. (Before,
# the contents were held until the mouse button was released, because a layout cost about 1 s; that cost was the
# ttk::separator painting, see ::hmm_ui::line. Holding until the release made the bottom of the window jump at the end.)
set ::hmm_ui::settleMs 40
set ::hmm_ui::frozen 0;set ::hmm_ui::sizeW 0;set ::hmm_ui::sizeH 0;set ::hmm_ui::resizeTimer ""
proc ::hmm_ui::window_resized {win width height} {
    if {![info exists ::hmm::window] || $win ne $::hmm::window || ![winfo exists $::hmm::window.content]} {return}
    if {$::hmm_ui::traceOn} {trace_event resize "$width $height frozen $::hmm_ui::frozen"}
    set w $::hmm::window
    if {!$::hmm_ui::frozen} {
        if {$::hmm_ui::sizeW <= 1} {set ::hmm_ui::sizeW $width;set ::hmm_ui::sizeH $height;return}
        if {$width == $::hmm_ui::sizeW && $height == $::hmm_ui::sizeH} {return}
        set ::hmm_ui::frozen 1
        content_place
    }
    # (ensure_main_pane does not widen the window for a while after the window was resized by the user)
    set ::hmm_ui::lastResize [clock milliseconds]
    if {$::hmm_ui::resizeTimer eq ""} {set ::hmm_ui::resizeTimer [after $::hmm_ui::settleMs {catch ::hmm_ui::window_settle}]}
}
proc ::hmm_ui::window_settle {} {
    set ::hmm_ui::resizeTimer ""
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window.content]} {return}
    catch {incr ::hmm_ui::settleRuns}
    set w $::hmm::window
    set t0 [clock microseconds]
    set ::hmm_ui::frozen 0
    content_place
    update idletasks
    set t1 [clock microseconds]
    set ::hmm_ui::sizeW [winfo width $w];set ::hmm_ui::sizeH [winfo height $w]
    # A sash dragged while the contents were held is checked now (the check is skipped while they are held).
    catch {::hmm_ui::ensure_main_pane 0}
    set t2 [clock microseconds]
    catch ::hmm_ui::align_regions
    set t3 [clock microseconds]
    if {$::hmm_ui::traceOn} {
        trace_event settle [format "layout %.0f ms, ensure_main_pane %.0f ms, align_regions %.0f ms" [expr {($t1-$t0)/1000.0}] [expr {($t2-$t1)/1000.0}] [expr {($t3-$t2)/1000.0}]]
        trace_flush
    }
}
# ---- Resize trace (diagnosis only): on while settings/resize_trace.on exists. Every resize event of the window, a 15 ms heartbeat
# while the contents are held (a late beat = the main thread was blocked, by the tool or by HyperMesh itself, e.g. redrawing the
# model) and the parts of the layout after the release go to LAST_RESIZE_TRACE.txt in the tool folder.
set ::hmm_ui::traceOn [file exists [file join $::hmm::projectDir settings resize_trace.on]]
set ::hmm_ui::traceLines {}
set ::hmm_ui::traceLast 0
set ::hmm_ui::traceBeat ""
proc ::hmm_ui::trace_event {kind text} {
    set now [clock microseconds]
    set gap [expr {$::hmm_ui::traceLast ? ($now - $::hmm_ui::traceLast) / 1000.0 : 0}]
    set ::hmm_ui::traceLast $now
    lappend ::hmm_ui::traceLines [format "%s	%s	gap %.1f ms	%s" [clock format [expr {$now / 1000000}] -format %H:%M:%S].[format %03d [expr {($now / 1000) % 1000}]] $kind $gap $text]
    if {$kind eq "resize" && $::hmm_ui::traceBeat eq ""} {set ::hmm_ui::traceBeatAt $now;set ::hmm_ui::traceBeat [after 15 ::hmm_ui::trace_beat]}
}
proc ::hmm_ui::trace_beat {} {
    set now [clock microseconds]
    set late [expr {($now - $::hmm_ui::traceBeatAt) / 1000.0 - 15}]
    if {$late > 35} {lappend ::hmm_ui::traceLines [format "%s	blocked	%.0f ms late" [clock format [expr {$now / 1000000}] -format %H:%M:%S].[format %03d [expr {($now / 1000) % 1000}]] $late]}
    set ::hmm_ui::traceBeatAt $now
    if {$::hmm_ui::frozen} {set ::hmm_ui::traceBeat [after 15 ::hmm_ui::trace_beat]} else {set ::hmm_ui::traceBeat ""}
}
proc ::hmm_ui::trace_flush {} {
    catch {
        set f [open [file join $::hmm::projectDir LAST_RESIZE_TRACE.txt] a];fconfigure $f -encoding utf-8
        foreach line $::hmm_ui::traceLines {puts $f $line}
        puts $f "---"
        close $f
    }
    set ::hmm_ui::traceLines {};set ::hmm_ui::traceLast 0
}
# Polls until both splitframes have their sash (no event is guaranteed to arrive after the first layout), then stops.
proc ::hmm_ui::thin_retry {{tries 0}} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window]} {return}
    set done 1
    foreach split [list $::hmm::window.content $::hmm::window.sidebar.split] {
        set found 0
        if {[winfo exists $split]} {foreach child [winfo children $split] {if {[string match *.__sash?__ $child]} {set found 1}}}
        if {!$found} {set done 0}
    }
    thin_all
    if {!$done && $tries < 40} {after 150 [list ::hmm_ui::thin_retry [incr tries]]}
}
proc ::hmm_ui::thin_all {} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window]} {return}
    foreach split [list $::hmm::window.content $::hmm::window.sidebar.split] {thin_sashes $split}
}
# Smallest widths at which nothing is squeezed: the four top groups of the main region, and the Filter/Type block plus the
# Property/Material block of the sidebar.
proc ::hmm_ui::min_primary {} {
    set f [page components];set width 0
    foreach g {bar cap massgrp} {if {[winfo exists $f.$g]} {incr width [winfo reqwidth $f.$g]}}
    if {!$width} {return 320}
    return [expr {$width + 18 + 8}]
}
proc ::hmm_ui::min_sidebar {} {
    set f [page properties]
    if {![winfo exists $f.bar]} {return 320}
    # The widest of what the sidebar pages ask for: the band of a tab (the Filter row with Type, the second row). A table can be
    # narrower than its columns (it scrolls); a button cannot.
    set need 360
    foreach type {properties materials library names} {
        set g [page $type]
        if {![winfo exists $g.bar]} {continue}
        set need [expr {max($need, [winfo reqwidth $g.bar] + 10 + 14 + 12 + 8)}]
    }
    return $need
}
# A sash let go after a drag is a new choice: a position still waiting for the window to grow (from an earlier drag or resize) is
# dropped before the new one is checked.
proc ::hmm_ui::sash_released {} {
    unset -nocomplain ::hmm_ui::wantPos
    ensure_main_pane 2
}
# The window grows for a sash position that needs it (allowGrow 1: the sash handlers). When the window itself is resized (allowGrow 0:
# the window resize and Configure handlers) the sidebar gives way down to its minimum instead; the window never widens by itself
# against the user's drag (it stops at wm minsize).
# allowGrow 2 (the sash was let go) always may; 1 (the sash is being dragged, limit_sashes) not within 0.7 s of a resize of the window
# itself: a vertical sash event after the window was made smaller must not widen it again.
proc ::hmm_ui::ensure_main_pane {{allowGrow 1}} {
    if {$allowGrow == 1 && [info exists ::hmm_ui::lastResize] && [clock milliseconds] - $::hmm_ui::lastResize < 700} {set allowGrow 0}
    set w $::hmm::window
    set content $w.content
    if {![winfo exists $content] || $::hmm_ui::frozen || [collapsed $content]} {return}
    thin_all
    set width [winfo width $content]
    if {$width < 700} {return}
    set pos [$content sashpos 0]
    set minPrimary [min_primary];set minSidebar [min_sidebar]
    # The window was widened for a sash position that needed it: put the sash back where it was dragged.
    if {[info exists ::hmm_ui::wantPos]} {
        set want $::hmm_ui::wantPos
        if {$width >= $want + 12 + $minPrimary - 1} {
            unset ::hmm_ui::wantPos
            if {$want != $pos} {$content sashpos 0 $want}
            return
        }
    }
    if {$pos <= 10 || $pos >= $width - 10} {
        set pos [expr {int($width * 0.43)}]
    } else {
        # Shrinking the sidebar is limited. Widening it is not: when the main region would drop below its own minimum,
        # the window grows by the missing width (up to the screen edge) instead of squeezing the main region.
        set pos [expr {max($minSidebar, $pos)}]
        set need [expr {$pos + 12 + $minPrimary}]
        if {$need > $width} {
            set extra [expr {$need - $width}]
            if {[wm state $w] ne "normal" || !$allowGrow} {
                set pos [expr {max($minSidebar, $width - 12 - $minPrimary)}];set extra 0
            } else {
                # A Tk toplevel cannot grow past its maximum size (the screen) whatever the position.
                set maxW [lindex [wm maxsize $w] 0]
                set room [expr {$maxW - [winfo width $w]}]
                if {$extra > $room} {set extra [expr {max(0, $room)}];set pos [expr {$width + $extra - 12 - $minPrimary}]}
            }
            if {$extra > 0} {
                set ::hmm_ui::wantPos $pos
                after 1500 {unset -nocomplain ::hmm_ui::wantPos}
                after 1700 ::hmm_ui::ensure_main_pane
                wm geometry $w [expr {[winfo width $w] + $extra}]x[winfo height $w]
                return
            }
        }
    }
    if {$pos != [$content sashpos 0]} {$content sashpos 0 $pos}
}
# ---- The band above every sidebar table (Properties, Materials, Library, Part name) --------------------------------------------
# One grid on all four tabs, so the controls sit in the same columns and the tables start at the same y:
#   row 0   Filter [box]  in [column dropdown]  Type [dropdown]        (Type only on Properties; its columns are kept on every tab)
#   row 1   Properties / Materials: Isolate only + Focus (icons, together exactly as wide as the Filter label and box) and Delete unused
#           Library / Part name:    File [box with the folder icon] and the Import split button (Import; Save and Save as... in its menu)
# The "in" dropdown, the Type dropdown and the Import button share one width on every tab: the widest text any of them shows (a
# column title, a type with its count) plus the arrow and the padding of a native dropdown.
proc ::hmm_ui::type_box_width {parent} {
    if {![info exists ::hmm_ui::typeBoxW]} {
        set widest 0
        foreach text {"All columns" "Library match" "PCOMPG (999)"} {
            set widest [expr {max($widest, [font measure TkTextFont $text])}]
        }
        set ::hmm_ui::typeBoxW [expr {$widest + 26}]
        # (the Import split button, with its icon and arrow, must fit the same width)
        combo_button $parent.importRef Import fileImportCSV {} {}
        update idletasks
        set ::hmm_ui::typeBoxW [expr {max($::hmm_ui::typeBoxW, [winfo reqwidth $parent.importRef])}]
        destroy $parent.importRef
    }
    return $::hmm_ui::typeBoxW
}
# A split button: the main part runs the first action, the arrow opens a menu with the others ($items = label command icon ...).
proc ::hmm_ui::combo_button {path text icon command items} {
    ttk::frame $path
    ttk::button $path.main -text $text -image [icon_spec $icon] -compound left -command [list ::hmm_ui::run $command]
    ttk::button $path.arrow -text "▾" -width 2 -command [list ::hmm_ui::combo_post $path]
    pack $path.arrow -side right -fill y -padx {1 0}
    pack $path.main -side left -fill both -expand 1
    menu $path.menu -tearoff 0
    foreach {label cmd name} $items {
        $path.menu add command -label $label -command [list ::hmm_ui::run $cmd]
        set img [icon $name]
        if {$img ne ""} {$path.menu entryconfigure end -image $img -compound left}
    }
}
proc ::hmm_ui::combo_post {path} {
    tk_popup $path.menu [winfo rootx $path.main] [expr {[winfo rooty $path.main] + [winfo height $path.main]}]
}
# A Tk button (it can have a colour) in a 1 px grey frame, as high as a ttk button and as wide as the grid cell its box is put in.
proc ::hmm_ui::icon_toggle {parent name command} {
    ttk::button $parent.ref -text Discard -width 9
    set refH [winfo reqheight $parent.ref]
    destroy $parent.ref
    if {"::hmm_ui::pixel" ni [image names]} {image create photo ::hmm_ui::pixel -width 1 -height 1}
    set innerH [expr {$refH - 2}]
    frame $parent.${name}Box -background #adadad -bd 0 -highlightthickness 0
    set b $parent.$name
    button $b -image ::hmm_ui::pixel -compound center -relief flat -bd 0 -overrelief flat -highlightthickness 0 -width 1 -height $innerH -command $command
    $b configure -height [expr {2 * $innerH - [winfo reqheight $b]}]
    pack $b -in $parent.${name}Box -fill both -expand 1 -padx 1 -pady 1
    raise $b $parent.${name}Box
}
# A tip under a widget after the pointer rests on it (the buttons that have only an icon).
proc ::hmm_ui::tip {w text} {
    bind $w <Enter> [list ::hmm_ui::tip_show $w $text]
    bind $w <Leave> ::hmm_ui::tip_hide
    bind $w <ButtonPress> ::hmm_ui::tip_hide
}
proc ::hmm_ui::tip_show {w text} {
    tip_hide
    set ::hmm_ui::tipAfter [after 500 [list ::hmm_ui::tip_open $w $text]]
}
proc ::hmm_ui::tip_open {w text} {
    if {![winfo exists $w]} {return}
    set t .hmm_tip
    catch {destroy $t}
    toplevel $t -bd 1 -relief solid -background #ffffe1
    wm overrideredirect $t 1
    label $t.l -text $text -background #ffffe1 -padx 4 -pady 1
    pack $t.l
    wm geometry $t +[winfo rootx $w]+[expr {[winfo rooty $w] + [winfo height $w] + 4}]
}
proc ::hmm_ui::tip_hide {} {
    if {[info exists ::hmm_ui::tipAfter]} {after cancel $::hmm_ui::tipAfter}
    catch {destroy .hmm_tip}
}
proc ::hmm_ui::controls {type} {
    set f [page $type]
    foreach child {band bar types library src iso} {if {[winfo exists $f.$child]} {destroy $f.$child}}
    ttk::frame $f.band -height [band_height]
    grid propagate $f.band 0
    grid columnconfigure $f.band 0 -weight 1
    # The two rows are centered in the band: the space above them and below them is always the same (rows 0 and 2 share what is left).
    grid rowconfigure $f.band 0 -weight 1 -minsize $::hmm_ui::bandPad
    grid rowconfigure $f.band 2 -weight 1 -minsize $::hmm_ui::bandPad
    ttk::frame $f.bar
    grid $f.bar -in $f.band -row 1 -column 0 -sticky ew -padx {0 10}
    ttk::label $f.bar.filterLabel -text Filter -image [icon_spec filter] -compound left
    ttk::entry $f.bar.search -textvariable ::hmm_ui::query($type) -width 6
    set refresh [expr {$type eq "names" ? "::hmm_ui::names_table" : [list ::hmm_ui::filter $type]}]
    bind $f.bar.search <KeyRelease> [list ::hmm_ui::run $refresh]
    if {![info exists ::hmm_ui::filterColumn($type)]} {set ::hmm_ui::filterColumn($type) "All columns"}
    ttk::combobox $f.bar.column -textvariable ::hmm_ui::filterColumn($type) -state readonly -width 8 -postcommand [list ::hmm_ui::filter_columns $type]
    bind $f.bar.column <<ComboboxSelected>> [list ::hmm_ui::run $refresh]
    ttk::label $f.bar.inLabel -text in
    ttk::label $f.bar.typeLabel -text Type
    grid $f.bar.filterLabel -row 0 -column 0 -sticky w -padx {0 6}
    grid $f.bar.search -row 0 -column 1 -sticky ew -padx {0 6}
    grid $f.bar.inLabel -row 0 -column 2 -sticky w -padx {0 6}
    grid $f.bar.column -row 0 -column 3 -sticky ew
    # The same columns on every tab: label, box (takes the free width), "in", dropdown, Type label, Type dropdown.
    grid columnconfigure $f.bar 0 -minsize [expr {[winfo reqwidth $f.bar.filterLabel] + 6}]
    grid columnconfigure $f.bar 1 -weight 1
    grid columnconfigure $f.bar 3 -minsize [type_box_width $f.bar]
    grid columnconfigure $f.bar 4 -minsize [expr {[winfo reqwidth $f.bar.typeLabel] + 16}]
    grid columnconfigure $f.bar 5 -minsize [type_box_width $f.bar]
    grid rowconfigure $f.bar 0 -minsize $::hmm_ui::rowH
    grid rowconfigure $f.bar 1 -minsize $::hmm_ui::rowH
    if {$type eq "properties"} {
        ttk::combobox $f.bar.type -textvariable ::hmm_ui::typeText -state readonly -width 8 -postcommand ::hmm_ui::type_refresh
        bind $f.bar.type <<ComboboxSelected>> {::hmm_ui::type_selected}
        grid $f.bar.typeLabel -row 0 -column 4 -sticky w -padx {10 6}
        grid $f.bar.type -row 0 -column 5 -sticky ew
    }
    if {$type in {properties materials}} {
        # Isolate (only) and Focus: icon and short text, side by side under the Filter label and box (together exactly as wide as they are).
        ttk::frame $f.iso
        icon_toggle $f.iso isolate {::hmm_ui::run ::hmm_ui::isolate_toggle}
        icon_toggle $f.iso focus {::hmm_ui::run ::hmm_ui::focus_toggle}
        grid columnconfigure $f.iso {0 1} -weight 1 -uniform iso
        grid $f.iso.isolateBox -row 0 -column 0 -sticky ew
        grid $f.iso.focusBox -row 0 -column 1 -sticky ew -padx {6 0}
        $f.iso.isolate configure -text Isolate
        $f.iso.focus configure -text Focus
        tip $f.iso.isolate "Isolate only (Ctrl+Shift+H)"
        tip $f.iso.focus "Focus: fit the view to what stays displayed"
        grid $f.iso -in $f.bar -row 1 -column 0 -columnspan 2 -sticky ew -padx {0 6}
        ttk::button $f.bar.unused -text "Delete unused (-)" -command [list ::hmm_ui::run [list ::hmm_ui::delete_unused $type]]
        grid $f.bar.unused -row 1 -column 3 -columnspan 3 -sticky ew
        isolate_shortcut
        isolate_buttons
    } else {
        # The file box is the main table's folder box (entry and folder icon); Import loads the file in it, and the arrow of the
        # Import button holds Save and Save as...
        ttk::label $f.bar.fileLabel -text File
        if {$type eq "library"} {
            set var ::hmm_ui::libFile;set text "Library CSV file";set browse ::hmm_ui::browse_library
            set import ::hmm_ui::import_library;set save ::hmm_ui::library_save;set saveas ::hmm_ui::library_save_as
        } else {
            if {![info exists ::hmm_ui::namesFile]} {set ::hmm_ui::namesFile ""}
            set var ::hmm_ui::namesFile;set text "Part names CSV file";set browse ::hmm_ui::browse_names
            set import ::hmm_ui::import_names_box;set save ::hmm_ui::names_save;set saveas ::hmm_ui::names_save_as
        }
        hwtk::openfileentry $f.bar.file -textvariable $var -width 4 -defaulttext $text -initialdir [file join $::hmm::projectDir library] -filetypes {{{CSV files} {.csv}}} -parent $::hmm::window
        # The widget's own Browse fails after the dialog: the button opens the native dialog directly.
        $f.bar.file.button configure -command $browse
        combo_button $f.bar.import Import fileImportCSV $import [list Save $save toolbarFileSaveStrip "Save as..." $saveas toolbarFileSaveAsStrip]
        grid $f.bar.fileLabel -row 1 -column 0 -sticky w -padx {0 6}
        grid $f.bar.file -row 1 -column 1 -sticky ew -padx {0 6}
        grid $f.bar.import -row 1 -column 3 -sticky ew
    }
    foreach child [grid slaves $f.band] {raise $child $f.band}
    set first [lindex [pack slaves $f] 0]
    if {$first ne "" && $first ne "$f.band"} {pack $f.band -side top -fill x -before $first} else {pack $f.band -side top -fill x}
    switch $type {
        properties {type_refresh}
        library {library_buttons_update}
        names {names_buttons_update}
    }
    update_status $type
    if {$type in {properties materials}} {after idle {catch ::hmm_ui::unused_update}}
    catch ::hmm_ui::apply_icons
    after idle ::hmm_ui::align_later
}
proc ::hmm_ui::ids {type} {
    variable selection
    if {$type eq "components"} {return [$::hmm::window.table.tree selection]}
    set t [page $type].table;set result {}
    if {![winfo exists $t] || ![info exists ::hmm_props::gridRows($type)]} {return $selection($type)}
    foreach row [$t selectionget rows] {regsub {^tag:} $row "" row;if {[dict exists $::hmm_props::gridRows($type) $row]} {lappend result [dict get $::hmm_props::gridRows($type) $row]}}
    return $result
}
# A selection event that only restores the same Components (table rebuilt after Apply or Refresh) must not
# pull the Entity away from the Property or Material the user clicked in the sidebar.
proc ::hmm_ui::components_select_event {} {
    if {[info exists ::hmm_ui::syncingRows] && $::hmm_ui::syncingRows} {return}
    if {[info exists ::hmm_ui::selection(components)] && [lsort -integer [ids components]] eq [lsort -integer $::hmm_ui::selection(components)]} {return}
    selected components
}
# One kind of highlight at a time in the sidebar: either the green reference rows (the Property and Material of the selected
# Components, scrolled into view on both tabs) or the blue rows the user selected in a sidebar table, never both; selecting in one
# sidebar tab clears the selection of the others.
set ::hmm_ui::refActive 0
proc ::hmm_ui::exclusive_highlight {type} {
    if {$type eq "components"} {
        set ::hmm_ui::refActive 1
        foreach t {properties materials library} {set ::hmm_ui::selection($t) {};catch {[page $t].table selectionclear}}
    } elseif {$type in {properties materials library}} {
        set ::hmm_ui::refActive 0
        foreach t {properties materials library} {if {$t ne $type} {set ::hmm_ui::selection($t) {};catch {[page $t].table selectionclear}}}
    }
}
# What was last selected in the Properties / Materials tab: selecting in the Library tab clears those selections, but the Library
# action "Apply params to Mats" still needs it.
array set ::hmm_ui::lastSelection {properties {} materials {}}
proc ::hmm_ui::previous_ids {type} {
    set ids $::hmm_ui::selection($type)
    if {![llength $ids] && [info exists ::hmm_ui::lastSelection($type)]} {
        foreach id $::hmm_ui::lastSelection($type) {if {[dict exists [set ::hmm::$type] $id]} {lappend ids $id}}
    }
    return $ids
}
proc ::hmm_ui::selected {type} {
    updated_clear
    set ::hmm_ui::selection($type) [ids $type]
    if {$type in {properties materials} && [llength $::hmm_ui::selection($type)]} {set ::hmm_ui::lastSelection($type) $::hmm_ui::selection($type)}
    exclusive_highlight $type
    set ::hmm_ui::detailType $type
    set ::hmm_props::editorTarget {}
    if {$type ne "library"} {set ::hmm_ui::previous $type}
    update_status $type
    if {$type eq "properties"} {select_components_of $::hmm_ui::selection(properties)}
    if {$type in {properties materials}} {isolate_update}
    ::hmm_props::sidebar_schedule
}
proc ::hmm_ui::restore {type} {
    if {$::hmm_ui::active ne $type} {return}
    set t [page $type].table
    # (no rows yet: the table load was put off while a mass was being read; it restores the selection itself)
    if {![winfo exists $t] || ![info exists ::hmm_props::gridRows($type)]} {return}
    dict for {row id} $::hmm_props::gridRows($type) {
        if {$id in $::hmm_ui::selection($type)} {$t selectionadd $row,name}
    }
}
proc ::hmm_ui::changed {} {
    variable active;variable previous
    set tabs $::hmm::window.sidebar.split.tabs
    if {![winfo exists $tabs] || ![winfo exists $::hmm::window.table.tree]} {return}
    set next [file tail [string map {. /} [$tabs select]]]
    if {$next eq ""} {return}
    if {$next eq "changes"} {
        if {$active ni {changes names}} {set ::hmm_ui::selection($active) [ids $active]}
        set active changes
        changes_table
        return
    }
    # The Part name page is a table of its own (no selection, queue or Entity of the model tabs).
    if {$next eq "names"} {
        if {$active ni {changes names}} {set ::hmm_ui::selection($active) [ids $active]}
        set active names
        names_table
        return
    }
    # Explicit activation and Tk's queued tab event can report the same transition.
    # Do not rebuild an already mounted page or clear a newly chosen preview twice.
    if {$next eq $active && [winfo exists [page $next].table]} {update_status $active;return}
    if {$next ne $active} {if {$active ni {changes names}} {set ::hmm_ui::selection($active) [ids $active]};set active $next}
    if {$active in {properties materials}} {
        ::hmm_props::data_mount $active
        # a hidden table cannot scroll: the reference rows of the selected Components are brought into view once it is shown
        unset -nocomplain ::hmm_ui::lastRef($active)
        after idle [list catch [list ::hmm_ui::mark_rows $active]]
        isolate_update
    } elseif {$active eq "library"} {library_table}
    set ::hmm_ui::detailType $active
    set ::hmm_props::editorTarget {}
    update_status $active
    ::hmm_props::sidebar_schedule
}
# ---- Apply / Discard: one pair at the top right of the window, in the empty end of the sidebar tab row --------------------
# Amber/red when something is pending, disabled otherwise. Classic Tk buttons carry the colour; their size and 1 px grey
# border are matched to a ttk button of the same width so they sit evenly beside the ttk buttons.
set ::hmm_ui::actionsLocked 0
# A Tk button (it can have a background colour) the size of a ttk button of width 9, inside a 1 px grey frame: the box is
# $parent.<name>Box and the button $parent.<name>; the caller grids the box.
proc ::hmm_ui::framed_button {parent name text command {var ""} {width 9}} {
    ttk::button $parent.ref -text Discard -width $width
    set refW [winfo reqwidth $parent.ref];set refH [winfo reqheight $parent.ref]
    destroy $parent.ref
    if {"::hmm_ui::pixel" ni [image names]} {image create photo ::hmm_ui::pixel -width 1 -height 1}
    set innerW [expr {$refW - 2}];set innerH [expr {$refH - 2}]
    frame $parent.${name}Box -background #adadad -bd 0 -highlightthickness 0
    set b $parent.$name
    button $b -text $text -image ::hmm_ui::pixel -compound center -relief flat -bd 0 -overrelief flat -highlightthickness 0 -width $innerW -height $innerH -command $command
    if {$var ne ""} {$b configure -textvariable $var}
    $b configure -width [expr {2 * $innerW - [winfo reqwidth $b]}] -height [expr {2 * $innerH - [winfo reqheight $b]}]
    pack $b -in $parent.${name}Box -padx 1 -pady 1
    raise $b $parent.${name}Box
    return $parent.${name}Box
}
# ---- Image folder: saving and loading use the same folder --------------------------------------------------------------------
proc ::hmm_ui::image_dir_init {} {
    # The box starts with the folder of the model; a folder the user chose earlier in this session stays.
    if {![info exists ::hmm_ui::imageDir] || $::hmm_ui::imageDir eq "" || [string equal -nocase $::hmm_ui::imageDir $::hmm_ui::imageDirAuto]} {
        if {[catch {set ::hmm_ui::imageDir [::hmm_images::model_folder]} message]} {
            set ::hmm_ui::imageDir [file normalize [file join $::hmm::projectDir images]]
        }
        set ::hmm_ui::imageDirAuto $::hmm_ui::imageDir
    }
    # Older builds loaded the folder when the box changed; Load does it now.
    catch {trace remove variable ::hmm_ui::imageDir write ::hmm_ui::image_dir_write}
}
proc ::hmm_ui::image_dir_write {args} {}
proc ::hmm_ui::image_dir_sync {{force 0}} {
    if {$::hmm_images::busy} {return 0}
    set model [::hmm_images::model_folder]
    if {!$force && [string equal -nocase $model $::hmm_ui::imageModel]} {return 0}
    set ::hmm_ui::imageModel $model
    set current [string trim $::hmm_ui::imageDir]
    if {$current eq "" || [string equal -nocase $current $::hmm_ui::imageDirAuto]} {
        set ::hmm_ui::imageDir $model;set ::hmm_ui::imageDirAuto $model;set current $model
    }
    ::hmm_images::clear
    if {![file isfile [file join $current images.dict]]} {catch ::hmm::sync_rows;return 0}
    # In the background: the window is there first, the progress bar shows the loading (see ::hmm_images::load_async).
    if {[catch {::hmm_images::load_async $current 1} count]} {
        catch ::hmm::sync_rows
        set ::hmm::status "\u26a0 Error: images not loaded: $count"
        return 0
    }
    return 0
}
# Import: show the images saved in the folder of the box; the result is always reported in the status line.
# Delete unused: HyperMesh's own "Delete Unused" dialog (the one of its Tools menu and browser context menu), restricted to the
# Properties or the Materials. HyperMesh builds it from its namespace ::hm::browser::unused::utils: the unused entities of the chosen
# type are found with hm_getunusedoremptyentities (as the native command does) and handed to ::hm::browser::deleteAdvanced, which opens
# the dialog; the entities are ticked and deleted there. Nothing is opened while there are pending changes.
# While the dialog is open the tool keeps out of the model: the Entity Editor is emptied before it opens (it may show an entity that
# is deleted), and no model read, Entity Editor refresh or mass reading runs (unusedBusy). The model is read once when the dialog
# closes; deleting unused entities changes no Component mass, so the masses are kept.
set ::hmm_ui::unusedBusy 0
proc ::hmm_ui::unused_ids {type} {
    set entity [expr {$type eq "properties" ? "props" : "mats"}]
    set saved1 [hm_getmark $entity 1];set saved2 [hm_getmark $entity 2]
    *clearmark $entity 1;*clearmark $entity 2
    *createmark $entity 1 all
    set found [hm_getunusedoremptyentities mode=unused outputmark=2 inputmark=1]
    *clearmark $entity 1;*clearmark $entity 2
    if {[llength $saved1]} {*createmark $entity 1 {*}$saved1}
    if {[llength $saved2]} {*createmark $entity 2 {*}$saved2}
    return $found
}
# The answer is {{props 3 4 5}}: the first word is the entity type.
proc ::hmm_ui::unused_count {found} {return [llength [lrange [lindex $found 0] 1 end]]}
# The number of unused Properties / Materials is written on the Delete unused buttons.
proc ::hmm_ui::unused_update {} {
    foreach type {properties materials} {
        set button [page $type].bar.unused
        if {![winfo exists $button]} {continue}
        if {[catch {unused_count [unused_ids $type]} count]} {continue}
        $button configure -text "Delete unused ($count)"
    }
}
proc ::hmm_ui::delete_unused {type} {
    if {[::hmm_flow::count]} {error "Apply or discard pending changes first"}
    ::hmm_props::require_idle
    set entity [expr {$type eq "properties" ? "props" : "mats"}]
    set label [expr {$type eq "properties" ? "Properties" : "Materials"}]
    if {![llength [info commands ::hm::browser::deleteAdvanced::InvokeDeleteAdvanced]]} {error "HyperMesh Delete Unused dialog is not available"}
    set found [unused_ids $type]
    if {![unused_count $found]} {set ::hmm::status "No unused $label";unused_update;return}
    ::hmm_props::editor_release
    set ::hmm_ui::unusedBusy 1
    if {[catch {
        set ::hm::browser::unused::utils::currentFunctionality unused
        set ::hm::browser::unused::utils::EntitiesUnused $found
        ::hm::browser::deleteAdvanced::InvokeDeleteAdvanced deleteunused
    } message options]} {set ::hmm_ui::unusedBusy 0;return -options $options $message}
    set ::hmm::status "[unused_count $found] unused $label: tick them in the HyperMesh dialog"
    unused_watch $type [llength [hm_entitylist $entity id all]] 0
}
proc ::hmm_ui::unused_dialog {} {
    if {[winfo exists .deleteAdvancedGui]} {return .deleteAdvancedGui}
    foreach w [winfo children .] {
        if {[winfo toplevel $w] eq $w && ![catch {wm title $w} title] && $title eq "Delete Unused"} {return $w}
    }
    return ""
}
# The dialog is open while it is on the screen (it may stay as a hidden window after it is closed).
proc ::hmm_ui::unused_open {} {
    set w [unused_dialog]
    return [expr {$w ne "" && [winfo viewable $w]}]
}
# Waits for the dialog to close (only its window is looked at), then reads the model once.
proc ::hmm_ui::unused_watch {type before tries} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window]} {set ::hmm_ui::unusedBusy 0;return}
    if {$tries < 1200 && ([unused_open] || $tries < 4)} {after 500 [list ::hmm_ui::unused_watch $type $before [incr tries]];return}
    set ::hmm_ui::unusedBusy 0
    set entity [expr {$type eq "properties" ? "props" : "mats"}]
    set label [expr {$type eq "properties" ? "Properties" : "Materials"}]
    set now [llength [hm_entitylist $entity id all]]
    set ::hmm::massAffected {}
    if {[catch {
        ::hmm_props::refresh_model
        refresh_view components;refresh_sidebar_tables
    } message]} {set ::hmm::status "\u26a0 Error: tables not reloaded: $message";return}
    if {$now < $before} {done "Deleted [expr {$before - $now}] unused $label"} else {set ::hmm::status "Delete unused closed"}
}
proc ::hmm_ui::browse_dir {} {
    set start [string trim $::hmm_ui::imageDir]
    if {![file isdirectory $start]} {set start [file join $::hmm::projectDir images]}
    set dir [tk_chooseDirectory -parent $::hmm::window -initialdir $start -title "Image folder"]
    if {$dir ne ""} {set ::hmm_ui::imageDir $dir}
}
proc ::hmm_ui::browse_library {} {
    set file [tk_getOpenFile -parent $::hmm::window -initialdir [file join $::hmm::projectDir library] -title "Library CSV file" -filetypes {{{CSV files} {.csv}}}]
    if {$file ne ""} {set ::hmm_ui::libFile $file}
}
proc ::hmm_ui::image_dir_load {} {
    if {$::hmm_images::busy} {error "Wait for the capture to finish"}
    set dir [string trim $::hmm_ui::imageDir]
    if {$dir eq ""} {error "Choose an image folder first"}
    if {![file isdirectory $dir]} {error "Image folder not found: $dir"}
    if {![file isfile [file join $dir images.dict]]} {error "No saved images in this folder (images.dict not found)"}
    set count [::hmm_images::load_bundle $dir 1]
    set ::hmm::status "Loaded $count images from $dir"
}
# Capture buttons follow the capture state: running -> Stop and Cancel, paused -> Continue and Cancel, idle -> Capture / Capture all.
proc ::hmm_ui::image_state {} {
    set f [page components]
    if {![winfo exists $f.cap.stop]} {return}
    set busy $::hmm_images::busy
    set paused [expr {$busy && [info exists ::hmm_images::paused] && $::hmm_images::paused}]
    foreach {name on} [list capture [expr {!$busy}] all [expr {!$busy}] stop [expr {$busy && !$paused}] cont $paused cancel $busy] {
        $f.cap.$name state [expr {$on ? "!disabled" : "disabled"}]
    }
    foreach name {dir import} {catch {$f.bar.$name state [expr {$busy ? "disabled" : "!disabled"}]}}
}
proc ::hmm_ui::image_busy_ui {busy} {image_state;catch isolate_buttons}
proc ::hmm_ui::action_buttons {} {
    set w $::hmm::window
    set a $w.actions
    if {[winfo exists $a]} {destroy $a}
    ttk::frame $a
    # As wide as Reload and Close beside them (ttk width 15), so the four bottom buttons are one size.
    ttk::button $a.ref -text Discard -width 15
    set refW [winfo reqwidth $a.ref];set refH [winfo reqheight $a.ref]
    destroy $a.ref
    if {"::hmm_ui::pixel" ni [image names]} {image create photo ::hmm_ui::pixel -width 1 -height 1}
    # Windows does not draw a Tk button's highlight ring when it has no focus: a 1 px grey frame around each button is the border.
    set innerW [expr {$refW - 2}];set innerH [expr {$refH - 2}]
    foreach {name label command} {discard Discard {::hmm_ui::run {::hmm_ui::revert all}} apply Apply {::hmm_ui::run {::hmm_ui::apply all}}} {
        frame $a.${name}Box -background #adadad -bd 0 -highlightthickness 0
        set b $a.$name
        button $b -text $label -image ::hmm_ui::pixel -compound center -relief flat -bd 0 -overrelief flat \
            -highlightthickness 0 -width $innerW -height $innerH -command $command
        # The image size is the inner size: take off whatever padding the button adds.
        $b configure -width [expr {2 * $innerW - [winfo reqwidth $b]}] -height [expr {2 * $innerH - [winfo reqheight $b]}]
        pack $b -in $a.${name}Box -padx 1 -pady 1
        raise $b $a.${name}Box
    }
    # Side by side in the bottom bar, left of Reload; action_buttons_update shows them only while something is pending.
    pack $a.discardBox -side left
    pack $a.applyBox -side left -padx {6 0}
    action_buttons_update
}
# ---- Alignment of the two regions ---------------------------------------------------------------------------------------
# The band above every sidebar table has one height (bandH); the main top band is aligned to it so the group border sits on the
# bottom edge of the tab row and both tables start at the same y. The footers share one height so the tables end together.
set ::hmm_ui::typeText ""
set ::hmm_ui::bandH 88
set ::hmm_ui::bandPad 6
set ::hmm_ui::rowH 28
if {![info exists ::hmm_ui::libFile]} {set ::hmm_ui::libFile ""}
proc ::hmm_ui::band_height {} {return $::hmm_ui::bandH}
proc ::hmm_ui::apply_band {} {
    foreach type {properties materials library names} {
        set band [page $type].band
        if {[winfo exists $band]} {$band configure -height $::hmm_ui::bandH}
    }
}
proc ::hmm_ui::align_regions {{round 0}} {
    if {[info exists ::hmm_ui::aligning] && $::hmm_ui::aligning} {return}
    set ::hmm_ui::aligning 1
    set ::hmm_ui::alignError ""
    for {set i 0} {$i < 4} {incr i} {
        if {[catch {align_pass $i} result]} {set ::hmm_ui::alignError $result;break}
        if {!$result} {break}
    }
    set ::hmm_ui::aligning 0
}
proc ::hmm_ui::align_pass {round} {
    set w $::hmm::window
    set tabs $w.sidebar.split.tabs
    set f [page components]
    if {![winfo exists $tabs] || ![winfo exists $w.table] || ![winfo exists $f.top] || ![winfo ismapped $w.table]} {align_retry;return 0}
    update idletasks
    set page [$tabs select]
    if {$page eq ""} {return 0}
    set changed 0
    # The window cannot be made narrower than the two regions (or the button row, with Discard and Apply) need.
    catch {wm minsize $w [expr {max(1200, [min_sidebar] + 12 + [min_primary] + 24, [winfo reqwidth $w.bottom] + 16)}] 560}
    # The band holds two rows; it is also tall enough for the View group, whose top border sits half a title line above the page.
    set need [expr {2 * $::hmm_ui::bandPad + 2 * $::hmm_ui::rowH}]
    foreach group {bar cap massgrp} {
        if {[winfo exists $f.$group]} {set need [expr {max($need, [winfo reqheight $f.$group] + 6 - [font metrics TkDefaultFont -linespace] / 2)}]}
    }
    if {$need != $::hmm_ui::bandH} {set ::hmm_ui::bandH $need;apply_band;set changed 1;update idletasks}
    # The group border runs through the middle of its title: put that line on the top edge of the tab page.
    set offset [expr {[font metrics TkDefaultFont -linespace] / 2}]
    set padTop [lindex [dict get [pack info $f.top] -pady] 0]
    set delta [expr {[winfo rooty $page] - $offset - [winfo rooty $f.top]}]
    if {$delta != 0} {
        pack configure $f.top -pady [list [expr {max(0, $padTop + $delta)}] 6]
        set changed 1
        update idletasks
    }
    # The main top band is as tall as it takes for the main table to start where the sidebar tables start.
    set sideTable $page.table
    if {![winfo exists $sideTable] || ![winfo ismapped $sideTable]} {align_retry}
    if {[winfo exists $sideTable] && [winfo ismapped $sideTable]} {
        set ::hmm_ui::alignTries 0
        set diff [expr {[winfo rooty $sideTable] - [winfo rooty $w.table]}]
        if {$diff != 0} {
            $f.top configure -height [expr {max(40, [winfo height $f.top] + $diff)}]
            set changed 1
            update idletasks
        }
    }
    return $changed
}
# The tables are built a little after the window opens (rows with images): try again until both are on screen.
set ::hmm_ui::alignTries 0
proc ::hmm_ui::align_retry {} {
    if {$::hmm_ui::alignTries >= 20} {return}
    incr ::hmm_ui::alignTries
    after 250 ::hmm_ui::align_regions
}
proc ::hmm_ui::align_later {} {
    after cancel ::hmm_ui::align_regions
    after idle ::hmm_ui::align_regions
}
# Selecting Properties in the sidebar selects the Components that use them in the main table (one way; the table never selects Properties).
proc ::hmm_ui::select_components_of {pids} {
    set tree $::hmm::window.table.tree
    if {![winfo exists $tree]} {return}
    set cids {}
    foreach cid [dict keys $::hmm::components] {
        if {[effective_property $cid] in $pids && [$tree exists $cid]} {lappend cids $cid}
    }
    # Set the remembered selection first: the table's selection event then finds nothing new and leaves the sidebar alone.
    set ::hmm_ui::selection(components) $cids
    set ::hmm_ui::syncingRows 1
    catch {$tree selection set $cids}
    set ::hmm_ui::syncingRows 0
    if {[llength $cids]} {catch {$tree see [lindex $cids 0]}}
    components_status
}
proc ::hmm_ui::action_buttons_update {} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window.actions.apply]} {return}
    set a $::hmm::window.actions
    # Pending changes come only from the Material cell of the Properties table and Duplicate for Comps: the pair is
    # in the GUI only while there are some (disabled while they are being applied), next to Reload.
    set bottom $::hmm::window.bottom
    if {[::hmm_flow::count] > 0} {
        if {[winfo manager $a] eq "" && [winfo exists $bottom.reset]} {pack $a -in $bottom -side right -padx {0 6} -after $bottom.reset;raise $a}
    } elseif {[winfo manager $a] ne ""} {pack forget $a}
    set on [expr {[::hmm_flow::count] > 0 && !$::hmm_ui::actionsLocked}]
    set face [ttk::style lookup TButton -background]
    if {$face eq ""} {set face SystemButtonFace}
    if {$on} {
        $a.apply configure -state normal -background #ffd84d -activebackground #ffe27a
        $a.discard configure -state normal -background #e05a5a -activebackground #e87878 -foreground white -activeforeground white
    } else {
        $a.apply configure -state disabled -background $face -activebackground $face
        $a.discard configure -state disabled -background $face -activebackground $face -foreground black
    }
}
# ---- Filter by column: the dropdown lists the columns currently shown; the main table also offers Unassigned ----------------
# Puts the Set group into the Properties band (above the type radios); called when either the group or the band is rebuilt.
proc ::hmm_ui::type_counts {} {
    set counts [dict create All 0]
    foreach id [hm_entitylist props id all] {dict incr counts All;dict incr counts [hm_getvalue props id=$id dataname=cardimage]}
    return $counts
}
# Refills the Type dropdown from the model; a type that no longer exists falls back to All (rebuild = 1 also rebuilds the table).
proc ::hmm_ui::type_refresh {{rebuild 0}} {
    set w [page properties].bar.type
    if {![winfo exists $w]} {return}
    set counts [type_counts]
    set values {}
    foreach card [linsert [lsort [lrange [dict keys $counts] 1 end]] 0 All] {lappend values "$card ([dict get $counts $card])"}
    $w configure -values $values
    set current $::hmm_props::propFilter
    if {![dict exists $counts $current]} {
        set ::hmm_props::propFilter All;set current All
        if {$rebuild} {after idle {::hmm_ui::run {::hmm_props::data_rebuild properties}}}
    }
    set ::hmm_ui::typeText "$current ([dict get $counts $current])"
}
proc ::hmm_ui::type_selected {} {
    if {![regexp {^(\S+)} $::hmm_ui::typeText -> card]} {return}
    set ::hmm_props::propFilter $card
    # The dropdown is rebuilt with the page: do it after its event has finished.
    after idle {::hmm_ui::run {::hmm_props::data_rebuild properties}}
}
proc ::hmm_ui::filter_columns {type} {
    set values [list "All columns"]
    if {$type eq "components"} {
        set native $::hmm_tree::state($::hmm::window.table.tree,native)
        foreach {field label} {id "Component ID" name Component property_id "Property ID" property_name Property material_id "Material ID" material_name Material shared Shared mass Mass property_card "Prop Card" property_t Thickness property_nsm NSM material_e "Mat E" material_nu "Mat NU" material_rho "Mat RHO" material_ge "Mat GE"} {
            if {[catch {$native column cget [$native column id $field] -visible} visible] || $visible} {lappend values $label}
        }
        lappend values Unassigned
    } else {
        set t [page $type].table
        if {[winfo exists $t]} {foreach column [$t columnlist] {lappend values [$t columncget $column -text]}}
    }
    [page $type].bar.column configure -values $values
    return $values
}
# Text of one row in the chosen column (or every column) for the sidebar tables.
proc ::hmm_ui::filter_text {type row} {
    set t [page $type].table
    upvar #0 ::hmm_props::grid_$type grid
    set choice [expr {[info exists ::hmm_ui::filterColumn($type)] ? $::hmm_ui::filterColumn($type) : "All columns"}]
    set parts {}
    foreach column [$t columnlist] {
        if {$choice ne "All columns" && [$t columncget $column -text] ne $choice} {continue}
        regsub {^tag:} $column {} key
        if {[info exists grid($row,$key)]} {lappend parts $grid($row,$key)}
    }
    return [string tolower [join $parts " "]]
}
# Index of the chosen column in the main table row values (-1 all, -2 Unassigned).
proc ::hmm_ui::filter_index {} {
    set choice [expr {[info exists ::hmm_ui::filterColumn(components)] ? $::hmm_ui::filterColumn(components) : "All columns"}]
    if {$choice eq "Unassigned"} {return -2}
    set at [lsearch -exact {"Component ID" Component "Property ID" Property "Material ID" Material Shared Mass "Prop Card" Thickness NSM "Mat E" "Mat NU" "Mat RHO" "Mat GE"} $choice]
    return $at
}
# The one Set group (Property + Material + Set for the selected Components) lives on the sidebar Properties tab.
proc ::hmm_ui::setgroup {} {return [page properties].setgroup}
# The read-only sheet of a library entry: an entry that is not in the model has no native Entity, so the Entity area shows its
# fields (ID <New>, Name, Card Image, E, NU, RHO, GE) here instead. Only the Library tab uses it.
proc ::hmm_ui::library_sheet {name} {
    set lower $::hmm::window.sidebar.split.lower
    if {![winfo exists $lower.proposed.sheet]} {return}
    set sheet $lower.proposed.sheet
    foreach item [$sheet itemlist] {$sheet itemdelete $item}
    set data [dict get $::hmm_lib::records $name]
    set fields [list ID <New> Name [::hmm_flow::next_name $name] {Card Image} MAT1]
    foreach key {E NU RHO GE} {
        set v [dict get $data $key]
        if {$v eq ""} {set v <Unspecified>}
        lappend fields $key $v
    }
    # The sheet may still hold a deleted item of the previous render within the same event cycle; remove it before creating.
    set i 0
    foreach {field value} $fields {
        set item f[incr i]
        if {[$sheet itemexists $item]} {$sheet itemdelete $item}
        $sheet itemcreate $item -text $field -type str -value $value
        if {[catch {$sheet itemconfigure $item -state readonly}]} {catch {$sheet itemconfigure $item -state disabled}}
    }
    catch {$sheet fittocontent}
    pack forget $lower.entity
    pack $lower.proposed -in $lower.strip.e -fill both -expand 1
}
proc ::hmm_ui::status_changed {args} {messages}
proc ::hmm_ui::messages {} {
    set tabs $::hmm::window.sidebar.split.tabs
    if {![winfo exists $tabs.changes]} {return}
    set n [::hmm_flow::count]
    $tabs tab $tabs.changes -text [expr {$n ? "Changes ($n)" : "Changes"}]
    if {[winfo exists $tabs.changes.table]} {
        if {[catch {changes_table} error]} {puts stderr "Changes table: $error"}
    }
}
proc ::hmm_ui::material_name {id} {
    if {$id == 0} {return Unassigned}
    if {[dict exists $::hmm::materials $id]} {return "$id | [dict get $::hmm::materials $id]"}
    return $id
}
proc ::hmm_ui::changes_table {} {
    set f [page changes]
    if {![winfo exists $f]} {return}
    set t $f.table
    if {![winfo exists $t]} {
        hwtk::datatable $t -variable ::hmm_ui::grid_changes -closeeditor 1
        pack $t -side top -fill both -expand 1
        foreach {key label width} {scope From 45 entity Type 55 id ID 35 name Name 100 field Field 60 current Current 100 proposed New 120 affected Comps 80 state Status 65} {
            set align [expr {$key eq "id" ? "right" : "left"}]
            set header center
            $t columncreate $key -text $label -type str -width $width -itemjustify $align -justify $header -editable 0
        }
    }
    after idle ::hmm_ui::vertical_layout
    set data {}
    foreach scope {components properties materials library} {
        set scopeName [dict get {components Model properties Props materials Mats library Library} $scope]
        dict for {key op} $::hmm_flow::queues($scope) {
            set id [dict get $op id];set kind [dict get $op kind]
            set affected {};set name "";set entity "";set field "";set current "";set proposed ""
            switch $kind {
                property {
                    set entity Component;set name [dict get $::hmm::components $id name]
                    set field Property;set current [dict get $op old];set proposed [dict get $op target]
                    set affected [list $id]
                }
                material {
                    set entity Property;set name [dict get $::hmm::properties $id name]
                    set field Material;set current [material_name [dict get $op old]]
                    set proposed [::hmm_flow::text [dict get $op target]]
                    set affected [::hmm::property_users $id]
                }
                parameters {
                    set entity Material;set name [dict get $::hmm::materials $id]
                    dict for {pid prop} $::hmm::properties {
                        if {$pid > 0 && [dict get $prop material] == $id} {set affected [concat $affected [::hmm::property_users $pid]]}
                    }
                    set affected [join [lsort -unique -integer $affected] {, }]
                    foreach {label attr} {E 1 NU 3 RHO 4 GE 7} {
                        set value [dict get $op library $label]
                        if {$value eq ""} {continue}
                        set old [lindex [dict get $op old $attr] 1]
                        lappend data [list $scopeName $entity $id $name $label $old $value $affected Pending]
                    }
                    continue
                }
                create {
                    set entity Material;set id "";set name [::hmm_flow::next_name [dict get $op target]]
                    set field Create;set proposed "MAT1 | [dict get $op target]"
                }
            }
            lappend data [list $scopeName $entity $id $name $field $current $proposed [join $affected {, }] Pending]
        }
    }
    # Operational status belongs here too, never below the Entity pane.
    if {[info exists ::hmm::status] && $::hmm::status ne ""} {lappend data [list Status "" "" "" Message "" $::hmm::status "" Info]}
    set rows [$t rowlist];if {[llength $rows]} {$t rowdelete $rows}
    array unset ::hmm_ui::grid_changes
    if {[llength $data]} {
        foreach row [$t rowinsert end changes -count [llength $data]] values $data {
            foreach key {scope entity id name field current proposed affected state} value $values {set ::hmm_ui::grid_changes($row,$key) $value}
        }
        $t liveupdate 1
    }
}
proc ::hmm_ui::update_status {type} {
    if {$type ni {components properties materials library}} {return}
    set ids [ids $type];set n [::hmm_flow::count $type]
    set text "[llength $ids] selected"
    if {$n} {
        set impact [::hmm_flow::impact $type]
        append text " | $n pending | Components: [join [dict get $impact components] {, }]"
        dict for {key op} $::hmm_flow::queues($type) {
            if {[dict get $op kind] eq "material"} {append text "\nProperty [dict get $op id] → [::hmm_flow::text [dict get $op target]]"}
        }
    }
    if {$type eq "library"} {append text " | Destination: [string totitle $::hmm_ui::previous] ([llength $::hmm_ui::selection($::hmm_ui::previous)])"}
    set ::hmm_ui::notice($type) $text
    messages
    set f [page $type]
    if {$type eq "components"} {components_status;return}
    catch components_status
    action_buttons_update
}
proc ::hmm_ui::refresh_view {type} {
    if {$type eq "changes"} {changes_table;return}
    if {$type eq "components"} {::hmm::sync_rows} elseif {$type eq "library"} {library_table} else {::hmm_props::data_reload $type}
    update_status $type
}
# One Apply for every tab: all pending changes are written as a single transaction (see ::hmm_flow::apply).
proc ::hmm_ui::apply {{type all}} {
    ::hmm_props::model_check
    set result [::hmm_flow::apply]
    if {[dict get $result status] eq "APPLIED"} {done Applied} else {set ::hmm::status "[string totitle [dict get $result status]]"}
    # After Apply the Entity Editor shows the selected row again.
    if {[dict get $result status] eq "APPLIED"} {set ::hmm_props::editorTarget {};set ::hmm_props::sidebarIds {};set ::hmm_props::created {}}
    refresh_view components
    refresh_sidebar_tables
    foreach each {properties materials library} {catch {update_status $each}}
}
proc ::hmm_ui::refresh_sidebar_tables {} {
    catch {type_refresh 1}
    foreach type {properties materials} {
        if {[winfo exists [page $type].table] && [catch {::hmm_props::data_reload $type} message]} {set ::hmm::status "\u26a0 Error: $type table: $message"}
    }
    if {[winfo exists [page library].table] && [catch library_table message]} {set ::hmm::status "\u26a0 Error: library table: $message"}
    catch unused_update
    ::hmm_props::sidebar_schedule
}
proc ::hmm_ui::revert {type} {
    if {$type eq "all"} {
        foreach each {components properties materials library} {set ::hmm_flow::queues($each) {}}
        catch ::hmm_props::drop_unused_created
        refresh_view components;refresh_sidebar_tables
        foreach each {properties materials library} {catch {update_status $each}}
        return
    }
    set ::hmm_flow::queues($type) {}
    catch ::hmm_props::drop_unused_created
    refresh_view $type;::hmm_props::sidebar_schedule
    catch {foreach each {components properties materials library} {if {$each ne $type} {update_status $each}}}
}
proc ::hmm_ui::refresh {type} {
    if {$type eq "all"} {
        if {[::hmm_flow::count]} {error "Apply or discard pending changes before reloading model data"}
        # Reload is how the tool picks up a model that was changed outside it, so it does not insist on an unchanged model.
        ::hmm_props::require_idle;::hmm_props::refresh_model
        refresh_view components;refresh_sidebar_tables
        return
    }
    if {[::hmm_flow::count]} {error "Apply or revert pending changes before refreshing model data"}
    ::hmm_props::require_idle;::hmm_props::refresh_model;refresh_view $type
}
proc ::hmm_ui::filter {type} {
    if {$type eq "components"} {set ::hmm::filterText $::hmm_ui::query($type);::hmm::sync_rows} else {refresh_view $type}
}
proc ::hmm_ui::cell_accept {table row column value previous} {
    regsub {^tag:} $row "" row
    if {[catch {
        set id [dict get $::hmm_props::gridRows(properties) $row]
        ::hmm_flow::stage_material properties [list $id] [::hmm_flow::token $value]
        update_status properties
        after idle ::hmm_props::sidebar_schedule
    } message]} {set ::hmm::status $message;return 0}
    return 1
}
# The columns of a sidebar table fit the width of the sidebar: the TreeCtrl underneath shares the free width among the columns (-expand), a
# column never gets narrower than its minimum (-minwidth), and when the minimums together are wider than the sidebar the table scrolls
# horizontally. Dragging the sidebar wider or narrower changes the columns with it. ID keeps the width computed for its numbers.
proc ::hmm_ui::fit_columns {table} {
    if {![winfo exists $table]} {return}
    catch {
        set draw [$table component table]
        # header text -> minimum width, share of the free width
        array set spec {ID {42 0} Name {90 3} Card {52 0} Material {120 3} {Library match} {110 2} {Name list} {120 2} Short {60 1} {Model matches} {110 2} Group {80 2} {JP name} {90 2} Source {80 2} Units {60 1} NU {50 1} GE {50 1} T {50 1}}
        foreach c [$draw column list] {
            if {"rowid" in [$draw column cget $c -tags]} {continue}
            set text [$draw column cget $c -text]
            if {$text eq "ID"} {continue}
            lassign [expr {[info exists spec($text)] ? $spec($text) : {64 1}}] minimum share
            $draw column configure $c -width {} -minwidth $minimum -squeeze 1 -expand $share
        }
    }
}
proc ::hmm_ui::library_table {} {
    set f [page library]
    if {![winfo exists $f.bar]} {controls library}
    if {[winfo exists $f.table]} {destroy $f.table}
    upvar #0 ::hmm_props::grid_library values
    array unset values
    hwtk::datatable $f.table -variable ::hmm_props::grid_library -closeeditor 1
    pack $f.table -side top -fill both -expand 1
    $f.table columncreate name -text Name -type str -width 160 -editable 0 -justify center -itemjustify left
    foreach key $::hmm_ui::libKeys {
        # E NU RHO GE Source Group and the Japanese name can be edited: that changes the list in memory only, the CSV is written by Save / Save as.
        # Group and the Japanese name only appear when the file has them.
        if {$::hmm_ui::libColumn($key) && ($key ni {Group NameJP} || [::hmm_lib::has_values $key])} {
            set editable [expr {$key in {E NU RHO GE Source Group NameJP}}]
            set title [expr {$key eq "NameJP" ? "JP name" : $key}]
            $f.table columncreate $key -text $title -type str -width [expr {$key in {Group NameJP} ? 130 : 105}] -editable $editable -justify center -itemjustify left -valueaccept [list ::hmm_ui::library_accept %W %I %C %V %P]
        }
    }
    # Right click on a column header shows or hides the optional columns (there is no Columns button).
    set menu $f.hdrmenu
    if {[winfo exists $menu]} {destroy $menu}
    menu $menu -tearoff 0
    foreach key $::hmm_ui::libKeys {$menu add checkbutton -label [expr {$key eq "NameJP" ? "JP name" : $key}] -variable ::hmm_ui::libColumn($key) -command {::hmm_ui::run ::hmm_ui::library_table}}
    foreach column [$f.table columnlist] {catch {$f.table columnconfigure $column -headermenu $menu}}
    set ::hmm_props::gridRows(library) [dict create]
    set names {};dict for {name data} $::hmm_lib::records {
        set choice [expr {[info exists ::hmm_ui::filterColumn(library)] ? $::hmm_ui::filterColumn(library) : "All columns"}]
        set text [expr {$choice eq "All columns" ? "$name $data" : ($choice eq "Name" ? $name : ([dict exists $data $choice] ? [dict get $data $choice] : ""))}]
        if {$::hmm_ui::query(library) eq "" || [string first [string tolower $::hmm_ui::query(library)] [string tolower $text]] >= 0} {lappend names $name}
    }
    if {[llength $names]} {
        foreach row [$f.table rowinsert end entries -count [llength $names]] name $names {
            dict set ::hmm_props::gridRows(library) $row $name
            set values($row,name) $name
            set data [dict get $::hmm_lib::records $name]
            foreach key $::hmm_ui::libKeys {if {[dict exists $data $key]} {set values($row,$key) [dict get $data $key]}}
        }
        $f.table liveupdate 1
    }
    table_bind library;restore library
    fit_columns $f.table
    library_buttons_update
}
proc ::hmm_ui::table_bind {type} {
    set t [page $type].table
    bind $t <ButtonRelease-3> [list ::hmm_ui::context $type %W %x %y %X %Y]
    bind $t <ButtonRelease-1> [list after idle [list ::hmm_ui::selected $type]]
    bind $t <KeyRelease> [list after idle [list ::hmm_ui::selected $type]]
}
# The Library match cell is a native dropdown cell (like the Material cell of the Properties tab). Its list is set per row (rowconfigure
# -values, see data_reload): the library names with the same parameters as the Material of the row. The name picked renames the Material
# at once (no Apply; only the name changes).
# The names for the dropdown of a Library match cell. The data table asks for the list when the cell is opened; the row comes with the
# arguments when the table passes it, otherwise it is the selected Material (a click selects the row first).
proc ::hmm_ui::library_values {args} {
    lappend ::hmm_ui::libValuesCalls $args
    set id ""
    foreach arg $args {
        regsub {^tag:} $arg "" row
        if {[dict exists $::hmm_props::gridRows(materials) $row]} {set id [dict get $::hmm_props::gridRows(materials) $row];break}
    }
    if {$id eq ""} {
        set selected [ids materials]
        if {[llength $selected] == 1} {set id [lindex $selected 0]}
    }
    if {$id eq "" || [catch {::hmm_lib::matches [::hmm_lib::native_values $id]} names]} {return {}}
    return $names
}
proc ::hmm_ui::library_pick_cell {table row column value previous} {
    regsub {^tag:} $row "" row
    if {[catch {
        set id [dict get $::hmm_props::gridRows(materials) $row]
        library_pick $id $value
    } message]} {set ::hmm::status "\u26a0 Error: $message";return 0}
    return 1
}
proc ::hmm_ui::library_pick {id name} {
    set done [::hmm_lib::pick $id $name]
    # The table is rebuilt after the cell has been accepted.
    after idle {::hmm_ui::run {::hmm_ui::refresh_view materials}}
    set ::hmm::status [expr {$done ? "Material $id renamed to $name" : "Material $id already has the name $name"}]
}
# The HWTK data tables keep their native sort, row numbers and Fit.
proc ::hmm_ui::context {type table x y X Y} {
    set blank 0
    if {[catch {
        if {$type eq "components"} {
            set row [$table identify row $x $y]
            if {$row eq ""} {return}
            if {$row ni [$table selection]} {$table selection set $row}
        } else {
            # The event window is the TreeCtrl inside the data table; rows and selection belong to the data table itself.
            set t [page $type].table
            set hit [$table identify $x $y]
            set row ""
            if {[lindex $hit 0] eq "item"} {
                foreach tag [$table item tag names [lindex $hit 1]] {if {[string match tag:* $tag]} {set row [string range $tag 4 end];break}}
            }
            # Below the last row of the Library / Part name table the menu offers Add only.
            if {$row eq "" && $type in {library names}} {set blank 1} elseif {$row eq ""} {return} else {context_select $t $row}
            set table $t
        }
        if {$type ne "names" && !$blank} {selected $type}
        set m $table.actions
        if {[winfo exists $m]} {destroy $m}
        menu $m -tearoff 0
        set actions [context_actions $type]
        if {$blank} {set actions [lrange $actions 0 1]}
        foreach {label command} $actions {
            if {$label eq "-"} {$m add separator;continue}
            $m add command -label $label -command [list ::hmm_ui::run $command]
            set img [menu_icon $label]
            if {$img ne ""} {$m entryconfigure end -image $img -compound left}
        }
        if {$type in {properties materials}} {
            set ::hmm_ui::isolateMenu $::hmm_ui::isolateOn
            $m add checkbutton -label "Isolate only" -accelerator Ctrl+Shift+H -variable ::hmm_ui::isolateMenu -command {::hmm_ui::run {::hmm_ui::isolate_set $::hmm_ui::isolateMenu}}
            set img [icon_sized displayIsolate 24]
            if {$img ne ""} {$m entryconfigure end -image $img -compound left}
        }
        tk_popup $m $X $Y
    } message] == 1} {set ::hmm::status "Menu: $message"}
}
proc ::hmm_ui::context_select {table row} {
    set selected {};foreach item [$table selectionget rows] {regsub {^tag:} $item "" item;lappend selected $item}
    if {$row ni $selected} {$table selectionclear;$table selectionadd $row,name}
}
proc ::hmm_ui::context_actions {type} {
    switch $type {
        # Property and Material of a Component are changed in the Entity Editor (native, applied at once, undoable in HyperMesh).
        # Selecting a Property already selects its Components and selecting a row already opens it in the Entity Editor, so there
        # is no "Show Components" or "Edit..." entry.
        components {return [list "Rename Comp" ::hmm_ui::comp_name_edit "Select shared Prop" ::hmm::select_shared Capture ::hmm_images::capture_selected "Renumber..." ::hmm_ui::renumber_dialog]}
        properties {return [list "Duplicate for Comps" ::hmm_ui::duplicate_property "Import part names..." ::hmm_ui::import_names]}
        materials {return [list "Show users" {::hmm_ui::users materials}]}
        library {return [list "Add entry..." ::hmm_ui::library_add Delete ::hmm_ui::library_delete - {} "Create Mat(s)" ::hmm_ui::library_create "Apply params to Mats" ::hmm_ui::library_parameters]}
        names {return [list "Add..." ::hmm_ui::names_add Delete ::hmm_ui::names_delete]}
    }
}
proc ::hmm_ui::one_library {} {set ids [ids library];if {[llength $ids] != 1} {error "Select one library entry"};return [lindex $ids 0]}
# Library > Apply params to Mats: E, NU, RHO and GE of the library row are written at once into the Materials last
# selected in the Materials tab (nothing is queued; HyperMesh can undo it). An empty library GE keeps the Material's GE. A Material
# that is not MAT1 or that defines G is refused before anything is written; a write whose readback differs puts that Material back.
proc ::hmm_ui::library_parameters {} {
    set name [one_library]
    set ids [previous_ids materials]
    if {![llength $ids]} {error "Select Materials first, then a library entry"}
    ::hmm_props::require_idle
    set values [dict get $::hmm_lib::records $name]
    foreach id $ids {
        if {[hm_getvalue mats id=$id dataname=cardimage] ne "MAT1"} {error "Material $id is not MAT1"}
        set g [::hmm_props::data_value materials $id 2 G MAT1]
        if {$g ne "" && $g != 0} {error "Material $id defines G; change it in the Entity Editor"}
    }
    set done {}
    progress_begin [llength $ids] "Writing parameters" task
    ::hmm::undoable "Library parameters $name" {
    foreach id $ids {
        progress_step [expr {[llength $done] + 1}] task
        set old [::hmm_flow::material_state $id]
        if {[catch {
            foreach {key attr} {E 1 NU 3 RHO 4 GE 7} {
                set value [dict get $values $key]
                if {$value eq ""} {continue}
                *setvalue mats id=$id STATUS=2 $attr=$value
                if {[::hmm_lib::decimal [hm_getvalue mats id=$id dataname=$attr]] ne [::hmm_lib::decimal $value]} {error "$key readback differs"}
            }
        } message]} {
            dict for {attr state} $old {lassign $state status value;if {$value eq ""} {set value 0};catch {*setvalue mats id=$id STATUS=$status $attr=$value}}
            progress_end task
            error "Material $id: $message[expr {[llength $done] ? " (done before it: [join $done {, }])" : ""}]"
        }
        lappend done $id
    }
    }
    progress_end task
    # RHO changes the mass of the Components that use these Materials.
    set affected {}
    dict for {pid data} $::hmm::properties {if {$pid > 0 && [dict get $data material] in $ids} {set affected [concat $affected [::hmm::property_users $pid]]}}
    set ::hmm::massAffected [lsort -unique -integer $affected]
    ::hmm_props::refresh_model;refresh_view components;refresh_sidebar_tables
    done "$name parameters written to Material [join $done {, }]"
}
# Library > Create Mat(s): one MAT1 per selected row, made at once (nothing is queued, nothing is checked against the model).
# A name that already exists in the model asks "Create NAME(1)?" (No skips that row); a row that fails is reported at the end and
# the next one is still made.
proc ::hmm_lib::make {name target} {
    variable records
    set values [dict get $records $name]
    if {[string tolower [hm_info templatetype]] ne "nastran"} {error "Nastran profile needed (current: [hm_info templatetype])"}
    set mark [hm_getmark mats 1]
    set want [::hmm_props::next_id mats]
    *createentity mats cardimage=MAT1 name=$target id=$want
    set id [hm_latestentityid mats]
    if {$id != $want} {error "HyperMesh gave ID $id instead of $want"}
    if {[catch {
        foreach {key attr} {E 1 NU 3 RHO 4 GE 7} {
            set value [dict get $values $key]
            if {$value ne ""} {*setvalue mats id=$id STATUS=2 $attr=$value}
        }
        set actual [native_values $id]
        foreach key {E NU RHO GE} {
            set value [dict get $values $key]
            if {$value ne "" && [decimal $value] ne [decimal [dict get $actual $key]]} {error "$key was written as [dict get $actual $key]"}
        }
    } message options]} {
        catch {*clearmark mats 1;*createmark mats 1 $id;*deletemark mats 1}
        if {[llength $mark]} {*createmark mats 1 {*}$mark}
        return -options $options "$name: $message"
    }
    if {[llength $mark]} {*createmark mats 1 {*}$mark}
    return $id
}
namespace eval ::hmm_ui {variable copyResolver ""}
proc ::hmm_ui::copy_ok {name target} {
    if {$::hmm_ui::copyResolver ne ""} {return [uplevel #0 [linsert $::hmm_ui::copyResolver end $name $target]]}
    return [expr {[tk_messageBox -parent $::hmm::window -type yesno -icon question -title Material -message "$name already exists.\nCreate $target?"] eq "yes"}]
}
proc ::hmm_ui::library_create {} {
    set names [ids library]
    if {![llength $names]} {error "Select library rows first"}
    set used {}
    foreach id [hm_entitylist mats id all] {lappend used [hm_getvalue mats id=$id dataname=name]}
    set made {};set skipped 0;set failed {};set step 0
    progress_begin [llength $names] "Creating Materials" task
    ::hmm::undoable "Create Materials" {
    foreach name $names {
        progress_step [incr step] task
        set target $name;set i 1
        if {$name in $used} {
            while {$target in $used} {set target "${name}($i)";incr i}
            if {![copy_ok $name $target]} {incr skipped;continue}
        }
        if {[catch {::hmm_lib::make $name $target} id]} {lappend failed $id;continue}
        lappend made $id;lappend used $target
    }
    }
    progress_end task
    if {[llength $made]} {
        # Masses do not change with a new Material, and queued changes stay.
        set ::hmm::massAffected {}
        if {[catch {::hmm_props::refresh_model;refresh_view components;refresh_sidebar_tables} message]} {set ::hmm::status "\u26a0 Error: tables not reloaded: $message";return}
    }
    set text "Created [llength $made] Material(s)"
    if {[llength $made]} {append text " (ID [join $made {, }])"}
    if {$skipped} {append text ", skipped $skipped"}
    if {[llength $failed]} {
        warn "$text, failed [llength $failed]: [lindex $failed 0]"
    } elseif {[llength $made]} {done $text} else {set ::hmm::status $text}
}
# ---- Library editing: records are changed in memory, the CSV only by Save / Save as -------------------------------------------
namespace eval ::hmm_lib {variable dirty;if {![info exists dirty]} {set dirty 0}}
# Same rules as the CSV reader (parse), for one value.
proc ::hmm_lib::check_value {name key value} {
    variable records
    set value [string trim $value]
    switch -- $key {
        Source - Group - NameJP {if {[string first "\n" $value] >= 0} {error "$key must be one line"};return $value}
        GE {if {$value eq ""} {return ""};decimal $value;if {$value < 0} {error "GE cannot be negative"};return $value}
        E - RHO {decimal $value;if {$value <= 0} {error "$key must be positive"};return $value}
        NU {decimal $value;if {$value <= -1 || $value >= 0.5} {error "NU must be between -1 and 0.5"};return $value}
        default {error "$key cannot be edited"}
    }
}
proc ::hmm_lib::set_value {name key value} {
    variable records;variable dirty
    if {![dict exists $records $name]} {error "Unknown library entry $name"}
    set value [check_value $name $key $value]
    if {[dict exists $records $name $key] && [dict get $records $name $key] eq $value} {return $value}
    dict set records $name $key $value
    set dirty 1
    return $value
}
# Writes the list to a CSV file: checked with the same reader first, written beside the file and then renamed over it; the file it
# replaces is kept as <file>.bak.
proc ::hmm_lib::save_to {file} {
    variable path;variable dirty;variable records
    set text [serialize]
    if {[catch {parse $text} problem]} {error "The library is not valid, nothing was written: $problem"}
    set file [file normalize $file]
    set temp "$file.tmp"
    # With a BOM, Excel reads the Japanese columns as UTF-8; this reader accepts the BOM.
    set f [open $temp w];fconfigure $f -encoding utf-8 -translation lf;puts -nonewline $f "\ufeff$text";close $f
    if {[file exists $file]} {catch {file copy -force $file "$file.bak"}}
    file rename -force $temp $file
    set path $file
    set dirty 0
    return $file
}
proc ::hmm_ui::library_buttons_update {} {
    set menu [page library].bar.import.menu
    if {![winfo exists $menu]} {return}
    $menu entryconfigure 0 -state [expr {$::hmm_lib::dirty && $::hmm_lib::path ne "" ? "normal" : "disabled"}]
    set tabs $::hmm::window.sidebar.split.tabs
    catch {$tabs tab $tabs.library -text "Library[expr {$::hmm_lib::dirty ? " *" : ""}]"}
}
proc ::hmm_ui::library_save {} {
    if {$::hmm_lib::path eq ""} {error "No library file is loaded: use Save as"}
    ::hmm_lib::save_to $::hmm_lib::path
    library_buttons_update
    done "Library saved"
}
proc ::hmm_ui::library_save_as {} {
    set start [expr {$::hmm_lib::path ne "" ? [file dirname $::hmm_lib::path] : [file join $::hmm::projectDir library]}]
    set name [expr {$::hmm_lib::path ne "" ? [file tail $::hmm_lib::path] : "library.csv"}]
    set file [tk_getSaveFile -parent $::hmm::window -initialdir $start -initialfile $name -defaultextension .csv -title "Save library as" -filetypes {{{CSV files} {.csv}}}]
    if {$file eq ""} {return}
    ::hmm_lib::save_to $file
    set ::hmm_ui::libFile $::hmm_lib::path
    library_buttons_update
    done "Library saved as [file tail $::hmm_lib::path]"
}
# A cell of the Library table was edited.
proc ::hmm_ui::library_accept {table row column value previous} {
    regsub {^tag:} $row "" row
    regsub {^tag:} $column "" column
    upvar #0 ::hmm_props::grid_library values
    if {[catch {
        if {[::hmm_flow::count]} {error "Apply or discard the pending changes before editing the library"}
        set name [dict get $::hmm_props::gridRows(library) $row]
        set value [::hmm_lib::set_value $name $column $value]
        set values($row,$column) $value
        set data [dict get $::hmm_lib::records $name]
        library_buttons_update
        set ::hmm::status "Library: $name $column = $value (not saved yet)"
    } message]} {set ::hmm::status "\u26a0 Error: $message";return 0}
    return 1
}
proc ::hmm_ui::import_library {} {
    if {[::hmm_flow::count]} {error "Apply or revert pending library choices before importing"}
    set file [string trim $::hmm_ui::libFile]
    if {$file eq "" || ![file isfile $file]} {error "Choose a library CSV file in the box first"}
    if {$::hmm_lib::dirty && [tk_messageBox -parent $::hmm::window -type yesno -icon warning -title "Library not saved" -message "The library has changes that were not saved. Discard them and load $file?"] ne "yes"} {return}
    ::hmm_lib::load $file
    library_table
}
# Right-click > Add entry... / Delete: the list in memory changes, the CSV is written by Save / Save as.
proc ::hmm_lib::new_record {values} {
    variable records
    set name [string trim [dict get $values Name]]
    if {![regexp {^[A-Za-z0-9][A-Za-z0-9_./+-]{0,63}$} $name]} {error "Name must use letters, digits and _ . / + - only"}
    if {[dict exists $records $name]} {error "\"$name\" is already in the library"}
    if {[dict size $records] >= 5000} {error "The library holds at most 5000 entries"}
    set record [dict create Group "" NameJP "" Source "" Units "" GE "" Extra [dict create]]
    foreach key {E NU RHO GE} {
        set value [string trim [dict get $values $key]]
        if {$value eq "" && $key ne "GE"} {error "$key is empty"}
        dict set record $key [check_value $name $key $value]
    }
    return [list $name $record]
}
proc ::hmm_lib::add {values} {
    variable records;variable dirty
    lassign [new_record $values] name record
    dict set records $name $record
    set dirty 1
    return $name
}
proc ::hmm_lib::remove {names} {
    variable records;variable dirty;variable selected
    set left [dict remove $records {*}$names]
    if {![dict size $left]} {error "The library cannot be empty"}
    set records $left
    if {![dict exists $records $selected]} {set selected [lindex [dict keys $records] 0]}
    set dirty 1
}
proc ::hmm_ui::library_add_check {values} {
    if {[catch {::hmm_lib::new_record $values} message]} {return $message}
    return ""
}
proc ::hmm_ui::library_add {} {
    set values [form_dialog "Add library entry" {Name Name 30 E E 14 NU NU 14 RHO RHO 14 GE {GE (optional)} 14} ::hmm_ui::library_add_check]
    if {$values eq ""} {return}
    set name [::hmm_lib::add $values]
    library_table
    done "Library entry $name added, not saved yet"
}
proc ::hmm_ui::library_delete {} {
    set names [ids library]
    if {![llength $names]} {error "Select library rows first"}
    ::hmm_lib::remove $names
    library_table
    done "Library: [llength $names] deleted, not saved yet"
}
proc ::hmm_ui::duplicate_property {} {
    set ids [ids properties]
    if {[llength $ids] != 1} {error "Select one source Property"}
    set targets $::hmm_ui::selection(components)
    set result [::hmm::undoable "Duplicate Property" {::hmm_props::copy_for_components $targets [lindex $ids 0]}]
    set assignments $result
    foreach name {components properties materials} data $::hmm_apply::baseline {set ::hmm::$name $data}
    dict for {cid pid} $assignments {::hmm_flow::stage_property components [list $cid] $pid}
    update_status components
}
proc ::hmm_ui::users {type} {
    set props {};set result {};set ids [ids $type]
    if {$type eq "properties"} {set props $ids} else {
        dict for {pid data} $::hmm::properties {if {$pid > 0 && [dict get $data material] in $ids} {lappend props $pid}}
    }
    foreach pid $props {set result [concat $result [::hmm::property_users $pid]]}
    set ::hmm_ui::query(components) "";set ::hmm::filterText "";::hmm::sync_rows
    $::hmm::window.table.tree selection set [lsort -unique -integer $result]
    activate components;selected components
}
proc ::hmm_ui::component_double {tree x y} {
    if {[$tree identify region $x $y] eq "separator" || [$tree identify column $x $y] eq "#0"} {::hmm::double_click $tree $x $y;return -code break}
    selected components
    return -code break
}
proc ::hmm_ui::resolve_dialog {name candidates} {
    set d $::hmm::window.resolve
    if {[winfo exists $d]} {error "A Material decision is already open"}
    toplevel $d;wm withdraw $d;wm title $d "Create Material";wm transient $d $::hmm::window
    set ::hmm_ui::decision cancel;set ::hmm_ui::reuse ""
    set newName [::hmm_flow::next_name $name]
    set message "Material \"$name\" is in the library but has not been created in the model."
    if {[llength $candidates]} {append message "\nModel Materials with identical parameters can be reused instead."}
    append message "\n\nCreate \"$newName\" from the library and apply it?"
    if {$newName ne $name} {append message "\n(\"$name\" is already used in the model, so the new Material is named \"$newName\".)"}
    ttk::label $d.text -text $message -padding 10 -justify left -wraplength 420
    pack $d.text -anchor w
    if {[llength $candidates]} {
        set values {};foreach id $candidates {lappend values "$id | [hm_getvalue mats id=$id dataname=name]"}
        set ::hmm_ui::reuse [lindex $values 0]
        ttk::combobox $d.existing -state readonly -values $values -textvariable ::hmm_ui::reuse -width 42
        pack $d.existing -fill x -padx 10 -pady 5
        ttk::button $d.use -text "Use existing" -command {set ::hmm_ui::decision [lindex [split $::hmm_ui::reuse |] 0]}
        pack $d.use -side left -padx 10 -pady 10
    }
    ttk::button $d.create -text "Create and apply" -command {set ::hmm_ui::decision new}
    ttk::button $d.cancel -text Cancel -command {set ::hmm_ui::decision cancel}
    pack $d.create $d.cancel -side left -padx 10 -pady 10
    wm protocol $d WM_DELETE_WINDOW {set ::hmm_ui::decision cancel}
    update idletasks
    set p $::hmm::window
    wm geometry $d [format "+%d+%d" [expr {[winfo rootx $p]+([winfo width $p]-[winfo reqwidth $d])/2}] [expr {[winfo rooty $p]+([winfo height $p]-[winfo reqheight $d])/2}]]
    wm deiconify $d
    grab set $d
    # Wait for an explicit choice; closing is cancellation, never implicit creation.
    tkwait variable ::hmm_ui::decision
    set result [string trim $::hmm_ui::decision];grab release $d;destroy $d
    return $result
}

# Keep the proven Altair metadata/value adapter; replace its surrounding layout.
foreach name {workspace_original_mount workspace_original_reload} {if {[llength [info commands ::hmm_props::$name]]} {rename ::hmm_props::$name {}}}
rename ::hmm_props::data_mount ::hmm_props::workspace_original_mount
rename ::hmm_props::data_reload ::hmm_props::workspace_original_reload
proc ::hmm_props::data_mount {type} {
    unset -nocomplain ::hmm_ui::lastRef($type)
    workspace_original_mount $type
    ::hmm_ui::controls $type
    ::hmm_ui::table_bind $type
    catch {::hmm_ui::sidebar_header_menu $type}
    # All page children stack vertically. Long messages never participate in table geometry.
    pack configure $::hmm::window.sidebar.split.tabs.$type.table -side top -fill both -expand 1
    if {$type eq "properties"} {
        dict for {column spec} $::hmm_props::gridSchemas($type) {
            if {[lindex $spec 1] eq "Material"} {$::hmm::window.sidebar.split.tabs.$type.table columnconfigure $column -type combobox -editable 1 -width 250 -valuelistcommand ::hmm_flow::choices -valueaccept {::hmm_ui::cell_accept %W %I %C %V %P}}
        }
    } else {
        set t $::hmm::window.sidebar.split.tabs.$type.table
        $t columnconfigure name -width 125
        $t columnconfigure card -width 55
        if {$type eq "materials"} {
            $t columnconfigure library -type combobox -editable 1 -width 140 -valuelistcommand ::hmm_ui::library_values -valueaccept {::hmm_ui::library_pick_cell %W %I %C %V %P}
        } else {
            $t columnconfigure library -width 165
        }
        dict for {column spec} $::hmm_props::gridSchemas($type) {
            set label [lindex $spec 1]
            set width 80
            if {$label in {NU GE}} {set width 60}
            $t columnconfigure $column -width $width
        }
    }
    ::hmm_ui::fit_columns $::hmm::window.sidebar.split.tabs.$type.table
    # Rebuilding toolbar widgets can clear HWTK's selection after row reload.
    # Restore only after the complete tab has been mounted, then after layout settles.
    ::hmm_ui::restore $type
    after idle [list ::hmm_ui::restore $type]
    after idle ::hmm_ui::vertical_layout
}
proc ::hmm_props::data_reload {type} {
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {after 300 [list ::hmm_props::data_reload $type];return}
    workspace_original_reload $type
    set t [::hmm_ui::page $type].table
    if {![winfo exists $t]} {return}
    set needle [string tolower $::hmm_ui::query($type)]
    dict for {row id} $::hmm_props::gridRows($type) {
        if {$type eq "properties"} {
            dict for {column spec} $::hmm_props::gridSchemas($type) {
                if {[lindex $spec 1] eq "Material" && [dict exists $::hmm_flow::queues(properties) m:$id]} {
                    # A queued change shows the Material the Property will have; the amber cell marks it as unapplied.
                    # A library Material not yet in the model has no ID and is marked with "*".
                    set op [dict get $::hmm_flow::queues(properties) m:$id]
                    set target [dict get $op target]
                    set ::hmm_props::grid_properties($row,$column) [expr {[lindex $target 0] eq "lib" ? "[lindex $target 1] *" : [::hmm_ui::material_label [lindex $target 1]]}]
                }
            }
        }
        if {$needle ne "" && [string first $needle [::hmm_ui::filter_text $type $row]] < 0} {$t rowdelete $row;dict unset ::hmm_props::gridRows($type) $row}
    }
    ::hmm_ui::fit_columns $t
    ::hmm_ui::restore $type
    ::hmm_ui::mark_rows $type
}
proc ::hmm_props::native_tab_changed {} {::hmm_ui::run ::hmm_ui::changed}
proc ::hmm_props::sidebar_update {} {
    variable sidebarTimer "";variable sidebarIds;variable sidebarKind;variable editorTarget
    set lower $::hmm::window.sidebar.split.lower
    if {![winfo exists $lower.entity]} {return}
    if {[winfo exists $lower.newpanel] && [winfo ismapped $lower.newpanel]} {return}
    # (the Delete Unused dialog is open: the refresh after it closes schedules this again)
    if {$::hmm_ui::unusedBusy} {return}
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {sidebar_schedule;return}
    ::hmm_props::model_check
    if {[catch {
        pack forget $lower.proposed
        pack $lower.entity -in $lower.strip.e -fill both -expand 1
        set type $::hmm_ui::detailType;set ids [::hmm_ui::ids $type]
        if {$editorTarget ne ""} {foreach {type ids} $editorTarget break}
        set key hmm_material_sidebar
        if {$type eq "library"} {
            set names [::hmm_ui::ids library]
            if {[llength $names] == 1} {::hmm_ui::library_sheet [lindex $names 0];return}
        }
        if {$type eq "library" || ![llength $ids] || $::hmm_images::busy} {
            if {$sidebarIds ne ""} {::hm::paController::funcs::ClearPropertyAreaWidget $key;::hm::paController::funcs::DestroyContent $key;set sidebarIds {}}
            return
        }
        if {$ids eq $sidebarIds && $type eq $sidebarKind} {return}
        ::hm::paController::funcs::CloseActiveeditor $key
        ::hm::paController::funcs::SetEntityIdList $key $ids
        ::hm::paController::funcs::SetEntityType $key $type
        ::hm::paController::funcs::RefreshData $key $type $ids
        if {[::hm::paController::funcs::GetHandleId $key] == -1} {error "Native Entity Editor returned no content"}
        set sidebarIds $ids;set sidebarKind $type
        catch edit_snapshot
    } message] == 1} {set ::hmm::status "\u26a0 Error: Entity Editor: $message"}
    ::hmm_ui::messages
}
# Entity Editor on several entities at once: what the user types applies to all of them.
# Empties the Entity Editor (before HyperMesh deletes entities it may show).
proc ::hmm_props::editor_release {} {
    variable sidebarIds;variable editorTarget
    set key hmm_material_sidebar
    if {$sidebarIds ne "" && $key in [::hm::PropertyAreaViewManager::GetKeyList]} {
        catch {::hm::paController::funcs::CloseActiveeditor $key}
        catch {::hm::paController::funcs::ClearPropertyAreaWidget $key}
        catch {::hm::paController::funcs::DestroyContent $key}
    }
    set sidebarIds {};set editorTarget {}
}
proc ::hmm_props::show_entities {kind ids} {
    variable editorTarget [list $kind $ids]
    variable sidebarIds {}
    sidebar_update
}
proc ::hmm_props::show_entity {kind id} {
    variable editorTarget [list $kind [list $id]]
    variable sidebarIds {}
    sidebar_update
}
proc ::hmm_props::review_sash {} {if {[winfo exists $::hmm::window.content]} {$::hmm::window.content sashpos 0 [expr {int([winfo width $::hmm::window.content]*0.43)}]
    set split $::hmm::window.sidebar.split
    ::hmm_ui::vertical_layout
}}

proc ::hmm_ui::vertical_layout {} {
    set split $::hmm::window.sidebar.split
    if {[winfo exists $split] && [winfo height $split] > 360 && ![collapsed $split]} {
        $split sashpos 0 [expr {int([winfo height $split]*$::hmm_ui::splitRatio)}]
    }
}
# Limits of the sidebar: the vertical sash keeps the band and a few table rows above it and a few Entity rows below it (the horizontal
# one is limited by min_sidebar/min_primary). Checked whenever a sash moves.
set ::hmm_ui::limiting 0
proc ::hmm_ui::vertical_limits {} {
    # top: tab row + band + table header + 3 rows; bottom: Entity tab + header + 4 rows.
    return [list [expr {$::hmm_ui::bandH + 25 + 24 + 60 + 6}] 140]
}
proc ::hmm_ui::limit_sashes {} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window.content] || $::hmm_ui::limiting} {return}
    set ::hmm_ui::limiting 1
    catch ensure_main_pane
    catch {
        set split $::hmm::window.sidebar.split
        set height [winfo height $split]
        lassign [vertical_limits] top bottom
        if {$height > $top + $bottom + 12 && ![collapsed $split]} {
            set pos [$split sashpos 0]
            set clamped [expr {max($top, min($pos, $height - $bottom - 12))}]
            if {$clamped != $pos} {$split sashpos 0 $clamped}
        }
    }
    set ::hmm_ui::limiting 0
}
proc ::hmm_ui::remember_split {} {
    set split $::hmm::window.sidebar.split
    if {![winfo exists $split] || [winfo height $split] <= 0 || [collapsed $split]} {return}
    set height [winfo height $split]
    limit_sashes
    set pos [$split sashpos 0]
    set ::hmm_ui::splitRatio [expr {double($pos) / $height}]
}

# Components workspace: view bar, assign group, table, and pending footer.
namespace eval ::hmm_ui {
    variable pendingText "No pending changes"
}
if {![info exists ::hmm::unassignedOnly]} {set ::hmm::unassignedOnly 0}
proc ::hmm_ui::components_controls {} {
    set f [page components]
    foreach child {top bar cap massgrp chg foot} {if {[winfo exists $f.$child]} {destroy $f.$child}}
    if {[winfo exists [setgroup]]} {destroy [setgroup]}
    # The top band holds four groups: View (stretches with the table), Capture, Mass and Changes (fixed size).
    # Its height is set by align_regions.
    ttk::frame $f.top
    grid propagate $f.top 0
    pack $f.top -side top -fill x -pady {0 6}
    $f.top configure -height 100
    grid columnconfigure $f.top 0 -weight 1
    grid rowconfigure $f.top 0 -weight 1

    # View: the Filter row, then the image folder and Import. The "in" column sits to the right of the aligned boxes.
    ttk::labelframe $f.bar -text View -padding {8 1}
    ttk::label $f.bar.filterLabel -text Filter -image [icon_spec filter] -compound left
    ttk::entry $f.bar.search -textvariable ::hmm_ui::query(components) -width 14
    bind $f.bar.search <KeyRelease> {::hmm_ui::run {::hmm_ui::filter components}}
    if {![info exists ::hmm_ui::filterColumn(components)]} {set ::hmm_ui::filterColumn(components) "All columns"}
    ttk::combobox $f.bar.column -textvariable ::hmm_ui::filterColumn(components) -state readonly -width 11 -postcommand {::hmm_ui::filter_columns components}
    bind $f.bar.column <<ComboboxSelected>> {::hmm_ui::run {::hmm_ui::filter components}}
    ttk::label $f.bar.inLabel -text in
    # One folder for saving and loading the images; Import shows the images saved there.
    ttk::label $f.bar.dirLabel -text Images
    hwtk::choosedirentry $f.bar.dir -textvariable ::hmm_ui::imageDir -width 20 -defaulttext "Image folder" -parent $::hmm::window
    # The widget's own Browse fails after the dialog (its PostSelection needs a hull this window does not have): the button opens the same native dialog directly.
    $f.bar.dir.button configure -command ::hmm_ui::browse_dir
    ttk::button $f.bar.import -text Import -width 8 -image [icon_spec fileImportCSV] -compound left -command {::hmm_ui::run ::hmm_ui::image_dir_load}
    grid $f.bar.filterLabel -row 0 -column 0 -sticky w -padx {0 6} -pady 1
    grid $f.bar.search -row 0 -column 1 -sticky ew -pady 1
    grid $f.bar.inLabel -row 0 -column 2 -sticky w -padx {12 6} -pady 1
    grid $f.bar.column -row 0 -column 3 -sticky ew -pady 1
    grid $f.bar.dirLabel -row 1 -column 0 -sticky w -padx {0 6} -pady 1
    grid $f.bar.dir -row 1 -column 1 -sticky ew -pady 1
    grid $f.bar.import -row 1 -column 3 -sticky ew -pady 1
    grid columnconfigure $f.bar 1 -weight 1
    # (the rows are centered in the group: equal space above and below)
    grid anchor $f.bar center
    image_dir_init

    # Capture: Stop pauses, Continue resumes, Cancel ends the capture (what was captured is kept).
    ttk::labelframe $f.cap -text Capture -padding {8 1}
    foreach {name text command row column} {capture Capture ::hmm_images::capture_selected 0 0 all {Capture all} {::hmm_images::begin [dict keys $::hmm::components]} 0 1 stop Stop ::hmm_images::pause 1 0 cont Continue ::hmm_images::resume 1 1} {
        ttk::button $f.cap.$name -text $text -width 9 -command [list ::hmm_ui::run $command]
        grid $f.cap.$name -row $row -column $column -padx 2 -pady 1
    }
    ttk::button $f.cap.cancel -text Cancel -width 6 -command {::hmm_ui::run ::hmm_images::cancel}
    grid $f.cap.cancel -row 0 -column 2 -rowspan 2 -sticky nsew -padx 2 -pady 1
    foreach name {stop cont cancel} {$f.cap.$name state disabled}
    grid anchor $f.cap center

    # Mass: Calc mass computes what has no value yet, Recalculate starts over.
    ttk::labelframe $f.massgrp -text Mass -padding {8 1}
    set box [framed_button $f.massgrp mass {} {::hmm_ui::run {::hmm_ui::mass_calc 0}} ::hmm_ui::massButtonText 13]
    grid $box -row 0 -column 0 -padx 2 -pady 1
    set box [framed_button $f.massgrp recalc Recalculate {::hmm_ui::run {::hmm_ui::mass_calc 1}} "" 13]
    grid $box -row 1 -column 0 -padx 2 -pady 1
    mass_button_state
    grid anchor $f.massgrp center

    # (Apply/Discard are not a group here: they appear next to Reload while something is pending.)
    grid $f.bar -in $f.top -row 0 -column 0 -sticky nsew
    grid $f.cap -in $f.top -row 0 -column 1 -sticky nsew -padx {6 0}
    grid $f.massgrp -in $f.top -row 0 -column 2 -sticky nsew -padx {6 0}

    mass_header_menu

    # The summary, the last message and the progress are in the window's status row (build_footer).
    progress_show
    components_status
}
proc ::hmm_ui::effective_property {cid} {
    set q $::hmm_flow::queues(components)
    if {[dict exists $q p:$cid]} {return [dict get $q p:$cid target]}
    return [dict get $::hmm::components $cid property]
}
proc ::hmm_ui::components_status {} {
    if {![winfo exists [statusbar]]} {return}
    set ids [ids components];set total [::hmm_flow::count]
    catch mark_sidebar
    # Only what tells something: the selection (or the row count), unapplied changes when there are some, the mass.
    set parts [list [expr {[llength $ids] ? "[llength $ids] of [dict size $::hmm::components] selected" : "[dict size $::hmm::components] Components"}]]
    if {$total} {lappend parts "$total unapplied"}
    if {[catch {mass_summary $ids} mass]} {set mass ""}
    if {$mass ne ""} {lappend parts $mass}
    set ::hmm_ui::pendingText [join $parts "   ·   "]
    action_buttons_update
}

# Show staged values in the main table; the pending cells keep a native treectrl state.
catch {rename ::hmm::row_values_model {}}
rename ::hmm::row_values ::hmm::row_values_model
proc ::hmm::row_values {cid} {
    set values [row_values_model $cid]
    lappend values [mass_text $cid]
    if {![dict size $::hmm_flow::queues(components)]} {return [concat $values [row_extras [lindex $values 2] [lindex $values 4]]]}
    lassign $values id name pid pname mid mname users
    set q $::hmm_flow::queues(components)
    if {[dict exists $q p:$cid]} {
        set pid [dict get $q p:$cid target]
        set pname [dict get $::hmm::properties $pid name]
        set mid [dict get $::hmm::properties $pid material]
        set mname [dict get $::hmm::materials $mid]
        if {[dict exists $::hmm_props::cards $pid] && [dict get $::hmm_props::cards $pid] eq "PBUSH"} {set mname "Not used"}
    }
    if {[dict exists $q m:$pid]} {
        set token [dict get $q m:$pid target]
        if {[lindex $token 0] eq "lib"} {set mid -;set mname "[lindex $token 1] *"} else {set mid [lindex $token 1];set mname [dict get $::hmm::materials $mid]}
    }
    return [concat [list $id $name $pid $pname $mid $mname $users [mass_text $cid]] [row_extras $pid $mid]]
}
# Property and Material information columns of the main table (hidden by default): only the visible ones are read, and what is
# read is kept per Property / Material until the model is read again.
set ::hmm_ui::infoCache [dict create]
proc ::hmm::row_extras {pid mid} {
    set out {}
    foreach {field kind attribute} {property_card p card property_t p 95 property_nsm p 96 material_e m 1 material_nu m 3 material_rho m 4 material_ge m 7} {
        if {![info exists ::hmm_ui::compColumn($field)] || !$::hmm_ui::compColumn($field)} {lappend out "";continue}
        set id [expr {$kind eq "p" ? $pid : $mid}]
        if {![string is integer -strict $id] || $id <= 0} {lappend out "";continue}
        set key $field,$id
        if {![dict exists $::hmm_ui::infoCache $key]} {
            set value ""
            catch {
                if {$field eq "property_card"} {
                    set value [hm_getvalue props id=$id dataname=cardimage]
                } elseif {$kind eq "p"} {
                    set value [::hmm_props::data_value properties $id $attribute $field {PSHELL}]
                } else {
                    set value [::hmm_props::data_value materials $id $attribute $field {}]
                }
            }
            dict set ::hmm_ui::infoCache $key $value
        }
        lappend out [dict get $::hmm_ui::infoCache $key]
    }
    return $out
}
catch {rename ::hmm::sync_rows_base {}}
rename ::hmm::sync_rows ::hmm::sync_rows_base
proc ::hmm::sync_rows {} {
    variable massCache
    if {![info exists massCache]} {set massCache [dict create]}
    # Rebuilding the table clears and restores the selection; those events are not user choices.
    set ::hmm_ui::syncingRows 1
    set code [catch sync_rows_base message options]
    set ::hmm_ui::syncingRows 0
    if {$code} {return -options $options $message}
    ::hmm_ui::mark_components
    catch ::hmm_ui::align_later
}
# The cached masses follow the model: any reload drops them (and stops a running calculation).
catch {rename ::hmm::load_model_base {}}
rename ::hmm::load_model ::hmm::load_model_base
proc ::hmm::load_model {} {
    variable massCache;variable massGen;variable massPending;variable massAffected
    set ::hmm_ui::infoCache [dict create]
    # After Apply only the affected Components lose their mass; a running job, an unknown Component set or any
    # other reload (Entity Editor, Refresh) still drops everything.
    set keep [dict create]
    if {[info exists massAffected] && [info exists massCache]} {
        dict for {cid value} $massCache {if {$cid ni $massAffected} {dict set keep $cid $value}}
    }
    set oldIds [lsort -integer [dict keys $::hmm::components]]
    unset -nocomplain massAffected
    unset -nocomplain massCache
    if {[info exists massGen]} {incr massGen}
    set massPending {}
    catch {::hmm_ui::progress_end mass}
    set ::hmm_ui::massButtonText "Calc mass"
    if {[dict size $keep]} {set massCache $keep}
    set result [load_model_base]
    if {[dict size $keep] && [lsort -integer [dict keys $::hmm::components]] ne $oldIds} {
        set massCache [dict create];::hmm::sync_rows
    }
    # Queued changes whose model value changed while the tool was closed or busy are stale.
    if {![catch ::hmm_props::queue_revalidate dropped] && [llength $dropped]} {
        ::hmm_ui::warn "[llength $dropped] pending change(s) dropped, the model changed"
    }
    catch ::hmm_ui::mass_auto
    return $result
}
if {![info exists ::hmm::massUnit]} {set ::hmm::massUnit kg}
if {![info exists ::hmm::massDecimals]} {set ::hmm::massDecimals auto}
if {![info exists ::hmm_ui::massButtonText]} {set ::hmm_ui::massButtonText "Calc mass"}
# Masses of a large model take seconds, so they are read only when the user asks: one Component per
# idle slice, filling the cells as they arrive.
proc ::hmm::mass_job_start {{all 1}} {
    variable massGen;variable massPending;variable massStarted;variable massCache;variable massTotal
    if {![info exists massGen]} {set massGen 0}
    incr massGen
    # All: start over. Otherwise only the Components without a value are computed and the others keep theirs.
    if {$all || ![info exists massCache]} {set massCache [dict create]}
    set massPending {}
    foreach cid [dict keys $::hmm::components] {if {![dict exists $massCache $cid]} {lappend massPending $cid}}
    if {![llength $massPending]} {return 0}
    set massTotal [dict size $::hmm::components]
    set massStarted [clock milliseconds]
    set ::hmm::massStats [dict create calls 0 call_ms 0 ticks 0 waits_images 0 waits_flow 0 waits_unused 0]
    catch {::hmm_ui::progress_begin $massTotal Mass mass}
    after 50 [list ::hmm::mass_tick $massGen]
    return 1
}
# One tick reads as many Components as fit in about 150 ms (hm_getmass itself lets Tk events run, so the window stays live), then
# gives the event loop a turn; the user's mark 1 is saved and restored once per tick.
proc ::hmm::mass_tick {gen} {
    variable massGen;variable massPending;variable massCache;variable massStarted;variable massTotal
    if {$gen != $massGen || ![winfo exists $::hmm::window] || ![llength $massPending]} {return}
    foreach {flag key} {::hmm_images::busy waits_images ::hmm_flow::busy waits_flow ::hmm_ui::unusedBusy waits_unused} {
        if {[set $flag]} {catch {dict incr ::hmm::massStats $key};after 500 [list ::hmm::mass_tick $gen];return}
    }
    catch {dict incr ::hmm::massStats ticks}
    # hm_getmass lets HyperMesh process events; massBusy makes model-changing operations wait instead of
    # running inside it (require_clean refuses while it is set).
    set ::hmm::massBusy 1
    set saved [hm_getmark comps 1]
    set until [expr {[clock milliseconds] + 150}]
    set held 0
    while {[llength $massPending] && [clock milliseconds] < $until && $gen == $massGen} {
        set cid [lindex $massPending 0];set massPending [lrange $massPending 1 end]
        if {[dict exists $massCache $cid]} {continue}
        # For some seconds after the window opens (it is opened through *evaltclscript) HyperMesh queues '*' commands instead of
        # running them: the mark stays empty and hm_getmass would fail. That Component is tried again a little later instead of
        # being taken as one without mass.
        catch {*clearmark comps 1;*createmark comps 1 $cid}
        if {[hm_getmark comps 1] ne $cid} {set massPending [linsert $massPending 0 $cid];set held 1;break}
        set value "";set t [clock microseconds]
        if {[catch {set value [lindex [hm_getmass comps 1] 0]} problem]} {set value "";catch {dict set ::hmm::massStats last_error [list $cid $problem]}}
        catch {dict incr ::hmm::massStats calls;dict set ::hmm::massStats call_ms [expr {[dict get $::hmm::massStats call_ms] + ([clock microseconds] - $t) / 1000}]}
        dict set massCache $cid $value
        catch {::hmm_tree::set_mass $::hmm::window.table.tree $cid [mass_text $cid]}
    }
    catch {*clearmark comps 1;if {[llength $saved]} {*createmark comps 1 {*}$saved}}
    set ::hmm::massBusy 0
    if {$gen != $massGen} {return}
    catch {::hmm_ui::progress_set [dict size $massCache] mass}
    if {$held} {catch {dict incr ::hmm::massStats held};after 500 [list ::hmm::mass_tick $gen];return}
    if {[llength $massPending]} {after 1 [list ::hmm::mass_tick $gen]} else {mass_job_done}
}
proc ::hmm::mass_job_done {} {
    variable massCache;variable massStarted
    set ::hmm::massReadMs [expr {[clock milliseconds] - $massStarted}]
    catch {dict set ::hmm::massStats wall_ms $::hmm::massReadMs}
    ::hmm_ui::done "Mass done: [dict size $massCache] Components, [format %.1f [expr {$::hmm::massReadMs / 1000.0}]] s"
    catch {::hmm_ui::progress_end mass}
    set ::hmm_ui::massButtonText "Calc mass"
    if {$::hmm::sortColumn eq "mass"} {sort_rows 0}
    catch ::hmm_ui::components_status
    if {[file exists [file join $::hmm::projectDir settings redraw_probe.on]] && ![info exists ::hmm_ui::redrawProbed]} {set ::hmm_ui::redrawProbed 1;after 1500 ::hmm_ui::redraw_probe_run}
}
# The mass of the selected Components is read at once (up to 50 per selection; the others come with the background job).
proc ::hmm::mass_now {ids} {
    variable massCache
    if {![info exists massCache]} {set massCache [dict create]}
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {return}
    set count 0
    foreach cid $ids {
        if {[dict exists $massCache $cid] || ![dict exists $::hmm::components $cid]} {continue}
        if {[incr count] > 50} {break}
        set ::hmm::massBusy 1
        set value "";set saved [hm_getmark comps 1]
        # (marks held back right after the window opened: leave it to the background job, which tries again)
        catch {*clearmark comps 1;*createmark comps 1 $cid}
        set ok [expr {[hm_getmark comps 1] eq $cid}]
        if {$ok && [catch {set value [lindex [hm_getmass comps 1] 0]}]} {set value ""}
        catch {*clearmark comps 1;if {[llength $saved]} {*createmark comps 1 {*}$saved}}
        set ::hmm::massBusy 0
        if {!$ok} {break}
        dict set massCache $cid $value
        catch {::hmm_tree::set_mass $::hmm::window.table.tree $cid [mass_text $cid]}
    }
}
# Displayed mass: kg or tonne (the model value is tonne); "..." while still being read.
proc ::hmm::mass_text {cid} {
    variable massCache;variable massUnit;variable massPending;variable massDecimals
    if {![info exists massCache] || ![dict exists $massCache $cid]} {
        return [expr {[info exists massPending] && $cid in $massPending ? "..." : "-"}]
    }
    set value [dict get $massCache $cid]
    if {![string is double -strict $value]} {return -}
    if {$massUnit eq "kg"} {set value [expr {$value * 1000.0}]}
    if {$massDecimals eq "auto"} {return [format %.6g $value]}
    return [format %.${massDecimals}f $value]
}
# The mass total (all Components) and of the selection, shown in the status line; the masses are read in the background after the
# model is read, and those of the selected rows at once.
proc ::hmm_ui::mass_auto {} {
    variable massAutoTimer
    if {[info exists massAutoTimer] && $massAutoTimer ne ""} {after cancel $massAutoTimer}
    set massAutoTimer [after 1000 ::hmm_ui::mass_auto_run]
}
proc ::hmm_ui::mass_auto_run {} {
    variable massAutoTimer ""
    variable massAutoOff
    variable massRequested
    if {[info exists massAutoOff] && $massAutoOff} {return}
    # Nothing is calculated when the tool opens: the masses are read after Calc mass was pressed once (later reads only fill what
    # a reload or an Apply cleared).
    if {![info exists massRequested] || !$massRequested} {return}
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window] || ![dict size $::hmm::components]} {return}
    if {$::hmm_images::busy || $::hmm_flow::busy || $::hmm_ui::unusedBusy} {mass_auto;return}
    if {[info exists ::hmm::massPending] && [llength $::hmm::massPending]} {return}
    if {[::hmm::mass_job_start 0]} {set ::hmm_ui::massButtonText Stop}
}
# Sum of the cached masses: {sum read noMass} - read counts the Components already calculated, noMass those that HyperMesh gave no
# mass for (for example a Property without thickness); they add nothing to the sum.
proc ::hmm_ui::mass_sum {ids} {
    set sum 0.0;set read 0;set none 0
    foreach cid $ids {
        if {![dict exists $::hmm::massCache $cid]} {continue}
        incr read
        set value [dict get $::hmm::massCache $cid]
        if {[string is double -strict $value]} {set sum [expr {$sum + $value}]} else {incr none}
    }
    if {$::hmm::massUnit eq "kg"} {set sum [expr {$sum * 1000.0}]}
    return [list [format %.6g $sum] $read $none]
}
# "Mass 1.2 kg" for the selection (or "Total mass" without one); "≥" while some are still being read (the progress bar shows how
# far), and how many Components have no mass.
proc ::hmm_ui::mass_summary {ids} {
    if {![info exists ::hmm::massCache] || ![dict size $::hmm::components]} {return ""}
    # (the test switch massAutoOff also keeps the selection from reading masses: hm_getmass lets HyperMesh handle events meanwhile)
    if {[llength $ids] && !([info exists ::hmm_ui::massAutoOff] && $::hmm_ui::massAutoOff)} {::hmm::mass_now $ids}
    set scope [expr {[llength $ids] ? $ids : [dict keys $::hmm::components]}]
    lassign [mass_sum $scope] sum read none
    if {!$read} {return [expr {[llength $ids] ? "Mass ..." : ""}]}
    set text "[expr {[llength $ids] ? "Mass" : "Total mass"}] [expr {$read < [llength $scope] ? "≥ " : ""}]$sum $::hmm::massUnit"
    if {$none} {append text " ($none without mass)"}
    return $text
}
# The Calc mass button: starts the calculation, or stops it while it runs.
proc ::hmm_ui::mass_calc {{all 1}} {
    set ::hmm_ui::massRequested 1
    if {[info exists ::hmm::massPending] && [llength $::hmm::massPending]} {
        incr ::hmm::massGen;set ::hmm::massPending {}
        set ::hmm_ui::massButtonText "Calc mass"
        set ::hmm::status "Mass stopped"
        catch {::hmm_ui::progress_end mass}
        ::hmm::sync_rows
        return
    }
    if {![::hmm::mass_job_start $all]} {
        set ::hmm::status "All masses are known (Recalculate to redo)"
        return
    }
    set ::hmm_ui::massButtonText Stop
    ::hmm::sync_rows
}
proc ::hmm_ui::mass_unit_changed {} {
    set tree $::hmm::window.table.tree
    $tree heading mass -text "Mass ($::hmm::massUnit)"
    ::hmm::sync_rows
}
# Right-click on the Mass header: unit and number of decimals (the treectrl's own -headermenu).
proc ::hmm_ui::mass_header_menu {} {
    set tree $::hmm::window.table.tree
    if {![info exists ::hmm_tree::state($tree,native)]} {return}
    set menu $::hmm::window.massmenu
    if {[winfo exists $menu]} {destroy $menu}
    menu $menu -tearoff 0
    foreach unit {kg ton} {$menu add radiobutton -label $unit -variable ::hmm::massUnit -value $unit -command {::hmm_ui::run ::hmm_ui::mass_unit_changed}}
    $menu add separator
    menu $menu.decimals -tearoff 0
    $menu.decimals add radiobutton -label Auto -variable ::hmm::massDecimals -value auto -command {::hmm_ui::run ::hmm_ui::mass_unit_changed}
    foreach n {0 1 2 3 4 5 6} {$menu.decimals add radiobutton -label "$n decimals" -variable ::hmm::massDecimals -value $n -command {::hmm_ui::run ::hmm_ui::mass_unit_changed}}
    $menu add cascade -label Decimals -menu $menu.decimals
    $menu add separator
    component_columns_menu $menu
    $::hmm_tree::state($tree,native) column configure mass -headermenu $menu
    component_columns_attach
    $tree heading mass -text "Mass ($::hmm::massUnit)"
}
proc ::hmm_ui::mark_components {} {
    set tree $::hmm::window.table.tree
    if {![winfo exists $tree] || ![dict size $::hmm_flow::queues(components)]} {return}
    foreach cid [dict keys $::hmm::components] {
        if {![$tree exists $cid]} {continue}
        set before [::hmm::row_values_model $cid];set after [::hmm::row_values $cid];set fields {}
        foreach field {property_id property_name material_id material_name} index {2 3 4 5} {
            if {[lindex $before $index] ne [lindex $after $index]} {lappend fields $field}
        }
        if {[llength $fields]} {::hmm_tree::mark_pending $tree $cid $fields}
    }
}

# Entity Editor edits write the model directly. Re-read it, keep still-valid queue items, and refresh every table.
proc ::hmm_props::model_check_later {widget} {
    variable modelTimer
    set lower $::hmm::window.sidebar.split.lower
    if {[string first $lower $widget] != 0} {return}
    if {[info exists modelTimer] && $modelTimer ne ""} {after cancel $modelTimer}
    set modelTimer [after 400 ::hmm_props::model_check]
}
proc ::hmm_props::queue_revalidate {} {
    set dropped {}
    foreach scope {components properties materials library} {
        set keep [dict create]
        dict for {key op} $::hmm_flow::queues($scope) {
            set id [dict get $op id];set ok 1
            if {[catch {
                switch [dict get $op kind] {
                    property {set ok [expr {[hm_getvalue comps id=$id dataname=propertyid] == [dict get $op old]}]}
                    material {set ok [expr {[hm_getvalue props id=$id dataname=materialid] == [dict get $op old]}]}
                    parameters {set ok [expr {[::hmm_flow::material_state $id] eq [dict get $op old]}]}
                }
            }]} {set ok 0}
            if {$ok} {dict set keep $key $op} else {lappend dropped $scope/$key}
        }
        set ::hmm_flow::queues($scope) $keep
    }
    return $dropped
}
# ---- Which Components change mass after an Entity Editor edit ---------------------------------------------------------------------
# When the Entity Editor is built for a selection, the values it can change are remembered: the Property of each Component, every
# attribute of the Properties shown (or used by the Components shown) and of their Materials. After an edit the new values are read
# and compared; only the Components that use an entity whose values changed lose their mass. A rename is not a value.
set ::hmm_props::editSnap {};set ::hmm_props::editTarget ""
proc ::hmm_props::edit_values {type id} {
    if {[catch {hm_attributelist $type $id id -byid} attrs]} {return ?}
    set out {}
    foreach attr $attrs {
        if {[catch {hm_getvalue $type id=$id dataname=$attr} value]} {set value ?}
        lappend out $attr $value
    }
    return $out
}
# The remembered value of one entity (key = comps,ID / props,ID / mats,ID), read from the model as it is now.
proc ::hmm_props::edit_value {key} {
    lassign [split $key ,] type id
    switch -- $type {
        comps {return [hm_getvalue comps id=$id dataname=propertyid]}
        props {return [list material [hm_getvalue props id=$id dataname=materialid] [edit_values props $id]]}
        mats {return [edit_values mats $id]}
    }
    error "Unknown key $key"
}
proc ::hmm_props::edit_state {kind ids} {
    set keys {};set pids {};set mids {}
    switch -- $kind {
        components {
            foreach cid $ids {
                lappend keys comps,$cid
                set pid [hm_getvalue comps id=$cid dataname=propertyid]
                if {$pid ne "" && $pid > 0} {lappend pids $pid}
            }
        }
        properties {set pids $ids}
        materials {set mids $ids}
        default {return ""}
    }
    set pids [lsort -unique -integer $pids]
    foreach pid $pids {
        lappend keys props,$pid
        set mid [hm_getvalue props id=$pid dataname=materialid]
        if {$mid ne "" && $mid > 0} {lappend mids $mid}
    }
    set mids [lsort -unique -integer $mids]
    # A very large selection is not remembered: reading it would take longer than the masses it saves.
    if {[llength $pids] + [llength $mids] > 60} {return ""}
    foreach mid $mids {lappend keys mats,$mid}
    set state [dict create]
    foreach key $keys {dict set state $key [edit_value $key]}
    return $state
}
proc ::hmm_props::edit_snapshot {} {
    variable sidebarIds;variable sidebarKind;variable editSnap;variable editTarget
    set editSnap "";set editTarget ""
    if {![llength $sidebarIds]} {return}
    if {[catch {edit_state $sidebarKind $sidebarIds} state] || $state eq ""} {return}
    set editSnap $state;set editTarget [list $sidebarKind $sidebarIds]
}
# Components whose Property, or whose Property's Material, differs between the model just read and the one held by the tool: a change
# made somewhere else than in the Entity Editor of this tool still counts.
proc ::hmm_props::link_changes {fresh} {
    lassign $fresh comps props mats
    set found {}
    dict for {cid data} $comps {
        if {![dict exists $::hmm::components $cid] || [dict get $::hmm::components $cid property] ne [dict get $data property]} {lappend found $cid}
    }
    dict for {pid data} $props {
        if {$pid > 0 && [dict exists $::hmm::properties $pid] && [dict get $::hmm::properties $pid material] ne [dict get $data material]} {
            dict for {cid each} $comps {if {[dict get $each property] == $pid} {lappend found $cid}}
        }
    }
    return $found
}
# True and the list of Components whose mass changes (empty for a rename); false when the edit cannot be told apart.
proc ::hmm_props::edit_affected {name} {
    variable editSnap
    upvar 1 $name result
    if {$editSnap eq ""} {return 0}
    set found {}
    # Each remembered entity is read again where it is, also when a Component now uses another Property.
    dict for {key before} $editSnap {
        lassign [split $key ,] type id
        if {[catch {edit_value $key} now]} {return 0}
        if {$now eq $before} {continue}
        switch -- $type {
            comps {lappend found $id}
            props {set found [concat $found [::hmm::property_users $id]]}
            mats {dict for {pid data} $::hmm::properties {if {$pid > 0 && [dict get $data material] == $id} {set found [concat $found [::hmm::property_users $pid]]}}}
        }
    }
    set result [lsort -unique -integer $found]
    return 1
}
# force = 1 when the Entity Editor has just written a value: the baseline only holds names and links, so a thickness, a Young's modulus
# or any other field would not show as a difference. The cells whose text changed turn green until the user does something else.
proc ::hmm_props::model_check {{force 0}} {
    variable modelTimer ""
    if {![winfo exists $::hmm::window] || $::hmm_apply::blocked || $::hmm_images::busy || $::hmm_flow::busy || ([info exists ::hmm::massBusy] && $::hmm::massBusy)} {return}
    if {[catch {::hmm::read_model} fresh] || (!$force && $fresh eq $::hmm_apply::baseline)} {return}
    set snapshot [::hmm_ui::updated_snapshot]
    set mainBefore [dict create]
    foreach cid [dict keys $::hmm::components] {if {![catch {::hmm::row_values $cid} values]} {dict set mainBefore $cid $values}}
    set dropped [queue_revalidate]
    set keep [list $::hmm_ui::detailType $::hmm_props::editorTarget]
    # Only the Components the edit changed lose their mass; when that cannot be told, every mass is read again.
    if {[edit_affected affected]} {set ::hmm::massAffected [lsort -unique -integer [concat $affected [link_changes $fresh]]]}
    refresh_model
    catch edit_snapshot
    foreach type {properties materials} {if {[winfo exists [::hmm_ui::page $type].table]} {data_reload $type}}
    lassign $keep ::hmm_ui::detailType ::hmm_props::editorTarget
    ::hmm_props::sidebar_schedule
    ::hmm_ui::updated_set $snapshot [::hmm_ui::updated_snapshot]
    ::hmm_ui::updated_main $mainBefore
    if {[llength $dropped]} {::hmm_ui::warn "[llength $dropped] pending change(s) dropped, the model changed"} else {set ::hmm::status "Model updated"}
    ::hmm_ui::update_status components
    ::hmm_ui::update_status $::hmm_ui::active
    catch ::hmm_ui::unused_update
}

# Sidebar rows carry treectrl states: hmmpending (queued change, amber) and hmmref (used by the selected
# Component, green). Selection colours stay first in the fill list so they still win.
proc ::hmm_ui::row_states_init {draw} {
    catch {$draw state define hmmpending}
    catch {$draw state define hmmref}
    catch {$draw state define hmmmatch}
    catch {$draw state define hmmupdated}
    set fill [$draw element cget cell -fill]
    # Selection colours first, then the reference (green), then pending cells (amber).
    # The pending (amber) and reference (green) colours come first so they win over the selection colour: a new or staged cell stays amber when selected.
    if {[string first hmmpending $fill] < 0} {$draw element configure cell -fill [concat [list #ffe08a hmmpending #b3e6a1 hmmupdated #cfe8c8 hmmref #dcc8f2 hmmmatch] $fill]}
    # Selected and active cells keep the plain grid colour: the selection is a flat fill, as in the main table.
    catch {$draw element configure cell -outline [list #C9CCCC {}]}
}
# Raw treectrl index of a datatable column by its label (raw column 0 is the row number).
proc ::hmm_ui::column_index_for {type label} {
    set t [page $type].table
    if {![info exists ::hmm_props::gridSchemas($type)]} {return ""}
    dict for {column spec} $::hmm_props::gridSchemas($type) {
        if {[lindex $spec 1] eq $label} {
            set i [lsearch -exact [$t columnlist] tag:$column]
            if {$i >= 0} {return [expr {$i + 1}]}
        }
    }
    return ""
}
# Property and Material IDs used by the selected Components, including staged values.
proc ::hmm_ui::sidebar_reference_ids {type} {
    set pids {};set mids {}
    foreach cid [ids components] {
        if {![dict exists $::hmm::components $cid]} {continue}
        set pid [effective_property $cid]
        if {$pid > 0 && [dict exists $::hmm::properties $pid]} {
            lappend pids $pid
            set q $::hmm_flow::queues(components)
            if {[dict exists $q m:$pid] && [lindex [dict get $q m:$pid target] 0] eq "model"} {
                lappend mids [lindex [dict get $q m:$pid target] 1]
            } elseif {![dict exists $q m:$pid]} {
                set mid [dict get $::hmm::properties $pid material]
                if {$mid > 0} {lappend mids $mid}
            }
        }
    }
    return [lsort -unique -integer [expr {$type eq "properties" ? $pids : $mids}]]
}
proc ::hmm_ui::mark_rows {type} {
    variable lastRef
    set table [page $type].table
    if {![winfo exists $table] || ![info exists ::hmm_props::gridRows($type)]} {return}
    set draw [$table component table]
    row_states_init $draw
    # Pending cells: the Material cell of a Property whose Material is queued, the parameter cells of a
    # Material whose library parameters are queued.
    set pending [dict create]
    dict for {key op} $::hmm_flow::queues($type) {
        if {![dict exists $op id]} {continue}
        set labels {}
        switch [dict get $op kind] {
            material {set labels {Material}}
            parameters {foreach label {E NU RHO GE} {if {[dict exists $op library $label] && [dict get $op library $label] ne ""} {lappend labels $label}}}
        }
        set columns {}
        foreach label $labels {set c [column_index_for $type $label];if {$c ne ""} {lappend columns $c}}
        dict set pending [dict get $op id] $columns
    }
    set allColumns {}
    for {set c 1} {$c <= [llength [$table columnlist]]} {incr c} {lappend allColumns $c}
    # A new, not yet applied entity is highlighted on the whole row in the pending colour.
    set createdKind [expr {$type eq "properties" ? "props" : "mats"}]
    foreach item $::hmm_props::created {
        if {[lindex $item 0] eq $createdKind} {dict set pending [lindex $item 1] $allColumns}
    }
    # Library match cells that offer a name (or several) are blue; clicking one lists the names.
    if {$type eq "materials"} {
        set position [lsearch -exact [$table columnlist] tag:library]
        if {$position >= 0} {
            incr position
            dict for {row id} $::hmm_props::gridRows(materials) {
                if {[catch {set item [$draw item id [list tag tag:$row]]}] || $item eq ""} {continue}
                set on [expr {[info exists ::hmm_lib::highlight($id)] && $::hmm_lib::highlight($id)}]
                catch {$draw item state forcolumn $item $position [expr {$on ? "hmmmatch" : "!hmmmatch"}]}
            }
        }
    }
    set refs [expr {$::hmm_ui::refActive ? [sidebar_reference_ids $type] : {}}]
    set first ""
    dict for {row id} $::hmm_props::gridRows($type) {
        if {[catch {set item [$draw item id [list tag tag:$row]]}] || $item eq ""} {continue}
        $draw item state set $item {!hmmref}
        foreach c $allColumns {catch {$draw item state forcolumn $item $c {!hmmpending !hmmupdated}}}
        if {[dict exists $pending $id]} {foreach c [dict get $pending $id] {catch {$draw item state forcolumn $item $c hmmpending}}}
        if {[dict exists $::hmm_ui::updated $type $id]} {
            set marked [dict get $::hmm_ui::updated $type $id]
            if {$marked eq "all"} {set marked $allColumns} else {
                set indexes {}
                foreach key $marked {set i [lsearch -exact [$table columnlist] tag:$key];if {$i >= 0} {lappend indexes [expr {$i + 1}]}}
                set marked $indexes
            }
            foreach c $marked {catch {$draw item state forcolumn $item $c hmmupdated}}
        }
        if {$id in $refs} {
            $draw item state set $item hmmref
            if {$first eq ""} {set first $item}
        }
    }
    # Scroll to the first referenced row only when the reference changes (or the table was rebuilt).
    if {![info exists lastRef($type)] || $lastRef($type) ne $refs} {
        set lastRef($type) $refs
        if {$first ne ""} {catch {$draw see $first}}
    }
}
# ---- Cells just updated by the Entity Editor: green until the next action ---------------------------------------------------------
# updated: type -> id -> list of column keys, or "all" for a new row. Any other action (selecting, a button, a menu) clears it; the
# half second after it is set is ignored so that the table's own refresh events do not clear it at once.
set ::hmm_ui::updated [dict create]
set ::hmm_ui::updatedGuard 0
proc ::hmm_ui::updated_snapshot {} {
    set snapshot [dict create]
    foreach type {properties materials} {
        if {![winfo exists [page $type].table] || ![info exists ::hmm_props::gridRows($type)]} {continue}
        upvar #0 ::hmm_props::grid_$type values
        dict for {row id} $::hmm_props::gridRows($type) {
            set cells [dict create]
            foreach key [array names values $row,*] {dict set cells [string range $key [expr {[string length $row] + 1}] end] $values($key)}
            dict set snapshot $type $id $cells
        }
    }
    return $snapshot
}
proc ::hmm_ui::updated_set {before after} {
    set result [dict create]
    dict for {type rows} $after {
        dict for {id cells} $rows {
            if {![dict exists $before $type $id]} {dict set result $type $id all;continue}
            set old [dict get $before $type $id];set changed {}
            dict for {key value} $cells {if {![dict exists $old $key] || [dict get $old $key] ne $value} {lappend changed $key}}
            if {[llength $changed]} {dict set result $type $id $changed}
        }
    }
    set ::hmm_ui::updated $result
    set ::hmm_ui::updatedGuard [expr {[clock milliseconds] + 800}]
    foreach type {properties materials} {catch {mark_rows $type}}
    return [dict size $result]
}
# The Components table: the Property and Material cells whose text changed.
proc ::hmm_ui::updated_main {before} {
    set tree $::hmm::window.table.tree
    if {![winfo exists $tree]} {return}
    ::hmm_tree::clear_updated $tree
    set count 0
    dict for {cid old} $before {
        if {![dict exists $::hmm::components $cid] || ![$tree exists $cid] || [catch {::hmm::row_values $cid} new]} {continue}
        set fields {}
        foreach field {property_id property_name material_id material_name} index {2 3 4 5} {
            if {[lindex $old $index] ne [lindex $new $index]} {lappend fields $field}
        }
        if {[llength $fields]} {::hmm_tree::mark_updated $tree $cid $fields;incr count}
    }
    return $count
}
proc ::hmm_ui::updated_clear {} {
    if {[clock milliseconds] < $::hmm_ui::updatedGuard} {return}
    catch {::hmm_tree::clear_updated $::hmm::window.table.tree}
    if {![dict size $::hmm_ui::updated]} {return}
    set ::hmm_ui::updated [dict create]
    foreach type {properties materials} {catch {mark_rows $type}}
}
proc ::hmm_ui::mark_sidebar {} {
    foreach type {properties materials} {mark_rows $type}
}

# ---- Column choice by right-click on a header (treectrl/datatable -headermenu) ----
namespace eval ::hmm_ui {
    variable compFields {image {Image} id {Component ID} name {Component} property_id {Property ID} property_name {Property} material_id {Material ID} material_name {Material} shared {Shared} mass {Mass} property_card {Prop Card} property_t {Thickness} property_nsm {NSM} material_e {Mat E} material_nu {Mat NU} material_rho {Mat RHO} material_ge {Mat GE}}
    variable compColumn
    variable propCardVisible 1
    variable libColumn
    variable libKeys {E NU RHO GE Units Source Group NameJP}
    # The Image folder box follows the model: imageDirAuto is the folder the tool put there, imageModel the model it last looked at.
    variable imageDirAuto "";variable imageModel ""
    foreach key $libKeys {if {![info exists libColumn($key)]} {set libColumn($key) [expr {$key ni {Units Source}}]}}
    variable propThicknessVisible 1
    # The Property and Material information columns are optional: hidden until chosen in the header menu.
    foreach {field label} $compFields {if {![info exists compColumn($field)]} {set compColumn($field) [expr {$field in {property_card property_t property_nsm material_e material_nu material_rho material_ge} ? 0 : 1}]}}
}
# A probe sets columnsFileOverride so it never touches the saved column choices.
proc ::hmm_ui::component_columns_file {} {
    if {[info exists ::hmm_ui::columnsFileOverride] && $::hmm_ui::columnsFileOverride ne ""} {return $::hmm_ui::columnsFileOverride}
    return [file join $::hmm::projectDir settings component_columns.dict]
}
proc ::hmm_ui::component_columns_load {} {
    set path [component_columns_file]
    if {![file isfile $path] || [file size $path] > 4096} {return}
    if {[catch {set f [open $path r];fconfigure $f -encoding utf-8;set text [read $f];close $f;dict size $text}]} {return}
    dict for {field visible} $text {if {[info exists ::hmm_ui::compColumn($field)] && $visible in {0 1}} {set ::hmm_ui::compColumn($field) $visible}}
}
# Adds one check entry per Component column (the Component name always stays) and a Show all entry.
proc ::hmm_ui::component_columns_menu {menu} {
    foreach {field label} $::hmm_ui::compFields {
        # (the Material parameters are listed by their own label: E, NU, RHO, GE)
        regsub {^Mat } $label {} label
        $menu add checkbutton -label $label -variable ::hmm_ui::compColumn($field) -command {::hmm_ui::run ::hmm_ui::component_columns_changed}
        if {$field eq "name"} {$menu entryconfigure end -state disabled}
    }
    $menu add command -label "Show all" -command {::hmm_ui::run {::hmm_ui::component_columns_all}}
}
proc ::hmm_ui::component_columns_all {} {
    foreach {field label} $::hmm_ui::compFields {set ::hmm_ui::compColumn($field) 1}
    component_columns_changed
}
proc ::hmm_ui::component_columns_changed {} {
    set tree $::hmm::window.table.tree
    if {![info exists ::hmm_tree::state($tree,native)]} {return}
    # An information column that was hidden has empty cells: read the rows again when the set of shown ones changes.
    set shown {}
    foreach field {property_card property_t property_nsm material_e material_nu material_rho material_ge} {lappend shown $::hmm_ui::compColumn($field)}
    if {![info exists ::hmm_ui::shownExtras] || $::hmm_ui::shownExtras ne $shown} {
        set first [expr {![info exists ::hmm_ui::shownExtras]}]
        set ::hmm_ui::shownExtras $shown
        if {!$first} {after idle {catch ::hmm::sync_rows}}
    }
    set native $::hmm_tree::state($tree,native)
    foreach {field label} $::hmm_ui::compFields {$native column configure [$native column id $field] -visible $::hmm_ui::compColumn($field)}
    set path [component_columns_file]
    if {[catch {file mkdir [file dirname $path];set f [open "$path.tmp" w];fconfigure $f -encoding utf-8;puts $f [array get ::hmm_ui::compColumn];close $f;file rename -force "$path.tmp" $path}]} {catch {close $f}}
}
proc ::hmm_ui::component_columns_attach {} {
    set tree $::hmm::window.table.tree
    set native $::hmm_tree::state($tree,native)
    set menu $::hmm::window.colmenu
    if {[winfo exists $menu]} {destroy $menu}
    menu $menu -tearoff 0
    component_columns_menu $menu
    foreach {field label} $::hmm_ui::compFields {
        if {$field ne "mass"} {$native column configure [$native column id $field] -headermenu $menu}
    }
    component_columns_load
    component_columns_changed
}
proc ::hmm_ui::sidebar_header_menu {type} {
    set t [page $type].table
    if {![winfo exists $t]} {return}
    set menu [page $type].hdrmenu
    if {[winfo exists $menu]} {destroy $menu}
    menu $menu -tearoff 0
    if {$type eq "materials"} {
        foreach label $::hmm_props::materialColumns {
            if {![info exists ::hmm_props::columnVisible($label)]} {set ::hmm_props::columnVisible($label) [expr {$label in {E NU RHO GE}}]}
            $menu add checkbutton -label $label -variable ::hmm_props::columnVisible($label) -command {::hmm_ui::run ::hmm_props::columns_changed}
        }
    } elseif {$type eq "properties"} {
        $menu add checkbutton -label Card -variable ::hmm_ui::propCardVisible -command {::hmm_ui::run ::hmm_ui::property_columns_changed}
        # Every other field of the card types shown (T, NSM, Z1... for PSHELL, ISOP... for PSOLID, K_LINE... for PBUSH).
        set filter $::hmm_props::propFilter;set labels {}
        catch {
            dict for {attribute data} [::hmm_props::data_metadata properties] {
                set label [dict get $data label]
                if {$label eq "Material" || ($filter ne "All" && $filter ni [dict get $data clientdata])} {continue}
                if {$label ni $labels} {lappend labels $label}
            }
        }
        set first {};set rest {}
        foreach label $labels {if {$label in {T NSM}} {lappend first $label} else {lappend rest $label}}
        set labels [concat [lsort $first] [lsort -dictionary $rest]]
        if {[llength $labels]} {$menu add separator}
        foreach label $labels {
            ::hmm_props::prop_column_on $filter $label
            $menu add checkbutton -label $label -variable ::hmm_props::propColumn($filter,$label) -command {after idle {::hmm_ui::run {::hmm_props::data_rebuild properties}}}
        }
    }
    foreach column [$t columnlist] {
        regsub {^tag:} $column "" name
        catch {$t columnconfigure $name -headermenu $menu}
    }
    if {$type eq "properties"} {property_columns_changed}
}
proc ::hmm_ui::property_columns_changed {} {
    set t [page properties].table
    if {![winfo exists $t]} {return}
    catch {$t columnconfigure card -visible $::hmm_ui::propCardVisible}
    if {[info exists ::hmm_props::gridSchemas(properties)]} {
        dict for {column spec} $::hmm_props::gridSchemas(properties) {
            if {[lindex $spec 1] eq "T"} {catch {$t columnconfigure $column -visible $::hmm_ui::propThicknessVisible}}
        }
    }
}

# ---- Progress shown in the footer while code runs (hwtk::progressbar) ----
if {![info exists ::hmm_ui::progressValue]} {set ::hmm_ui::progressValue 0}
# Progress of long operations: one bar with a caption at the right of the footer. Each operation has a key (mass, capture, read,
# task...); several can run at once (the background mass job while the model is read): the one started last is shown and the
# previous one comes back when it ends. Without a key, progress_set / progress_end act on the operation shown.
if {![info exists ::hmm_ui::progressJobs]} {set ::hmm_ui::progressJobs {}}
if {![info exists ::hmm_ui::progressTask]} {set ::hmm_ui::progressTask ""}
set ::hmm_ui::progressDrawn 0
proc ::hmm_ui::progress_begin {total {label ""} {key main}} {
    progress_drop $key
    lappend ::hmm_ui::progressJobs [list $key $label [expr {max($total, 1)}] 0]
    progress_show
}
proc ::hmm_ui::progress_drop {key} {
    set kept {};foreach job $::hmm_ui::progressJobs {if {[lindex $job 0] ne $key} {lappend kept $job}}
    set ::hmm_ui::progressJobs $kept
}
proc ::hmm_ui::progress_set {n {key ""}} {
    if {![llength $::hmm_ui::progressJobs]} {return}
    if {$key eq ""} {set key [lindex $::hmm_ui::progressJobs end 0]}
    set i 0
    foreach job $::hmm_ui::progressJobs {
        if {[lindex $job 0] eq $key} {lset ::hmm_ui::progressJobs $i 3 $n;break}
        incr i
    }
    if {$key eq [lindex $::hmm_ui::progressJobs end 0]} {progress_caption}
}
proc ::hmm_ui::progress_end {{key ""}} {
    if {$key eq ""} {set key [lindex $::hmm_ui::progressJobs end 0]}
    progress_drop $key
    progress_show
}
proc ::hmm_ui::progress_caption {} {
    lassign [lindex $::hmm_ui::progressJobs end] key label total value
    set ::hmm_ui::progressValue $value
    set ::hmm_ui::progressTask [string trim "$label [expr {int(100.0 * min($value, $total) / $total)}]%"]
}
proc ::hmm_ui::progress_show {} {
    set foot [statusbar]
    if {![winfo exists $foot.progress] || ![winfo exists $foot.task]} {return}
    # First in the status row: "Ready", or the bar of a running operation with its caption; then the summary.
    if {![llength $::hmm_ui::progressJobs]} {
        pack forget $foot.progress $foot.task
        set ::hmm_ui::progressValue 0;set ::hmm_ui::progressTask ""
        if {[winfo exists $foot.ready] && [winfo manager $foot.ready] eq ""} {pack $foot.ready -side left -padx {0 16} -before $foot.pending}
        return
    }
    $foot.progress configure -maximum [lindex $::hmm_ui::progressJobs end 2]
    progress_caption
    if {[winfo manager $foot.progress] eq ""} {
        if {[winfo exists $foot.ready]} {pack forget $foot.ready}
        pack $foot.progress -side left -before $foot.pending
        pack $foot.task -side left -after $foot.progress -padx {8 16}
    }
}
# A step of an operation that keeps HyperMesh busy (no event loop meanwhile): the bar is redrawn at most every 80 ms.
proc ::hmm_ui::progress_step {n {key ""}} {
    progress_set $n $key
    set now [clock milliseconds]
    if {$now - $::hmm_ui::progressDrawn >= 80} {set ::hmm_ui::progressDrawn $now;update idletasks}
}


proc ::hmm_ui::material_label {mid} {
    if {$mid eq "" || $mid == 0} {return Unassigned}
    if {[dict exists $::hmm::materials $mid]} {return "$mid | [dict get $::hmm::materials $mid]"}
    return $mid
}

# The capture state also drives the Stop button and the folder box.
catch {rename ::hmm::set_image_busy ::hmm::set_image_busy_base}
proc ::hmm::set_image_busy {busy} {
    catch {::hmm::set_image_busy_base $busy}
    catch {::hmm_ui::image_busy_ui $busy}
}

# Recalculate is locked while a calculation runs (the Calc mass button then reads Stop).
proc ::hmm_ui::mass_button_state {args} {
    catch {
        set b [page components].massgrp.recalc
        if {[winfo exists $b]} {$b configure -state [expr {$::hmm_ui::massButtonText eq "Stop" ? "disabled" : "normal"}]}
        set m [page components].massgrp.mass
        if {[winfo exists $m]} {$m configure -image [icon [expr {$::hmm_ui::massButtonText eq "Stop" ? "toolbarAnimationPlaybackPauseStrip" : "entityMasses"}]] -compound left}
    }
}
if {[lsearch -exact [trace info variable ::hmm_ui::massButtonText] [list write ::hmm_ui::mass_button_state]] < 0} {trace add variable ::hmm_ui::massButtonText write ::hmm_ui::mass_button_state}

# ---- Part names: a CSV of Component names with a short name of at most 8 characters each (Name, Short). A Component gets a full name
# of the list as its name with Rename Comp in the Part name tab (one Component of the main table, one name of the list). The file last
# imported is remembered in settings/name_list.txt.
namespace eval ::hmm_names {
    variable entries;variable path;variable extras;variable meta;variable dirty;variable shown;variable gridRows
    if {![info exists entries]} {set entries [dict create];set path ""}
    # The other columns of the file (kept when it is saved), where Name and Short are, and the header row: see parse_full.
    if {![info exists extras]} {set extras [dict create];set dirty 0;set shown "";set gridRows [dict create]}
    if {![info exists meta]} {set meta [dict create nameAt 0 shortAt 1 first 0 header {} width 2]}
}
proc ::hmm_names::column_key {cell} {
    set base [string tolower [string trim [string trimleft $cell ﻿]]]
    regsub -all {[ _-]+} $base " " base
    switch -- $base {
        name - "component name" - "full name" - component - "名前" - "名称" {return Name}
        short - "short name" - abbreviation - abbr - abbrev - "略称" - "略語" {return Short}
    }
    return ""
}
# Returns {short name ...} in file order. A first row whose cells are both known column names is the header; without one the
# first column is the name and the second the short name.
proc ::hmm_names::parse_full {text} {
    set rows [::hmm_lib::csv_rows $text]
    if {![llength $rows]} {error "The file is empty"}
    set nameAt 0;set shortAt 1;set first 0
    set keys {};foreach cell [lindex $rows 0] {lappend keys [column_key $cell]}
    if {"Name" in $keys && "Short" in $keys} {set nameAt [lsearch -exact $keys Name];set shortAt [lsearch -exact $keys Short];set first 1}
    set result [dict create];set extra [dict create];set names {};set line $first
    set width [expr {max($nameAt, $shortAt) + 1}]
    foreach r $rows {if {[llength $r] > $width} {set width [llength $r]}}
    foreach row [lrange $rows $first end] {
        incr line
        set name [string trim [lindex $row $nameAt]];set short [string trim [lindex $row $shortAt]]
        if {$name eq "" && $short eq ""} {continue}
        if {$name eq ""} {error "Row $line: the name is empty"}
        if {$short eq ""} {error "Row $line ($name): the short name is empty"}
        if {[string length $short] > 8} {error "Row $line ($name): the short name \"$short\" has [string length $short] characters (at most 8)"}
        if {[regexp {[\s",|]} $short]} {error "Row $line ($name): the short name \"$short\" contains a space, comma, quote or |"}
        if {[dict exists $result $short]} {error "Row $line: the short name \"$short\" is used twice"}
        if {$name in $names} {error "Row $line: the name \"$name\" is used twice"}
        dict set result $short $name;dict set extra $short $row;lappend names $name
    }
    if {![dict size $result]} {error "No names in the file"}
    set meta [dict create nameAt $nameAt shortAt $shortAt first $first header [expr {$first ? [lindex $rows 0] : {}}] width $width]
    return [list $result $extra $meta]
}
proc ::hmm_names::parse {text} {return [lindex [parse_full $text] 0]}
# (::hmm_names::settingsOverride: a probe keeps its own remembered file out of the user's settings)
proc ::hmm_names::settings_file {} {
    if {[info exists ::hmm_names::settingsOverride]} {return $::hmm_names::settingsOverride}
    return [file join $::hmm::projectDir settings name_list.txt]
}
proc ::hmm_names::load {file} {
    if {[file size $file] > 2097152} {error "File exceeds 2 MB"}
    set f [open $file rb];set bytes [read $f];close $f
    if {[catch {parse_full [::hmm_lib::decode_text $bytes]} full]} {error "[file tail $file]: $full"}
    variable entries [lindex $full 0]
    variable extras [lindex $full 1]
    variable meta [lindex $full 2]
    variable dirty 0
    variable path [file normalize $file]
    catch {file mkdir [file dirname [settings_file]];set f [open [settings_file] w];fconfigure $f -encoding utf-8;puts $f $path;close $f}
    return [dict size $entries]
}
proc ::hmm_names::load_saved {} {
    variable path
    if {$path ne "" || ![file isfile [settings_file]]} {return}
    set f [open [settings_file] r];fconfigure $f -encoding utf-8;set saved [string trim [read $f]];close $f
    if {$saved ne "" && [file isfile $saved]} {catch {load $saved}}
}
# ---- Part name tab: the list as a table that can be edited (Name, Short), with names added and deleted, and saved over the file.
# A name is checked with the rules of parse_full (short name: at most 8 characters, no space, comma, quote or |; no name or short
# name twice). The Components keep the names they have when the list changes; Rename Comp gives one of them a name of the list.
proc ::hmm_names::check {name short {exceptShort ""}} {
    variable entries
    set name [string trim $name];set short [string trim $short]
    if {$name eq ""} {return "The name is empty"}
    if {$short eq ""} {return "The short name is empty"}
    if {[string length $short] > 8} {return "The short name \"$short\" has [string length $short] characters (at most 8)"}
    if {[regexp {[\s",|]} $short]} {return "The short name \"$short\" contains a space, comma, quote or |"}
    dict for {s n} $entries {
        if {$s eq $exceptShort} {continue}
        if {$s eq $short} {return "The short name \"$short\" is already used"}
        if {$n eq $name} {return "The name \"$name\" is already in the list"}
    }
    return ""
}
proc ::hmm_names::markdirty {} {variable dirty;set dirty 1}
proc ::hmm_names::add {name short} {
    variable entries
    set name [string trim $name];set short [string trim $short]
    set message [check $name $short]
    if {$message ne ""} {error $message}
    dict set entries $short $name
    markdirty
    return $short
}
proc ::hmm_names::set_name {short name} {
    variable entries
    set name [string trim $name]
    set message [check $name $short $short]
    if {$message ne ""} {error $message}
    dict set entries $short $name
    markdirty
    return $name
}
# A new short name keeps the place of the entry in the list.
proc ::hmm_names::set_short {old new} {
    variable entries;variable extras
    set new [string trim $new]
    set message [check [dict get $entries $old] $new $old]
    if {$message ne ""} {error $message}
    if {$new eq $old} {return $new}
    set e [dict create];set x [dict create]
    dict for {s n} $entries {
        set key [expr {$s eq $old ? $new : $s}]
        dict set e $key $n
        if {[dict exists $extras $s]} {dict set x $key [dict get $extras $s]}
    }
    set entries $e;set extras $x
    markdirty
    return $new
}
proc ::hmm_names::remove {shorts} {
    variable entries;variable extras
    foreach s $shorts {set entries [dict remove $entries $s];set extras [dict remove $extras $s]}
    markdirty
}
# The Components that have this name, as "Comp 3, 7".
proc ::hmm_names::used_by {name} {
    set ids {}
    dict for {id data} $::hmm::components {if {[dict get $data name] eq $name} {lappend ids $id}}
    return [expr {[llength $ids] ? "Comp [join $ids {, }]" : ""}]
}
# Rename Comp: the Component gets this name, as the Entity Editor writes it (one native undo step "Modified Name of Component ...").
proc ::hmm_names::rename_component {cid name} {
    ::hmm_props::require_idle
    if {![dict exists $::hmm::components $cid]} {error "Unknown Component $cid"}
    set name [string trim $name]
    if {$name eq ""} {error "The name is empty"}
    if {$name eq [hm_getvalue comps id=$cid dataname=name]} {return "Component $cid already has the name $name"}
    foreach other [hm_entitylist comps id all] {
        if {$other != $cid && [hm_getvalue comps id=$other dataname=name] eq $name} {error "\"$name\" is used by Component $other"}
    }
    ::hmm::native_edit {*setvalue comps id=$cid name=$name}
    if {[hm_getvalue comps id=$cid dataname=name] ne $name} {error "HyperMesh did not rename Component $cid to \"$name\""}
    return "Component $cid named \"$name\""
}
proc ::hmm_names::csvline {cells} {
    set out {};foreach cell $cells {lappend out [::hmm_lib::csv_field $cell]}
    return [join $out ,]
}
# The file as text: the header and the other columns of the file it came from stay as they were; a list without a header gets one.
proc ::hmm_names::serialize {} {
    variable entries;variable extras;variable meta
    set nameAt [dict get $meta nameAt];set shortAt [dict get $meta shortAt];set width [dict get $meta width]
    if {[dict get $meta first]} {
        set head [dict get $meta header]
    } else {
        set head {};for {set i 0} {$i < $width} {incr i} {lappend head ""}
        lset head $nameAt Name;lset head $shortAt Short
    }
    set lines [list [csvline $head]]
    dict for {short name} $entries {
        set cells [expr {[dict exists $extras $short] ? [dict get $extras $short] : {}}]
        while {[llength $cells] < $width} {lappend cells ""}
        lset cells $nameAt $name;lset cells $shortAt $short
        lappend lines [csvline $cells]
    }
    return "[join $lines \n]\n"
}
# Writes the list to a CSV file: checked with the same reader first, written beside the file and then renamed over it; the file it
# replaces is kept as <file>.bak. UTF-8 with a BOM, so Excel shows Japanese names; the reader also accepts CP932 files.
proc ::hmm_names::save_to {file} {
    variable path;variable dirty;variable meta;variable entries
    if {![dict size $entries]} {error "The list is empty, nothing was written"}
    set text [serialize]
    if {[catch {parse_full $text} full]} {error "The list is not valid, nothing was written: $full"}
    set file [file normalize $file]
    set temp "$file.tmp"
    set f [open $temp w];fconfigure $f -encoding utf-8 -translation lf;puts -nonewline $f "\ufeff$text";close $f
    if {[file exists $file]} {catch {file copy -force $file "$file.bak"}}
    file rename -force $temp $file
    set path $file;set dirty 0;set meta [lindex $full 2]
    catch {file mkdir [file dirname [settings_file]];set f [open [settings_file] w];fconfigure $f -encoding utf-8;puts $f $path;close $f}
    return $file
}
# Part names: the file in the box of the tab is read by Import; the right-click item "Import part names..." (Properties tab) picks a file
# with the native dialog first.
proc ::hmm_ui::names_file_sync {} {
    if {$::hmm_names::path ne ""} {set ::hmm_ui::namesFile [file nativename $::hmm_names::path]}
}
proc ::hmm_ui::browse_names {} {
    set start [expr {$::hmm_names::path ne "" ? [file dirname $::hmm_names::path] : [file join $::hmm::projectDir library]}]
    set file [tk_getOpenFile -parent $::hmm::window -initialdir $start -title "Part names (Name, Short)" -filetypes {{{CSV files} {.csv}} {{All files} *}}]
    if {$file ne ""} {set ::hmm_ui::namesFile [file nativename $file]}
}
proc ::hmm_ui::names_confirm_discard {} {
    if {!$::hmm_names::dirty} {return 1}
    return [expr {[tk_messageBox -parent $::hmm::window -type yesno -icon warning -title "Part names not saved" -message "The part names have changes that were not saved. Discard them and load another file?"] eq "yes"}]
}
proc ::hmm_ui::import_names {} {
    if {![names_confirm_discard]} {return}
    set start [expr {$::hmm_names::path ne "" ? [file dirname $::hmm_names::path] : [file join $::hmm::projectDir library]}]
    set file [tk_getOpenFile -parent $::hmm::window -initialdir $start -title "Part names (Name, Short)" -filetypes {{{CSV files} {.csv}} {{All files} *}}]
    if {$file eq ""} {return}
    import_names_file $file
}
proc ::hmm_ui::import_names_box {} {
    set file [string trim $::hmm_ui::namesFile]
    if {$file eq "" || ![file isfile $file]} {error "Choose a part names CSV file in the box first"}
    if {![names_confirm_discard]} {return}
    import_names_file $file
}
proc ::hmm_ui::import_names_file {file} {
    set n [::hmm_names::load $file]
    names_file_sync
    if {[winfo exists [page names].table]} {names_table}
    done "Part names: $n names from [file tail $file]"
}
# ---- Part name tab (see ::hmm_names): the band above the table is the common one (controls names); Add and Delete are in the
# right-click menu of the table, a Component is renamed by editing its name in the main table (double click or F2).
# The path of a part of the Part name page.
proc ::hmm_ui::names_widget {name} {
    set f [page names]
    switch -- $name {
        import {return $f.bar.import.main}
        menu {return $f.bar.import.menu}
        file {return $f.bar.file}
        default {return $f.bar.$name}
    }
}
proc ::hmm_ui::names_page {} {
    if {![winfo exists [page names].bar]} {
        if {![info exists ::hmm_ui::query(names)]} {set ::hmm_ui::query(names) ""}
        controls names
    }
}
proc ::hmm_ui::names_table {} {
    names_page
    set f [page names]
    ::hmm_names::load_saved
    names_file_sync
    if {[winfo exists $f.table]} {destroy $f.table}
    upvar #0 ::hmm_names::grid values
    array unset values
    hwtk::datatable $f.table -variable ::hmm_names::grid -closeeditor 1
    pack $f.table -side top -fill both -expand 1
    foreach {key title editable} {name Name 1 short Short 1 used "Used by" 0} {
        set options [list -text $title -type str -width [expr {$key eq "name" ? 220 : 90}] -editable $editable -justify center -itemjustify left]
        if {$editable} {lappend options -valueaccept [list ::hmm_ui::names_accept %W %I %C %V %P]}
        $f.table columncreate $key {*}$options
    }
    set ::hmm_names::gridRows [dict create]
    set query [string tolower [string trim $::hmm_ui::query(names)]]
    set choice [expr {[info exists ::hmm_ui::filterColumn(names)] ? $::hmm_ui::filterColumn(names) : "All columns"}]
    set shorts {}
    dict for {short name} $::hmm_names::entries {
        switch -- $choice {
            Name {set text $name}
            Short {set text $short}
            "Used by" {set text [::hmm_names::used_by $name]}
            default {set text "$name $short [::hmm_names::used_by $name]"}
        }
        if {$query eq "" || [string first $query [string tolower $text]] >= 0} {lappend shorts $short}
    }
    if {[llength $shorts]} {
        foreach row [$f.table rowinsert end entries -count [llength $shorts]] short $shorts {
            set name [dict get $::hmm_names::entries $short]
            dict set ::hmm_names::gridRows $row $short
            set values($row,name) $name;set values($row,short) $short;set values($row,used) [::hmm_names::used_by $name]
        }
        $f.table liveupdate 1
    }
    bind $f.table <ButtonRelease-3> [list ::hmm_ui::context names %W %x %y %X %Y]
    fit_columns $f.table
    names_buttons_update
    if {![dict size $::hmm_names::entries]} {set ::hmm::status "Part name: no list yet, use Import or right-click > Add..."}
}
# Save is possible while there are changes; Save as... when there is a list; the tab title carries a * while the list is not saved.
proc ::hmm_ui::names_buttons_update {} {
    set menu [page names].bar.import.menu
    if {![winfo exists $menu]} {return}
    $menu entryconfigure 0 -state [expr {$::hmm_names::dirty ? "normal" : "disabled"}]
    $menu entryconfigure 1 -state [expr {[dict size $::hmm_names::entries] ? "normal" : "disabled"}]
    set tabs $::hmm::window.sidebar.split.tabs
    catch {$tabs tab $tabs.names -text "Part name[expr {$::hmm_names::dirty ? " *" : ""}]"}
}
proc ::hmm_ui::names_changed {} {names_buttons_update}
# A cell of the Part name table was edited (Name or Short).
proc ::hmm_ui::names_accept {table row column value previous} {
    regsub {^tag:} $row "" row
    regsub {^tag:} $column "" column
    upvar #0 ::hmm_names::grid values
    if {[catch {
        set short [dict get $::hmm_names::gridRows $row]
        if {$column eq "name"} {
            set value [::hmm_names::set_name $short $value]
            set values($row,used) [::hmm_names::used_by $value]
        } elseif {$column eq "short"} {
            set value [::hmm_names::set_short $short $value]
            dict set ::hmm_names::gridRows $row $value
        } else {error "This column cannot be edited"}
        set values($row,$column) $value
        names_changed
        set ::hmm::status "Part name: $column = $value (not saved yet)"
    } message]} {set ::hmm::status "⚠ Error: $message";return 0}
    return 1
}
# A small dialog with one box per field, centered on the tool window. $fields = key label width ...; $check is a command prefix that
# gets the values as a dict and returns "" or the reason it refuses them. Returns the values as a dict, or "" when cancelled.
proc ::hmm_ui::form_dialog {title fields check} {
    set top .hmm_form
    catch {destroy $top}
    array unset ::hmm_ui::form
    set ::hmm_ui::formMessage "";set ::hmm_ui::formResult ""
    foreach {key label width} $fields {set ::hmm_ui::form($key) ""}
    toplevel $top
    wm withdraw $top
    wm title $top $title
    wm transient $top $::hmm::window
    wm resizable $top 0 0
    wm protocol $top WM_DELETE_WINDOW {set ::hmm_ui::formResult cancel}
    ttk::frame $top.f -padding 14
    pack $top.f -fill both -expand 1
    set row 0;set first ""
    foreach {key label width} $fields {
        ttk::label $top.f.l$row -text $label
        ttk::entry $top.f.e$row -textvariable ::hmm_ui::form($key) -width $width
        grid $top.f.l$row -row $row -column 0 -sticky w -padx {0 10} -pady {0 8}
        grid $top.f.e$row -row $row -column 1 -sticky w -pady {0 8}
        if {$first eq ""} {set first $top.f.e$row}
        incr row
    }
    ttk::label $top.f.message -textvariable ::hmm_ui::formMessage -foreground #b00020 -wraplength 300
    ttk::frame $top.f.buttons
    ttk::button $top.f.buttons.ok -text OK -width 9 -command [list ::hmm_ui::form_ok $check]
    ttk::button $top.f.buttons.cancel -text Cancel -width 9 -command {set ::hmm_ui::formResult cancel}
    pack $top.f.buttons.cancel -side right
    pack $top.f.buttons.ok -side right -padx {0 8}
    grid $top.f.message -row $row -column 0 -columnspan 2 -sticky w
    grid $top.f.buttons -row [expr {$row + 1}] -column 0 -columnspan 2 -sticky e -pady {10 0}
    bind $top <Return> [list $top.f.buttons.ok invoke]
    bind $top <Escape> [list $top.f.buttons.cancel invoke]
    update idletasks
    set host $::hmm::window
    set x [expr {[winfo rootx $host] + ([winfo width $host] - [winfo reqwidth $top]) / 2}]
    set y [expr {[winfo rooty $host] + ([winfo height $host] - [winfo reqheight $top]) / 2}]
    wm geometry $top +$x+$y
    wm deiconify $top
    catch {grab $top}
    focus $first
    vwait ::hmm_ui::formResult
    catch {grab release $top}
    set result $::hmm_ui::formResult
    set values [array get ::hmm_ui::form]
    destroy $top
    return [expr {$result eq "ok" ? $values : ""}]
}
proc ::hmm_ui::form_ok {check} {
    set ::hmm_ui::formMessage [uplevel #0 [linsert $check end [array get ::hmm_ui::form]]]
    if {$::hmm_ui::formMessage eq ""} {set ::hmm_ui::formResult ok}
}
# Right-click > Add...: a new Name and Short.
proc ::hmm_ui::names_add_check {values} {return [::hmm_names::check [dict get $values name] [dict get $values short]]}
proc ::hmm_ui::names_add {} {
    set values [form_dialog "Add part name" {name Name 34 short {Short (at most 8)} 12} ::hmm_ui::names_add_check]
    if {$values eq ""} {return}
    ::hmm_names::add [dict get $values name] [dict get $values short]
    names_table;names_changed
    done "Part name added: [string trim [dict get $values name]] ([string trim [dict get $values short]]), not saved yet"
}
proc ::hmm_ui::names_delete {} {
    set f [page names]
    set shorts {}
    foreach row [$f.table selectionget rows] {
        regsub {^tag:} $row "" row
        if {[dict exists $::hmm_names::gridRows $row]} {lappend shorts [dict get $::hmm_names::gridRows $row]}
    }
    set shorts [lsort -unique $shorts]
    if {![llength $shorts]} {error "Select the names to delete first"}
    set used {}
    foreach short $shorts {
        set name [dict get $::hmm_names::entries $short]
        set by [::hmm_names::used_by $name]
        if {$by ne ""} {lappend used "$name ($by)"}
    }
    if {[llength $used] && [tk_messageBox -parent $::hmm::window -type yesno -icon warning -title "Names in use" -message "These names are used by Components (they keep their names):\n[join $used \n]\n\nDelete them from the list anyway?"] ne "yes"} {return}
    ::hmm_names::remove $shorts
    names_table;names_changed
    done "Part name: [llength $shorts] deleted, not saved yet"
}
# A Component is renamed by editing its name in the main table (double click on the cell, or F2 / right-click > Rename Comp on the
# selected Component): a box with the names of the Part name list opens over the cell, Enter renames it (a native step, Ctrl+Z in
# HyperMesh undoes it), Esc leaves it. A Property is not renamed here: its name is changed in the Entity Editor.
proc ::hmm_ui::comp_rename {cid name} {
    set text [::hmm_names::rename_component $cid $name]
    comp_name_refresh $cid
    if {[winfo exists [page names].table]} {catch names_table}
    done $text
}
proc ::hmm_ui::comp_name_box {} {return $::hmm_tree::state($::hmm::window.table.tree,raw).hmmrename}
proc ::hmm_ui::comp_name_cancel {} {catch {destroy [comp_name_box]}}
proc ::hmm_ui::comp_name_commit {cid} {
    set name [string trim $::hmm_ui::compEditValue]
    comp_name_cancel
    run [list ::hmm_ui::comp_rename $cid $name]
}
proc ::hmm_ui::comp_name_focus {} {
    set e [comp_name_box]
    if {![winfo exists $e]} {return}
    set focus [focus]
    if {$focus eq "" || ![string match $e* $focus]} {comp_name_cancel}
}
proc ::hmm_ui::comp_name_edit {{cid ""}} {
    set tree $::hmm::window.table.tree
    if {$cid eq ""} {
        set ids [ids components]
        if {[llength $ids] != 1} {error "Select one Component to rename"}
        set cid [lindex $ids 0]
    }
    comp_name_cancel
    set raw $::hmm_tree::state($tree,raw);set n $::hmm_tree::state($tree,native)
    if {![dict exists $::hmm_tree::state($tree,rows) $cid]} {error "Component $cid is not in the table"}
    set item [dict get $::hmm_tree::state($tree,rows) $cid]
    catch {$raw see $item}
    update idletasks
    if {[catch {$raw item bbox $item [$n column id name]} box] || [llength $box] != 4} {error "The name of Component $cid is not shown"}
    lassign $box x1 y1 x2 y2
    catch {::hmm_names::load_saved}
    set ::hmm_ui::compEditValue [dict get $::hmm::components $cid name]
    set e [comp_name_box]
    ttk::combobox $e -textvariable ::hmm_ui::compEditValue -values [dict values $::hmm_names::entries]
    place $e -x $x1 -y $y1 -width [expr {max(150, $x2 - $x1)}] -height [expr {max(22, $y2 - $y1)}]
    foreach key {<Return> <KP_Enter> <<ComboboxSelected>>} {bind $e $key [list ::hmm_ui::comp_name_commit $cid]}
    bind $e <Escape> ::hmm_ui::comp_name_cancel
    bind $e <FocusOut> {after idle ::hmm_ui::comp_name_focus}
    raise $e
    focus $e
    $e selection range 0 end
    $e icursor end
}
# After a Component rename only what shows the name changes: its cell of the main table (the whole model is not read again).
proc ::hmm_ui::comp_name_refresh {cid} {
    set name [hm_getvalue comps id=$cid dataname=name]
    if {[dict exists $::hmm::components $cid]} {dict set ::hmm::components $cid name $name}
    if {[namespace exists ::hmm_launch] && [info exists ::hmm_launch::baseline]} {set ::hmm_launch::baseline [list $::hmm::components $::hmm::properties $::hmm::materials]}
    catch {::hmm_tree::set_field $::hmm::window.table.tree $cid name $name}
    ::hmm_props::sidebar_schedule
}
proc ::hmm_ui::names_save {} {
    if {$::hmm_names::path eq ""} {names_save_as;return}
    ::hmm_names::save_to $::hmm_names::path
    names_buttons_update
    done "Part names saved: [file tail $::hmm_names::path]"
}
proc ::hmm_ui::names_save_as {} {
    set start [expr {$::hmm_names::path ne "" ? [file dirname $::hmm_names::path] : [file join $::hmm::projectDir library]}]
    set name [expr {$::hmm_names::path ne "" ? [file tail $::hmm_names::path] : "part_names.csv"}]
    set file [tk_getSaveFile -parent $::hmm::window -initialdir $start -initialfile $name -defaultextension .csv -title "Save part names as" -filetypes {{{CSV files} {.csv}}}]
    if {$file eq ""} {return}
    ::hmm_names::save_to $file
    names_file_sync
    names_buttons_update
    done "Part names saved as [file tail $::hmm_names::path]"
}

# ---- Renumber: the selected Components (drag over the rows), in the order the main table shows them, get Start, Start+Step, ...
# Their Property and Material follow with the same number: a Property used by several selected Components takes the number of the
# first one, a Material that of its first Property. A number already held by an entity outside the renumbered ones stops it before
# anything is written. HyperMesh renumbers natively (*renumbersolverid), in one history step (Ctrl+Z undoes it); when the new
# numbers overlap the old ones, the entities first move to free numbers. The captured images follow their Components.
if {![info exists ::hmm_ui::renStart]} {set ::hmm_ui::renStart 1000;set ::hmm_ui::renEnd "";set ::hmm_ui::renStep 1;set ::hmm_ui::renProps 1;set ::hmm_ui::renMats 1}
proc ::hmm_ui::display_order {cids} {
    set tree $::hmm::window.table.tree
    set raw $::hmm_tree::state($tree,raw)
    set byItem [dict create];dict for {cid item} $::hmm_tree::state($tree,rows) {dict set byItem $item $cid}
    set out {}
    foreach item [$raw item children root] {if {[dict exists $byItem $item] && [dict get $byItem $item] in $cids} {lappend out [dict get $byItem $item]}}
    return $out
}
proc ::hmm_ui::renumber_int {label value} {
    set value [string trim $value]
    if {![string is integer -strict $value] || $value <= 0} {error "$label must be a whole number above 0"}
    return $value
}
# {comps {old new ...} props {...} mats {...} last N} for the Components cids (in order); only entities whose number changes are listed.
proc ::hmm_ui::renumber_plan {cids start end step withProps withMats} {
    set start [renumber_int Start $start];set step [renumber_int Step $step]
    set last [expr {$start + $step * ([llength $cids] - 1)}]
    if {[string trim $end] ne ""} {
        set end [renumber_int End $end]
        if {$last > $end} {error "[llength $cids] Components need numbers up to $last, End is $end"}
    }
    set number [dict create comps {} props {} mats {}]
    set n $start
    foreach cid $cids {
        dict set number comps $cid $n
        set pid [dict get $::hmm::components $cid property]
        if {$withProps && $pid > 0 && ![dict exists [dict get $number props] $pid]} {
            dict set number props $pid $n
            set mid [dict get $::hmm::properties $pid material]
            if {$withMats && $mid > 0 && ![dict exists [dict get $number mats] $mid]} {dict set number mats $mid $n}
        }
        incr n $step
    }
    set plan [dict create]
    foreach kind {comps props mats} {
        set map [dict create]
        dict for {old new} [dict get $number $kind] {if {$old != $new} {dict set map $old $new}}
        set moving [dict keys [dict get $number $kind]]
        set taken {}
        foreach id [hm_entitylist $kind id all] {if {$id ni $moving} {lappend taken $id}}
        set clash {}
        dict for {old new} $map {if {$new in $taken} {lappend clash $new}}
        if {[llength $clash]} {
            set what [dict get {comps Component props Property mats Material} $kind]
            error "$what number(s) [join [lrange [lsort -integer $clash] 0 7] {, }][expr {[llength $clash] > 8 ? " ..." : ""}] already used by another $what"
        }
        dict set plan $kind $map
    }
    dict set plan last $last
    return $plan
}
proc ::hmm_ui::renumber_one {kind old new} {
    *createmark $kind 1 $old
    *renumbersolverid $kind 1 $new 1 0 0 0 0 0
    *clearmark $kind 1
    if {[catch {hm_getvalue $kind id=$new dataname=id} got] || $got != $new} {error "HyperMesh did not renumber $kind $old to $new"}
}
proc ::hmm_ui::renumber_execute {plan} {
    if {[::hmm_flow::count]} {error "Apply or discard pending changes first"}
    ::hmm_props::require_idle
    if {$::hmm_images::busy} {error "Wait for the capture to finish"}
    set done {}
    set marks [dict create];foreach kind {comps props mats} {dict set marks $kind [hm_getmark $kind 1]}
    ::hmm::history_begin {Material Manager renumber}
    set code [catch {
        foreach kind {comps props mats} {
            set map [dict get $plan $kind]
            if {![dict size $map]} {continue}
            set olds [dict keys $map];set overlap 0
            dict for {old new} $map {if {$new in $olds} {set overlap 1}}
            if {$overlap} {
                set free [expr {max([lindex [lsort -integer [hm_entitylist $kind id all]] end], [lindex [lsort -integer [dict values $map]] end]) + 1}]
                set parked [dict create]
                dict for {old new} $map {renumber_one $kind $old $free;lappend done [list $kind $old $free];dict set parked $free $new;incr free}
                set map $parked
            }
            dict for {old new} $map {renumber_one $kind $old $new;lappend done [list $kind $old $new]}
        }
        # the links follow the entities
        foreach cid [dict keys $::hmm::components] {
            set to [expr {[dict exists [dict get $plan comps] $cid] ? [dict get $plan comps $cid] : $cid}]
            set pid [dict get $::hmm::components $cid property]
            set want [expr {[dict exists [dict get $plan props] $pid] ? [dict get $plan props $pid] : $pid}]
            if {[hm_getvalue comps id=$to dataname=propertyid] != $want} {error "Component $to lost its Property after renumbering"}
        }
    } message options]
    ::hmm::history_end {Material Manager renumber}
    dict for {kind ids} $marks {catch {*clearmark $kind 1;if {[llength $ids]} {*createmark $kind 1 {*}$ids}}}
    if {$code} {
        set problems {}
        foreach step [lreverse $done] {lassign $step kind from to;if {[catch {renumber_one $kind $to $from} problem]} {lappend problems $problem}}
        catch {::hmm_props::refresh_model;refresh_view components;refresh_sidebar_tables}
        if {[llength $problems]} {error "Renumber failed ($message); putting the numbers back also failed: [lindex $problems 0]. Use Ctrl+Z in HyperMesh"}
        return -options $options "Renumber failed, numbers put back: $message"
    }
    return [llength $done]
}
# Images of renumbered Components: their files and records in the loaded image folder take the new numbers.
proc ::hmm_ui::renumber_images {map} {
    set folder [expr {[info exists ::hmm_images::bundle] ? $::hmm_images::bundle : ""}]
    if {$folder eq "" || ![file isfile [file join $folder images.dict]] || ![dict size $map]} {return ""}
    set f [open [file join $folder images.dict] r];fconfigure $f -encoding utf-8;set data [read $f 4000000];close $f
    set records [dict get $data records];set moved {}
    dict for {old new} $map {if {[dict exists $records $old]} {lappend moved $old $new}}
    if {![llength $moved]} {return $folder}
    set places [list [list $folder png] [list [file join $folder thumbs] gif] [list [file join $folder previews] gif]]
    foreach {old new} $moved {foreach place $places {lassign $place dir ext;set file [file join $dir $old.$ext];if {[file isfile $file]} {file rename -force $file [file join $dir renumber_$old.$ext]}}}
    set next [dict create]
    dict for {cid record} $records {if {![dict exists $map $cid]} {dict set next $cid $record}}
    foreach {old new} $moved {
        foreach place $places {lassign $place dir ext;set file [file join $dir renumber_$old.$ext];if {[file isfile $file]} {file rename -force $file [file join $dir $new.$ext]}}
        dict set next $new [dict get $records $old]
    }
    dict set data records $next
    dict set data model [::hmm_images::fingerprint]
    ::hmm_images::write_data [file join $folder images.dict] $data
    return $folder
}
proc ::hmm_ui::renumber_run {cids} {
    set plan [renumber_plan $cids $::hmm_ui::renStart $::hmm_ui::renEnd $::hmm_ui::renStep $::hmm_ui::renProps $::hmm_ui::renMats]
    renumber_execute $plan
    if {[catch {renumber_images [dict get $plan comps]} folder]} {set imageError $folder;set folder ""}
    ::hmm_props::refresh_model
    if {$folder ne ""} {catch {::hmm_images::load_bundle $folder 1}}
    refresh_view components;refresh_sidebar_tables
    set fresh {};foreach cid $cids {lappend fresh [expr {[dict exists [dict get $plan comps] $cid] ? [dict get $plan comps $cid] : $cid}]}
    catch {$::hmm::window.table.tree selection set $fresh;selected components}
    set text "Renumbered [llength $cids] Components $::hmm_ui::renStart..[dict get $plan last]: [dict size [dict get $plan comps]] Components, [dict size [dict get $plan props]] Properties, [dict size [dict get $plan mats]] Materials changed"
    if {[info exists imageError]} {warn "$text; images not moved: $imageError"} else {done $text}
}
proc ::hmm_ui::renumber_preview {args} {
    set d $::hmm::window.renumber
    if {![winfo exists $d]} {return}
    if {[catch {renumber_plan $::hmm_ui::renCids $::hmm_ui::renStart $::hmm_ui::renEnd $::hmm_ui::renStep $::hmm_ui::renProps $::hmm_ui::renMats} plan]} {
        set ::hmm_ui::renText $plan;$d.f.text configure -foreground #c00000;$d.f.buttons.ok state disabled;return
    }
    set ::hmm_ui::renText "[llength $::hmm_ui::renCids] Components: $::hmm_ui::renStart ... [dict get $plan last]\n[dict size [dict get $plan props]] Properties and [dict size [dict get $plan mats]] Materials change number"
    $d.f.text configure -foreground "";$d.f.buttons.ok state !disabled
}
proc ::hmm_ui::renumber_dialog {} {
    set cids [display_order [ids components]]
    if {![llength $cids]} {error "Select the Components first (drag over the rows)"}
    set ::hmm_ui::renCids $cids
    set d $::hmm::window.renumber
    destroy $d
    toplevel $d;wm withdraw $d
    wm title $d Renumber;wm transient $d $::hmm::window;wm resizable $d 0 0
    ttk::frame $d.f -padding 12;pack $d.f -fill both -expand 1
    set row 0
    foreach {label var} {Start renStart End renEnd Step renStep} {
        ttk::label $d.f.l$var -text $label
        ttk::entry $d.f.e$var -textvariable ::hmm_ui::$var -width 10 -justify right
        grid $d.f.l$var -row $row -column 0 -sticky w -padx {0 8} -pady 2
        grid $d.f.e$var -row $row -column 1 -sticky w -pady 2
        incr row
    }
    ttk::label $d.f.hint -text "(may stay empty)" -foreground #777777
    grid $d.f.hint -row 1 -column 2 -sticky w -padx {8 0}
    ttk::checkbutton $d.f.props -text "Property follows" -variable ::hmm_ui::renProps
    ttk::checkbutton $d.f.mats -text "Material follows" -variable ::hmm_ui::renMats
    grid $d.f.props -row $row -column 0 -columnspan 3 -sticky w -pady {8 0};incr row
    grid $d.f.mats -row $row -column 0 -columnspan 3 -sticky w;incr row
    ttk::label $d.f.text -textvariable ::hmm_ui::renText -justify left -wraplength 300
    grid $d.f.text -row $row -column 0 -columnspan 3 -sticky w -pady {10 0};incr row
    ttk::frame $d.f.buttons
    ttk::button $d.f.buttons.ok -text Renumber -width 10 -command {::hmm_ui::renumber_ok}
    ttk::button $d.f.buttons.cancel -text Cancel -width 10 -command [list destroy $d]
    pack $d.f.buttons.cancel $d.f.buttons.ok -side right -padx {6 0}
    grid $d.f.buttons -row $row -column 0 -columnspan 3 -sticky e -pady {12 0}
    foreach var {renStart renEnd renStep renProps renMats} {trace add variable ::hmm_ui::$var write ::hmm_ui::renumber_preview}
    bind $d <Destroy> [list ::hmm_ui::renumber_untrace $d %W]
    bind $d <Return> {::hmm_ui::renumber_ok}
    bind $d <Escape> [list destroy $d]
    renumber_preview
    # centred on the Material Manager window: wm geometry places the outer frame, so the title bar and border measured once the
    # dialog is shown are taken off
    update idletasks
    set w $::hmm::window
    set x [expr {[winfo rootx $w] + ([winfo width $w] - [winfo reqwidth $d]) / 2}]
    set y [expr {[winfo rooty $w] + ([winfo height $w] - [winfo reqheight $d]) / 2}]
    wm geometry $d +[expr {max($x, 0)}]+[expr {max($y, 0)}]
    wm deiconify $d
    update idletasks
    set left [expr {[winfo rootx $d] - [winfo x $d]}];set top [expr {[winfo rooty $d] - [winfo y $d]}]
    if {$left > 0 || $top > 0} {wm geometry $d +[expr {max($x - $left, 0)}]+[expr {max($y - $top, 0)}]}
    focus $d.f.erenStart;$d.f.erenStart selection range 0 end
}
proc ::hmm_ui::renumber_untrace {d w} {
    if {$w ne $d} {return}
    foreach var {renStart renEnd renStep renProps renMats} {catch {trace remove variable ::hmm_ui::$var write ::hmm_ui::renumber_preview}}
}
proc ::hmm_ui::renumber_ok {} {
    set d $::hmm::window.renumber
    if {[winfo exists $d] && [$d.f.buttons.ok instate disabled]} {return}
    set cids $::hmm_ui::renCids
    destroy $d
    run [list ::hmm_ui::renumber_run $cids]
}

# ---- Isolate only: a mode of the Properties and Materials tabs (button, right-click entry, Ctrl+Shift+H). While it is on, the rows
# selected in the tab are isolated in the graphics: only the Components that use those Properties / Materials stay displayed
# (*isolateonlyentitybymark, as HyperMesh's own Isolate Only). Turning it off leaves the display as it is. With "Focus" ticked the
# view is fitted to what is isolated (hm_viewfit, the F key). Each isolation is one HyperMesh history step named "Isolate only", so Ctrl+Z in
# HyperMesh goes back to the display before it. The Components of a selection are read from the model data of the tool (Reload
# after changes made outside it).
namespace eval ::hmm_ui {
    if {![info exists isolateOn]} {set isolateOn 0}
    if {![info exists isolateMenu]} {set isolateMenu 0}
    if {![info exists isolateFocus]} {set isolateFocus 0}
    if {![info exists isolatePending]} {set isolatePending ""}
}
proc ::hmm_ui::isolate_components {type ids} {
    set props {}
    if {$type eq "properties"} {set props $ids} else {
        dict for {pid data} $::hmm::properties {if {$pid > 0 && [dict get $data material] in $ids} {lappend props $pid}}
    }
    set cids {}
    foreach pid $props {set cids [concat $cids [::hmm::property_users $pid]]}
    return [lsort -unique -integer $cids]
}
# hm_getmass lets Tk events run inside it: a display command is put off until the mass read has returned.
proc ::hmm_ui::isolate_busy {command} {
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {
        after cancel $::hmm_ui::isolatePending
        set ::hmm_ui::isolatePending [after 150 [list ::hmm_ui::run $command]]
        return 1
    }
    return 0
}
proc ::hmm_ui::isolate_set {on} {
    if {$on && !$::hmm_ui::isolateOn} {
        if {$::hmm_images::busy} {error "Isolate only is not available while images are captured"}
        set ::hmm_ui::isolateOn 1
        isolate_buttons
        isolate_update
    } elseif {!$on && $::hmm_ui::isolateOn} {
        set ::hmm_ui::isolateOn 0
        isolate_buttons
        set ::hmm::status "Isolate only off"
    }
    set ::hmm_ui::isolateMenu $::hmm_ui::isolateOn
}
proc ::hmm_ui::isolate_toggle {} {isolate_set [expr {!$::hmm_ui::isolateOn}]}
# Isolates the Components of the rows selected in the active Properties / Materials tab (nothing selected: the display stays).
proc ::hmm_ui::isolate_update {} {
    if {!$::hmm_ui::isolateOn || $::hmm_ui::active ni {properties materials}} {return}
    if {[isolate_busy ::hmm_ui::isolate_update]} {return}
    set type $::hmm_ui::active
    set ids [expr {[info exists ::hmm_ui::selection($type)] ? $::hmm_ui::selection($type) : {}}]
    if {![llength $ids]} {set ::hmm::status "Isolate only: select rows";return}
    set cids [isolate_components $type $ids]
    set what [expr {$type eq "properties" ? "Property" : "Material"}]
    if {![llength $cids]} {warn "Isolate only: no Component uses the selected $what";return}
    ::hmm::history_begin "Isolate only"
    set failed [catch {
        hm_markclearall 2
        *createmark comps 2 {*}$cids
        *isolateonlyentitybymark 2
        *clearmark comps 2
        # (hm_viewfit is what HyperMesh's F key does with nothing selected: it fits what is displayed; *window 0 fits the model)
        if {$::hmm_ui::isolateFocus} {hm_viewfit}
    } message]
    ::hmm::history_end "Isolate only"
    if {$failed} {set ::hmm::status "⚠ Error: Isolate only: $message";return}
    set ::hmm::status "Isolated [llength $cids] Component[expr {[llength $cids] == 1 ? "" : "s"}]"
}
# Isolate only and Focus: on = blue, off = the plain button face, disabled while images are captured.
proc ::hmm_ui::focus_toggle {} {
    set ::hmm_ui::isolateFocus [expr {!$::hmm_ui::isolateFocus}]
    isolate_buttons
    isolate_update
}
proc ::hmm_ui::isolate_buttons {} {
    if {![info exists ::hmm::window]} {return}
    set face [ttk::style lookup TButton -background]
    if {$face eq ""} {set face SystemButtonFace}
    set busy [expr {[info exists ::hmm_images::busy] && $::hmm_images::busy}]
    foreach type {properties materials} {
        set iso [page $type].iso
        if {![winfo exists $iso.isolate]} {continue}
        foreach {name on} [list isolate $::hmm_ui::isolateOn focus $::hmm_ui::isolateFocus] {
            if {$busy} {
                $iso.$name configure -state disabled -background $face -activebackground $face
            } elseif {$on} {
                $iso.$name configure -state normal -background #7fb8ef -activebackground #9ccaf3
            } else {
                $iso.$name configure -state normal -background $face -activebackground $face
            }
        }
    }
}
# Ctrl+Shift+H anywhere in the tool window (the toplevel is in every widget's binding tags).
proc ::hmm_ui::isolate_shortcut {} {
    foreach key {<Control-Shift-KeyPress-H> <Control-Shift-KeyPress-h>} {
        bind $::hmm::window $key {::hmm_ui::run ::hmm_ui::isolate_toggle;break}
    }
}

# ---- Native icons: HyperMesh's own 16 px images (hw/images), loaded the way its own scripts do (hwtk::image cache) --------------
# A "...Strip" image holds the states of a toolbar button side by side: hwtk::image cache returns them as a list of state/image
# pairs (normal, active, disabled, pressed...), from which the state asked for is taken.
proc ::hmm_ui::icon {name {state normal}} {
    set key ::hmm_ui::icon_${name}_$state
    if {$key in [image names]} {return $key}
    set opts [expr {$state eq "disabled" && ![string match *Strip $name] ? {-state disabled} : {}}]
    if {[catch {hwtk::image cache $name-16.png {*}$opts} src] || $src eq ""} {return ""}
    if {[llength $src] > 1} {
        if {[llength $src] % 2 || ![dict exists $src $state]} {return ""}
        set src [dict get $src $state]
    }
    if {[catch {
        image create photo $key -width 16 -height 16
        $key copy $src -from 0 0 16 16
    }]} {catch {image delete $key};return ""}
    return $key
}
# A 24 px native icon made 16 px (some commands have no 16 px image): every pixel of the new image is the average of the pixels of the
# old one it covers (weighted by the covered area; transparent ones do not count), and is transparent when less than half is covered.
proc ::hmm_ui::icon_sized {name from} {
    set key ::hmm_ui::icon_${name}_${from}_16
    if {$key in [image names]} {return $key}
    if {[catch {hwtk::image cache $name-$from.png} src] || $src eq "" || [llength $src] > 1} {return ""}
    set scale [expr {double($from) / 16}]
    if {[catch {
        image create photo $key -width 16 -height 16
        for {set y 0} {$y < 16} {incr y} {
            set y0 [expr {$y * $scale}];set y1 [expr {($y + 1) * $scale}]
            for {set x 0} {$x < 16} {incr x} {
                set x0 [expr {$x * $scale}];set x1 [expr {($x + 1) * $scale}]
                set r 0.0;set g 0.0;set b 0.0;set solid 0.0;set total 0.0
                for {set sy [expr {int($y0)}]} {$sy < $y1 && $sy < $from} {incr sy} {
                    set wy [expr {min($y1, $sy + 1) - max($y0, $sy)}]
                    for {set sx [expr {int($x0)}]} {$sx < $x1 && $sx < $from} {incr sx} {
                        set w [expr {$wy * (min($x1, $sx + 1) - max($x0, $sx))}]
                        set total [expr {$total + $w}]
                        if {[$src transparency get $sx $sy]} {continue}
                        lassign [$src get $sx $sy] pr pg pb
                        set r [expr {$r + $pr * $w}];set g [expr {$g + $pg * $w}];set b [expr {$b + $pb * $w}];set solid [expr {$solid + $w}]
                    }
                }
                if {$solid * 2 >= $total && $solid > 0} {
                    $key put [format "#%02x%02x%02x" [expr {int($r / $solid + 0.5)}] [expr {int($g / $solid + 0.5)}] [expr {int($b / $solid + 0.5)}]] -to $x $y
                }
            }
        }
    }]} {catch {image delete $key};return ""}
    return $key
}
# A ttk image option: the normal icon, and its greyed form while the widget is disabled.
proc ::hmm_ui::icon_spec {name} {
    set normal [icon $name]
    if {$normal eq ""} {return ""}
    set grey [icon $name disabled]
    return [expr {$grey eq "" ? $normal : [list $normal disabled $grey]}]
}
# A ttk button with an icon, exactly $target px wide: the text width (in characters) is taken down until the button fits, and the
# pixels still missing are a transparent margin on the right of the icon.
proc ::hmm_ui::icon_fit {b name chars target} {
    $b configure -width $chars -image [icon_spec $name] -compound left
    while {[winfo reqwidth $b] > $target && $chars > 1} {$b configure -width [incr chars -1]}
    set gap [expr {$target - [winfo reqwidth $b]}]
    if {$gap <= 0} {return}
    set spec {}
    foreach {state} {normal disabled} {
        set src [icon $name $state]
        if {$src eq ""} {continue}
        set key ::hmm_ui::icon_${name}_${state}_pad$gap
        if {$key ni [image names]} {image create photo $key -width [expr {16 + $gap}] -height 16;$key copy $src -to 0 0}
        lappend spec $key
    }
    if {[llength $spec] == 2} {set spec [list [lindex $spec 0] disabled [lindex $spec 1]]}
    $b configure -image $spec
}
# Width of a Delete unused button with its icon (measured once on a hidden copy).
proc ::hmm_ui::unused_width {parent} {
    if {[info exists ::hmm_ui::unusedW]} {return $::hmm_ui::unusedW}
    ttk::button $parent.unusedRef -text "Delete unused (-)" -width 18
    set spec [icon_spec glyphDeleteStrip]
    if {$spec ne ""} {$parent.unusedRef configure -image $spec -compound left}
    set ::hmm_ui::unusedW [winfo reqwidth $parent.unusedRef]
    destroy $parent.unusedRef
    return $::hmm_ui::unusedW
}
proc ::hmm_ui::menu_icon {label} {
    set map {"Select shared Prop" entityComponents Capture browserPublishImage "Renumber..." listSimple
        "Duplicate for Comps" glyphCopy "Import part names..." fileImportCSV "Show users" entityComponents
        "Create Mat(s)" add "Apply params to Mats" check}
    if {![dict exists $map $label]} {return ""}
    return [icon [dict get $map $label]]
}
# Puts the icons on what exists now; run again whenever a band or the window is rebuilt.
proc ::hmm_ui::apply_icons {} {
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window]} {return}
    set w $::hmm::window
    set tabs $w.sidebar.split.tabs
    foreach {type name} {properties entityProperties materials entityMaterials library listDetailed names listDetailed} {
        if {[winfo exists $tabs.$type] && [set img [icon $name]] ne ""} {catch {$tabs tab $tabs.$type -image $img -compound left}}
    }
    # ttk widgets: path and icon
    set ttk {}
    foreach type {properties materials library names} {
        set f [page $type]
        lappend ttk $f.bar.filterLabel filter $f.bar.unused glyphDeleteStrip
    }
    set f [page components]
    lappend ttk $f.bar.filterLabel filter $f.bar.import fileImportCSV $f.cap.capture browserPublishImage $f.cap.all browserPublishImage \
        $f.cap.stop toolbarAnimationPlaybackPauseStrip $f.cap.cont toolbarAnimationPlaybackPlayCircleStrip $f.cap.cancel toolbarActionCancelStrip \
        $w.bottom.reset refresh
    foreach {path name} $ttk {
        if {[winfo exists $path] && [set spec [icon_spec $name]] ne ""} {catch {$path configure -image $spec -compound left}}
    }
    # Reload keeps the width of Close (and of Discard / Apply beside it) with its icon.
    if {[winfo exists $w.bottom.reset] && [winfo exists $w.bottom.close]} {catch {icon_fit $w.bottom.reset refresh 15 [winfo reqwidth $w.bottom.close]}}
    # Tk buttons in a grey frame: they hold their size in pixels, so the icon does not change it.
    set tk [list $f.massgrp.recalc refresh $w.actions.discard arrowReset $w.actions.apply check]
    foreach {path name} $tk {
        if {[winfo exists $path] && [set img [icon $name]] ne ""} {catch {$path configure -image $img -compound left}}
    }
    # Isolate and Focus: icon (24 px native images made 16 px) and text
    foreach type {properties materials} {
        set iso [page $type].iso
        if {![winfo exists $iso.isolate]} {continue}
        foreach {name icon} {isolate displayIsolate focus viewFit} {
            if {[set img [icon_sized $icon 24]] ne ""} {catch {$iso.$name configure -image $img -compound left}}
        }
    }
    catch mass_button_state
}

# ---- Redraw probe (diagnosis only): runs once after the masses are read when settings/redraw_probe.on exists. It resizes the window
# in 8 steps with the contents held (as while the border is dragged) and times each step, with all regions shown, with the main
# table folded, with the Entity region folded and with both folded; the difference tells which region is slow to paint. The window
# size and the folds are put back. Result: LAST_REDRAW_PROBE.txt in the tool folder.
proc ::hmm_ui::rp_wait {ms} {set end [expr {[clock milliseconds] + $ms}];while {[clock milliseconds] < $end} {update;after 20}}
proc ::hmm_ui::rp_note {text} {
    catch {set f [open [file join $::hmm::projectDir LAST_REDRAW_PROBE.progress] a];puts $f "[clock milliseconds] $text";close $f}
}
proc ::hmm_ui::rp_fold {split want} {
    if {![winfo exists $split.__sashbutton0__]} {return}
    rp_note "fold $split want $want collapsed [collapsed $split]"
    if {[collapsed $split] != $want} {$split.__sashbutton0__ invoke;rp_note invoked;rp_wait 400;rp_note waited}
}
proc ::hmm_ui::rp_write {lines} {
    catch {set f [open [file join $::hmm::projectDir LAST_REDRAW_PROBE.txt] w];fconfigure $f -encoding utf-8;foreach l $lines {puts $f $l};close $f}
}
# (errors go into the result file: a failure must not vanish in a catch)
proc ::hmm_ui::redraw_probe_run {} {
    rp_write [list "started [clock format [clock seconds] -format %H:%M:%S]"]
    if {[catch ::hmm_ui::redraw_probe message]} {
        unset -nocomplain ::hmm_ui::mouseHeldOverride
        rp_write [list "error\t$message" "info\t$::errorInfo"]
    }
}
proc ::hmm_ui::redraw_probe {} {
    set w $::hmm::window;set main $w.content;set side $w.sidebar.split
    set g0 [wm geometry $w]
    if {![regexp {^(\d+)x(\d+)([+-]-?\d+)([+-]-?\d+)$} $g0 -> W H X Y]} {error "geometry $g0"}
    set out [list geometry $g0 components [dict size $::hmm::components]]
    foreach {name foldMain foldSide} {all 0 0 main_folded 1 0 entity_folded 0 1 both_folded 1 1 all_again 0 0} {
        rp_note "config $name"
        rp_fold $main $foldMain;rp_fold $side $foldSide
        rp_wait 600
        set ::hmm_ui::mouseHeldOverride 1
        set steps {}
        for {set i 1} {$i <= 8} {incr i} {
            set t [clock microseconds]
            rp_note "step $i"
            wm geometry $w [expr {$W + $i * 15}]x[expr {$H + ($i % 2) * 10}]$X$Y
            update
            lappend steps [expr {([clock microseconds] - $t) / 1000}]
        }
        set sum 0;foreach s $steps {incr sum $s}
        # release: one layout at the original size
        set ::hmm_ui::mouseHeldOverride 0
        wm geometry $w $g0
        set t [clock microseconds];rp_wait 900
        lappend out $name [list steps_ms $steps avg_ms [expr {$sum / [llength $steps]}] frozen_during [expr {$::hmm_ui::frozen}] release_wait_ms [expr {([clock microseconds] - $t) / 1000}]]
    }
    rp_fold $main 0;rp_fold $side 0
    unset -nocomplain ::hmm_ui::mouseHeldOverride
    wm geometry $w $g0
    set lines {};foreach {k v} $out {lappend lines "$k\t$v"}
    rp_write $lines
    set ::hmm::status "Redraw probe written"
}

