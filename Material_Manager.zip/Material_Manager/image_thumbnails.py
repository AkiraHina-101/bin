"""Create display-only GIF copies; preserve original HyperMesh PNG captures."""
import argparse
from pathlib import Path
import re
from PIL import Image


def build(bundle):
    bundle = bundle.resolve()
    paths = sorted(p for p in bundle.glob('*.png') if re.fullmatch(r'[1-9][0-9]*', p.stem))
    if not paths or len(paths) > 10000:
        raise ValueError('Expected 1..10000 numeric component PNGs')
    for sub in ('thumbs', 'previews'):
        (bundle / sub).mkdir(exist_ok=True)
    resample = getattr(Image, 'Resampling', Image).LANCZOS
    for path in paths:
        path.resolve().relative_to(bundle)
        with Image.open(path) as image:
            image.load()
            if image.width > 4096 or image.height > 4096:
                raise ValueError('Image exceeds capture limit')
            for sub, size in (('thumbs', (96, 72)), ('previews', (640, 480))):
                copy = image.convert('RGB')
                copy.thumbnail(size, resample)
                canvas = Image.new('RGB', size, 'white')
                canvas.paste(copy, ((size[0]-copy.width)//2, (size[1]-copy.height)//2))
                target = bundle / sub / (path.stem + '.gif')
                target.resolve().relative_to(bundle)
                canvas.save(target, 'GIF')
    return len(paths)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bundle', type=Path)
    args = parser.parse_args()
    print(build(args.bundle))
