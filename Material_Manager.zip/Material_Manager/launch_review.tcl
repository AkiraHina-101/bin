# Tcl 8.5. Launch evidence only; no model writes and no alternate GUI entry.
namespace eval ::hmm_launch {}

# Error reporting itself must never escape into Tk's modal background-error handler.
proc ::hmm_launch::report_error {launcher message details} {
    catch {set ::hmm::status "Launch failed: $message"}
    catch {puts stderr "Material Manager launch failed: $message"}
    set f ""
    catch {
        set f [::open [file join [file dirname $launcher] LAST_LAUNCH_ERROR.txt] w]
        fconfigure $f -encoding utf-8 -translation lf
        puts $f "[clock seconds]\t$message"
        puts $f $details
    }
    if {$f ne ""} {catch {close $f}}
    return
}

# Build widgets after the native MAC callback has returned to the host event loop.
# mode: verified (the workspace launcher: preflight receipt required, evidence in 02_HM_MCP) or portable (a copy made by
# export_material_manager_portable.py: one folder, no preflight, evidence beside the tool, errors shown in a message box).
proc ::hmm_launch::request {launcher {mode verified}} {
    variable scheduled
    variable mode_requested
    if {$mode ni {verified portable}} {error "Unknown launch mode $mode"}
    if {[info exists scheduled] && $scheduled ne "" && ![catch {after info $scheduled}]} {return}
    set mode_requested $mode
    if {[catch {guard} message options]} {
        report_error $launcher $message [dict get $options -errorinfo]
        if {$mode eq "portable"} {show_error $message [dict get $options -errorinfo] $launcher}
        if {[info exists ::hmm::status]} {set ::hmm::status $message}
        catch {puts stderr "Material Manager reload stopped: $message"}
        return
    }
    set scheduled [after idle [list ::hmm_launch::dispatch $launcher]]
}

proc ::hmm_launch::dispatch {launcher} {
    variable scheduled
    variable mode_requested
    set scheduled ""
    if {[catch {run $launcher} message options]} {
        report_error $launcher $message [dict get $options -errorinfo]
        if {[info exists mode_requested] && $mode_requested eq "portable"} {show_error $message [dict get $options -errorinfo] $launcher}
    }
}

# A portable copy has no one watching the log files: say it on screen too.
# The message box says what failed and where (the first lines of the Tcl stack, and the file that keeps all of it).
proc ::hmm_launch::show_error {message {details ""} {launcher ""}} {
    set text "Material Manager could not open:\n$message"
    set lines [lrange [split $details "\n"] 1 6]
    if {[llength $lines]} {append text "\n\nWhere:\n[join $lines "\n"]"}
    if {$launcher ne ""} {append text "\n\nFull details: [file join [file dirname $launcher] LAST_LAUNCH_ERROR.txt]"}
    catch {tk_messageBox -icon error -title "Material Manager" -message $text}
}

proc ::hmm_launch::read_bytes {path} {
    set f [::open $path rb]
    set data [read $f]
    close $f
    return $data
}

proc ::hmm_launch::verify_preflight {project workspace names} {
    set folder [string trim [read_bytes [file join $project LAST_PREFLIGHT.txt]]]
    set folder [file normalize $folder]
    set base [file normalize [file join $workspace 04_AGENT_SUPPORT reports material_manager_preflight]]
    if {![string equal -nocase [string range $folder 0 [string length $base]] "$base/"]} {
        error "Run Material Manager preflight before opening"
    }
    if {[string trim [read_bytes [file join $folder preflight.tsv]]] ne "status\tOFFLINE_PASS_REQUIRES_NATIVE_TEST"} {
        error "Material Manager preflight did not pass"
    }
    foreach name $names {
        if {[read_bytes [file join $project $name]] ne [read_bytes [file join $folder $name]]} {
            error "Source changed since preflight: $name. Run preflight again."
        }
    }
    return $folder
}

proc ::hmm_launch::guard {} {
    variable baseline
    if {[info exists ::hmm_props::editing] && $::hmm_props::editing} {error "Finish native property Settings first"}
    if {[info exists ::hmm_images::busy] && $::hmm_images::busy} {error "Wait for image capture to finish"}
    if {[winfo exists .hmm_material_manager.table.tree.editor]} {error "Finish the active cell edit before reopening."}
}

proc ::hmm_launch::pending_state {} {
    variable baseline
    if {[llength [info commands ::hmm_flow::count]] && [::hmm_flow::count]} {return 1}
    if {![info exists baseline]} {return 0}
    return [expr {[list $::hmm::components $::hmm::properties $::hmm::materials] ne $baseline}]
}

proc ::hmm_launch::run {launcher} {
    variable baseline
    variable mode_requested
    set mode [expr {[info exists mode_requested] ? $mode_requested : "verified"}]
    guard
    set preserve [pending_state]
    set savedUI [dict create]
    foreach name {filterText sortColumn sortReverse} {
        if {[info exists ::hmm::$name]} {dict set savedUI $name [set ::hmm::$name]}
    }
    set savedSelection {}
    if {[winfo exists .hmm_material_manager.table.tree]} {set savedSelection [.hmm_material_manager.table.tree selection]}
    if {$preserve} {
        set savedData [list $::hmm::components $::hmm::properties $::hmm::materials]
        # A window left behind by an earlier failed launch has no baseline: the model is read again below.
        set savedBaseline [expr {[info exists baseline] ? $baseline : ""}]
        set savedStatus $::hmm::status
    }
    # The build is only recorded, never checked: the tool must open on any HyperMesh that runs it.
    set build unknown
    catch {set build [string trim [hm_info -appinfo DISPLAYVERSION]]}
    set project [file dirname $launcher]
    set names {launch_material_manager.tcl launch_review.tcl material_manager.tcl component_images.tcl image_thumbnails.py assignments.tcl property_tools.tcl material_library.tcl workflow.tcl component_table.tcl workspace.tcl}
    set workspace [file dirname [file dirname $project]]
    if {$mode eq "portable"} {
        # The portable launcher replaces launch_material_manager.tcl; nothing outside the folder is read or written.
        set names [lreplace $names 0 0 [file tail $launcher]]
        namespace eval ::hmm {variable portable 1}
    } else {
        verify_preflight $project $workspace $names
        namespace eval ::hmm {variable portable 0}
    }
    set sources {}
    foreach name $names {dict set sources $name [read_bytes [file join $project $name]]}
    if {$mode eq "portable"} {
        set folder [file join $project evidence material_manager_launch "[pid]_[clock seconds]_[clock clicks]"]
        file mkdir $folder
    } else {
        set folder [file join $workspace 02_HM_MCP evidence material_manager_verified "[pid]_[clock seconds]_[clock clicks]"]
        file mkdir $folder
        foreach name $names {
            set f [::open [file join $folder $name] {WRONLY CREAT EXCL}]
            fconfigure $f -translation binary
            puts -nonewline $f [dict get $sources $name]
            close $f
        }
    }
    source -encoding utf-8 [file join $project material_manager.tcl]
    if {$preserve} {
        # The model may have changed while the manager was closed or busy, and queued changes may have gone
        # stale in an earlier session. Read the model again and keep only the queued changes still valid, so
        # the preserved window opens on current data.
        if {![catch {::hmm::read_model} current]} {
            set savedData $current;set savedBaseline $current
            catch ::hmm_flow::upgrade_queues
            if {![catch ::hmm_props::queue_revalidate dropped] && [llength $dropped]} {
                set savedStatus "Dropped [llength $dropped] pending change(s) whose model value changed."
            }
        }
        foreach name {components properties materials} value $savedData {set ::hmm::$name $value}
        set ::hmm_apply::baseline $savedBaseline
        if {![info exists ::hmm_apply::baselineModel]} {set ::hmm_apply::baselineModel [hm_info currentfile]}
        ::hmm::open
        set ::hmm::status "Reloaded, pending changes kept"
        set imageError ""
        if {[catch {::hmm_images::load_saved} imageError]} {set ::hmm::status "Pending changes preserved. Images: $imageError"}
        set f [::open [file join $folder image_load.dict] w]
        puts $f [list count [dict size $::hmm_images::handles] result $imageError]
        close $f
    } else {
        ::hmm::open_live
    }
    dict for {name value} $savedUI {set ::hmm::$name $value}
    ::hmm::sync_rows
    foreach cid $savedSelection {
        if {[$::hmm::window.table.tree exists $cid]} {$::hmm::window.table.tree selection add $cid}
    }
    foreach name $names {
        if {[read_bytes [file join $project $name]] ne [dict get $sources $name]} {error "Source changed during launch; review rejected."}
    }
    if {![winfo exists .hmm_material_manager] || ![winfo ismapped .hmm_material_manager]} {error "Manager window is not visible"}
    if {$preserve} {set baseline $savedBaseline} else {set baseline [list $::hmm::components $::hmm::properties $::hmm::materials]}
    set f [::open [file join $folder launch.tsv] {WRONLY CREAT EXCL}]
    fconfigure $f -encoding utf-8 -translation lf
    foreach {key value} [list pid [pid] build $build epoch [clock seconds] launcher $launcher status launched window .hmm_material_manager pending_preserved $preserve] {
        puts $f "$key\t$value"
    }
    close $f
    set pointer [file join $project LAST_VERIFIED_LAUNCH.txt]
    set f [::open "$pointer.tmp" w]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f $folder
    close $f
    file rename -force "$pointer.tmp" $pointer
    return $folder
}
