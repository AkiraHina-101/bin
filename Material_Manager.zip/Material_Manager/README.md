# Material Manager — bản portable

Thư mục này chạy độc lập trên một máy có HyperMesh 2022.3. Không cần workspace, menu tổng hay preflight.

## Cài

1. Chép cả thư mục này tới vị trí bất kỳ, ví dụ `D:/Tools/Material_Manager`.
2. Gắn `launch_material_manager.tcl` vào một nút trong file MAC của bạn:

   ```
   *createbutton(1, "Material Manager", 0, 0, 10, BUTTON, "Open Material Manager", "Run_Material_Manager", "D:/Tools/Material_Manager/launch_material_manager.tcl")
   *beginmacro("Run_Material_Manager")
   *evaltclscript($1,0)
   *endmacro()
   ```

   Thay số trang `1` và đường dẫn cho đúng máy đó. Có thể chạy thẳng bằng File > Run > Tcl/Tk Script.
3. Tool tự tìm Python đi kèm bản Altair đang chạy. Nếu không tìm thấy, thêm đường dẫn tới `python.exe` có cài Pillow vào `settings/python_path.txt`. Python chỉ dùng để tạo ảnh thu nhỏ sau khi chụp. Nếu không tìm thấy Python, Capture vẫn lưu ảnh PNG nhưng không tạo ảnh thu nhỏ.

## Tool ghi gì, ở đâu

Tất cả nằm trong thư mục này:

| Nơi | Nội dung |
|---|---|
| `images/` | Ảnh Component chụp được. Chọn thư mục ở ô Images rồi bấm Load. |
| `evidence/` | Bằng chứng mỗi lần đọc model, Apply và mở tool. Xóa được khi không cần. |
| `settings/` | Cột đang hiện của các bảng, đường dẫn Python. |
| `library/` | Thư viện vật liệu CSV. Save/Save as của tab Library ghi vào file đang mở. |
| `LAST_*.txt` | Con trỏ tới lần đọc/chụp/mở gần nhất. |

Khi mở lỗi, tool hiện hộp thông báo và ghi chi tiết vào `LAST_LAUNCH_ERROR.txt`.

## Cập nhật

Bản này được xuất từ workspace bằng `04_AGENT_SUPPORT/tools/export_material_manager_portable.py`. Khi cập nhật, chép đè các file mã lên thư mục cũ. `settings/`, `images/`, `evidence/` và thư viện bạn đã sửa vẫn được giữ.
