# Native HWI capture with saved-view restoration. Image manifests are data, never sourced.
namespace eval ::hmm_images {
    variable busy
    variable cancelled
    variable paused
    variable halted
    variable handles
    variable paths
    variable bundle
    variable job
    if {![info exists busy]} {set busy 0}
    if {![info exists cancelled]} {set cancelled 0}
    if {![info exists paused]} {set paused 0}
    if {![info exists halted]} {set halted 0}
    if {![info exists handles]} {set handles [dict create]}
    if {![info exists paths]} {set paths [dict create]}
    if {![info exists bundle]} {set bundle ""}
    if {![info exists job]} {set job [dict create]}
}

proc ::hmm_images::fingerprint {} {
    set names {}
    foreach cid [lsort -integer [hm_entitylist comps id all]] {lappend names $cid [hm_getvalue comps id=$cid dataname=name]}
    # hm_count gives the same numbers as the id lists in about 2 ms; listing every node and element id of a model with 3 million
    # elements took about 2 s (measured 08/11/2026, probe counttime).
    return [list model [hm_info currentfile] components $names nodes [hm_count nodes all 0 0] elements [hm_count elems all 0 0]]
}

proc ::hmm_images::write_data {path value} {
    set f [::open "$path.tmp" w]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f $value
    close $f
    file rename -force "$path.tmp" $path
}

proc ::hmm_images::displayed {} {
    set old [hm_getmark comps 1]
    *createmark comps 1 displayed
    set result [lsort -integer [hm_getmark comps 1]]
    *clearmark comps 1
    if {[llength $old]} {*createmark comps 1 {*}$old}
    return $result
}

# Native 2022.3 returns a braced matrix string with comma-separated rows.
proc ::hmm_images::view_numbers {value} {
    set numbers [string map [list \{ " " \} " " , " "] $value]
    if {![llength $numbers]} {error "Empty view matrix"}
    foreach number $numbers {
        if {![string is double -strict $number]} {error "Invalid view matrix value"}
    }
    return $numbers
}

proc ::hmm_images::begin {ids} {
    variable busy
    variable cancelled
    variable job
    if {$busy} {error "Image capture is already running"}
    if {[info exists ::hmm_props::editing] && $::hmm_props::editing} {error "Finish native property Settings first"}
    if {![llength $ids]} {error "Select at least one component"}
    foreach cid $ids {
        if {![string is integer -strict $cid] || $cid <= 0 || ![dict exists $::hmm::components $cid]} {error "Invalid component ID"}
        if {[hm_getvalue comps id=$cid dataname=name] ne [dict get $::hmm::components $cid name]} {error "Reload model data before capture; names or IDs differ"}
    }
    set ids [lsort -unique -integer $ids]
    # The folder in the window's image box (saving and loading share it; an existing capture there is overwritten).
    if {[info exists ::hmm_ui::imageDir] && [string trim $::hmm_ui::imageDir] ne ""} {
        set folder [file normalize [string trim $::hmm_ui::imageDir]]
    } else {
        set folder [file join $::hmm::projectDir images "capture_[clock seconds]_[pid]_[clock clicks]"]
    }
    file mkdir $folder
    set savedView "HMM_capture_[pid]_[clock clicks]"
    set handle "hmm_capture_[pid]_[clock clicks]"
    set job [dict create folder $folder ids $ids index 0 records [dict create] fingerprint [fingerprint] view [hm_getcurrentview] displayed [displayed] modified_before [hm_info database_modified] savedView $savedView handle $handle start [clock milliseconds] marks [dict create]]
    foreach type {nodes elems comps props mats} {
        foreach mark {1 2} {dict set job marks $type $mark [hm_getmark $type $mark]}
    }
    *saveviewmask $savedView 0
    if {[catch {hwi GetSessionHandle $handle} message]} {
        *removeview $savedView
        error $message
    }
    set busy 1
    set cancelled 0
    set ::hmm_images::paused 0
    set ::hmm_images::halted 0
    ::hmm::set_image_busy 1
    # One bar for all phases: capturing, thumbnails and loading each get a share, so it is full only at the very end.
    dict set job pad [expr {max(1, [llength $ids] / 10)}]
    catch {::hmm_ui::progress_begin [expr {[llength $ids] + 2 * [dict get $job pad]}] Capture capture}
    after idle ::hmm_images::step
    return $folder
}

# Stop pauses the capture (the view stays isolated until Continue or Cancel); Cancel ends it for good and keeps what was captured.
proc ::hmm_images::pause {} {
    variable busy
    variable paused
    if {!$busy} {error "No capture is running"}
    set paused 1
    set ::hmm::status "Capture paused: Continue or Cancel"
    catch ::hmm_ui::image_state
}
proc ::hmm_images::resume {} {
    variable busy
    variable paused
    variable halted
    if {!$busy || !$paused} {return}
    set paused 0
    if {$halted} {set halted 0;after idle ::hmm_images::step}
    set ::hmm::status "Capturing..."
    catch ::hmm_ui::image_state
}
proc ::hmm_images::cancel {} {
    variable busy
    variable cancelled
    variable paused
    variable halted
    if {!$busy} {return}
    set cancelled 1
    set paused 0
    if {$halted} {set halted 0;after idle ::hmm_images::step}
    set ::hmm::status "Cancelling capture..."
    catch ::hmm_ui::image_state
}
proc ::hmm_images::step {} {
    variable busy
    variable cancelled
    variable paused
    variable halted
    variable job
    if {!$busy} {return}
    # Paused: the chain stops here (the job stays open); Continue starts it again.
    if {$paused} {set halted 1;return}
    set index [dict get $job index]
    set ids [dict get $job ids]
    if {$cancelled || $index >= [llength $ids]} {finish ""; return}
    set cid [lindex $ids $index]
    set code [catch {
        *isolateonlyentity comps "by id" $cid
        *view iso1
        *window 0 0 0 0 0
        update idletasks
        set target [file join [dict get $job folder] "$cid.png"]
        [dict get $job handle] CaptureScreenToSize png $target 768 768 100
        if {![file isfile $target] || [file size $target] < 100} {error "Native capture did not produce an image"}
        dict set job records $cid [dict create name [dict get $::hmm::components $cid name] elements [llength [hm_getvalue comps id=$cid dataname=elements]]]
        dict incr job index
        set ::hmm::status "Capturing [dict get $job index]/[llength $ids]"
        catch {::hmm_ui::progress_set [dict get $job index] capture}
    } message]
    if {$code} {finish $message; return}
    after 1 ::hmm_images::step
}

proc ::hmm_images::finish {failure} {
    variable busy
    variable cancelled
    variable job
    set restoreErrors {}
    set savedView [dict get $job savedView]
    if {[catch {*restoreviewmask $savedView 0} error]} {lappend restoreErrors $error}
    if {[catch {*removeview $savedView} error]} {lappend restoreErrors $error}
    foreach type {nodes elems comps props mats} {
        foreach mark {1 2} {
            set ids [dict get $job marks $type $mark]
            if {[catch {
                *clearmark $type $mark
                if {[llength $ids]} {*createmark $type $mark {*}$ids}
            } error]} {lappend restoreErrors $error}
        }
    }
    if {[catch {[dict get $job handle] ReleaseHandle} error]} {lappend restoreErrors $error}
    update idletasks
    if {[catch {
        foreach type {nodes elems comps props mats} {
            foreach mark {1 2} {
                if {[lsort -integer [hm_getmark $type $mark]] ne [lsort -integer [dict get $job marks $type $mark]]} {
                    error "Selection mark was not restored: $type/$mark"
                }
            }
        }
        if {[displayed] ne [dict get $job displayed]} {error "Component display was not restored"}
        set current [view_numbers [hm_getcurrentview]]
        set original [view_numbers [dict get $job view]]
        if {[llength $current] != [llength $original]} {error "View matrix length differs"}
        foreach a $current b $original {
            if {abs($a-$b) > 1e-7 * max(1, abs($b))} {error "View matrix was not restored"}
        }
        if {[fingerprint] ne [dict get $job fingerprint]} {error "Model identity/counts changed during capture"}
    } error]} {lappend restoreErrors $error}
    set busy 0
    set paused 0
    set halted 0
    ::hmm::set_image_busy 0
    set prepare [expr {![llength $restoreErrors] && $failure eq "" && [dict size [dict get $job records]] > 0}]
    # The bar stays up while thumbnails are made and images are loaded; every other outcome ends it here.
    if {!$prepare} {catch {::hmm_ui::progress_end capture}}
    set folder [dict get $job folder]
    set result [dict create pid [pid] build [hm_info -appinfo DISPLAYVERSION] count [dict size [dict get $job records]] cancelled $cancelled failure $failure restoration_errors $restoreErrors modified_before [dict get $job modified_before] modified_after [hm_info database_modified] elapsed_ms [expr {[clock milliseconds]-[dict get $job start]}]]
    write_data [file join $folder capture_result.dict] $result
    if {[llength $restoreErrors]} {set ::hmm::status "\u26a0 Error: view not restored after capture (see capture_result.dict)"; return}
    if {$failure ne ""} {set ::hmm::status "\u26a0 Error: capture failed: $failure"; return}
    if {![dict size [dict get $job records]]} {set ::hmm::status "Capture cancelled"; return}
    set total [dict size [dict get $job records]];set pad [dict get $job pad];set steps [llength [dict get $job ids]]
    set ::hmm::status "Preparing thumbnails for $total images"
    catch {::hmm_ui::progress_set $steps capture}
    update idletasks
    set code [catch {
        set python [python_exe]
        exec $python -B [file join $::hmm::projectDir image_thumbnails.py] $folder
        # Images of Components that were not captured this time stay: their old records are kept while their files exist.
        set records [dict get $job records]
        catch {
            set f [::open [file join $folder images.dict] r];fconfigure $f -encoding utf-8;set old [read $f 4000000];close $f
            # Only records of the same model (same file, node and element counts) are kept: those of another model would not match
            # this model's Components and would make the loading of the whole capture fail.
            set oldModel [dict get $old model];set newModel [dict get $job fingerprint]
            set sameModel [expr {[string equal -nocase [dict get $oldModel model] [dict get $newModel model]] && [dict get $oldModel nodes] eq [dict get $newModel nodes] && [dict get $oldModel elements] eq [dict get $newModel elements]}]
            if {[dict get $old version] == 1 && $sameModel} {
                dict for {cid record} [dict get $old records] {
                    if {![dict exists $records $cid] && [file isfile [file join $folder thumbs "$cid.gif"]] && [file isfile [file join $folder previews "$cid.gif"]]} {dict set records $cid $record}
                }
            }
        }
        set manifest [dict create version 1 model [dict get $job fingerprint] records $records]
        write_data [file join $folder images.dict] $manifest
        set ::hmm::status "Loading $total images into the table"
        catch {::hmm_ui::progress_set [expr {$steps + $pad}] capture}
        update idletasks
        load_bundle $folder 1
    } message]
    catch {::hmm_ui::progress_set [expr {$steps + 2 * $pad}] capture}
    update idletasks
    catch {::hmm_ui::progress_end capture}
    if {$code} {set ::hmm::status "\u26a0 Error: images not prepared: $message"; return}
    ::hmm_ui::done "[dict size [dict get $job records]] images captured"
}

# Thumbnail Python (with Pillow): prefer the configured path, then discover the running Altair install.
proc ::hmm_images::python_exe {} {
    set config [file join $::hmm::projectDir settings python_path.txt]
    if {[file isfile $config]} {
        set f [::open $config r];fconfigure $f -encoding utf-8;set lines [split [read $f] \n];close $f
        foreach line $lines {
            set line [string trim [string trim $line] \"]
            if {$line eq "" || [string index $line 0] eq "#"} {continue}
            set path [file normalize $line]
            if {![file isfile $path]} {error "Python not found: $line (path written in $config)"}
            return $path
        }
    }
    set roots {}
    if {[llength [info commands ::hm_info]] && ![catch {::hm_info -appinfo ALTAIR_HOME} install]} {
        lappend roots $install
    }
    if {[info exists ::env(ALTAIR_HOME)]} {lappend roots $::env(ALTAIR_HOME)}
    foreach install $roots {
        if {[string trim $install] eq ""} {continue}
        set dir [file normalize $install]
        for {set depth 0} {$depth < 3} {incr depth} {
            set path [file join $dir common python python3.8 win64 python.exe]
            if {[file isfile $path]} {return [file normalize $path]}
            set parent [file dirname $dir]
            if {$parent eq $dir} {break}
            set dir $parent
        }
    }
    error "Altair Python not found: set the path to python.exe (with Pillow) in $config"
}

# ---- Loading the saved images of a folder. Three steps, so the same code serves two ways of running them:
#   load_prepare   reads and checks the manifest, returns a job (a dict: folder, partial, records, ids, index, handles, paths)
#   load_step      makes the image of the next record (a thumbnail is a Tk photo image from a GIF file)
#   load_finish    swaps the images in, remembers the folder and shows them in the table
# load_bundle runs them to the end at once (a button, after a capture: the caller needs the result). load_async runs them in short
# slices from the event loop (when the manager opens or the model changes), so the window is there first and stays alive, and the
# progress bar of the status row shows how far the loading is.
proc ::hmm_images::load_prepare {folder compatible} {
    variable busy
    if {$busy} {error "Wait for capture to finish"}
    set folder [file normalize $folder]
    set f [::open [file join $folder images.dict] r]
    fconfigure $f -encoding utf-8
    set data [read $f 4000000]
    close $f
    set current [fingerprint]
    if {[dict get $data version] != 1} {error "Unsupported image manifest"}
    set partial 0
    if {[dict get $data model] ne $current} {
        if {!$compatible} {error "Image set belongs to a different model state"}
        set old [dict get $data model]
        foreach key {model nodes elements} {
            if {![dict exists $old $key] || ![string equal -nocase [dict get $old $key] [dict get $current $key]]} {error "Saved images belong to a different model or mesh"}
        }
        set partial 1
    }
    set records [dict get $data records]
    return [dict create folder $folder partial $partial records $records ids [dict keys $records] index 0 handles [dict create] paths [dict create]]
}
proc ::hmm_images::load_step {jobVar} {
    upvar 1 $jobVar job
    set cid [lindex [dict get $job ids] [dict get $job index]]
    dict incr job index
    set record [dict get [dict get $job records] $cid]
    set folder [dict get $job folder]
    if {![string is integer -strict $cid] || $cid <= 0} {error "Invalid image component ID"}
    if {![dict exists $::hmm::components $cid] || [dict get $record name] ne [dict get $::hmm::components $cid name]} {
        if {[dict get $job partial]} {return}
        error "Image component does not match table"
    }
    set thumb [file normalize [file join $folder thumbs "$cid.gif"]]
    if {![string equal -nocase [file dirname [file dirname $thumb]] $folder]} {error "Image path escaped bundle"}
    dict set job handles $cid [image create photo -file $thumb]
    dict set job paths $cid [file join $folder previews "$cid.gif"]
}
proc ::hmm_images::load_abort {job} {dict for {cid image} [dict get $job handles] {catch {image delete $image}}}
proc ::hmm_images::load_finish {job} {
    variable handles
    variable paths
    variable bundle
    set newHandles [dict get $job handles]
    if {![dict size $newHandles]} {error "No saved images match the current Components"}
    dict for {cid image} $handles {catch {image delete $image}}
    set handles $newHandles
    set paths [dict get $job paths]
    set bundle [dict get $job folder]
    write_data [file join $::hmm::projectDir LAST_IMAGE_BUNDLE.txt] $bundle
    ::hmm::sync_rows
    set ::hmm::status "Loaded [dict size $handles] images"
    return [dict size $handles]
}
proc ::hmm_images::load_bundle {folder {compatible 0}} {
    set job [load_prepare $folder $compatible]
    set total [llength [dict get $job ids]]
    set ui [llength [info commands ::hmm_ui::progress_step]]
    if {$ui} {catch {::hmm_ui::progress_begin $total "Loading images" images}}
    set code [catch {
        while {[dict get $job index] < $total} {
            if {$ui} {catch {::hmm_ui::progress_step [expr {[dict get $job index] + 1}] images}}
            load_step job
        }
    } message options]
    if {$ui} {catch {::hmm_ui::progress_end images}}
    if {$code} {
        load_abort $job
        return -options $options $message
    }
    return [load_finish $job]
}
namespace eval ::hmm_images {variable loadGen 0;variable loadJob ""}
# Stops a loading in the background (a new load, the images cleared, a capture, the window closed): the images made so far go away.
proc ::hmm_images::load_cancel {} {
    variable loadGen
    variable loadJob
    incr loadGen
    if {$loadJob ne ""} {load_abort $loadJob;set loadJob "";catch {::hmm_ui::progress_end images}}
}
# The manager is open and usable while this runs; a slice of about 30 ms is followed by a turn of the event loop. An error is only
# said in the status line (the table simply stays without images).
proc ::hmm_images::load_async {folder {compatible 1}} {
    variable loadGen
    variable loadJob
    load_cancel
    set job [load_prepare $folder $compatible]
    set loadJob $job
    set gen [incr loadGen]
    catch {::hmm_ui::progress_begin [llength [dict get $job ids]] "Loading images" images}
    after 30 [list ::hmm_images::load_tick $gen]
}
proc ::hmm_images::load_tick {gen} {
    variable loadGen
    variable loadJob
    variable busy
    if {$gen != $loadGen || $loadJob eq ""} {return}
    if {![info exists ::hmm::window] || ![winfo exists $::hmm::window] || $busy} {load_cancel;return}
    set job $loadJob
    set total [llength [dict get $job ids]]
    set until [expr {[clock milliseconds] + 30}]
    set code [catch {
        while {[dict get $job index] < $total && [clock milliseconds] < $until} {load_step job}
    } message]
    if {$code} {
        load_abort $job
        set loadJob ""
        catch {::hmm_ui::progress_end images}
        set ::hmm::status "\u26a0 Error: images not loaded: $message"
        return
    }
    set loadJob $job
    catch {::hmm_ui::progress_set [dict get $job index] images}
    if {[dict get $job index] < $total} {
        after 1 [list ::hmm_images::load_tick $gen]
        return
    }
    set loadJob ""
    catch {::hmm_ui::progress_end images}
    if {[catch {load_finish $job} message]} {set ::hmm::status "\u26a0 Error: images not loaded: $message"}
}
proc ::hmm_images::photo {cid} {
    variable handles
    if {[dict exists $handles $cid]} {return [dict get $handles $cid]}
    return ""
}
# One image folder per model: images/<model file name>_<hash of its path>. Capturing and loading never mix two models. An unsaved
# model has no path: its folder is named from its Component IDs.
proc ::hmm_images::short_hash {text} {
    set h 5381
    foreach char [split $text ""] {scan $char %c code;set h [expr {(($h * 33) ^ $code) & 0xffffffff}]}
    return [format %08x $h]
}
proc ::hmm_images::model_folder {} {
    set model [string trim [hm_info currentfile]]
    if {$model eq ""} {
        set name untitled;set seed [lsort -integer [hm_entitylist comps id all]]
    } else {
        set name [regsub -all {[^A-Za-z0-9_.-]+} [file rootname [file tail $model]] _];set seed [string tolower [file normalize $model]]
        if {$name eq ""} {set name model}
    }
    return [file normalize [file join $::hmm::projectDir images "[string range $name 0 39]_[short_hash $seed]"]]
}
# Called when the manager opens (force) and whenever the model is read again: if the model changed, the images of the old model are
# dropped and the folder of the new one is shown in the Image folder box and loaded when it holds a capture. A folder the user chose
# or typed in the box is respected (it is only loaded).
proc ::hmm_images::load_saved {} {return [::hmm_ui::image_dir_sync 1]}


proc ::hmm_images::capture_selected {} {
    set ids [$::hmm::window.table.tree selection]
    if {[catch {begin $ids} error]} {set ::hmm::status "\u26a0 Error: capture failed: $error"}
}

proc ::hmm_images::preview {cid} {
    variable paths
    if {![dict exists $paths $cid]} {return}
    set window .hmm_image_preview
    if {[winfo exists $window]} {destroy $window}
    if {[info exists ::hmm_images::previewPhoto]} {catch {image delete $::hmm_images::previewPhoto}}
    set ::hmm_images::previewPhoto [image create photo -file [dict get $paths $cid]]
    toplevel $window
    wm withdraw $window
    wm title $window "Component $cid"
    ttk::label $window.image -image $::hmm_images::previewPhoto
    pack $window.image
    update idletasks
    set x [expr {[winfo rootx .]+([winfo width .]-640)/2}]
    set y [expr {[winfo rooty .]+([winfo height .]-480)/2}]
    wm geometry $window [format "640x480%+d%+d" $x $y]
    wm deiconify $window
}

proc ::hmm_images::clear {} {
    variable handles
    variable paths
    catch ::hmm_images::load_cancel
    dict for {cid photo} $handles {catch {image delete $photo}}
    set handles [dict create]
    set paths [dict create]
}
