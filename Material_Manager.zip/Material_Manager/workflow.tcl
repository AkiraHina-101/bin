# Per-tab queues. Library decisions are collected before any model mutation.
namespace eval ::hmm_flow {
    variable queues
    if {![array exists queues]} {array set queues {components {} properties {} materials {} library {}}}
    variable busy 0
    variable resolver ""
}
proc ::hmm_flow::count {{scope ""}} {
    variable queues
    if {$scope ne ""} {return [dict size $queues($scope)]}
    set n 0;foreach key [array names queues] {incr n [dict size $queues($key)]};return $n
}
# Every queue as one plan. A key (p:<Component>, m:<Property>, v:<Material>, c:<name>) is held by one queue only, because a
# new Set for the same key replaces the earlier one wherever it was staged.
proc ::hmm_flow::merged {} {
    variable queues
    set all [dict create]
    foreach scope {components properties materials library} {set all [dict merge $all $queues($scope)]}
    return $all
}
proc ::hmm_flow::claim {scope keys} {
    variable queues
    set replaced 0
    foreach other [array names queues] {
        if {$other eq $scope} {continue}
        foreach key $keys {if {[dict exists $queues($other) $key]} {dict unset queues($other) $key;incr replaced}}
    }
    if {$replaced} {set ::hmm::status "Replaced $replaced earlier pending change(s) for the same item"}
}
proc ::hmm_flow::token {text} {
    if {[regexp {^(?:MODEL \| )?([0-9]+) \| } $text -> id]} {return [list model $id]}
    if {[regexp {^LIB \| (.+)$} $text -> name] && [dict exists $::hmm_lib::records $name]} {return [list lib $name]}
    error "Choose a MODEL or LIB Material"
}
proc ::hmm_flow::choices {args} {
    set result {}
    dict for {id name} $::hmm::materials {if {$id > 0} {lappend result "$id | $name"}}
    foreach name [dict keys $::hmm_lib::records] {lappend result "LIB | $name"}
    return $result
}
proc ::hmm_flow::text {token} {
    foreach {kind value} $token break
    if {$kind eq "lib"} {return "LIB | $value"}
    return "$value | [dict get $::hmm::materials $value]"
}
proc ::hmm_flow::validate_token {token} {
    foreach {kind value} $token break
    if {$kind eq "lib"} {
        if {![dict exists $::hmm_lib::records $value]} {error "Library entry no longer exists"}
    } elseif {$kind eq "model"} {
        if {$value == 0 || ![dict exists $::hmm::materials $value] || [hm_getvalue mats id=$value dataname=cardimage] ne "MAT1"} {error "Choose an existing MAT1"}
    } else {error "Invalid Material selection"}
}
proc ::hmm_flow::property_supported {id} {
    if {$id == 0 || ![dict exists $::hmm::properties $id]} {error "Create or assign a Property first"}
    set card [hm_getvalue props id=$id dataname=cardimage]
    if {$card ni {PSHELL PSOLID}} {error "$card does not support this single-Material assignment; use Entity Editor"}
    if {$card eq "PSHELL" && [hm_getvalue props id=$id dataname=MID1_blank] != 0} {error "PSHELL MID1 is disabled; use Entity Editor"}
}
proc ::hmm_flow::stage_material {scope ids token} {
    ::hmm_props::require_clean
    validate_token $token
    # A library entry that already exists in the model is used as that model Material.
    set token [resolve_token $token]
    if {![llength $ids]} {error "Select target rows first"}
    variable queues
    set next $queues($scope);set claimed {}
    foreach id [lsort -unique -integer $ids] {
        property_supported $id
        set key m:$id
        set old [hm_getvalue props id=$id dataname=materialid]
        if {[dict exists $next $key]} {set old [dict get $next $key old]}
        set op [dict create kind material id $id old $old target $token]
        if {[lindex $token 0] eq "lib"} {dict set op library [dict get $::hmm_lib::records [lindex $token 1]]}
        dict set next $key $op
        lappend claimed $key
    }
    set queues($scope) $next
    claim $scope $claimed
}
proc ::hmm_flow::stage_property {scope ids pid} {
    ::hmm_props::require_clean
    if {![llength $ids] || $pid <= 0 || ![dict exists $::hmm::properties $pid]} {error "Select Components and a Property"}
    variable queues
    set next $queues($scope);set claimed {}
    foreach id [lsort -unique -integer $ids] {
        if {![dict exists $::hmm::components $id]} {error "Unknown Component $id"}
        ::hmm_apply::check_element_card $id [hm_getvalue props id=$pid dataname=cardimage]
        set old [hm_getvalue comps id=$id dataname=propertyid]
        set key p:$id
        if {[dict exists $next $key]} {set old [dict get $next $key old]}
        dict set next $key [dict create kind property id $id old $old target $pid]
        lappend claimed $key
    }
    set queues($scope) $next
    claim $scope $claimed
}
proc ::hmm_flow::component_properties {scope ids} {
    variable queues
    set result {}
    foreach cid $ids {
        set pid [hm_getvalue comps id=$cid dataname=propertyid]
        if {[dict exists $queues($scope) p:$cid]} {set pid [dict get $queues($scope) p:$cid target]}
        property_supported $pid;lappend result $pid
    }
    return [lsort -unique -integer $result]
}
proc ::hmm_flow::stage_parameters {scope ids name} {
    ::hmm_props::require_clean
    if {![llength $ids] || ![dict exists $::hmm_lib::records $name]} {error "Select Materials and a library entry"}
    variable queues
    set next $queues($scope);set claimed {}
    set data [dict get $::hmm_lib::records $name]
    foreach id $ids {
        if {[hm_getvalue mats id=$id dataname=cardimage] ne "MAT1"} {error "Parameter update supports MAT1 only"}
        set g [::hmm_props::data_value materials $id 2 G MAT1]
        if {$g ne "" && $g != 0} {error "Material $id defines G; review it in Entity Editor before changing E/NU"}
        set old [material_state $id]
        if {[dict exists $next v:$id]} {set old [dict get $next v:$id old]}
        dict set next v:$id [dict create kind parameters id $id old $old target $name library $data]
        lappend claimed v:$id
    }
    set queues($scope) $next
    claim $scope $claimed
}
proc ::hmm_flow::material_state {id} {
    set attrs [dict create]
    foreach {key attr} {E 1 NU 3 RHO 4 GE 7} {
        set status 0;set value ""
        if {$attr in [hm_attributelist mats $id id -byid]} {
            set status [hm_attributestatus mats $id $attr -byid]
            if {$status != 0} {set value [hm_getvalue mats id=$id dataname=$attr]}
        }
        dict set attrs $attr [list $status $value]
    }
    return $attrs
}
proc ::hmm_flow::impact {scope} {
    variable queues
    set props {};set comps {};set mats {}
    dict for {key op} [expr {$scope eq "all" ? [merged] : $queues($scope)}] {
        switch [dict get $op kind] {
            property {lappend comps [dict get $op id]}
            material {lappend props [dict get $op id]}
            parameters {lappend mats [dict get $op id]}
        }
    }
    dict for {pid data} $::hmm::properties {if {$pid > 0 && [dict get $data material] in $mats} {lappend props $pid}}
    foreach pid [lsort -unique $props] {set comps [concat $comps [::hmm::property_users $pid]]}
    return [dict create properties [lsort -unique -integer $props] components [lsort -unique -integer $comps] materials [lsort -unique -integer $mats]]
}
proc ::hmm_flow::existing {data} {
    set result {}
    foreach id [hm_entitylist mats id all] {
        if {[hm_getvalue mats id=$id dataname=cardimage] ne "MAT1"} {continue}
        set actual [::hmm_lib::native_values $id];set match 1
        foreach key {E NU RHO GE} {
            set value [dict get $data $key]
            if {$value eq ""} {continue}
            if {[dict get $actual $key] eq "" || [::hmm_lib::decimal $value] ne [::hmm_lib::decimal [dict get $actual $key]]} {set match 0;break}
        }
        if {$match} {lappend result $id}
    }
    return $result
}
# A library token becomes a model token when exactly one model Material has the library name and the
# same parameters (E, NU, RHO, GE where the library gives them); otherwise Apply still asks.
proc ::hmm_flow::resolve_token {token} {
    if {[lindex $token 0] ne "lib"} {return $token}
    set name [lindex $token 1]
    if {![dict exists $::hmm_lib::records $name]} {return $token}
    set named {}
    foreach id [existing [dict get $::hmm_lib::records $name]] {
        if {[dict exists $::hmm::materials $id] && [dict get $::hmm::materials $id] eq $name} {lappend named $id}
    }
    if {[llength $named] == 1} {return [list model [lindex $named 0]]}
    return $token
}
# Re-resolve queued library tokens after the model changed (a Material may have been created meanwhile).
proc ::hmm_flow::upgrade_queues {} {
    variable queues
    foreach scope [array names queues] {
        set next [dict create]
        dict for {key op} $queues($scope) {
            if {[dict get $op kind] eq "material" && [lindex [dict get $op target] 0] eq "lib"} {
                set resolved [resolve_token [dict get $op target]]
                if {$resolved ne [dict get $op target]} {dict set op target $resolved;dict unset op library}
            }
            dict set next $key $op
        }
        set queues($scope) $next
    }
}
proc ::hmm_flow::next_name {name} {
    set used [dict values $::hmm::materials]
    set result $name;set i 1
    while {$result in $used} {set result "${name}($i)";incr i}
    return $result
}
proc ::hmm_flow::ask {name ids} {
    variable resolver
    if {$resolver ne ""} {return [uplevel #0 [linsert $resolver end $name $ids]]}
    return [::hmm_ui::resolve_dialog $name $ids]
}
proc ::hmm_flow::create_material {name} {
    return [::hmm_lib::create $name [next_name $name]]
}
proc ::hmm_flow::stage_create {scope name} {
    ::hmm_props::require_clean
    if {![dict exists $::hmm_lib::records $name]} {error "Select a library entry"}
    variable queues
    dict set queues($scope) c:$name [dict create kind create id 0 target $name library [dict get $::hmm_lib::records $name]]
}
# Applies every pending change of every tab as one transaction (one snapshot, one rollback). The scope argument is kept for
# callers and tests; it no longer narrows what is applied.
proc ::hmm_flow::apply {{scope all}} {
    variable queues;variable busy
    if {$busy} {error "Apply is already running"}
    ::hmm_props::require_clean
    set scope all
    if {![dict size [merged]]} {error "No pending changes"}
    set plan [merged];set resolutions [dict create]
    # Validate every queued old value and collect every decision before writing.
    dict for {key op} $plan {
        set id [dict get $op id]
        switch [dict get $op kind] {
            create {
                set name [dict get $op target]
                if {![dict exists $::hmm_lib::records $name] || [dict get $op library] ne [dict get $::hmm_lib::records $name]} {error "Library changed; select it again"}
                if {[ask $name {}] eq "cancel"} {return [dict create status CANCELLED]}
                dict set resolutions $name new
            }
            property {if {[hm_getvalue comps id=$id dataname=propertyid] != [dict get $op old]} {error "Component $id changed; select it again"}}
            material {
                property_supported $id
                if {[hm_getvalue props id=$id dataname=materialid] != [dict get $op old]} {error "Property $id changed; select it again"}
                set token [dict get $op target];validate_token $token
                if {[lindex $token 0] eq "lib"} {
                    set name [lindex $token 1]
                    if {[dict get $op library] ne [dict get $::hmm_lib::records $name]} {error "Library changed; choose $name again"}
                    if {![dict exists $resolutions $name]} {
                        set candidates [existing [dict get $op library]]
                        set decision [ask $name $candidates]
                        if {$decision eq "cancel"} {return [dict create status CANCELLED]}
                        if {$decision ne "new" && $decision ni $candidates} {error "Invalid Material resolution"}
                        dict set resolutions $name $decision
                    }
                }
            }
            parameters {
                if {[material_state $id] ne [dict get $op old]} {error "Material $id parameters changed; select it again"}
                if {![dict exists $::hmm_lib::records [dict get $op target]] || [dict get $op library] ne [dict get $::hmm_lib::records [dict get $op target]]} {error "Library changed; choose it again"}
            }
        }
    }
    ::hmm_props::require_clean
    dict for {key op} $plan {
        if {[dict get $op kind] eq "parameters" && [material_state [dict get $op id]] ne [dict get $op old]} {error "Material parameters changed during confirmation"}
        if {[dict exists $op library]} {
            set name [dict get $op target]
            if {[dict get $op kind] eq "material"} {set name [lindex $name 1]}
            if {![dict exists $::hmm_lib::records $name] || [dict get $op library] ne [dict get $::hmm_lib::records $name]} {error "Library changed during confirmation"}
        }
    }
    dict for {name decision} $resolutions {
        if {$decision ne "new" && $decision ni [existing [dict get $::hmm_lib::records $name]]} {error "Matching Material changed during confirmation"}
    }
    set affected [dict get [impact $scope] components]
    set before [::hmm::read_model];set physical [::hmm_lib::snapshot]
    set folder [::hmm_lib::evidence workflow [list scope $scope model $before physical $physical plan $plan decisions $resolutions]]
    set created {};set written {};set applied {};set busy 1
    set code [catch {
        dict for {name decision} $resolutions {
            if {$decision eq "new"} {set decision [create_material $name];lappend created $decision}
            dict set resolutions $name $decision
        }
        dict for {key op} $plan {
            if {[dict get $op kind] ne "parameters"} {continue}
            set id [dict get $op id]
            foreach {label attr} {E 1 NU 3 RHO 4 GE 7} {
                set value [dict get $op library $label]
                if {$value eq ""} {continue}
                lappend written [list $id $attr [dict get $op old $attr]]
                *setvalue mats id=$id STATUS=2 $attr=$value
                set actual [hm_getvalue mats id=$id dataname=$attr]
                if {[::hmm_lib::decimal $actual] ne [::hmm_lib::decimal $value]} {error "Parameter readback differs: $id $label"}
            }
        }
        foreach name {components properties materials} data [::hmm::read_model] {set ::hmm::$name $data}
        dict for {key op} $plan {
            set id [dict get $op id]
            switch [dict get $op kind] {
                property {dict set ::hmm::components $id property [dict get $op target]}
                material {
                    foreach {kind value} [dict get $op target] break
                    if {$kind eq "lib"} {set value [dict get $resolutions $value]}
                    dict set ::hmm::properties $id material $value
                }
            }
        }
        if {[llength [dict get [::hmm_apply::plan] changes]]} {set applied [dict get [::hmm_apply::execute] changes]}
        # Verify supplied fields and preserve unspecified GE and unrelated values.
        set after [::hmm_lib::snapshot]
        foreach id $created {dict unset after $id}
        set expected $physical
        dict for {key op} $plan {
            if {[dict get $op kind] ne "parameters"} {continue}
            set id [dict get $op id]
            foreach {label attr} {E 1 NU 3 RHO 4 GE 7} {
                if {[dict get $op library $label] ne ""} {
                    set row [dict get $expected $id]
                    set attrs [lindex $row 1]
                    dict set attrs $attr [dict get [lindex [dict get $after $id] 1] $attr]
                    dict set expected $id [list [lindex $row 0] $attrs]
                }
            }
        }
        if {$after ne $expected} {error "Unrelated Material data changed"}
        ::hmm_apply::save_data [file join $folder result.dict] [list status PASS created $created changes $applied parameter_fields [llength $written] after [::hmm::read_model]]
    } message options]
    if {$code} {
        set errors {}
        foreach change [lreverse $applied] {if {[catch {::hmm_apply::write_value $change 1} problem]} {lappend errors $problem}}
        foreach item [lreverse $written] {
            foreach {id attr old} $item break;foreach {status value} $old break
            if {$value eq ""} {set value 0}
            if {[catch {*setvalue mats id=$id STATUS=$status $attr=$value} problem]} {lappend errors $problem}
        }
        if {[llength $created] && ![llength $errors] && !$::hmm_apply::blocked} {
            set mark [hm_getmark mats 1]
            if {[catch {*createmark mats 1 {*}$created;*deletemark mats 1} problem]} {lappend errors $problem}
            *createmark mats 1 {*}$mark
        }
        if {[catch {
            if {[::hmm::read_model] ne $before} {error "Assignment rollback differs"}
            foreach item $written {foreach {id attr old} $item break;if {[dict get [material_state $id] $attr] ne $old} {error "Parameter rollback differs: $id/$attr"}}
        } problem]} {lappend errors $problem}
        ::hmm_apply::save_data [file join $folder failure.dict] [list error $message rollback_errors $errors]
        set busy 0
        if {[llength $errors] || $::hmm_apply::blocked} {set ::hmm_apply::blocked 1;error "Apply failed; inspect $folder"}
        ::hmm_props::refresh_model
        return -options $options $message
    }
    foreach each [array names queues] {set queues($each) {}}
    set busy 0
    # Only Components using a changed Property, Material assignment or Material parameter need new masses.
    set ::hmm::massAffected $affected
    ::hmm_props::refresh_model
    return [dict create status APPLIED evidence $folder created $created]
}
