# Native HWTK table, with Component IDs preserved at the product boundary.
namespace eval ::hmm_tree {variable state;variable columns {id name property_id property_name material_id material_name shared mass property_card property_t property_nsm material_e material_nu material_rho material_ge}}
proc ::hmm_tree::create {w} {
 variable state
 ttk::frame $w
 rename $w ::${w}__frame
 set n ::$w.native
 hwtk::treectrl $w.native -showroot no -showlines false -selectmode extended -stripes false
 pack $w.native -fill both -expand 1
 interp alias {} $w {} ::hmm_tree::dispatch $w
 set raw [$n component treectrl]
 set state($w,native) $n;set state($w,raw) $raw
 set state($w,rows) {};set state($w,ids) {};set state($w,data) {};set state($w,photos) {}
 $raw configure -font TkDefaultFont -background white -showbuttons 0
 catch {$raw state define pending}
 catch {$raw state define updated}
 # A selected row uses the same fill as the hovered row (native GMouseover gradient), so choosing a row looks like pointing at it.
 catch {$raw element configure rectangle -fill [list GMouseover {enabled selected} GMouseover {enabled MOUSEOVER}]}
 # Selected rows are a flat fill like the native tables: the per-cell outline of selected/active cells (which did not line up between
 # cells and stayed on the last clicked row after it was deselected) is dropped; only the hover outline remains.
 catch {$raw element configure rectoutline -outline [list #b8d6fb {enabled MOUSEOVER}]}
 # Amber = a staged change, green = a cell the Entity Editor has just updated (the same rectangle shows both).
 $raw element create hmm_pending rect -fill {#b3e6a1 updated #ffe08a pending} -outlinewidth 0
 $raw element create hmm_grid rect -outline #c8c8c8 -outlinewidth 1 -open nw
 $n element create rownum str -editable 0
 $n column create rownum -text "" -elements rownum -width 24 -itemjustify center -justify center
 if {![itcl::is class ::hmm_tree::PhotoEditor]} {
  itcl::class ::hmm_tree::PhotoEditor {
   inherit ::hwtk::prop::editor::image
   constructor {window} {chain {*}$window} {}
   method GetDisplayImage {value {ambiguous false} {enabled true}} {return $value}
  }
 }
 $n registertype hmm_photo ::hmm_tree::PhotoEditor image
 $n element create photo hmm_photo -editable 0
 $n column create image -text Image -elements photo -width 104 -justify center -itemjustify center
 foreach {col text width} {id ID 50 name Component 105 property_id ID 50 property_name Property 105 material_id ID 50 material_name Material 105 shared Shared 55 mass {Mass (kg)} 90 property_card {Prop Card} 80 property_t Thickness 80 property_nsm NSM 70 material_e {Mat E} 85 material_nu {Mat NU} 70 material_rho {Mat RHO} 90 material_ge {Mat GE} 70} {
  $n element create $col str -editable 0
  $n column create $col -text $text -elements [list $col] -width $width -sort false -justify center -itemjustify center
 }
 $raw notify bind $w <Selection> [list ::hmm_tree::notify $w]
 $raw notify bind $w <Header-invoke> [list ::hmm_tree::sort $w %C]
 bind $raw <ButtonRelease-3> [list ::hmm_ui::context components $w %x %y %X %Y]
 # HWTK rewrites the sensitive-element list when rows change, so it is set again right before the native press binding runs.
 bind $raw <ButtonPress-1> [list ::hmm_tree::set_sensitive $w]
 bind $raw <ButtonRelease-1> [list +::hmm_tree::clicked $w %x %y]
 bind $raw <Double-Button-1> "[list ::hmm_tree::double $w] %x %y; break"
 bind $raw <F2> {::hmm_ui::run ::hmm_ui::comp_name_edit}
 bind $w <Destroy> [list ::hmm_tree::destroyed $w %W]
 return $w
}
proc ::hmm_tree::destroyed {w actual} {
 if {$w ne $actual} {return}
 variable state
 array unset state $w,*
 if {[llength [info commands $w]]} {rename $w {}}
}
# Clicking a Component row always shows that Component in the Entity, even if the selection did not change.
proc ::hmm_tree::clicked {w x y} {
 variable state
 if {![info exists state($w,raw)] || [lindex [$state($w,raw) identify $x $y] 0] ne "item"} {return}
 after idle {catch {::hmm_ui::selected components}}
}
# TreeCtrl file-list bindings select a row only when the click lands on a "sensitive" element, and they fail with a background
# error when no list exists. Every element of every cell style is sensitive, so a click anywhere in a cell selects its row.
proc ::hmm_tree::set_sensitive {w} {
 variable state
 if {![info exists state($w,raw)]} {return}
 set raw $state($w,raw);set row [lindex [$raw item children root] 0]
 if {$row eq ""} {return}
 set list {}
 foreach column [$raw column list] {
  set id [$raw column id $column]
  set style [$raw item style set $row $id]
  lappend list [concat [list $id $style] [$raw style elements $style]]
 }
 ::TreeCtrl::SetSensitive $raw $list
}
proc ::hmm_tree::notify {w} {if {[winfo exists $w]} {event generate $w <<TreeviewSelect>>}}
# Pending cells get an amber background: a rect element in each cell style that shows only in the pending state.
proc ::hmm_tree::mark_pending {w cid fields} {
 variable state
 if {![dict exists $state($w,rows) $cid]} {return}
 set raw $state($w,raw);set n $state($w,native);set row [dict get $state($w,rows) $cid]
 foreach field $fields {$raw item state forcolumn $row [$n column id $field] pending}
}
# Green cells: what an Entity Editor edit just changed in this table; cleared by the next action.
proc ::hmm_tree::mark_updated {w cid fields} {
 variable state
 if {![dict exists $state($w,rows) $cid]} {return}
 set raw $state($w,raw);set n $state($w,native);set row [dict get $state($w,rows) $cid]
 foreach field $fields {
  $raw item state forcolumn $row [$n column id $field] updated
  lappend state($w,updatedCells) [list $cid $field]
 }
}
proc ::hmm_tree::clear_updated {w} {
 variable state
 if {![info exists state($w,updatedCells)]} {return}
 if {[info exists state($w,rows)]} {
  set raw $state($w,raw);set n $state($w,native)
  foreach cell $state($w,updatedCells) {
   lassign $cell cid field
   if {[dict exists $state($w,rows) $cid]} {catch {$raw item state forcolumn [dict get $state($w,rows) $cid] [$n column id $field] !updated}}
  }
 }
 set state($w,updatedCells) {}
}
proc ::hmm_tree::set_mass {w cid text} {
 variable state
 if {![info exists state($w,rows)] || ![dict exists $state($w,rows) $cid]} {return}
 $state($w,native) item configure [dict get $state($w,rows) $cid] -values [list mass $text]
 dict set state($w,data) $cid [lreplace [dict get $state($w,data) $cid] 7 7 $text]
}
# One cell of one row (a renamed Property shows its new name without the table being rebuilt).
proc ::hmm_tree::set_field {w cid field text} {
 variable state;variable columns
 set index [lsearch -exact $columns $field]
 if {$index < 0 || ![info exists state($w,rows)] || ![dict exists $state($w,rows) $cid]} {return}
 $state($w,native) item configure [dict get $state($w,rows) $cid] -values [list $field $text]
 dict set state($w,data) $cid [lreplace [dict get $state($w,data) $cid] $index $index $text]
}
proc ::hmm_tree::fit {w column} {
 variable state;variable columns
 set raw $state($w,raw);set n $state($w,native)
 if {$column eq [$n column id rownum]} {$n column configure $column -width 24;return}
 if {$column eq [$n column id image]} {$n column configure $column -width 104;return}
 set field "";set index 0
 foreach f $columns {if {[$n column id $f] eq $column} {set field $f;break};incr index}
 if {$field eq ""} {return}
 set width [font measure TkDefaultFont [$n column cget $column -text]]
 dict for {cid values} $state($w,data) {set width [expr {max($width,[font measure TkDefaultFont [lindex $values $index]])}]}
 $n column configure $column -width [expr {$width+24}]
}
proc ::hmm_tree::double {w x y} {
 variable state
 set hit [$state($w,raw) identify $x $y]
 if {[lindex $hit 0] eq "header"} {
  # identify gives {header COLUMN ?elem NAME? ?left|right?}; the side flag marks the divider hotspot.
  set column [lindex $hit 1]
  if {$column eq "" || $column eq "tail"} {return}
  if {[lindex $hit end] eq "left"} {
   # Left hotspot of a column is the divider after the previous visible column.
   set prev ""
   for {set o [expr {[$state($w,raw) column order $column]-1}]} {$o >= 0} {incr o -1} {
    set c [$state($w,raw) column id [list order $o]]
    if {[$state($w,raw) column cget $c -visible]} {set prev $c;break}
   }
   if {$prev ne ""} {set column $prev}
  }
  fit $w $column
  return
 }
 if {[$w identify column $x $y] eq "#0"} {
  set cid [$w identify row $x $y]
  if {$cid ne "" && [catch {::hmm_images::preview $cid} message]} {set ::hmm::status "Preview failed: $message"}
  return
 }
 # A double click on the name of a Component renames it in the table (see ::hmm_ui::comp_name_edit).
 if {[lindex $hit 0] eq "item" && [lindex $hit 3] eq [$state($w,native) column id name]} {
  set cid [$w identify row $x $y]
  if {$cid ne ""} {::hmm_ui::run [list ::hmm_ui::comp_name_edit $cid]}
 }
}
proc ::hmm_tree::sort {w column} {
 variable state;variable columns
 set index [$state($w,raw) column order $column]
 if {$index >= 2} {::hmm::sort_by [lindex $columns [expr {$index-2}]]}
}
proc ::hmm_tree::renumber {w} {
 variable state
 set n $state($w,native);set i 0
 foreach row [$n item children 0] {incr i;$n item configure $row -values [list rownum $i]}
 $n column configure rownum -width [expr {max(24,[font measure TkDefaultFont $i]+12)}]
}
proc ::hmm_tree::col {w col} {
 variable columns
 if {$col eq "#0"} {return image}
 if {[regexp {^#([0-9]+)$} $col -> i]} {return [lindex $columns [expr {$i-1}]]}
 return $col
}
proc ::hmm_tree::dispatch {w command args} {
 variable state;variable columns
 set n $state($w,native);set raw $state($w,raw)
 switch -- $command {
  children {set out {};foreach row [$n item children 0] {if {[dict exists $state($w,ids) $row]} {lappend out [dict get $state($w,ids) $row]}};return $out}
  exists {return [dict exists $state($w,rows) [lindex $args 0]]}
  insert {
   array set a [lrange $args 2 end];set cid $a(-id)
   set vals [list photo "" rownum [expr {[dict size $state($w,rows)] + 1}]]
   if {$a(-image) ne ""} {
    # Cache by Tk image name; no resampling or disabled-state conversion.
    set photo $a(-image)
    set vals [lreplace $vals 1 1 $photo]
   }
   foreach key $columns value $a(-values) {lappend vals $key $value}
   set row [$n item create -parent 0 -values $vals]
   foreach col [$n column list] {
    set column [$n column id $col]
    set style [$raw item style set $row $column]
    set elements [$raw style elements $style]
    if {"hmm_grid" ni $elements} {
     # The pending background sits above the selection rectangle so a selected row still shows it.
     # Order: selection fill, pending amber, native outline, then the grid lines (so selected rows keep their lines), then content.
     set all [linsert [linsert $elements [expr {[lsearch -exact $elements rectangle] + 1}] hmm_pending] [expr {[lsearch -exact $elements rectoutline] + 2}] hmm_grid]
     $raw style elements $style $all
     # The native fill and outline start one pixel below the cell top; shrink the top padding so the top edge matches the bottom.
     foreach e {rectangle rectoutline} {catch {$raw style layout $style $e -ipady {0 1}}}
     $raw style layout $style hmm_pending -union $elements -iexpand xy -detach yes
     $raw style layout $style hmm_grid -union $elements -iexpand xy -detach yes

    }
   }
   dict set state($w,rows) $cid $row;dict set state($w,ids) $row $cid
   dict set state($w,data) $cid $a(-values);dict set state($w,photos) $cid $a(-image)
   return $cid
  }
  delete {
   foreach cid [lindex $args 0] {if {[dict exists $state($w,rows) $cid]} {set row [dict get $state($w,rows) $cid];$n item delete $row;dict unset state($w,ids) $row;foreach k {rows data photos} {dict unset state($w,$k) $cid}}}
   return
  }
  selection {
   if {![llength $args]} {set out {};foreach row [$n select] {if {[dict exists $state($w,ids) $row]} {lappend out [dict get $state($w,ids) $row]}};return $out}
   set op [lindex $args 0]
    if {$op eq "set"} {foreach selected [$n select] {$n deselect $selected}}
   foreach cid [lindex $args 1] {if {[dict exists $state($w,rows) $cid]} {set row [dict get $state($w,rows) $cid];if {$op eq "remove"} {$n deselect $row} else {$n select $row}}}
   return
  }
  item {
   set cid [lindex $args 0]
   if {$cid in {create configure cget delete id children}} {return [$n item {*}$args]}
   switch -- [lindex $args 1] {-values {return [dict get $state($w,data) $cid]} -image {return [dict get $state($w,photos) $cid]}}
   error "Unsupported Component item query"
  }
  move {set cid [lindex $args 0];$raw item lastchild 0 [dict get $state($w,rows) $cid];return}
  see {$n see [dict get $state($w,rows) [lindex $args 0]];return}
  heading - column {
   if {$command eq "column" && [lindex $args 0] in {create configure cget list delete}} {return [$n column {*}$args]}
   if {$command eq "column" && [lindex $args 0] eq "id" && ![string match -* [lindex $args 1]]} {return [$n column {*}$args]}
   set col [col $w [lindex $args 0]];set opts [lrange $args 1 end]
   if {[llength $opts] == 1} {
    set key [lindex $opts 0];if {$key eq "-anchor"} {return w}
    return [$n column cget $col $key]
   }
   foreach {key value} $opts {
    switch -- $key {
     -text {$n column configure $col -text $value}
     -width {$n column configure $col -width $value}
     -anchor {$n column configure $col [expr {$command eq "heading" ? "-justify" : "-itemjustify"}] center}
    }
   };return
  }
  cget {switch -- [lindex $args 0] {-columns {return $columns} -show {return {tree headings}}};return [$n cget {*}$args]}
  tag {return}
  yview - xview {return [$raw $command {*}$args]}
  bbox {set row [dict get $state($w,rows) [lindex $args 0]];set c [col $w [lindex $args 1]];return [$raw item bbox $row [$n column id $c]]}
  identify {
   if {[lindex $args 0] ni {row region column}} {return [$n identify {*}$args]}
   set hit [$raw identify [lindex $args 1] [lindex $args 2]]
   set part [lindex $args 0]
   if {$part eq "region"} {if {[lindex $hit 0] eq "header"} {if {"right" in $hit || "left" in $hit} {return separator};return heading};if {[lindex $hit 0] eq "item"} {return cell};return ""}
   if {$part eq "row"} {if {[lindex $hit 0] eq "item" && [dict exists $state($w,ids) [lindex $hit 1]]} {return [dict get $state($w,ids) [lindex $hit 1]]};return ""}
   set i [lsearch -exact $hit column]
   if {$i >= 0} {set c [lindex $hit [expr {$i+1}]];set index [$raw column order $c];return #[expr {$index-1}]};return ""
  }
  default {return [uplevel 1 [linsert $args 0 $n $command]]}
 }
}
