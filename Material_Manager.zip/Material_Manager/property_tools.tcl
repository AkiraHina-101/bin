# Use native property cards. Physical parameters are edited by the user, not inferred.
namespace eval ::hmm_props {
    variable editing
    if {![info exists editing]} {set editing 0}
    variable cardType
    if {![info exists cardType]} {set cardType ""}
    variable cards
    if {![info exists cards]} {set cards [dict create]}
    # Basic Material parameters the sidebar may show.
    variable materialColumns {E G NU RHO A TREF GE}
}
proc ::hmm_props::require_clean {} {
    variable editing
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {error "Reading Component masses; try again in a moment"}
    if {$editing || $::hmm_images::busy} {error "Finish the current operation first"}
    if {$::hmm_apply::blocked} {error "Inspect the previous failed operation before reloading"}
    if {[string tolower [hm_info templatetype]] ne "nastran"} {error "The Nastran user profile is required (current template: [hm_info templatetype])"}
    if {![info exists ::hmm_apply::baseline] || [hm_info currentfile] ne $::hmm_apply::baselineModel} {error "Reload model data first"}
    if {[llength [dict get [::hmm_apply::plan] changes]]} {error "Apply or revert pending assignments before creating/editing properties"}
    if {[::hmm::read_model] ne $::hmm_apply::baseline} {error "The model changed outside the tool; reload first"}
}
# Like require_clean but without the comparison with the last read model: used by Reload, which is how a model that changed
# outside the tool is read again.
proc ::hmm_props::require_idle {} {
    variable editing
    if {[info exists ::hmm::massBusy] && $::hmm::massBusy} {error "Reading Component masses; try again in a moment"}
    if {$editing || $::hmm_images::busy} {error "Finish the current operation first"}
    if {$::hmm_apply::blocked} {error "Inspect the previous failed operation before reloading"}
    if {[string tolower [hm_info templatetype]] ne "nastran"} {error "The Nastran user profile is required (current template: [hm_info templatetype])"}
}
proc ::hmm_props::plan {ids card} {
    if {$card ni {PBUSH PSHELL PSOLID}} {error "Choose PBUSH, PSHELL or PSOLID"}
    if {![llength $ids]} {error "Select at least one component"}
    set used [dict create]
    dict for {pid data} $::hmm::properties {dict set used [dict get $data name] 1}
    set result {}
    foreach cid [lsort -unique -integer $ids] {
        if {![dict exists $::hmm::components $cid]} {error "Unknown component $cid"}
        if {[dict get $::hmm::components $cid property] != 0} {error "Component $cid already has a property; nothing was created"}
        set base "[dict get $::hmm::components $cid name]_$card"
        set name $base;set suffix 2
        while {[dict exists $used $name]} {set name "${base}_$suffix";incr suffix}
        dict set used $name 1
        lappend result [dict create component $cid card $card name $name]
    }
    return $result
}
proc ::hmm_props::create {ids card} {
    require_clean
    set plan [plan $ids $card]
    # Check compatibility without choosing or setting any physical parameter.
    foreach item $plan {
        set cid [dict get $item component]
        ::hmm_apply::check_element_card $cid $card
        foreach value [::hmm_apply::element_values [hm_getvalue comps id=$cid dataname=elements] propertyid] {
            if {$value != 0} {error "Component $cid has element-level property assignments; resolve them first"}
        }
    }
    set folder [::hmm::evidence_folder material_manager_properties]
    file mkdir $folder
    ::hmm_apply::save_data [file join $folder before.dict] $::hmm_apply::baseline
    ::hmm_apply::save_data [file join $folder plan.dict] $plan
    file copy [file join $::hmm::projectDir property_tools.tcl] [file join $folder property_tools_snapshot.tcl]
    set created {};set assigned {};set history 0
    set originalMark [hm_getmark props 1]
    set code [catch {
        ::hmm::history_begin {Material Manager create properties}
        set history 1
        foreach item $plan {
            set cid [dict get $item component]
            set name [dict get $item name]
            *createentity props cardimage=$card name=$name
            set pid [hm_latestentityid props]
            lappend created $pid
            if {[hm_getvalue props id=$pid dataname=cardimage] ne $card || [hm_getvalue props id=$pid dataname=name] ne $name} {error "Created property readback failed"}
            lappend assigned [list $cid $pid]
            *setvalue comps id=$cid propertyid=$pid
            if {[hm_getvalue comps id=$cid dataname=propertyid] != $pid} {error "Created property assignment readback failed"}
            foreach value [::hmm_apply::element_values [hm_getvalue comps id=$cid dataname=elements] propertyid] {
                if {$value != $pid} {error "Element property assignment readback failed"}
            }
        }
        ::hmm_apply::save_data [file join $folder after.dict] [::hmm::read_model]
        ::hmm::history_end {Material Manager create properties}
        set history 0
    } message options]
    if {$code} {
        set errors {}
        foreach pair [lreverse $assigned] {
            set cid [lindex $pair 0]
            if {[catch {*setvalue comps id=$cid propertyid=0} error]} {lappend errors $error}
        }
        if {![llength $errors] && [llength $created]} {
            if {[catch {*createmark props 1 {*}$created;*deletemark props 1} error]} {lappend errors $error}
            if {[catch {*clearmark props 1;if {[llength $originalMark]} {*createmark props 1 {*}$originalMark}} error]} {lappend errors $error}
        }
        if {$history} {if {[catch {::hmm::history_end {Material Manager create properties}} error]} {lappend errors $error}}
        if {[catch {if {[::hmm::read_model] ne $::hmm_apply::baseline} {error "Rollback differs from the original model"}} error]} {lappend errors $error}
        if {[llength $errors]} {set ::hmm_apply::blocked 1}
        catch {::hmm_apply::save_data [file join $folder result.dict] [list status FAIL error $message rollback_errors $errors created $created assigned $assigned]}
        if {[llength $errors]} {error "Creation failed; rollback incomplete. Inspect $folder"}
        error "Creation failed; model restored. $message"
    }
    set result [dict create created $created assigned $assigned card $card evidence $folder]
    set ::hmm_apply::baseline [::hmm::read_model]
    foreach name {components properties materials} value $::hmm_apply::baseline {set ::hmm::$name $value}
    if {[namespace exists ::hmm_launch]} {set ::hmm_launch::baseline $::hmm_apply::baseline}
    catch {::hmm_apply::save_data [file join $folder result.dict] [dict merge $result [dict create status PASS pid [pid] build [hm_info -appinfo DISPLAYVERSION] parameters native_defaults_only]]}
    return $result
}
proc ::hmm_props::refresh_model {} {
    ::hmm::load_model
    catch ::hmm_flow::upgrade_queues
    # Queued changes in any tab whose model value changed meanwhile (for example by an Apply in another
    # tab) are stale: drop them instead of showing them as pending.
    if {![catch ::hmm_props::queue_revalidate dropped] && [llength $dropped]} {
        ::hmm_ui::warn "[llength $dropped] pending change(s) dropped, the model changed"
    }
    if {[namespace exists ::hmm_launch]} {set ::hmm_launch::baseline [list $::hmm::components $::hmm::properties $::hmm::materials]}
    # A different model was opened in HyperMesh: its images replace those of the old one.
    catch {::hmm_ui::image_dir_sync}
    ::hmm::sync_rows
}
proc ::hmm_props::editor_components {ids} {
    if {![llength $ids]} {error "Select at least one component"}
    foreach cid $ids {if {![dict exists $::hmm::components $cid]} {error "Unknown component $cid"}}
    return [lsort -unique -integer $ids]
}
proc ::hmm_props::component_identity {} {
    set result {}
    foreach cid [lsort -integer [dict keys $::hmm::components]] {lappend result $cid [dict get $::hmm::components $cid name]}
    return $result
}

# Embed the installed HyperMesh Entity Editor; never reparent the global popup.
proc ::hmm_props::sidebar_destroy {} {
    variable sidebarTimer
    if {[info exists sidebarTimer] && $sidebarTimer ne ""} {after cancel $sidebarTimer;set sidebarTimer ""}
    native_tabs_destroy
    set key hmm_material_sidebar
    if {$key in [::hm::PropertyAreaViewManager::GetKeyList]} {
        ::hm::paController::cleanup::DestroyPropertyArea $key
        ::hm::PropertyAreaViewManager::UpdateData $key 1 status
        ::hm::PropertyAreaViewManager::DeleteKey $key
    }
    unset -nocomplain ::hm::paController::funcs::_paControllerVars(${key}|bbcreate)
    unset -nocomplain ::hm::notebooktab::panedwindow::${key}
    variable sidebarIds {}
}
proc ::hmm_props::sidebar_destroy_event {widget} {
    if {$widget eq "$::hmm::window.sidebar"} {::hmm_props::sidebar_destroy}
}
proc ::hmm_props::sidebar_create {parent} {
    if {[llength [info commands ::hmm_ui::create_pages]]} {::hmm_ui::create_pages $parent;return}
    table_preferences
    if {![dict size $::hmm_lib::records]} {
        set bundled [file join $::hmm::projectDir library jis_23_N_mm_s_tonne.csv]
        if {[catch {::hmm_lib::load $bundled} message]} {set ::hmm_lib::notice "Library: $message"}
    }
    variable sidebarIds {}
    variable editorTarget {}
    variable targetSelection {}
    variable sidebarKind components
    variable sidebarTimer ""
    set key hmm_material_sidebar
    ::hm::PropertyAreaViewManager::AddKey $key
    ::hm::PropertyAreaViewManager::UpdateData $key 1 contextmenustatus
    ttk::notebook $parent.tabs
    pack $parent.tabs -fill both -expand 1
    foreach {tab title} {details Entity properties Properties materials Materials} {
        ttk::frame $parent.tabs.$tab
        $parent.tabs add $parent.tabs.$tab -text $title
    }
    bind $parent.tabs <<NotebookTabChanged>> ::hmm_props::native_tab_changed
    set body $parent.tabs.details
    # Native callbacks use the registered pane for reference editors.
    array set ::hm::notebooktab::panedwindow::${key} [list propertyarea:frame $body propertyarea:status 1]
    set ::hm::paController::funcs::_paControllerVars(${key}|bbcreate) 0
    ::hm::paController::funcs::CreatePropertyAreaWidget $key
    bind $parent <Destroy> [list ::hmm_props::sidebar_destroy_event %W]
}
proc ::hmm_props::sidebar_schedule {} {
    variable sidebarTimer
    if {[info exists sidebarTimer] && $sidebarTimer ne ""} {after cancel $sidebarTimer}
    set sidebarTimer [after 100 ::hmm_props::sidebar_update]
}
# Accepted native values may queue a rebuild; refresh independently after acceptance.
proc ::hmm_props::sidebar_native_accepted {command code result operation} {
    if {$code != 0 || "hmm_material_sidebar" ni $command} {return}
    # SetPropertyValue answers whether the value was accepted; SetValue (a value picked from a list, such as a Material) does not.
    if {[lindex $command 0] eq "::hm::paController::funcs::SetPropertyValue" && !$result} {return}
    # Several setter calls in a row (a list pick may call both) read the model once.
    variable readbackTimer
    if {[info exists readbackTimer]} {after cancel $readbackTimer}
    set readbackTimer [after 150 ::hmm_props::sidebar_readback]
}
proc ::hmm_props::sidebar_readback {} {
    if {![winfo exists $::hmm::window.sidebar]} {return}
    # The Entity Editor writes the model directly: read it again, keep the queued changes that are still valid, and refresh the main
    # table and the sidebar tables (a Property whose Material was changed there must show it at once, also while changes are pending).
    set old [component_identity]
    if {[catch {model_check 1} message]} {set ::hmm::status "\u26a0 Error: reload after Entity edit: $message";return}
    if {$old ne [component_identity]} {::hmm_images::clear;::hmm::sync_rows}
}
foreach setter {SetPropertyValue SetValue} {
    if {[llength [info commands ::hm::paController::funcs::$setter]]} {
        set callback ::hmm_props::sidebar_native_accepted
        if {[lsearch -exact [trace info execution ::hm::paController::funcs::$setter] [list leave $callback]] < 0} {
            trace add execution ::hm::paController::funcs::$setter leave $callback
        }
    }
}
foreach obsolete {schedule_native edit_native editor_window open_entity_editor watch_editor finish_editor} {
    if {[llength [info commands ::hmm_props::$obsolete]]} {rename ::hmm_props::$obsolete {}}
}

proc ::hmm_props::native_tabs_destroy {} {
    legacy_native_views_destroy
    variable gridRows
    unset -nocomplain gridRows
}
proc ::hmm_props::data_metadata {type} {
    set view hmm_metadata_$type
    hmbr_content registerview $view [hm_getentitytype $type]
    return [hmbr_content getpropertieslist $view [hm_getentitytypedisplayname $type 0]]
}
proc ::hmm_props::data_value {type id attribute label cards {rowState ""}} {
    if {$rowState eq ""} {
        set card [hm_getvalue $type id=$id dataname=cardimage]
        set attributes [hm_attributelist $type $id id -byid]
    } else {foreach {card attributes} $rowState break}
    if {[llength $cards] && $card ni $cards} {return ""}
    if {$type eq "properties" && $label eq "Material"} {
        if {$card eq "PBUSH"} {return "Not used"}
        set mid [hm_getvalue props id=$id dataname=materialid]
        if {$mid == 0} {return "Unassigned"}
        return "$mid | [hm_getvalue mats id=$mid dataname=name]"
    }
    if {$attribute ni $attributes} {return ""}
    if {[hm_attributestatus $type $id $attribute -byid] == 0} {return ""}
    return [hm_getvalue $type id=$id dataname=$attribute]
}
proc ::hmm_props::table_preferences {} {
    variable propFilter
    if {![info exists propFilter]} {set propFilter All}
    variable columnVisible
    if {[array exists columnVisible]} {return}
    array set columnVisible {E 1 NU 1 RHO 1 GE 1}
    set path [preferences_path]
    if {[file isfile $path] && [file size $path] < 32768} {
        set f [open $path r];fconfigure $f -encoding utf-8;set text [read $f];close $f
        if {[catch {dict size $text}] == 0} {
            dict for {label visible} $text {if {$visible in {0 1}} {set columnVisible($label) $visible}}
        }
    }
}
proc ::hmm_props::preferences_path {} {
    variable preferenceFile
    if {![info exists preferenceFile]} {set preferenceFile [file join $::hmm::projectDir settings material_columns.dict]}
    return $preferenceFile
}
# Whether the optional property column $label is shown for the type filter (kept per filter).
proc ::hmm_props::prop_column_on {filter label} {
    variable propColumn
    if {![info exists propColumn($filter,$label)]} {set propColumn($filter,$label) [expr {($filter eq "PSHELL" && $label eq "T") || ($filter eq "PBUSH" && $label in {K1 K2 K3 K4 K5 K6})}]}
    return $propColumn($filter,$label)
}
proc ::hmm_props::data_rebuild {type} {
    require_clean
    set frame $::hmm::window.sidebar.split.tabs.$type
    set selected {}
    if {[winfo exists $frame.table] && [info exists ::hmm_props::gridRows($type)]} {
        foreach row [$frame.table selectionget rows] {
            regsub {^tag:} $row "" row
            if {[dict exists $::hmm_props::gridRows($type) $row]} {lappend selected [dict get $::hmm_props::gridRows($type) $row]}
        }
    }
    foreach child {table bar types library} {if {[winfo exists $frame.$child]} {destroy $frame.$child}}
    data_mount $type
    dict for {row id} $::hmm_props::gridRows($type) {if {$id in $selected} {$frame.table selectionadd $row,name}}
}
proc ::hmm_props::columns_changed {} {
    if {[catch {
        require_clean
        set path [preferences_path];file mkdir [file dirname $path]
        set f [open "$path.tmp" w];fconfigure $f -encoding utf-8
        puts $f [array get ::hmm_props::columnVisible];close $f
        file rename -force "$path.tmp" $path
        data_rebuild materials
    } message]} {set ::hmm::status "Columns: $message"}
}
proc ::hmm_props::type_changed {} {
    set list $::hmm::window.sidebar.split.tabs.properties.types.list
    set index [$list curselection]
    if {![llength $index]} {return}
    set kind [lindex $::hmm_props::propKinds [lindex $index 0]]
    if {$kind eq $::hmm_props::propFilter} {return}
    if {[catch {require_clean;set ::hmm_props::propFilter $kind;data_rebuild properties} message]} {set ::hmm::status "Property type: $message"}
}
proc ::hmm_props::library_bar {frame} {
    if {[dict size $::hmm_lib::records]} {set ::hmm_lib::notice "[dict size $::hmm_lib::records] entries | MPa / tonne/mm3"}
    ttk::labelframe $frame.library -text "Library" -padding {8 4}
    ttk::label $frame.library.notice -textvariable ::hmm_lib::notice
    pack $frame.library.notice -side top -anchor w
    ttk::frame $frame.library.actions
    set row $frame.library.actions
    ttk::combobox $row.choice -state readonly -width 19 -textvariable ::hmm_lib::selected -values [dict keys $::hmm_lib::records]
    bind $row.choice <<ComboboxSelected>> ::hmm_lib::preview
    ttk::button $row.choose -text "Use match" -width 10 -command {::hmm_lib::action choose}
    ttk::button $row.rename -text "Rename" -width 10 -command {::hmm_lib::action rename}
    ttk::button $row.create -text "Create" -width 10 -command {::hmm_lib::action create}
    grid $row.choice -row 0 -column 0 -columnspan 2 -sticky ew -padx 3 -pady 3
    grid $row.create -row 0 -column 2 -sticky ew -padx 3 -pady 3
    grid $row.choose -row 1 -column 1 -sticky ew -padx 3 -pady 3
    grid $row.rename -row 1 -column 2 -sticky ew -padx 3 -pady 3
    grid columnconfigure $row 0 -weight 1
    pack $row -side top -anchor w
    ::hmm_lib::preview
    ttk::label $frame.library.preview -textvariable ::hmm_lib::previewText
    pack $frame.library.preview -side top -anchor w
    pack $frame.library -side top -fill x -pady {2 5}
}
proc ::hmm_props::data_mount {type} {
    variable gridSchemas
    variable gridRows
    variable gridMetadata
    set frame $::hmm::window.sidebar.split.tabs.$type
    set table $frame.table
    set metadata [data_metadata $type]
    if {$type eq "properties"} {
        set filtered [dict create]
        # The Material is always shown; every other field is an optional column chosen in the header menu (right click).
        # Default: the thickness T for PSHELL. Parameters are still edited in the Entity pane except T NSM Z1 Z2 I12_T3 TS_T.
        set filter $::hmm_props::propFilter
        dict for {attribute data} $metadata {
            set label [dict get $data label]
            if {$filter ne "All" && $filter ni [dict get $data clientdata]} {continue}
            if {$label ne "Material" && ![prop_column_on $filter $label]} {continue}
            dict set filtered $attribute $data
        }
        set metadata $filtered
    }
    if {[winfo exists $table] && (![info exists gridMetadata($type)] || $metadata ne $gridMetadata($type))} {
        foreach child {table bar types library} {if {[winfo exists $frame.$child]} {destroy $frame.$child}}
        unset -nocomplain gridRows($type)
    }
    if {![winfo exists $table]} {
        set gridMetadata($type) $metadata
        set ordered {}
        set preferred [expr {$type eq "materials" ? {E G NU RHO A TREF GE} : {Material T NSM MID1_blank MID2_opts MID3_opts}}]
        foreach label $preferred {
            dict for {attribute data} $metadata {if {[dict get $data label] eq $label} {lappend ordered $attribute}}
        }
        foreach attribute [dict keys $metadata] {if {$attribute ni $ordered} {lappend ordered $attribute}}
        set gridSchemas($type) [dict create]
        ttk::frame $frame.bar
        ttk::button $frame.bar.edit -text "Edit..." -width 10 -command [list ::hmm_props::data_edit_selected $type]
        ttk::button $frame.bar.reload -text "Refresh" -width 10 -command [list ::hmm_props::data_reload $type]
        pack $frame.bar.edit $frame.bar.reload -side left -padx 3
        pack $frame.bar -side top -fill x
        if {$type eq "materials"} {
            ttk::menubutton $frame.bar.columns -text Columns -width 10 -menu $frame.bar.columns.menu
            menu $frame.bar.columns.menu -tearoff 0
            foreach label $::hmm_props::materialColumns {
                if {![info exists ::hmm_props::columnVisible($label)]} {set ::hmm_props::columnVisible($label) [expr {$label in {E NU RHO GE}}]}
                $frame.bar.columns.menu add checkbutton -label $label -variable ::hmm_props::columnVisible($label) -command ::hmm_props::columns_changed
            }
            ttk::button $frame.bar.import -text "Import..." -width 10 -command {::hmm_lib::action import}
            pack $frame.bar.columns $frame.bar.import -side left -padx 3
            library_bar $frame
        } else {
            ttk::frame $frame.types -width 120
            ttk::label $frame.types.title -text "Property types"
            listbox $frame.types.list -exportselection 0 -width 15 -height 8
            pack $frame.types.title -anchor w
            pack $frame.types.list -fill both -expand 1
            pack $frame.types -side left -fill y -padx {0 5}
            set counts [dict create All 0]
            foreach id [hm_entitylist props id all] {
                set card [hm_getvalue props id=$id dataname=cardimage]
                dict incr counts All;dict incr counts $card
            }
            set ::hmm_props::propKinds [linsert [lsort [lrange [dict keys $counts] 1 end]] 0 All]
            foreach kind $::hmm_props::propKinds {$frame.types.list insert end "$kind ([dict get $counts $kind])"}
            set index [lsearch -exact $::hmm_props::propKinds $::hmm_props::propFilter]
            if {$index >= 0} {$frame.types.list selection set $index}
            bind $frame.types.list <<ListboxSelect>> ::hmm_props::type_changed
        }
        hwtk::datatable $table -variable ::hmm_props::grid_$type -closeeditor 1
        pack $table -side left -fill both -expand 1
        $table columncreate id -text ID -type real -precisionvalue 0 -width 55 -itemjustify right -justify center -expand 0 -editable 0
        $table columncreate name -text Name -type str -width 150 -itemjustify left -justify center -editable 0
        $table columncreate card -text Card -type str -width 75 -itemjustify left -justify center -editable 0
        foreach attribute $ordered {
            set data [dict get $metadata $attribute]
            set label [dict get $data label]
            if {$type eq "materials" && ($label ni $::hmm_props::materialColumns || ![info exists ::hmm_props::columnVisible($label)] || !$::hmm_props::columnVisible($label))} {continue}
            set editable [expr {$type eq "materials" ? $label in {E G NU RHO A TREF GE ST SC SS} : $label in {T NSM Z1 Z2 I12_T3 TS_T}}]
            dict set gridSchemas($type) f$attribute [list $attribute $label [dict get $data clientdata] $editable]
            $table columncreate f$attribute -text $label -type str -width 95 -itemjustify left -justify center -editable $editable -valueaccept [list ::hmm_props::data_accept $type %W %I %C %V %P]
        }
        if {$type eq "materials"} {$table columncreate library -text "Library match" -type combobox -width 120 -itemjustify left -justify center -editable 1}
    }
    data_reload $type
}
proc ::hmm_props::data_reload {type} {
    variable gridSchemas
    variable gridRows
    set table $::hmm::window.sidebar.split.tabs.$type.table
    if {![winfo exists $table]} {return}
    require_clean
    upvar #0 ::hmm_props::grid_$type values
    set current [$table rowlist]
    if {[llength $current]} {$table rowdelete $current}
    array unset values
    set gridRows($type) [dict create]
    set ids [lsort -integer [hm_entitylist $type id all]]
    if {$type eq "properties" && $::hmm_props::propFilter ne "All"} {
        set filtered {}
        foreach id $ids {if {[hm_getvalue props id=$id dataname=cardimage] eq $::hmm_props::propFilter} {lappend filtered $id}}
        set ids $filtered
    }
    set idWidth [font measure TkDefaultFont ID]
    foreach id $ids {set idWidth [expr {max($idWidth, [font measure TkDefaultFont $id])}]}
    $table columnconfigure id -width [expr {$idWidth + 28}] -itemjustify right -justify center -expand 0
    if {![llength $ids]} {return}
    set rows [$table rowinsert end entities -count [llength $ids]]
    foreach row $rows id $ids {
        dict set gridRows($type) $row $id
        set values($row,name) [hm_getvalue $type id=$id dataname=name]
        set values($row,id) $id
        set values($row,card) [hm_getvalue $type id=$id dataname=cardimage]
        set rowState [list $values($row,card) [hm_attributelist $type $id id -byid]]
        dict for {column spec} $gridSchemas($type) {
            foreach {attribute label cards editable} $spec break
            set values($row,$column) [data_value $type $id $attribute $label $cards $rowState]
        }
        if {$type eq "materials"} {set values($row,library) [::hmm_lib::label $id]}
    }
    $table liveupdate 1
    # Keep the native integer alignment and compact width after row updates.
    $table columnconfigure id -width [expr {$idWidth + 28}] -itemjustify right -justify center -expand 0
}
proc ::hmm_props::data_edit_selected {type} {
    variable gridRows
    set table $::hmm::window.sidebar.split.tabs.$type.table
    set rows [$table selectionget rows]
    if {[llength $rows] != 1} {set ::hmm::status "Select one row to edit in Entity";return}
    show_entity $type [dict get $gridRows($type) [lindex $rows 0]]
}
proc ::hmm_props::data_accept {type table row column value previous} {
    variable gridRows
    variable gridSchemas
    upvar #0 ::hmm_props::grid_$type values
    if {[catch {
        require_clean
        set id [dict get $gridRows($type) $row]
        foreach {attribute label cards editable} [dict get $gridSchemas($type) $column] break
        if {!$editable} {error "Edit this field in Entity"}
        if {![string is double -strict $value] || [regexp -nocase {nan|inf} $value]} {error "Enter a finite number; use Entity to clear a field"}
        set card [hm_getvalue $type id=$id dataname=cardimage]
        if {$card ni $cards} {error "Field $label is not available on $card"}
        set actual [data_value $type $id $attribute $label $cards]
        if {$actual ne $values($row,$column)} {error "Field changed outside the table; reload it first"}
        set present [expr {$attribute in [hm_attributelist $type $id id -byid]}]
        if {$present && [hm_attributestatus $type $id $attribute -byid] != 0} {
            *setvalue $type id=$id $attribute=$value
        } else {
            *setvalue $type id=$id STATUS=1 $attribute=$value
        }
        set readback [hm_getvalue $type id=$id dataname=$attribute]
        if {![string is double -strict $readback] || $readback != $value} {set ::hmm_apply::blocked 1;error "Native value readback differs; inspect the model"}
        set values($row,$column) $readback
        if {$type eq "materials"} {set values($row,library) [::hmm_lib::label $id]}
        set ::hmm::status "Updated $type $id: $label"
    } message]} {set ::hmm::status "\u26a0 Error: $message";return 0}
    return 1
}
proc ::hmm_props::legacy_native_views_destroy {} {
    variable nativeMounted
    variable nativePoll
    if {[info exists nativePoll] && $nativePoll ne ""} {after cancel $nativePoll;set nativePoll ""}
    if {![array exists nativeMounted]} {return}
    foreach type [array names nativeMounted] {
        set view $type
        set owned 1
        if {$view in [hwbrmanager window names]} {
            hwbrmanager window current $view
            set owned [string match "$::hmm::window.sidebar.split.tabs.$type*" [hwbrmanager window frame]]
        }
        if {$owned} {
            hmbr::viewmgr unpost $view 1
            hmbr::viewmgr updateviewinfo $view enableattributecolumns $nativeMounted($type)
        }
        unset nativeMounted($type)
    }
}

# ID rule for every entity the New flow makes: the largest existing id + 1, so new ids are consecutive and never fill old gaps.
proc ::hmm_props::next_id {kind {skip ""}} {
    set max 0
    foreach id [hm_entitylist $kind id all] {if {$id != $skip && $id > $max} {set max $id}}
    return [expr {$max + 1}]
}
# An entity created without an explicit id (a copy) is renumbered to the largest other id + 1 when HyperMesh placed it elsewhere.
proc ::hmm_props::settle_id {kind id} {
    set target [next_id $kind $id]
    if {$id == $target} {return $id}
    set oldMark [hm_getmark $kind 1]
    *createmark $kind 1 $id
    *renumber $kind 1 $target 1 0 0
    *clearmark $kind 1;if {[llength $oldMark]} {*createmark $kind 1 {*}$oldMark}
    if {[lsearch -exact [hm_entitylist $kind id all] $target] < 0} {error "Could not renumber $kind $id to $target"}
    return $target
}
# Name rule for every entity the New flow makes: <card>_<id>, then <card>_<id>(1), (2), (3)... when that name is taken.
proc ::hmm_props::auto_name {kind id {used ""}} {
    set card [hm_getvalue $kind id=$id dataname=cardimage]
    if {$used eq ""} {
        foreach other [hm_entitylist $kind id all] {if {$other != $id} {lappend used [hm_getvalue $kind id=$other dataname=name]}}
    }
    set base ${card}_$id;set name $base;set i 1
    while {$name in $used} {set name "${base}($i)";incr i}
    ::hmm::native_edit {*setvalue $kind id=$id name=$name}
    if {[hm_getvalue $kind id=$id dataname=name] ne $name} {error "Could not name $kind $id $name"}
    return $name
}
# Entities this tool created and that no Apply has kept yet. Discard removes the ones nothing uses.
if {![info exists ::hmm_props::created]} {set ::hmm_props::created {}}
proc ::hmm_props::entity_used {kind id} {
    if {$kind eq "props"} {
        foreach cid [hm_entitylist comps id all] {if {[hm_getvalue comps id=$cid dataname=propertyid] == $id} {return 1}}
    } else {
        foreach pid [hm_entitylist props id all] {if {[hm_getvalue props id=$pid dataname=materialid] == $id} {return 1}}
    }
    foreach op [dict values [::hmm_flow::merged]] {
        if {$kind eq "props" && [dict get $op kind] eq "property" && [dict get $op target] == $id} {return 1}
        if {$kind eq "mats" && [dict get $op kind] eq "material" && [lindex [dict get $op target] 0] eq "model" && [lindex [dict get $op target] 1] == $id} {return 1}
    }
    return 0
}
proc ::hmm_props::drop_unused_created {} {
    set keep {};set removed 0
    foreach item $::hmm_props::created {
        lassign $item kind id
        if {[lsearch -exact [hm_entitylist $kind id all] $id] < 0} {continue}
        if {[entity_used $kind $id]} {lappend keep $item;continue}
        # A Material staged for a Property that is going away goes with it.
        if {$kind eq "props"} {foreach scope {components properties materials library} {set ::hmm_flow::queues($scope) [dict remove $::hmm_flow::queues($scope) m:$id]}}
        set oldMark [hm_getmark $kind 1]
        *createmark $kind 1 $id;*deletemark $kind 1
        *clearmark $kind 1;if {[llength $oldMark]} {*createmark $kind 1 {*}$oldMark}
        incr removed
    }
    set ::hmm_props::created $keep
    if {$removed} {refresh_model}
    return $removed
}
proc ::hmm_props::property_content {id} {
    set values [dict create]
    foreach attribute [lsort -integer [hm_attributelist props $id id -byid]] {
        dict set values $attribute [hm_getvalue props id=$id dataname=$attribute]
    }
    return [list [hm_getvalue props id=$id dataname=cardimage] [hm_getvalue props id=$id dataname=materialid] $values]
}
proc ::hmm_props::copy_for_components {ids source} {
    require_clean
    set ids [editor_components $ids]
    if {![dict exists $::hmm::properties $source] || $source == 0} {error "Choose an existing source Property"}
    set card [hm_getvalue props id=$source dataname=cardimage]
    if {$card ni {PBUSH PSHELL PSOLID}} {error "Copy supports PBUSH, PSHELL and PSOLID"}
    set contents [property_content $source]
    foreach cid $ids {
        ::hmm_apply::check_element_card $cid $card
        set old [dict get $::hmm::components $cid property]
        foreach value [::hmm_apply::element_values [hm_getvalue comps id=$cid dataname=elements] propertyid] {
            if {$value != $old} {error "Component $cid has element property overrides"}
        }
    }
    set existing [hm_entitylist props id all]
    set created {};set targets [dict create]
    set oldMark [hm_getmark props 1]
    set folder [::hmm::evidence_folder material_manager_property_copy]
    file mkdir $folder
    ::hmm_apply::save_data [file join $folder before.dict] [list source $source contents $contents targets $ids baseline $::hmm_apply::baseline]
    set code [catch {
        foreach cid $ids {
            *createentitysameas props $source
            set id [hm_latestentityid props]
            if {$id in $existing || $id in $created} {error "Native copy did not return a new Property ID"}
            lappend created $id
            if {[property_content $id] ne $contents} {error "Property copy differs from source"}
            set renumbered [settle_id props $id]
            if {$renumbered != $id} {set created [lreplace $created end end $renumbered];set id $renumbered}
            auto_name props $id
            dict set targets $cid $id
        }
        if {[property_content $source] ne $contents} {error "Source property changed"}
    } message options]
    if {$code} {
        set failed 0
        if {[llength $created]} {
            if {[catch {*createmark props 1 {*}$created;*deletemark props 1} problem]} {set failed 1}
        }
        if {$failed} {set ::hmm_apply::blocked 1}
        ::hmm_apply::save_data [file join $folder result.dict] [list status FAIL error $message rollback_failed $failed]
    }
    *clearmark props 1
    if {[llength $oldMark]} {*createmark props 1 {*}$oldMark}
    if {$code} {return -options $options $message}
    foreach id $created {lappend ::hmm_props::created [list props $id]}
    refresh_model
    dict for {cid id} $targets {::hmm::assign_property $cid $id}
    ::hmm::sync_rows
    ::hmm_apply::save_data [file join $folder result.dict] [list status STAGED source $source created $created assignments $targets]
    return $targets
}

# One-shot, PID-bound display request used only for explicit UI review.
proc ::hmm_props::consume_review_layout {} {
    set path [file join $::hmm::projectDir REVIEW_LAYOUT_REQUEST.txt]
    if {![file isfile $path]} {return}
    set data [string trim [::hmm_launch::read_bytes $path]]
    if {[llength $data] != 2} {error "Invalid UI review layout request"}
    foreach {target tab} $data break
    if {$target ne [pid]} {return}
    if {$tab ni {components properties materials library changes} || [clock seconds]-[file mtime $path] > 120} {error "Expired or invalid UI review layout request"}
    file delete $path
    after 200 [list ::hmm_props::apply_review_layout $tab]
}
proc ::hmm_props::apply_review_layout {tab} {
    if {![winfo exists $::hmm::window]} {return}
    if {[catch {
        require_clean
        wm state $::hmm::window zoomed
        $::hmm::window.sidebar.split.tabs select $::hmm::window.sidebar.split.tabs.$tab
        native_tab_changed
        after 200 ::hmm_props::review_sash
    } message]} {set ::hmm::status "UI review: $message"}
}
