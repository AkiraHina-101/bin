# CSV is data only. Exact decimal comparison never uses an epsilon or rounding.
namespace eval ::hmm_lib {
    foreach {key value} {records {} header {} choices {} path {} selected {} notice {No library loaded}} {
        variable $key
        if {![info exists $key]} {set $key $value}
    }
}
proc ::hmm_lib::decimal {text} {
    set text [string trim $text]
    if {[string length $text] > 80 || ![regexp {^([+-]?)([0-9]*)(?:\.([0-9]*))?(?:[eE]([+-]?[0-9]+))?$} $text -> sign whole fraction power] || "$whole$fraction" eq ""} {error "Invalid decimal: $text"}
    set power [string trimleft $power +]
    set negative [string match -* $power]
    set power [string trimleft [string trimleft $power -] 0]
    if {$power eq ""} {set power 0}
    if {[string length $power] > 3 || $power > 300} {error "Decimal exponent exceeds supported range"}
    if {$negative} {set power [expr {-$power}]}
    set power [expr {$power - [string length $fraction]}]
    set digits [string trimleft "$whole$fraction" 0]
    if {$digits eq ""} {return {0 0}}
    while {[string index $digits end] eq "0"} {set digits [string range $digits 0 end-1];incr power}
    if {$sign eq "-"} {set digits -$digits}
    return [list $digits $power]
}
proc ::hmm_lib::csv_rows {text} {
    # RFC4180 quoted fields, including commas, escaped quotes and newlines.
    set rows {};set row {};set field "";set state plain
    set text [string trimleft $text \ufeff]
    set text [string map [list \r\n \n \r \n] $text]
    foreach char [split $text ""] {
        if {$state eq "quoted"} {
            if {$char eq "\""} {set state closed} else {append field $char}
        } elseif {$state eq "closed" && $char eq "\""} {
            append field $char;set state quoted
        } elseif {$char eq "," || $char eq "\n"} {
            lappend row $field;set field "";set state plain
            if {$char eq "\n"} {if {$row ne {{}}} {lappend rows $row};set row {}}
        } elseif {$state eq "closed"} {error "Unexpected text after CSV quote"} elseif {$char eq "\""} {
            if {$field ne ""} {error "Unexpected CSV quote"};set state quoted
        } else {append field $char}
    }
    if {$state eq "quoted"} {error "Unclosed CSV quote"}
    if {$field ne "" || [llength $row]} {lappend row $field;lappend rows $row}
    return $rows
}
# The columns are found by the name in the header, in any order. Only the text before the first "(", "[" or "{" counts, so E, "E (MPa)"
# and E[MPa] are all the column E: the unit written there is a note for the reader, the tool never converts or checks it.
proc ::hmm_lib::column_key {cell} {
    set cell [string trim [string trimleft $cell \ufeff]]
    regsub {[\(\[\{].*$} $cell "" base
    set base [string tolower [string trim $base]]
    regsub -all {[ _-]+} $base " " base
    switch -- $base {
        name {return Name}
        e {return E}
        nu {return NU}
        rho {return RHO}
        ge {return GE}
        units - unit {return Units}
        source {return Source}
        group - "material group" - "type material" - type {return Group}
        "name jp" - "jp name" - "japanese name" - "name japanese" - "name ja" - "material name jp" - "\u548c\u540d" - "\u65e5\u672c\u8a9e\u540d" {return NameJP}
    }
    return ""
}
# Returns the records; parse_with_header also returns the header cells as written, so that Save writes the same columns back.
proc ::hmm_lib::parse {text} {return [lindex [parse_with_header $text] 0]}
proc ::hmm_lib::parse_with_header {text} {
    set rows [csv_rows $text]
    if {![llength $rows]} {error "The CSV file is empty"}
    set header [lindex $rows 0]
    set index [dict create];set position 0
    foreach cell $header {
        set key [column_key $cell]
        if {$key ne ""} {
            if {[dict exists $index $key]} {error "Header: the column $key appears twice (\"$cell\")"}
            dict set index $key $position
        }
        incr position
    }
    foreach need {Name E NU RHO} {
        if {![dict exists $index $need]} {error "Header: no $need column found. The header has: [join $header {, }]"}
    }
    set result [dict create];set line 1
    foreach row [lrange $rows 1 end] {
        incr line
        if {[llength $row] > [llength $header]} {error "Row $line has [llength $row] fields but the header has [llength $header]"}
        while {[llength $row] < [llength $header]} {lappend row ""}
        set record [dict create Group "" NameJP "" Source "" Units "" GE ""]
        foreach key {Name E NU RHO GE Units Source Group NameJP} {
            if {[dict exists $index $key]} {dict set record $key [string trim [lindex $row [dict get $index $key]]]}
        }
        set name [dict get $record Name]
        set e [dict get $record E];set nu [dict get $record NU];set rho [dict get $record RHO];set ge [dict get $record GE]
        if {[catch {
            if {![regexp {^[A-Za-z0-9][A-Za-z0-9_./+-]{0,63}$} $name]} {error "Name must use letters, digits and _ . / + - only (the Japanese name goes in its own column)"}
            if {[dict exists $result $name]} {error "Name is used twice"}
            foreach {label value} [list E $e NU $nu RHO $rho] {
                if {$value eq ""} {error "$label is empty"}
                if {[catch {decimal $value}]} {error "$label is not a number: $value"}
            }
            if {$ge ne "" && [catch {decimal $ge}]} {error "GE is not a number: $ge"}
            if {$e <= 0 || $rho <= 0 || $nu <= -1 || $nu >= 0.5 || ($ge ne "" && $ge < 0)} {error "E and RHO must be positive, NU between -1 and 0.5, GE not negative"}
        } problem]} {error "Row $line ($name): $problem"}
        set extra [dict create];set position 0
        foreach cell $header {
            if {[column_key $cell] eq ""} {dict set extra $cell [lindex $row $position]}
            incr position
        }
        dict set record Extra $extra
        dict unset record Name
        dict set result $name $record
    }
    if {![dict size $result] || [dict size $result] > 5000} {error "Library must contain 1 to 5000 records"}
    return [list $result $header]
}
# The bytes are read as UTF-8 (with or without BOM); a file that is not valid UTF-8 is read as Windows Japanese (CP932), what Excel
# writes for "CSV" in a Japanese locale.
proc ::hmm_lib::decode_text {bytes} {
    if {[string range $bytes 0 2] eq "\xef\xbb\xbf"} {return [encoding convertfrom utf-8 [string range $bytes 3 end]]}
    set text [encoding convertfrom utf-8 $bytes]
    if {[encoding convertto utf-8 $text] eq $bytes} {return $text}
    return [encoding convertfrom cp932 $bytes]
}
proc ::hmm_lib::load {file} {
    if {[file size $file] > 2097152} {error "CSV exceeds 2 MB"}
    set f [open $file rb];set bytes [read $f];close $f
    if {[catch {parse_with_header [decode_text $bytes]} result options]} {return -options $options "[file tail $file]: $result"}
    variable records [lindex $result 0]
    variable header [lindex $result 1]
    variable path [file normalize $file]
    variable choices [dict create]
    variable selected [lindex [dict keys $records] 0]
    variable notice "[dict size $records] entries"
    variable dirty 0
    return [dict size $records]
}
proc ::hmm_lib::native_values {id} {
    set result [dict create]
    foreach {label attr} {E 1 NU 3 RHO 4 GE 7} {
        dict set result $label [::hmm_props::data_value materials $id $attr $label MAT1]
    }
    return $result
}
proc ::hmm_lib::matches {values} {
    variable records
    set result {}
    dict for {name data} $records {
        set same 1
        foreach key {E NU RHO GE} {
            if {$key eq "GE" && [dict get $data $key] eq ""} {continue}
            set actual [dict get $values $key]
            if {$actual eq "" || [catch {decimal $actual} normalized] || $normalized ne [decimal [dict get $data $key]]} {set same 0;break}
        }
        if {$same} {lappend result $name}
    }
    return $result
}
# The short text of the Library match column: empty without a match, the library name when there is one, "N matches" when several
# library entries have the same parameters (they are listed in the dropdown of the cell). highlight(id) tells the table to colour the
# cell: there is something to choose (the Material has another name than the match, or several names match).
proc ::hmm_lib::label {id} {
    variable highlight
    variable matchNames
    set highlight($id) 0;set matchNames($id) {}
    if {[hm_getvalue mats id=$id dataname=cardimage] ne "MAT1"} {return ""}
    set matches [matches [native_values $id]]
    set matchNames($id) $matches
    if {![llength $matches]} {return ""}
    set name [hm_getvalue mats id=$id dataname=name]
    set highlight($id) [expr {[llength $matches] > 1 || $name ni $matches}]
    if {$name in $matches} {return $name}
    if {[llength $matches] == 1} {return [lindex $matches 0]}
    return "[llength $matches] matches"
}
# Choosing a name in the dropdown of the cell renames the Material at once (no Apply): the name only, the parameters are unchanged.
proc ::hmm_lib::pick {id name} {
    if {[hm_getvalue mats id=$id dataname=name] eq $name} {return 0}
    # A new name changes no mass: the masses already calculated are kept when the model is read again.
    set ::hmm::massAffected {}
    choose [list $id] $name
    return [rename_matches [list $id]]
}
proc ::hmm_lib::csv_field {text} {
    if {[regexp {[,"\n\r]} $text]} {return "\"[string map [list \" \"\"] $text]\""}
    return $text
}
# Writes the columns of the loaded file back in its own order and with its own header text (units written there stay as they are);
# columns the tool does not know are written back unchanged.
proc ::hmm_lib::serialize {} {
    variable records;variable header
    set columns [expr {[info exists header] && [llength $header] ? $header : {Name E NU RHO GE Units Source}}]
    set head {}
    foreach cell $columns {lappend head [csv_field $cell]}
    set lines [list [join $head ,]]
    dict for {name data} $records {
        set row {}
        foreach cell $columns {
            set key [column_key $cell]
            if {$key eq "Name"} {
                set value $name
            } else {
                # No expr here: it would rewrite a number such as 1.36E-09 as 1.36e-9.
                set value ""
                if {$key ne "" && [dict exists $data $key]} {
                    set value [dict get $data $key]
                } elseif {$key eq "" && [dict exists $data Extra $cell]} {
                    set value [dict get $data Extra $cell]
                }
            }
            lappend row [csv_field $value]
        }
        lappend lines [join $row ,]
    }
    return "[join $lines \n]\n"
}
# True when at least one record has a value in the optional column (Group, NameJP).
proc ::hmm_lib::has_values {key} {
    variable records
    dict for {name data} $records {if {[dict exists $data $key] && [dict get $data $key] ne ""} {return 1}}
    return 0
}
proc ::hmm_lib::selected_ids {} {
    set table $::hmm::window.sidebar.tabs.materials.table
    set ids {}
    foreach row [$table selectionget rows] {regsub {^tag:} $row "" row;lappend ids [dict get $::hmm_props::gridRows(materials) $row]}
    if {![llength $ids]} {error "Select Material rows first"}
    return [lsort -unique -integer $ids]
}
proc ::hmm_lib::preview {} {
    variable selected;variable records
    variable previewText ""
    if {![dict exists $records $selected]} {return}
    foreach key {E NU RHO GE} {
        set value [dict get $records $selected $key]
        if {$value eq ""} {set value "unspecified"}
        append previewText "$key: $value   "
    }
}
proc ::hmm_lib::choose {ids name} {
    variable records;variable choices
    ::hmm_props::require_clean
    if {![dict exists $records $name]} {error "Select a library entry"}
    foreach id $ids {if {$name ni [matches [native_values $id]]} {error "Material $id does not exactly match $name"}}
    foreach id $ids {dict set choices $id $name}
}
proc ::hmm_lib::snapshot {} {
    set result [dict create]
    foreach id [hm_entitylist mats id all] {
        set attrs [dict create]
        foreach attr [hm_attributelist mats $id id -byid] {dict set attrs $attr [list [hm_attributestatus mats $id $attr -byid] [hm_getvalue mats id=$id dataname=$attr]]}
        dict set result $id [list [hm_getvalue mats id=$id dataname=cardimage] $attrs]
    }
    return $result
}
proc ::hmm_lib::evidence {operation before} {
    set folder [::hmm::evidence_folder material_library]
    file mkdir $folder
    ::hmm_apply::save_data [file join $folder before.dict] [list operation $operation model [hm_info currentfile] state $before]
    return $folder
}
proc ::hmm_lib::rename_matches {ids} {
    ::hmm_props::require_clean
    variable choices;variable records
    if {![llength $ids]} {error "Select Material rows first"}
    set ids [lsort -unique -integer $ids]
    set changes [dict create];set names {}
    foreach id $ids {
        set matches [matches [native_values $id]]
        if {[dict exists $choices $id]} {set name [dict get $choices $id]} elseif {[llength $matches] == 1} {set name [lindex $matches 0]} else {error "Choose one matching library name for Material $id"}
        if {$name ni $matches} {error "Material $id changed; compare again"}
        if {$name in $names} {error "Duplicate target name $name; select one Material at a time"}
        lappend names $name;dict set changes $id $name
    }
    foreach id [hm_entitylist mats id all] {
        if {$id ni $ids && [hm_getvalue mats id=$id dataname=name] in $names} {error "Target name already exists on Material $id"}
    }
    set before [::hmm::read_model];set physical [snapshot]
    set expected $before;set materials [lindex $before 2]
    dict for {id name} $changes {dict set materials $id $name}
    lset expected 2 $materials
    set folder [evidence rename [list $before $physical $changes]]
    set code [catch {
        dict for {id name} $changes {*setvalue mats id=$id name=$name}
        if {[::hmm::read_model] ne $expected || [snapshot] ne $physical} {error "Rename readback differs"}
    } message options]
    if {$code} {
        set errors {}
        foreach id $ids {if {[catch {*setvalue mats id=$id name=[dict get [lindex $before 2] $id]} failure]} {lappend errors $failure}}
        if {[::hmm::read_model] ne $before || [snapshot] ne $physical} {lappend errors "Rollback differs";set ::hmm_apply::blocked 1}
        ::hmm_apply::save_data [file join $folder failure.dict] [list error $message rollback_errors $errors]
        return -options $options $message
    }
    ::hmm_apply::save_data [file join $folder result.dict] [list status PASS names $changes physical_unchanged 1]
    ::hmm_props::refresh_model
    return [dict size $changes]
}
# Creates a MAT1 from a library entry, or from explicit E/NU/RHO/GE values (a copy of a model Material).
proc ::hmm_lib::create {name {requested ""} {explicit ""}} {
    ::hmm_props::require_clean
    variable records
    if {$explicit ne ""} {
        set values $explicit
    } else {
        if {![dict exists $records $name]} {error "Select a library entry"}
        set values [dict get $records $name]
    }
    set before [::hmm::read_model];set physical [snapshot]
    set existing [hm_entitylist mats id all]
    set used [dict values [lindex $before 2]];set target $name;set suffix 2
    while {$target in $used} {set target "${name}_$suffix";incr suffix}
    if {$requested ne ""} {
        if {$requested in $used} {error "Material name already exists: $requested"}
        set target $requested
    }
    set folder [evidence create [list $before $physical $name $values]]
    set id ""
    set code [catch {
        set want [::hmm_props::next_id mats]
        *createentity mats cardimage=MAT1 name=$target id=$want
        set latest [hm_latestentityid mats]
        if {$latest in $existing || $latest != $want} {error "Native create returned an unexpected ID"};set id $latest
        foreach {key attr} {E 1 NU 3 RHO 4 GE 7} {
            set value [dict get $values $key]
            if {$value ne ""} {*setvalue mats id=$id STATUS=2 $attr=$value}
        }
        set actual [native_values $id]
        foreach key {E NU RHO GE} {
            set value [dict get $values $key]
            if {$value eq ""} {if {[dict get $actual $key] ne ""} {error "Unspecified $key became a value"}} elseif {[decimal $value] ne [decimal [dict get $actual $key]]} {error "Created $key readback differs"}
        }
        set expected $before;set materials [lindex $before 2];dict set materials $id $target;lset expected 2 $materials
        set after [snapshot];dict unset after $id
        if {[::hmm::read_model] ne $expected || $after ne $physical} {error "Existing model state changed during creation"}
    } message options]
    if {$code} {
        set errors {}
        if {$id ne ""} {
            set mark [hm_getmark mats 1]
            if {[catch {*createmark mats 1 $id;*deletemark mats 1} failure]} {lappend errors $failure}
            eval [linsert $mark 0 *createmark mats 1]
        }
        if {[::hmm::read_model] ne $before || [snapshot] ne $physical} {lappend errors "Rollback differs";set ::hmm_apply::blocked 1}
        ::hmm_apply::save_data [file join $folder failure.dict] [list error $message rollback_errors $errors]
        return -options $options $message
    }
    ::hmm_apply::save_data [file join $folder result.dict] [list status PASS id $id name $target parameters $actual]
    ::hmm_props::refresh_model
    return $id
}
proc ::hmm_lib::action {kind} {
    if {[catch {
        switch $kind {
            import {
                set file [tk_getOpenFile -parent $::hmm::window -initialdir [file join $::hmm::projectDir library] -filetypes {{{CSV files} {.csv}}}]
                if {$file eq ""} {return};load $file
            }
            choose {
                choose [selected_ids] $::hmm_lib::selected
                dict for {row id} $::hmm_props::gridRows(materials) {set ::hmm_props::grid_materials($row,library) [label $id]}
                $::hmm::window.sidebar.tabs.materials.table liveupdate 1
                return
            }
            rename {set count [rename_matches [selected_ids]];set ::hmm::status "Renamed $count Materials; parameters unchanged"}
            create {set id [create $::hmm_lib::selected];set ::hmm::status "Created MAT1 $id from $::hmm_lib::selected; not assigned"}
        }
        ::hmm_props::data_rebuild materials
    } message] == 1} {set ::hmm::status "Library: $message"}
}
