# Tcl 8.5. Staged relation changes, native preflight/readback and compensating rollback.
namespace eval ::hmm_apply {
    variable baseline
    variable baselineModel
    variable blocked
    if {![info exists blocked]} {set blocked 0}
}
proc ::hmm_apply::plan {} {
    variable baseline
    if {![info exists baseline]} {error "Reload model data before applying"}
    foreach {oldComps oldProps oldMats} $baseline break
    if {$oldMats ne $::hmm::materials} {error "Pending material names/IDs are not supported by Apply"}
    foreach {old current} [list $oldComps $::hmm::components $oldProps $::hmm::properties] {
        if {[lsort -integer [dict keys $old]] ne [lsort -integer [dict keys $current]]} {error "Pending ID changes are not supported by Apply"}
        dict for {id data} $old {
            if {[dict get $data name] ne [dict get $current $id name]} {error "Pending name changes are not supported by Apply"}
        }
    }
    set changes {};set changedComps {};set changedProps {};set affected [dict create]
    dict for {cid data} $::hmm::components {
        set old [dict get $oldComps $cid property];set target [dict get $data property]
        if {$old == $target} {continue}
        if {![dict exists $::hmm::properties $target]} {error "Unknown target property $target"}
        lappend changes [list comps $cid propertyid $old $target]
        lappend changedComps $cid
        dict set affected $cid 1
    }
    dict for {pid data} $::hmm::properties {
        set old [dict get $oldProps $pid material];set target [dict get $data material]
        if {$old == $target} {continue}
        if {$pid == 0 || $target == 0 || ![dict exists $::hmm::materials $target]} {error "Choose an existing material"}
        lappend changes [list props $pid materialid $old $target]
        lappend changedProps $pid
        foreach collection [list $oldComps $::hmm::components] {
            dict for {cid comp} $collection {if {[dict get $comp property] == $pid} {dict set affected $cid 1}}
        }
    }
    return [dict create changes $changes component_assignments $changedComps material_properties $changedProps affected_components [lsort -integer [dict keys $affected]]]
}
proc ::hmm_apply::element_values {ids field} {
    if {![llength $ids]} {return {}}
    return [hm_getvalue elems "user_ids=$ids" dataname=$field]
}
proc ::hmm_apply::check_element_card {cid card} {
    switch -- $card {
        PSHELL {set allowed {103 104 106 108}}
        PSOLID {set allowed {204 205 206 208 210 213 215 220}}
        PBUSH {set allowed {21}}
        default {error "Property card is not supported: $card"}
    }
    set elems [hm_getvalue comps id=$cid dataname=elements]
    foreach config [element_values $elems config] {
        if {$config ni $allowed} {error "Component $cid contains element config $config incompatible with $card"}
    }
    if {$card eq "PBUSH"} {
        foreach type [element_values $elems type] {if {$type != 6} {error "Component $cid is not a Nastran CBUSH"}}
    }
}
proc ::hmm_apply::validate_native {plan} {
    set elementChecks [dict create]
    foreach change [dict get $plan changes] {
        foreach {kind id field old target} $change break
        if {$kind eq "props"} {
            set card [hm_getvalue props id=$id dataname=cardimage]
            if {$card eq "PBUSH"} {error "PBUSH has its own stiffness/damping settings and does not use a Material reference"}
            if {$card ni {PSHELL PSOLID}} {error "Material Apply supports PSHELL and PSOLID only (property $id: $card)"}
            if {[hm_getvalue mats id=$target dataname=cardimage] ne "MAT1"} {error "Material Apply currently supports MAT1 only"}
            if {$card eq "PSHELL" && [hm_getvalue props id=$id dataname=MID1_blank] != 0} {error "Property $id has disabled MID1; edit it in the native card editor first"}
        } else {
            set elems [hm_getvalue comps id=$id dataname=elements]
            if {$target > 0} {
                set card [hm_getvalue props id=$target dataname=cardimage]
                check_element_card $id $card
            }
            foreach value [element_values $elems propertyid] {
                if {$value != $old} {error "Component $id has element property overrides; resolve them in HyperMesh first"}
            }
            dict set elementChecks $id $elems
        }
    }
    return $elementChecks
}
proc ::hmm_apply::write_value {change reverse} {
    foreach {kind id field old target} $change break
    set value [expr {$reverse ? $old : $target}]
    *setvalue $kind id=$id $field=$value
    if {[hm_getvalue $kind id=$id dataname=$field] != $value} {error "Native readback failed: $kind $id $field"}
}
proc ::hmm_apply::save_data {path data} {
    set f [::open "$path.tmp" w]
    fconfigure $f -encoding utf-8 -translation lf
    puts $f $data
    ::close $f
    file rename -force "$path.tmp" $path
}
proc ::hmm_apply::execute {} {
    variable baseline
    variable baselineModel
    variable blocked
    if {$blocked} {error "A previous rollback failed; inspect the model before reloading"}
    if {[info exists ::hmm_props::editing] && $::hmm_props::editing} {error "Finish native property Settings first"}
    if {[info exists ::hmm_images::busy] && $::hmm_images::busy} {error "Wait for image capture to finish"}
    if {[string tolower [hm_info templatetype]] ne "nastran"} {error "The Nastran user profile is required (current template: [hm_info templatetype])"}
    if {![info exists baselineModel] || [hm_info currentfile] ne $baselineModel} {error "The active model changed; reload data"}
    set plan [plan]
    if {![llength [dict get $plan changes]]} {error "No pending assignments"}
    set current [::hmm::read_model]
    if {$current ne $baseline} {error "Model assignments or names changed outside this tool; reload before Apply"}
    set checks [validate_native $plan]
    set wanted [list $::hmm::components $::hmm::properties $::hmm::materials]
    set folder [::hmm::evidence_folder material_manager_apply]
    file mkdir $folder
    save_data [file join $folder before.dict] [list model $baselineModel data $baseline]
    save_data [file join $folder plan.dict] $plan
    file copy [file join $::hmm::projectDir assignments.tcl] [file join $folder assignments_snapshot.tcl]
    set attempted {};set history 0
    set code [catch {
        ::hmm::history_begin {Material Manager assignments}
        set history 1
        foreach change [dict get $plan changes] {
            lappend attempted $change
            write_value $change 0
        }
        dict for {cid elems} $checks {
            set target [dict get $::hmm::components $cid property]
            foreach value [element_values $elems propertyid] {if {$value != $target} {error "Element property readback failed on component $cid"}}
        }
        set after [::hmm::read_model]
        if {$after ne $wanted} {error "Full assignment readback differs from the staged plan"}
        save_data [file join $folder after.dict] $after
        ::hmm::history_end {Material Manager assignments}
        set history 0
    } message options]
    if {$code} {
        set restoreErrors {}
        foreach change [lreverse $attempted] {
            if {[catch {write_value $change 1} problem]} {lappend restoreErrors $problem}
        }
        if {[catch {set restored [::hmm::read_model];if {$restored ne $baseline} {error "Rollback readback differs"}} problem]} {lappend restoreErrors $problem}
        if {$history} {if {[catch {::hmm::history_end {Material Manager assignments}} problem]} {lappend restoreErrors $problem}}
        if {[llength $restoreErrors]} {set blocked 1}
        catch {save_data [file join $folder result.dict] [list status FAIL pid [pid] build [hm_info -appinfo DISPLAYVERSION] error $message rollback_errors $restoreErrors attempted $attempted]}
        if {$blocked} {error "Apply failed; rollback incomplete. Inspect $folder"}
        error "Apply failed; previous assignments restored. $message"
    }
    set baseline $after
    if {[namespace exists ::hmm_launch]} {set ::hmm_launch::baseline $after}
    set warning ""
    if {[catch {save_data [file join $folder result.dict] [list status PASS pid [pid] build [hm_info -appinfo DISPLAYVERSION] component_assignments [llength [dict get $plan component_assignments]] material_properties [llength [dict get $plan material_properties]] affected_components [dict get $plan affected_components]]} problem]} {
        set warning "Model applied and verified; final receipt could not be saved: $problem"
    }
    return [dict merge $plan [dict create evidence $folder warning $warning]]
}
