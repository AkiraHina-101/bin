# MeshEdit (Equivalence bậc 2)

Gộp node trùng cho lưới bậc 2 (tria6/quad8/tetra10, lẫn bậc 1) trong HyperMesh 2022.3 mà không làm gãy cạnh tại node giữa.

## Cách dùng (cập nhật 22/11/2026)

Menu Test → **Equiv 2nd** mở cửa sổ nhỏ chỉ có hai nút, ở giữa cửa sổ chính HyperMesh và trên đúng màn hình đang chứa HyperMesh (kể cả màn hình bên trái/phía trên màn chính, tọa độ âm). Mỗi nút mở một panel chọn **hai node theo thứ tự** (Node 1 rồi Node 2), làm xong lại mở panel cho cặp tiếp theo; **proceed** không chọn gì thì dừng.

- **Keep id: Node 1 / Node 2** (tự tích): hai node thành một node tại vị trí Node 2, giữ id đã chọn (Node 1 thì đổi id bằng `*renumber` trong cùng bước Undo).
- **Split**: bấm một đỉnh (Node 1) rồi node thứ hai (Node 2). Với hai đỉnh đối diện của hai tam giác chung cạnh, tùy chọn **Equivalence** chuyển giữa hai cách:
  - *Bật* — đổi đường chéo sang cạnh nối hai đỉnh đã chọn (2 → 2 element). Không thêm node góc tại giao điểm.
  - *Tắt* (mặc định) — tạo node góc tại giao điểm của đường Node 1 – Node 2 với cạnh chung (giao điểm nhìn theo pháp tuyến mặt, tria6 dùng đường cong của cạnh). Chia các element trên cạnh đó tại node mới (2 → 4 với hai tam giác). Node giữa hai nửa cạnh nằm trên đường cong cũ.
  - Nếu Node 2 nằm trên hoặc sát cạnh cần chia, cả hai chế độ đều chia tại chính Node 2. Áp dụng cho tria3/tria6/tetra4/tetra10.

Bản đảo công tắc đạt **48/48** trên scratch HyperMesh `2022.3.0.24`. Probe gọi trực tiếp ô Equivalence và nút Split, dùng Tcl cấp cặp node, sau đó đọc lại kết nối, tọa độ giao điểm, node giữa và Undo. Đã xem ảnh cửa sổ. Chưa thử chọn cặp node bằng chuột trong bản này. [Kết quả](tests/runs/7d10229bdec747a2b068bbee7c7307f0/checks.txt) · [Ảnh cửa sổ](tests/runs/7d10229bdec747a2b068bbee7c7307f0/window_1.png)
  - Node giữa: cạnh không đổi giữ node giữa; node giữa sẵn có trên hai nửa cạnh được dùng lại, còn lại tạo mới; mỗi cạnh mới có đúng một node giữa dùng chung; node giữa cũ của cạnh bị cắt bị xóa khi không còn dùng. Giữ component và chiều element.
- **Replace** / **Equiv** (nút Equiv đã bỏ): Node 1 gộp vào Node 2, element của nó chuyển sang node còn lại; node giữa trên cạnh chung được gộp và đặt lại đúng cạnh; element suy biến (chứa cả hai node) bị xóa.

Mỗi lần là một bước Undo; kết quả ghi ở dòng trạng thái của cửa sổ và dòng thông báo HyperMesh.

## Cách làm

- Chỉ gộp node **góc** cách nhau ≤ Tolerance; giữ node id nhỏ nhất tại vị trí của nó. Element có hai góc bị gộp vào nhau thì từ chối.
- Cạnh sau gộp được nhiều element dùng với node giữa khác nhau: giữ một node giữa (id nhỏ nhất).
- Node giữa của cạnh có góc bị dời được đặt lại = trung điểm hai góc mới + độ lệch cũ so với trung điểm hai góc cũ (trung bình khi gộp nhiều node): cạnh thẳng vẫn thẳng, cạnh cong giữ độ cong, không bị gãy. Node giữa không bao giờ được gộp chỉ vì gần nhau.
- Node bị thay không còn element nào dùng thì bị xóa.

## Kiểm chứng (21/11/2026, HyperMesh 2022.3.0.24 batch, scratch riêng qua `run_probe.py`)

`tests/probe_equiv.tcl` PASS 11/11: hai lưới quad8 và hai lưới tria6 4x4 lệch 0,004 tại x = 4 (gộp 5 góc + 4 node giữa, mọi node giữa nằm đúng trung điểm, không còn node trùng ở mối nối, một Undo về đúng số element/node); cạnh cong lệch 0,05 giữ nguyên độ cong và dùng chung node giữa. Menu sinh lại, `build_menu.py --check` STATIC_PASS.

**Chưa kiểm:** cửa sổ (ảnh, vị trí giữa cửa sổ HyperMesh), tetra10, model người dùng; chưa chép dist, chưa commit.

## Thử trên model full (21/11/2026, `02-Test_Full_Model.hm`, 4.745.090 node, 2.836.205 element, chủ yếu tetra10)

- Cập nhật cả element liên quan ngoài vùng chọn: element dùng node góc bị gộp được đưa vào để đặt lại node giữa. Equivalence tìm thêm node góc của element xung quanh trong hộp bao vùng chọn (`*createmark nodes "by box"`), chỉ gộp cặp có ít nhất một node của vùng chọn, không bao giờ gộp node giữa.
- Nút **Midsides**: sau khi move node góc (native), node giữa bị trượt dọc cạnh (> 0,1 % chiều dài) được đưa về: bỏ phần dọc cạnh, giữ phần vuông góc (độ cong). Gồm cả element xung quanh dùng chung node góc.
- `tests/probe_full.tcl` (PSOLID_23, 240 tetra10 + 75 element xung quanh): move 16 node góc 0,3 mm → 667 cạnh gãy; Midsides → 0 (lệch dọc cạnh lớn nhất 7,7e-4), lập kế hoạch 130 ms. Phần Equivalence trên model full chưa chạy lại sau khi thêm tìm node xung quanh (bản trước tìm 0 vì chỉ xét node của vùng chọn).
- **Tốc độ:** mỗi lệnh ghi node (`*nodemodify`, `*setvalue x=`, `*translatemark` từng node) mất 0,33–0,5 s trên model này (167 node = 82 s), không đổi khi tắt vẽ, ẩn model, tắt command file; tắt ghi lịch sử chỉ giảm còn ~0,33 s. Diễn đàn Altair báo cùng hiện tượng với 50.000 node. Chưa có cách ghi hàng loạt; `*secondorderfix2` (native) và `*setoption` theo hướng dẫn tối ưu của Altair chưa thử xong (scratch không khởi động được ở lần cuối).

- Probe `tests/probe_pair.tcl` PASS 9/9 (quad8, tria6: thay lần lượt 5 node góc của mối nối, không chọn element nào; node giữa gộp và thẳng hàng; chọn node giữa bị từ chối; một Undo mỗi lần; cửa sổ có Node 1/Node 2/Replace/Midsides).
- Probe `tests/probe_pair.tcl` PASS 10/10 sau khi bỏ cửa sổ: thêm element suy biến bị xóa (2 element) và Equiv theo danh sách node (5 góc + 4 node giữa).
- Probe `tests/probe_pair.tcl` PASS 13/13 sau khi tách Replace (chỉ dời, không mất element) và Equiv (gộp, xóa element suy biến), cửa sổ chỉ có hai nút.
- Probe `tests/probe_pair.tcl` PASS 14/14 với Keep id (giữ id Node 1: còn đúng một node mang id Node 1 tại vị trí Node 2, Undo trả lại).
- Probe `tests/probe_pair.tcl` PASS 22/22 có Split: T-junction (chỉ tam giác lớn bị tách, tổng 4 element) và cạnh chung hai tam giác với node tự do (2 → 4), tria3 và tria6, node giữa dùng chung trên các cạnh mới, một Undo. Lỗi tìm được: `hm_info currentcollector` trả id nên `*currentcollector` treo HyperMesh — chỉ trả lại khi là tên component có thật.
- Split viết lại thành chia đôi cạnh tổng quát (người dùng báo lỗi với tetra10): probe PASS 26/26, thêm hai tetra4/tetra10 chung cạnh → 4, mọi cạnh có đúng một node giữa dùng chung, một Undo.
- Split tìm cạnh theo đường cạnh thật của tria6 (qua node giữa) thay vì dây cung: node treo trên cạnh cong (lệch dây cung > 5 %) vẫn được nhận. Cửa sổ hiện suốt lúc chọn, dòng trạng thái báo kết quả/lý do từng lần. Probe PASS 27/27 (thêm ca cạnh cong).
- Split thêm **đổi đường chéo**: khi Node 1 không nằm trên cạnh mà Node 1, Node 2 là hai đỉnh đối diện của hai tam giác chung cạnh (ca người dùng 6965942 / 7010939), cạnh chung được thay bằng cạnh Node 1 – Node 2 (2 element vẫn 2, tria6 giữ node giữa 4 cạnh ngoài, tạo node giữa mới). `tests/probe_rc.tcl` trên test4.bdf, part RC (tria6): đổi đường chéo và chia tại node treo trên cạnh cong (2 → 4) đều không tạo cạnh tự do mới, mỗi cạnh một node giữa, một Undo — PASS 4/4.
- Cửa sổ tách hai nhóm: **Replace** (Keep id) và **Split** (tùy chọn *Equivalence*: bật = chia tại chính Node 1 — dùng được cho node của part khác nằm sát cạnh; tắt = tạo node mới trên cạnh tại điểm gần Node 1 nhất, 2 → 4, hai part vẫn tách rời). probe_rc PASS 5/5 (thêm ca tắt Equivalence, Node 1 lệch cạnh 0,05).
- Split bật Equivalence: Node 2 chỉ ra cạnh (cạnh đối diện Node 2), Node 1 không cần nằm sát cạnh (part khác cách một khe): chia tại chính Node 1. Nếu Node 1 là đỉnh của tam giác bên kia cạnh thì đổi đường chéo. probe_rc PASS 6/6 (thêm Node 1 lệch 10 % cạnh), probe_pair PASS 27/27.

## Lịch sử 22/11/2026: tách Split theo Equivalence, vị trí cửa sổ

Ticket: `.scratch/equiv2nd/issues/01-split-equiv-modes.md` (cách hiểu tạm, **người dùng chưa xác nhận**) và `.scratch/elem-imprint/issues/02-window-on-host-monitor.md` (phần của MeshEdit).

- **Split**: Split trước đây (bật/tắt cho kết quả như nhau) trở thành Split thường khi tắt Equivalence. Tùy chọn Equivalence được định nghĩa lại như mục Cách dùng: bật thì hai đỉnh đối diện tạo node tại giao điểm (2 → 4) thay vì đổi đường chéo. Bỏ hành vi cũ "tắt = tạo node mới trên cạnh tại điểm gần Node 1 nhất, hai part vẫn tách rời". Mặc định tắt (nếu phiên HyperMesh đã mở tool trước đó, ô tích giữ giá trị cũ của phiên).
- **Lỗi có sẵn ở bản commit, đã sửa:** Split tetra4/tetra10 báo "Node 1 is not on an edge..." vì bước tìm cạnh chỉ xét tam giác, còn bước tìm theo cạnh nằm trong nhánh chết `if {1} ... else`. Khôi phục bước đó thành dự phòng `edge_near` (khi không có tam giác phù hợp). Lần PASS tetra cuối (21/11 21:04) có trước lần sửa 21:33 nên chưa bắt được.
- **Vị trí cửa sổ** (`place_center`): căn giữa theo khung Win32 của `[wm frame .]` (twapi `get_window_coordinates`), giữ trong vùng làm việc của màn hình chứa HyperMesh; bỏ kẹp `max(x,0)` và bỏ căn theo màn chính. Thiếu twapi thì căn theo `winfo` của `.`.
- Sự thật runtime 2022.3 (scratch, run `5b2ede2ea5084b07882233e0ea4d495a`): `[wm frame .]` là cửa sổ top-level HyperWorks (lớp `TkTopLevel`, tiêu đề "Untitled - HyperWorks 2022.3 - NastranMSC", `GetAncestor` root là chính nó), khung `-9 -9 2569 1389` khi phóng to; `winfo` của `.` là vùng nội dung `0 54 2560x1326`; `wm geometry .` báo sai `+64+64`. `twapi::get_display_monitors` trả thiết bị hiển thị, không phải HMONITOR: dùng `get_display_monitor_from_window` + `get_display_monitor_info` (khóa `-workarea`).
- **Lỗi probe, đã sửa:** `probe_pair`, `probe_rc`, `diag_speed`, `diag_split_user`, `survey_full` không ghi `identity.dict` nên `run_probe.py` không nhận và không dừng được scratch (các lần chạy trước để lại `hw_.exe`). Đã thêm dòng ghi identity; ba probe diag/survey chỉ sửa tĩnh, chưa chạy lại.

Kiểm chứng (HyperMesh 2022.3 scratch qua `run_probe.py`, mỗi scratch đã dừng; `mesh_edit.tcl` md5 `92ed143e24979831574943e6f753387e`):

- `tests/probe_pair.tcl` PASS 48/48 (run `8f2a893ef91148b7b47d13d1e326fdca`): 27 check cũ (gồm tetra) + 20 check Split chéo: hình vuông và hình diều, tria3/tria6, đường chéo tria6 cong. Tắt: vẫn 2 element, cạnh Node 1 – Node 2, số node không đổi, một Undo. Bật: một node mới đúng giao điểm tính tay ((1,1); (1,2; 1,2); cong: nghiệm 0,4f² − 10,4f + 6 = 0, sai lệch 5e-14), 4 element đều chứa node đó, 4 cạnh ngoài vẫn tự do, 4 cạnh trong mỗi cạnh 2 element cùng một node giữa, node giữa hai nửa nằm trên đường cong, không lật chiều, +1 node (tria3) / +4 (tria6), một Undo. Thêm check cửa sổ: ô Equivalence mặc định tắt, căn giữa khung HyperMesh. Lần chạy trước `dcef8f59838c4675ade767967849f36c` FAIL 2 (tetra, lỗi có sẵn nói trên).
- `tests/probe_rc.tcl` PASS 10/10 (run `7ba81982712e44e49efea386ca482b39`, `test4.bdf`, part RC, tria6): `swap.nonode` (tắt: không thêm node), `swap.equiv` (bật: node trên đường cong cạnh b–c lệch 3e-12, lệch ngang so với đường a–d 2e-12, lệch theo pháp tuyến 0,447 = đúng khe giữa hai đường chéo của cặp tam giác gập; không thêm cạnh tự do, mỗi cạnh một node giữa, +4 node +2 element, một Undo). `hang.noequiv` đổi oracle theo định nghĩa mới: tắt Equivalence, Node 1 lệch cạnh 0,05 → chia tại chính Node 1. Lần chạy trước `b2b922cce00c42a3a0c7c208f8ebbe6d` FAIL 1: ngưỡng "cách đường a–d dưới 5 % cạnh" do agent tự đặt là sai tiền đề (cặp tam giác gập), đã thay bằng tách lệch ngang/lệch pháp tuyến.
- `tests/probe_window.tcl` PASS 3/3 (run `5565f032de714ad6a9eb1c0eb7df396e`, mở qua `*evaltclscript mesh_edit.tcl 0` như nút MAC): màn chính (khung `-9 -9 2569 1389`), cửa sổ chính scratch chuyển (không kích hoạt) sang màn trái với đúng khung phóng to của phiên người dùng `-2569 -9 9 1389` → tool tại `-1436,571`, và cửa sổ nhỏ trên màn trái → `-1376,461`; tâm lệch 8/23 px (viền và thanh tiêu đề), cùng màn hình, nằm trong vùng làm việc. Công thức cũ cho x = 0 ở cả hai ca màn trái (lỗi tái hiện). Ảnh `window_1.png` đã xem: đủ hai nhóm Replace/Split, ô Equivalence chưa tích; `capture_window.ps1` đọc vị trí `-1376,461` từ ngoài tiến trình.

**Chưa kiểm:** chọn node bằng panel thật (`pick_two`, cần chuột), phiên HyperMesh của người dùng, HyperMesh thật sự ở trạng thái phóng to trên màn trái (chỉ giả lập bằng cùng khung), hai màn khác DPI, Split chéo trên quad/tetra, model full. Chưa chép dist, chưa commit.

## 22/11/2026: đổi tên thành Mesh edit, thêm Perpendicular và Split line

- Tên hiển thị (nút menu, tiêu đề cửa sổ, MeshForge, bước Undo) là **Mesh edit**; thư mục và tệp vẫn là `MeshEdit/mesh_edit.tcl` vì Element Imprint nạp tệp này.
- Cửa sổ: mỗi dòng một nút bên trái, tùy chọn bên phải, không khung nhóm. Ô "Equivalence (use picked corners)" đổi thành "Equivalence".
- **Perpendicular**: chọn 1 node (panel tự chuyển bước), rồi 2 node của cạnh; chân đường vuông góc thành node mới trên cạnh, mọi element trên cạnh đó (tria3/tria6/tetra) bị cắt đôi. Chân nằm ngoài cạnh (dưới 2 % hoặc trên 98 %) hoặc cạnh của quad: từ chối. Một bước Undo.
- **Split line**: chọn 2 node; hai góc đối của quad4/quad8 → 2 tria3/tria6 (tria6 thêm node giữa đường chéo); một góc và một node trên cạnh đối → như Split.
- Kiểm: `tests/probe_cut.tcl` PASS 8/8 (HyperMesh 2022.3 scratch, run `tests/runs/4994bb00599a44efba6cbc169fab8a4e`, ảnh cửa sổ đã xem). Chưa thử panel chọn node bằng tay, chưa chạy trên phiên người dùng.

## 23/11/2026: thêm nhóm Create element

- Cửa sổ Mesh edit có thêm nhóm **Create element** (dưới **Cut element**): **Pick nodes** cùng hàng với **Tria3 / Tria6**, **Clear** cùng hàng với số node đang chọn. Cách chọn và tạo tria giống hệt tool Create element cũ (xem [TriaFill/README.md](../TriaFill/README.md)); mã vẫn nằm ở `TriaFill/tria_fill.tcl`, Mesh edit nạp các thủ tục đó.
- Đóng Mesh edit khi panel chọn node đang mở: dừng chọn, xóa lựa chọn và đánh dấu, rồi đóng cửa sổ.
- Create element không còn nút riêng trong Toolbox và menu Utility → test.
- [probe_create.tcl](tests/probe_create.tcl) đạt **5/5** trên scratch HyperMesh 2022.3: mở qua `*evaltclscript`, tạo một CTRIA3 đúng ba node góc trong component hiện hành, một Undo, đóng khi panel đang mở, mở lại. [Kết quả](tests/runs/293255a8f0054af0a062665923153c35/checks.txt) · [Ảnh cửa sổ](tests/runs/293255a8f0054af0a062665923153c35/window_1.png)
- Hồi quy: `probe_cut` 8/8, `TriaFill/tests/probe_strip.tcl` 69/69, Toolbox `probe_toolbox` 14/14.
