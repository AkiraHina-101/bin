# MeshForge (cửa sổ Toolbox)

Một cửa sổ nhỏ gom các tool thử của `05-Test` thành lưới nút, luôn nằm trên cửa sổ HyperMesh (chỉ trên HyperMesh, không trên mọi ứng dụng). HyperMesh 2022.3, profile Nastran.

- Điểm vào: [meshforge.tcl](meshforge.tcl). Menu: Utility → **test** → **Toolbox** (MAC [meshforge.mac](meshforge.mac), sinh bằng bộ sinh menu).
- Mở cửa sổ không đổi model. Mỗi nút chạy **đúng lệnh của nút menu cùng tên**: `*evaltclscript <điểm vào của tool> 0`, nên tool mở cửa sổ hoặc panel riêng như khi bấm từ menu. Cửa sổ Toolbox vẫn mở.
- Khi chuyển sang tool khác trong lúc đang chọn, panel chọn cũ thoát trước rồi yêu cầu mới mới chạy. Các cửa sổ tool giữ mở. Mục đang chọn dở ở panel cũ được bỏ theo quy tắc của tool đó. Thao tác đang ghi mô hình cần hoàn tất trước khi bắt đầu thao tác mới.
- Các điểm vào của nhóm dùng chung [tool_session.tcl](../tool_session.tcl) để điều phối panel, mark và các thao tác dùng lịch sử HyperMesh. Preview Circle của Ruled mesh tạm dừng khi chuyển tool. Cửa sổ Circle giữ mở để tiếp tục chỉnh sau.

## Bố cục

- 10 nút chữ nhật cùng cỡ, mỗi cột 5 nút, xếp theo cột như trang Tool của HyperMesh: RBE2 bar, Shared faces, Ruled mesh, Imprint, Pattern | Translate, Center node, Equiv 2nd, Create element, Advanced Select (đã gộp Edge sides vào trong Advanced Select).
- Icon kèm chữ: icon 16 px có sẵn của HyperMesh (`<ALTAIR_HOME>/hwdesktop/hw/images`, nạp bằng `hwtk::image cache` như script của Altair; không vẽ tay). Thiếu một icon thì mọi nút chỉ hiện chữ (một hàng nút hoặc cùng có icon hoặc cùng không).

| Nút | Điểm vào | Icon native |
|---|---|---|
| RBE2 bar | `BoltLink/bolt_link.tcl` | `entityElementsRigidlink` |
| Shared faces | `SharedFaces/shared_faces.tcl` | `meshFace` |
| Ruled mesh | `Bridge/bridge.tcl` | `toolbarRuledSurfaceShowStrip` |
| Imprint | `Imprint/imprint.tcl` | `meshCircleImprint` |
| Pattern | `Pattern/pattern.tcl` | `glyphCopy` |
| Translate | `Translate/translate.tcl` | `browserTransformPosition` |
| Center node | `CenterNode/center_node.tcl` | `microMeasureRadiusStrip` |
| Equiv 2nd | `MeshEdit/mesh_edit.tcl` | `entityEquivalences` |
| Create element | `TriaFill/tria_fill.tcl` | `entityElementsTria3` |
| Advanced Select | `Select/select.tcl` | `selectionPolygonalStrip` |

- Thanh tiêu đề kiểu cửa sổ công cụ (nhỏ, chỉ nút đóng): với thanh tiêu đề thường, cửa sổ hẹp này bị cắt chữ "Toolbox" thành "Tool...".

## Vị trí và luôn trên HyperMesh

- Mở giữa cửa sổ chính HyperMesh: lấy khung Win32 của cửa sổ chính (`wm frame .`, `twapi::get_window_coordinates`), không dùng màn hình chính; tọa độ âm (màn hình nằm bên trái/phía trên màn chính) giữ nguyên, không kẹp về 0. Không lấy được khung Win32 thì dùng cửa sổ Tk gốc.
- Luôn trên HyperMesh: cửa sổ chính HyperMesh làm owner Win32 (cùng cách `keep_above_host` của các tool).
- Mở lại từ menu thì dựng lại và đặt lại giữa HyperMesh. Không nhớ vị trí giữa các lần mở.

## Kiểm chứng (22/11/2026, HyperMesh 2022.3, scratch riêng của agent qua `run_probe.py`)

- Sau khi gộp `Edge sides` vào **Advanced Select**, [tests/probe_toolbox.tcl](tests/probe_toolbox.tcl) run `e07a6781699c4b4f821978d01449d078` đạt **14/14 PASS**, ảnh [window_1.png](tests/runs/e07a6781699c4b4f821978d01449d078/window_1.png) đã xem: 10 nút (gồm `Advanced Select` ở vị trí thứ 10, lưới 2 cột × 5 hàng đồng đều `143×28 px`), đủ 10 icon 16×16, gọi mở cả 10 công cụ không lỗi, cửa sổ Toolbox giữ mở.
- Bản điều phối panel mở đủ 10 nút, đạt **14/14** trong probe Toolbox. Probe chuyển tool giữ cả hai cửa sổ, kiểm Replace và Tria có hai bước Undo độc lập, kiểm 90 lượt chống gọi chồng theo bảng 10 tool và kiểm Circle tạm dừng rồi tiếp tục. Các thao tác được kích bằng lệnh Tcl vào callback của nút thật. [Mở 10 tool](tests/runs/e07a6781699c4b4f821978d01449d078/checks.txt) · [Chuyển panel](tests/runs/dbe0d448d39143b69630714db1fb6ecc/complete.dict)

[probe_toolbox.tcl](tests/probe_toolbox.tcl), run `b3afcfa2`: **14/14 PASS**, ảnh `window_1.png` trong run đã xem. Kỳ vọng lấy từ MAC đã sinh và từ Win32, không từ tool:
- Đọc `05-Test/menu_page.mac` và các MAC nó include: đủ 11 nút (10 tool + Toolbox), thân macro đều là `*evaltclscript($1,0)`, tệp Tcl tồn tại.
- Mở Toolbox bằng chính lệnh của nút menu Toolbox. 10 nút đúng thứ tự, xếp theo cột (5 hàng); lệnh mỗi nút là `::MeshForge::Toolbox::launch <tệp>` với tệp trùng tệp của nút menu cùng tên; đủ 10 icon 16×16; mọi nút cùng cỡ 120×28 px, không bị cắt chữ.
- Vị trí: khung Toolbox lệch tâm cửa sổ chính HyperMesh (tìm theo tiêu đề "HyperWorks") 9 px ngang, 23,5 px dọc (viền và thanh tiêu đề không có trong cỡ yêu cầu lúc đặt). Owner Win32 = cửa sổ chính HyperMesh. Với khung host giả ở tọa độ âm (−1700, 120), cửa sổ đặt ở x = −1133, không bị kẹp.
- Gọi `invoke` từng nút (không dùng chuột): 8 tool mở cửa sổ riêng (RBE2 - CBAR - RBE2, Shared Faces, Ruled Mesh, Element Imprint, Element Translate, Edge Sides, Center Node, Equivalence 2nd order); Pattern mở panel chọn native (probe thoát bằng `hm_exitpanel`); Create element báo không có component hiện hành (model trống) và không mở panel, đúng hành vi. Không lỗi; Toolbox vẫn mở.
- Ảnh: dải đen ở mép phải và mép dưới ảnh là viền ẩn của khung Win32 mà PrintWindow không vẽ với kiểu cửa sổ công cụ (suy từ kích thước: 284 = 266 + 2 × 9), không phải nội dung cửa sổ.

Chưa kiểm: phiên người dùng và màn hình thứ hai thật (chỉ thử tọa độ âm bằng khung giả); click chuột thật; menu chưa nạp vào phiên người dùng.
