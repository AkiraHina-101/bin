# Shared Faces

Tạo face element trên mặt tiếp giáp chung node giữa các component, HyperMesh 2022.3, profile Nastran.

- Điểm vào: [shared_faces.tcl](shared_faces.tcl). Menu: Utility → **test** → **Shared faces**.
- Script cũ `03-Meshing_tool/SharedNodes/mark_shared_nodes.tcl` (chỉ 2 component) vẫn ở Meshing → Interface.

## Cách dùng

1. Bấm **Shared faces**: cửa sổ nhỏ có hai nút. **Components...** mở panel chọn component native; **Elements...** mở panel chọn element native. Chọn rồi **proceed**; return/ESC là hủy.
2. Tool tạo ngay: element được nhóm theo component (chọn component thì lấy trọn component). Với mỗi cặp component có node chung, tạo face vào component mới `sf_<A>-<B>` (không ghi đè tên có sẵn). Component mới lấy màu đang hiển thị trong ô **Color**. Tất cả gộp một bước undo "Shared faces".
3. Kết quả ghi ở dòng trạng thái của cửa sổ, thanh trạng thái HyperMesh và Tcl console (tên từng component). Cửa sổ giữ mở để chọn tiếp.
4. Nhóm **Shared faces** xử lý các component do tool tạo trong phiên HyperMesh này (giữ cả khi đóng/mở lại cửa sổ):
   - **Color** (ô chọn màu native `hwtk::colorbutton`, bảng màu HyperMesh) + **Apply**: tô một màu cho tất cả.
   - **Auto**: tô lại mỗi component đã tạo bằng một màu khác nhau (bảng màu bão hòa xếp theo sắc độ, các màu liền nhau cách xa nhau).
   - **Delete all**: xóa mọi component shared face đã tạo cùng các face trong đó.
   - Mỗi thao tác là một bước undo. Tên ví dụ: `sf_PSOLID11-PSHELL20`.

Chỉ element đã chọn được tính: chọn một phần component thì interface chỉ gồm phần đó, nhỏ hơn khi chọn trọn component.

## Quy tắc

- Node chung: node được element đã chọn của từ hai component trở lên dùng.
- Face chung: mọi node của face (cả midside) là node chung của cặp đó.
- Shell: chính element là face. Tetra4/Tetra10: face lấy từ connectivity (face chỉ thuộc một element của nhóm). Solid khác: `*findfaces` tạm trên các element gần node chung, xóa ngay sau khi đọc.
- Hai nhóm đều có 2D/3D: lấy face của nhóm đầu. Face được giữ khi nhóm kia có face trùng góc, hoặc khi mọi node của nó nằm trên các face chung của nhóm kia (lưới không khớp, ví dụ 1 quad hex với 2 tria tet). Face chỉ chạm theo cạnh bị loại.
- Một nhóm chỉ có 1D/rigid (RBE2, bar): lấy face của nhóm kia. Face trùng góc chỉ tạo một lần.
- Vùng chọn phủ trọn các component: dùng `*findbetween` native. Chọn một phần: vẫn dùng `*findbetween` trên các component đó để lấy node ứng viên, rồi chỉ giữ element đã chọn.

## Kiểm chứng (18/11/2026)

Thay đổi màu khi tạo đã qua kiểm tra bộ sinh menu và 5 ca mô phỏng bằng Tcl 8.5.9. Hai ca đọc màu trực tiếp từ component mới qua hai luồng chọn đã được thêm vào probe và đang chờ chạy trong HyperMesh.

Công cụ: viết mã Tcl, kiểm tĩnh bộ sinh menu (`--check`), chạy thật trong HyperMesh 2022.3.0.24 trên phiên scratch riêng của agent. Panel chọn bằng chuột chưa chạy thử; probe gọi `::SharedFaces::run_on <element ids>` và `run_on_comps <component ids>`, đúng phần chạy sau hai panel.

- Trước thay đổi màu khi tạo, [tests/probe_shared_faces.tcl](tests/probe_shared_faces.tcl) đạt **23/23 PASS** trên model [tests/build_block_model.tcl](tests/build_block_model.tcl), chạy lặp 3 lần. Gồm: tên `sf_A-B`, tô một màu (đọc lại `color`), Auto cho 4 màu khác nhau, Delete all về đúng số entity ban đầu và undo khôi phục lại; chọn qua nút Components (20 face, một bước undo), trọn 5 component (hex–hex 4 quad, hex–tet 4 quad, shell–solid 4, tet–RBE2 8), chọn một phần (4 face), hẹp hơn (2 face), element xa (không tạo gì), một component (không tạo gì), bỏ một hex góc (shell–solid còn 3), component ẩn vẫn ẩn, một bước undo gỡ hết.
- Thuật toán face giữ nguyên bản đã đối chiếu với `SharedEdges` trên `02-Test_Full_Model.hm` (222/223 cặp trùng số face; cặp lệch do 75 shell trùng nhau, SharedEdges tạo đôi).
- Thời gian trên model đó (2,8 triệu element, không lưu): 2 component trọn (24.573 + 462.188 element, 5.276 face) 6,2 s; nửa số element của 2 component đó (1.348 face) 4,8 s; toàn bộ model (231 cặp, 60.835 face) 124 s, trong đó tạo 223 component khoảng 70 s vì mỗi `*createelements` tốn cố định ~0,25 s.
- Cửa sổ hai nút mở qua đúng đường MAC (`*evaltclscript`), đã xem ảnh: 320×96, giữa HyperMesh, owner là cửa sổ HyperMesh.
- Nhóm Shared faces đã xem ảnh: cửa sổ 320×188; 4 component `sf_…` hiện 4 màu khác nhau.

## Vị trí cửa sổ (22/11/2026, ticket `02-window-on-host-monitor`)

- Lỗi cũ: căn giữa theo Tk `.` rồi kẹp `max(x,0)`/`max(y,0)` (viết thẳng trong `show`). Màn hình bên trái hoặc phía trên màn chính có tọa độ âm (máy người dùng: màn trái x từ −2560 đến 0, HyperMesh phóng to ở đó), nên cửa sổ bị đẩy sang mép trái màn chính. Phần đặt chỗ nay tách thành `place_center`.
- Nay `place_center` căn khung ngoài của cửa sổ (cộng viền và thanh tiêu đề theo `GetSystemMetrics`) vào giữa khung Win32 của `[wm frame .]` (cửa sổ HyperWorks; Tk `.` chỉ là vùng nội dung bên trong), giữ cửa sổ trong vùng làm việc của màn hình chứa HyperMesh và viết `+$x+$y` để giữ tọa độ âm. Không có twapi thì căn theo vùng nội dung `.`, không giới hạn vùng làm việc.
- Kiểm trên scratch HyperMesh 2022.3 riêng (chỉ thử vị trí, không đổi model): [tests/gui_place.tcl](tests/gui_place.tcl) run `89329dbe9df246b1a8363ad7fc49c0ba` **13/13 PASS**. Mở qua `*evaltclscript` như nút MAC trong ba ca: scratch ở màn chính; khung scratch dời sang màn trái tọa độ âm (`SetWindowPos`, không kích hoạt) với hình chữ nhật phóng to như HyperMesh của người dùng; rồi cửa sổ nhỏ trên màn đó. Tâm cửa sổ lệch tâm khung HyperMesh ≤ 0,5 px, cùng màn hình, nằm trong vùng làm việc, khung ngoài thực bằng khung tính trước. Ảnh ghép `overlay.png` trong run đã xem. [tests/place_math.tcl](tests/place_math.tcl) chạy bằng tclsh 8.5.9 của Altair: 11/11 bố cục có tọa độ âm (màn trái, trên, trái-trên, tràn mép, cửa sổ lớn hơn vùng làm việc).
- Chưa kiểm: mở từ menu trong phiên người dùng; hai màn khác DPI (viền tính theo DPI hệ thống).
