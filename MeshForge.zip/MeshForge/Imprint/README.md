# Imprint

Imprint mặt nguồn (source, ví dụ vòng đệm) lên mặt đích (target) trong HyperMesh 2022.3. Chỉ tria3/tria6; không còn xử lý 3D.
Kết quả: hai mặt dùng chung node, phần target nằm dưới source bị thay bằng đúng lưới của source, và luôn nối được vào source.

## Cách dùng

1. **Target...** (nút tách đôi, mũi tên ▾ chọn cách chọn): *By face* (mặc định, mở rộng ra cả mặt theo *Face angle*), *By area* (chấm lần lượt các node làm đỉnh vùng, từ 3 node; target là các tria có tâm trong vùng, nhìn dọc pháp tuyến vùng, bỏ phần xa mặt phẳng vùng quá 0,3 kích thước vùng), *Elements* (đúng các element chọn).
2. **Source...** (nút tách đôi): *Elements* hoặc *By component*. **Swap** đổi vai trò.
3. Khung **Imprint**: *Gap L/d* (mặc định 5, trống = tắt): element target không nằm dưới source nhưng sát viền tới mức dải nối dày dưới 1/(L/d) chiều dài cạnh bị xóa thêm; **Preview gaps** tô các element đó trước khi imprint (không đổi model); *2nd order*. Imprint không lọc gì thêm: khoảng cách tự động, không Gap ratio, không Near src, luôn chép trọn source và nối thẳng vào vành trong của nó (Join small hole luôn bật). *Near src* nằm ở khung Check, chỉ để kiểm sau imprint.
4. **Imprint** (sau đó là **Re-imprint**: hoàn tác lần trước rồi làm lại với thông số mới). Thành công thì không giữ màu selection.
5. Khung **Check**: Aspect / Skew / Min length kiểm lại khi bấm Enter hoặc rời ô (không kiểm theo từng phím gõ); Near src đo khi Show (Enter trong ô đo lại nếu Show đang bật). **Show** tô các element mới không đạt theo loại lỗi bằng contour native (1 Aspect, 2 Skew, 3 Min length; legend góc trái), đồng thời mới đo Near src (gõ số vào ô Near src không đo lại ngay). **Hide** trả chế độ màu cũ.

Dải nối giữa viền vùng xóa và viền bản sao dựng bằng ruled native R-trias (như Ruled Mesh với kiểu R-trias); chỉ khi mesher native không dùng được (vòng không khớp, tam giác lặp element còn giữ) mới về cách ruled cũ.

## Cách làm (ngắn)

- Target lớn được làm trong cửa sổ cục bộ quanh source (nhân đôi cửa sổ khi cần), từng cụm source rời nhau làm riêng (mỗi cụm một bước Undo).
- Dựng thường: xóa element target dưới source, chép element source, nối vòng ruled giữa hai viền, gộp/chia node.
- Ruled (21/11): hai vòng được đưa cùng chiều quanh pháp tuyến, gán tham số theo góc quanh tâm vòng nhỏ (hoặc theo độ dài cung chung mốc khi vòng không bao tâm) rồi trộn theo tham số, giống ruled native với hai danh sách node đã xếp thứ tự; sau đó lật đường chéo để tăng góc nhỏ nhất.
- Nếu vòng không đóng được thì dựng trực tiếp: xóa các hàng target bị chạm, nối ruled từ viền vùng vừa xóa lên viền bản sao (vòng ngoài với vòng ngoài, lỗ với lỗ).
- Source không nằm trọn trên target (lỗ source nhỏ hơn lỗ target, hoặc vượt mép): chỉ chép phần nằm trọn trên target, phần còn lại giữ nguyên.
- **Đã bỏ tiêu chuẩn chất lượng** (min length / aspect / stretch, plotel `imprint_check`, các lần thử lại theo tiêu chuẩn): imprint luôn nối hết, việc chia lại lưới gần mép do người dùng quyết định.

## Giới hạn

- Vòng lệch tâm mạnh có thể bị từ chối rõ ràng (không đổi model) hoặc imprint không nứt; luôn một Undo.
- Target by area dùng tâm element, không cắt element nằm vắt qua biên vùng; vùng nên bao trọn khu vực quanh source.

## Kiểm chứng (21/11/2026, HyperMesh 2022.3.0.24, scratch riêng qua `run_probe.py`)

Sau khi bỏ tiêu chuẩn chất lượng và rút gọn vòng thử: `probe_holegap` 17/17, `probe_imprint` 184/184, `probe_user_case` (test.bdf) 35/35, `probe_user_case2` (test.2bdf) 8/8, `gui_redo` 12/12, `probe_test4` 4/4 (24 vòng đệm, 12 cụm mỗi bên, 0 lỗi, khoảng 9–10 s cho 12 cụm), `probe_area` 6/6 (hàm `by_area` với đa giác vuông, tam giác, chữ L, đảo thứ tự, thẳng hàng/2 node bị từ chối). Ảnh cửa sổ (`gui_open`, có ô Target by area, không còn khung Quality) đã xem.

**Chưa kiểm:** luồng chấm node thật bằng panel `*createlistpanel` (probe gọi thẳng `by_area`), chạy trên phiên người dùng. Chưa chép sang `dist/`, chưa commit.

## Thử 21/11/2026 (ruled theo tham số, xóa theo viền lỗ, bỏ element gap)

- HyperMesh 2022.3.0.24 batch, scratch riêng (`run_probe.py`): `probe_test4` PASS 4/4 (hole_larger/hole_small, mỗi bên 12 cụm, 0 lỗi, ~7,2–7,5 s); `gui_open` PASS (không còn ô Remesh layers, Hole gap và Max distance cùng một hàng).
- `diag_test4_view.tcl` (một vòng đệm hole_larger, xuất lưới và vẽ phẳng): số tam giác góc nhỏ nhất < 15° quanh vòng đệm 1: trước imprint 7, bản đầu ngày 17, sau sửa 15; vòng đệm 5: 15 / 23 / 18. Phần dẹt còn lại là quạt tam giác từ node target ở xa (element target lớn hơn vòng đệm) tới viền dày của bản sao.
- Thử thêm hàng node trung gian trong dải nối (3 cách: đặt theo tham số chung, số hàng theo khoảng hở lớn nhất, đặt trên thanh nối ruled): hai cách đầu bị chồng diện tích 3–4% nên tool quay về một hàng; cách thứ ba làm node dồn cụm, tam giác < 15° tăng lên 36/37. Đã hoàn lại, `ring_fill` giữ như trước; chỉ giữ biến chẩn đoán `::MeshForge::Imprint::rfLog`.
- Chưa: ảnh cửa sổ mới (probe chỉ đo kích thước widget), chạy lại probe_imprint/holegap/user_case, thử trên phiên người dùng.

## Chamfer (21/11/2026)

- Viền lỗ khép kín của target nằm gần bản sao (dưới nó hoặc cách viền nó không quá một cỡ lưới): các element ngoài target trên viền đó, nghiêng 15–70° so với mặt target, bị xóa cùng vùng xóa, từng hàng xuống tới thành lỗ (> 70°). Mép trên thành lỗ thành viền lỗ của vùng xóa và được nối ruled lên lỗ trong của bản sao. Không áp dụng khi chỉ chép phần source nằm trọn trên target (trim).
- Quy tắc gap không lấy hàng có cạnh tự do của target (trước đó ca `washer_near_edge` bị xóa cả mặt).
- Kiểm (HyperMesh 2022.3.0.24 batch, scratch riêng): test4 có 1 hàng vát ~42°, sâu ~1 mm; vòng đệm 1 và 5 xóa 16 element vát, khe giữa lỗ target và lỗ vòng đệm được nối kín, crack 0. Hồi quy: holegap 17/17, imprint 184/184, user_case 35/35, user_case2 8/8, test4 4/4, gui_redo 12/12. Vòng đệm 1 còn 17 tam giác < 15° (trước imprint 7), phần dải ngoài chưa xử lý.
- Chưa: thử trên phiên người dùng; ca vát nhiều hàng hoặc vát không đều chưa có fixture riêng.

## Target chỉ xác định mặt, sửa lỗi By area (21/11/2026)

- Vùng chọn Target (pick hay By area) chỉ để xác định mặt: trước khi imprint, cửa sổ mở rộng nó ra cả mặt theo *Face angle* (`target_face`); tool tự lấy element cần quanh source (cửa sổ cục bộ, hàng vát).
- By area bỏ element nghiêng quá *Face angle* so với pháp tuyến vùng (trước đó lấy cả hàng vát và phần trên thành lỗ, gây lỗi "open edges inside the host face").
- Khi cách dựng thường để lại cạnh hở, tool hoàn lại rồi dựng trực tiếp thay vì báo lỗi; dựng trực tiếp thử tới 3 hàng khi viền vùng xóa tự chạm.
- Kiểm (HyperMesh 2022.3.0.24 batch, scratch riêng): probe mới `probe_test4_area` (By area 6 node góc quanh từng vòng đệm hole_larger) — bộ lọc cũ hỏng 4/12, bản mới 12/12 PASS (36 kiểm: chép đủ, không cạnh hở, một Undo). Hồi quy: holegap 17/17, imprint 184/184, user_case 35/35, user_case2 8/8, test4 4/4, gui_redo 12/12.
- Chưa: thử trên phiên người dùng; góc nhỏ nhất dải nối vẫn có ca 0,4–1,3°.

## Fix cục bộ (21/11/2026)

- **Fix** không imprint lại nữa: sửa từng element không đạt tại chỗ bằng thao tác của Equiv 2nd (nạp `../MeshEdit/mesh_edit.tcl`): tam giác *kim* (cạnh ngắn < cạnh dài / Aspect) → gộp hai node cạnh ngắn, giữ node của source; tam giác *nắp* → đổi đường chéo với tam giác bên kia cạnh dài. Chỉ giữ lần sửa khi độ dẹt xấu nhất quanh đó tốt hơn, không thì Undo đúng bước đó. Node của source không bao giờ bị dời.
- Không tích **Autofix**: các element không đạt hiện màu tối (highlight native *low*), click từng element (màu select) để sửa, return để dừng. Tích **Autofix**: sửa hết, tối đa 3 lượt.
- Element "mới" được nhận theo id lớn hơn id lớn nhất trước khi imprint.
- Kiểm: `tests/probe_fix_local.tcl` (test4, vòng đệm hole_larger 1, Aspect 3): Autofix 9 → 4 element không đạt, 6,7 s. Chế độ click từng element chưa kiểm (cần click thật).

## Gap ratio (21/11/2026)

- Ô **Gap ratio** (khung Options, 0…1, mặc định 0,3): element target còn giữ lại có cạnh trên viền vùng xóa chạy sát viền source (khe d tại 7 điểm dọc cạnh nhỏ hơn Gap ratio × độ dài cạnh L) bị xóa thêm, rồi dải nối dựng lại; ngưỡng node gap = 1,5 × Gap ratio × cạnh trung bình (0,45 ở 0,3, như trước); 0 = tắt. Giải thích hình học: sheet "Gap ratio" trong `Imprint_loi_mesh.xlsx` (ảnh `gap_ratio.png`).
- Kiểm: test4 vòng đệm hole_larger 1 chạy được (PASS), số tam giác < 15° không đổi (17): các tam giác dẹt còn lại ở vòng đệm này do element target lớn nối quạt, không do khe hẹp — Gap ratio không xử lý loại này.
- Gap ratio qua cửa sổ cục bộ: mép cửa sổ không còn bị coi là mép tự do; khi cần xóa element bên kia mép cửa sổ, tool hoàn lại và nới cửa sổ gấp đôi (tối đa 12 hàng). probe_test4_area PASS 36/36 ở Gap ratio 0,3 và 1; ở 1 xóa thêm: vòng đệm 2 35→39, 7 96→153, 9 39→40, 10 44→46.
- Ô **Near src** (mm, chỉ để xem, không dùng khi imprint): Show tô (highlight *low*) các element target cũ kề lưới mới có cạnh cách một node source < Near src (khoảng cách từ node source tới đoạn thẳng của cạnh, không tới đỉnh); dòng trạng thái: "Near src: n of m neighbours, closest d (elem E edge a-b <- src node q)". test4 vòng đệm 1: 53 element kề, gần nhất 0,346 mm (theo đỉnh trước đây 0,652); 3 mm bắt 47.
- Near src nay **tham gia imprint**: element target còn giữ, chạm viền vùng xóa, có cạnh cách một node viền source < Near src (khoảng cách tới đoạn thẳng của cạnh) bị xóa thêm (trừ element trên mép tự do thật của mặt). Show tô thêm node source gần nhất (màu select) và hai đầu cạnh được đo (màu tối). test4 vòng đệm 1 (Gap ratio 0,3): Near src trống/1 mm xóa 37, 2–3 mm xóa 53; tam giác < 15° 17 → 14 (mất các tam giác dẹt lớn dưới trái). Tô node chưa kiểm (cần phiên người dùng).
- Near src: Show đo giống quy tắc imprint (chỉ node viền source) và báo lý do còn lại: "kept: x outside the target face, y on its free edge, z other". Xem trước khi imprint: chọn Target/Source xong là tính, dòng "Near src (before imprint): ...". test4 vòng đệm 1: trước imprint 20/20 element target quanh source (gồm cả element nằm dưới source); sau imprint Near src 3: 47 element, 32 ngoài mặt target, 7 trên mép tự do, 8 khác (quy tắc chưa xóa).
- Near src đo thêm **một lớp element shell kề bên ngoài** (cả trước và sau imprint): test4 vòng đệm 1 trước imprint 54 element (20 target + lớp kề), sau imprint 119.
- **Join small hole** (mặc định bật): source phủ qua lỗ target (lỗ vòng đệm nhỏ hơn lỗ target) không bị cắt bớt nữa; chép cả source, nối dải từ viền lỗ target tới lỗ trong của source. Tắt = như cũ (chỉ chép phần nằm trọn trên target). test4 hole_small vòng đệm 1: overhang 0, crack 0; cả 12 vòng đệm: 0 lỗi, còn overhang 32.
- **Lỗi tồn tại (từ 21/11 ~16:15, sau đợt chamfer):** probe_test4 hole_larger 1/12 cụm thất bại ("the outline of the deleted host elements touches itself"); probe không đánh FAIL khi một cụm thất bại nên trước đó bị báo nhầm là đạt. Chưa sửa.
- Near src: element đè lên source (đỉnh hoặc tâm nằm trên source) không tính là gần (đằng nào cũng bị xóa); quy tắc xóa khi imprint xét mọi element target trong cửa sổ, không chỉ element chạm viền vùng xóa. test4 vòng đệm 1: trước imprint 5/54 element trong 1 mm (trước đây 41/54 vì tính cả element dưới source); Near src 2 mm xóa 53.
- **Hole gap tạm ngắt**: ô khóa, giá trị 0, viền lỗ luôn được nối bằng dải.
- Near src xóa cả **lớp element ở mặt kế bên** (ngoài mặt By face): các element shell kề mặt target có cạnh cách node viền source < Near src được thêm vào target (`near_outer`) và được phép xóa dù nằm trên mép target. test4, cả 12 vòng đệm hole_small, Near src 1 mm: thêm 237 element mặt kế bên, 12/12 cụm thành công (trước đó 1 cụm lỗi), 710 element thay, còn 20 element gần source (đều nằm trên mép tự do của vùng mới), 12,1 s. Chưa kiểm chất lượng dải nối đi qua chỗ gãy góc giữa hai mặt.

## Cửa sổ mới (22/11/2026)

- Ba khung: **Elements** (Target, Source, Source by component, By area/By face, Swap), **Imprint** (Gap ratio, Near src, Max distance, Join small hole; Hole gap ẩn = 0), **Check** (Aspect, Skew, Min length, Quality colors, Show, < Prev, Next >).
- Dòng trạng thái ngắn: "Done: 11/12 patches, 710 replaced. Failed 1: <lý do>." / "Failed: <lý do>." / "Errors: n of m new elements" / "Near src: n of m, closest d" (chi tiết in ra Tcl console).
- **Prev/Next**: nhảy tới element lỗi, khung nhìn vừa element và lân cận (`*window_entitymark`), element tô màu select, dòng trạng thái ghi aspect/skew/length.
- **Quality colors**: bật chế độ màu native "Element Quality" (`*setelementcolormode 17`, tiêu chuẩn của HyperMesh) — HyperMesh tự vẽ nên cập nhật khi sửa lưới bằng tool khác; tắt/Close trả lại chế độ màu cũ.
- **Close**: xóa hết highlight, trả chế độ màu.
- Kiểm: gui_fix (scratch): Prev nhảy đúng element, chế độ màu 17 bật và trả về 1. Chưa chụp ảnh cửa sổ mới.

## Chamfer sửa triệt để (22/11/2026)

- Nguyên nhân lỗ chưa nối: một lỗ của test4 có vát không đều (element 0°, 20°, 71° xen giữa); tool chỉ nhận vát 15–70° nên sót, viền vùng xóa tự chạm, vòng đệm đó thất bại (hole_small 2) hoặc sót vát (hole_larger 11).
- Sửa: vát = mọi element từ mép lỗ mặt target tới thành lỗ có góc < 80° (kể cả bậc gần phẳng), tối đa 4 hàng; mọi element vát target đang giữ (`chamferRows`) đều bị xóa khi imprint.
- Kiểm (`tests/diag_chamfer_all.tcl`, test4, cả 12 vòng đệm): hole_small và hole_larger đều 12/12 cụm, 0 element vát sót, 16/16 cạnh lỗ vòng đệm đã nối ở mọi vòng đệm.
- Hồi quy (mỗi probe một phiên, đóng sau): holegap 17/17, imprint 184/184, user_case 35/35, user_case2 9/9 (thành lỗ giữ nguyên 42/42, vát xóa hết), test4 By area 36/36, gui_redo 12/12. Probe đổi theo thiết kế mới: holegap chạy Join small hole tắt; user_case2 kiểm thành lỗ giữ, vát xóa; gui_redo theo trạng thái "Done:".

## Dải nối R-trias, dọn thông số, màu lỗi native (22/11/2026)

- **Dải nối R-trias:** `ring_fill` thử trước `native_ruled`: chia vòng ra 4 đoạn (gập thì 8) cắt ở tham số góc khớp nhau trên hai viền, mỗi đoạn ruled native hai danh sách node kiểu R-trias (như Ruled Mesh), đọc lại tam giác, xóa element tạm, ghép node đường cắt, định chiều theo cạnh chung. Bị loại (về ruled cũ) khi: gập 3D (hai tam giác không mảnh kề nhau ngược pháp tuyến), tam giác lặp element còn giữ, tam giác phẳng, diện tích có dấu không khớp vành khăn. `flip_improve` không lật đường chéo của tam giác R-trias.
- **Phát hiện runtime** (ghi vào `03_HM_API_LIBRARY/API/gui/RUNTIME_DA_KIEM_2022_3.md`): xóa element do mesher tạo thì HyperMesh xóa luôn node bên trong của nó; `*createelements` trên node không tồn tại thì treo (không trả lỗi) — nên node bị mất được tạo lại tại chỗ, và dải luôn tạo trước khi xóa hàng target (node giữa cạnh tria6 cũng bị xóa theo). `*deletemark nodes` báo lỗi "0" với node tự do: dùng `*nodemarkcleartempmark`.
- **Dọn thông số chết:** cửa sổ bỏ Hole gap (luôn 0) và các biến `opt(holeGap)`, `opt(layers)`; bỏ đường `fixNodes` (Fix cũ làm lại imprint) và đoạn dựng dòng trạng thái dài bị ghi đè. Tham số `holeGap`/`layers` của hàm `imprint` vẫn giữ cho probe và dựng trực tiếp.
- **Near src:** gõ số không đo lại; chỉ đo và hiện khi bấm Show (`near_show`).
- **Màu lỗi:** Show vẽ contour native `*tablecontour` (1 Aspect, 2 Skew, 3 Min length; element khác "No Result"); bảng tạm tạo trong một bước note rồi Undo ngay nên lịch sử Undo không đổi. Dòng trạng thái: "Errors: n of m new elements (Aspect a, Skew s, Min length l)". `*reviewentitybymark` đã thử nhưng chỉ giữ một màu tại một thời điểm.
- **probe_test4** nay đánh FAIL khi có cụm thất bại hoặc overhang (`all_patches`, `no_overhang`).
- **Kiểm (HyperMesh 2022.3.0.24, scratch riêng qua `run_probe.py`, mỗi probe một phiên, đóng sau; `tests/run_all.sh`):** diag_native_ruled PASS (tấm phẳng: dải R-trias native 34 tam giác, không cạnh hở), holegap 17/17, imprint 184/184, user_case 35/35, user_case2 9/9, **test4 8/8** (hole_larger và hole_small mỗi bên 12/12 cụm, overhang 0, cạnh hở 0, Undo trả đúng; R-trias native ở 54/62 dải, 8 dải native gập 3D nên dùng ruled cũ; ~23–24 s cho 12 cụm, trước đây ~17 s), test4 By area 36/36, gui_redo 12/12, gui_fix PASS (Near src chỉ hiện sau Show; contour chế độ màu 14, Undo không đổi, bảng tạm không còn; Hide trả chế độ màu), gui_open PASS, ảnh cửa sổ đã xem (`tests/runs/9e862ea73dd6465aaa0c7b4121a87d65/window_1.png`), ảnh màu lỗi đã xem (`tests/runs/53fda72036e948e8b8a0cdbed64014a8/show_errors.jpg`).
- **Giới hạn:** màu contour theo dải giá trị có mặt (chỉ có Aspect thì Aspect mang màu trên cùng); legend luôn ghi số loại 1/2/3 và tiêu đề giải nghĩa. Neo dải bằng ID element không tồn tại không có tác dụng. Chưa thử trên phiên người dùng, chưa chép `dist/`, chưa commit.

## Sửa sau thử của người dùng (22/11/2026, chiều)

- **"n elements are both target and source":** sau một lần imprint, vòng đệm dùng chung node với RC nên bước tìm hàng vát (`face_chamfer`) và `near_outer` nhặt cả element source vào target (128 = 4 vòng đệm × 32) và mọi imprint bị từ chối. Nay hai bước bỏ qua source và `target_face` luôn loại source khỏi target. Probe mới `tests/probe_second_comp.tcl` (hole_larger rồi hole_small hai lần, target chọn như người dùng): không còn trùng.
- **hole_small không nối viền vát:** cụm hai vòng đệm sát nhau (64 element) cần 4 hàng thêm khi dựng trực tiếp; giới hạn cũ 3 nên cụm đó bị bỏ. Nay tối đa 5. `tests/diag_chamfer_all.tcl` (Gap ratio 1, Near src 0, Join small hole) đánh FAIL khi còn vát hoặc lỗ chưa nối; chạy riêng hole_small và sau hole_larger (`KP_FIRST`).
- **Ô 2nd order** (khung Imprint): sau imprint, tria3 mới đổi sang tria6 bằng `*orderchangetosecond 1 0 0` (node giữa cạnh chung với tria6 bên cạnh dùng lại), một bước Undo riêng; Re-imprint gỡ cả bước này. gui_open: 52 element mới thành tria6, Undo trả đúng số element/node.
- **Kiểm (HyperMesh 2022.3.0.24, scratch riêng, `tests/run_all.sh`, 13 probe):** đều PASS — diag_native_ruled, holegap 17, imprint 184, user_case 35, user_case2 9, test4 8, test4 By area 36, second_comp 9 (hole_larger rồi hole_small hai lần: không trùng, 12/12 mỗi lượt, không cạnh hở), chamfer hole_small 12/12 lỗ nối (riêng và sau hole_larger), gui_redo 12, gui_fix, gui_open (có 2nd order) + ảnh cửa sổ đã xem. Chưa thử trên phiên người dùng.

## Imprint không lọc, hole_small chép trọn vòng đệm (22/11/2026, tối)

- **Lỗi người dùng** (`03-Meshing_tool/models/test_fail.bdf`, mong muốn `test_desired.bdf`): cửa sổ có Max distance 0.3, hole_small chỉ chép vành ngoài vòng đệm (R 5,8–8,4), vành trong (R 3,8–5,8) để chìa trên lỗ với mép tự do, dải vát bám vào vòng node giữa vòng đệm; dòng trạng thái "381 source elements left off the target". Mong muốn: chép trọn vòng đệm và nối một hàng vát ngắn từ mép lỗ bản chép xuống mép trên thành lỗ.
- **Nguyên nhân:** phép thử Join small hole (`over_or_hole`) lấy lỗ của target sau khi đã gộp hàng vát (mép thành lỗ R ~4,0), dung sai là Max distance. Node vòng đệm phía trên vát cách mặt vát 0,3–0,9 mm nên không "nằm trên target" cũng không "trong lỗ" → rơi vào nhánh trim. Khi Max distance trống (dung sai cỡ lưới) thì không lỗi, nên các probe trước không bắt được.
- **Sửa:** khi có `chamferRows`, phép thử dùng lỗ của mặt target không tính hàng vát (mép trên vát). Theo yêu cầu người dùng, cửa sổ imprint không lọc nữa (`gui_options`: maxDist trống, gapRatio 0, không Near src, joinSmall 1); bỏ bước `near_outer` (nhặt element mặt kế bên theo Near src). Khung Imprint chỉ còn 2nd order; Near src chuyển xuống khung Check (Show). Gap ratio, Max distance, Join small hole bỏ khỏi cửa sổ; tham số của hàm `imprint` vẫn giữ cho probe.
- **Kiểm:** tái hiện `diag_chamfer_all` với maxDist 0.3: overhang 381, 12/12 lỗ còn hở (run `6ef4f7fd`); sau sửa overhang 0, 0 cạnh hở, vát dưới vòng đệm xóa hết (run `6895a742`). Oracle `diag_chamfer_all` nay tách vát trong lỗ/dưới vòng đệm và kiểm cạnh hở của vát giữ lại. Công cụ chẩn đoán: `tests/diag_small_layers.tcl` (một vòng đệm, `KP_FIRST`), `tests/plot_dump.py` (SVG hình chiếu), `tests/view_bdf.tcl` (ảnh một BDF nhỏ).
- **Hồi quy sau sửa** (HyperMesh 2022.3.0.24, scratch riêng, mỗi probe một phiên): diag_native_ruled, holegap 17 (kiểm `gui_redo_below` đổi thành `gui_redo_whole` vì cửa sổ không còn Join small hole), imprint 184, user_case 35, user_case2 9, test4 8, test4 By area 36, second_comp 9, chamfer hole_small (riêng và sau hole_larger) 12/12, gui_redo 12, gui_fix, gui_open đều PASS; với đúng thông số cửa sổ (maxDist trống, gapRatio 0, joinSmall 1) hole_small 12/12, overhang 0, lỗ nối kín, riêng và sau hole_larger. Chưa xem ảnh cửa sổ mới.
- **Ca người dùng sau đó** ("Failed 3: the outline of the deleted host elements touches itself", Target 1763 tria3/tria6): Target đã chứa tria3 của lần imprint trước (trước đó 1962 tria6), tức imprint chồng lên lưới đã imprint lỗi; chưa tái hiện trong scratch. Điểm yếu cấu trúc (đọc mã): vùng xóa R được nới bởi nhiều vòng lặp riêng, bước sửa chỗ thắt (pinch) bỏ qua cạnh tự do của target trong khi `outlines` kiểm cả chúng; thêm hàng/nới cửa sổ không chạm hàng gây thắt nên thất bại rồi hoàn lại.

## Một luật nối cho hole_small và hole_larger, dải ruled Tcl, nút tách đôi (22/11/2026, tối)

- **Yêu cầu người dùng:** hole_small và hole_larger dùng cùng một luật: chép trọn vòng đệm, xóa phần RC dưới vòng đệm (kể cả vát), nối viền lỗ RC còn lại lên viền lỗ trong của bản chép (ca large dải tỏa lên, ca small chụm xuống); chạy nhanh hơn; các lựa chọn chọn element đưa vào hai nút dạng combobutton. Chỉ cần lưới không chồng/chéo element và không bắt sai node.
- **Nối lỗ một luật:** `direct_bands` luôn nối một dải giữa lỗ bản chép và lỗ RC (vòng nhỏ → vòng lớn), bỏ cờ `joinSmallUsed`. Dựng thường: cạnh lỗ bản chép chỉ coi là nằm trên cạnh tự do của target khi cũng lệch không quá `mtolV` theo pháp tuyến (`near_edges` thêm tham số `off`); một lỗ bản chép còn chưa nối mà nằm trên lỗ của RC thì báo `LAYER` để chuyển sang dựng trực tiếp (trước đó vòng đệm 6 của test4 hole_small để hở 24 cạnh mà oracle cũ không thấy vì đếm cả vòng đệm gốc).
- **Bỏ R-trias mặc định** (`::MeshForge::Imprint::rtrias 0`): so trên test4 theo luồng cửa sổ, cùng góc nhỏ nhất và số tam giác < 15°/< 5°, Aspect > 10 đều 0; Skew > 60: small 169 (R-trias) / 243 (Tcl), large 155 / 149; thời gian tuần tự small 21,7–22,0 s → 15,0–15,5 s, large 23,7–24,0 s → 14,3 s. `diag_native_ruled` tự bật R-trias để vẫn kiểm đường native.
- **Tốc độ khác:** vòng hộp bao của `local_window` viết lại (cùng phép tính): 3,8 → 2,7 s cho 13 lần gọi. Cache đọc RC giữa các vòng đệm không nhanh hơn (đo), đã hoàn lại. Dải native từng chiếm 30–40% thời gian (đo bằng `tests/profile_imprint.tcl`, `KP_PROF`, `KP_NOPROF`, `KP_RTRIAS`).
- **Cửa sổ:** Target/Source là nút tách đôi (`combo_button`, theo mẫu nút Import của Material Manager); biến `targetMode` (face/area/elements) và `sourceMode` (elements/component) thay cho `byFace`/`byArea`/`srcByComp`. Hàng dưới: Face angle và Swap.
- **Oracle mới `tests/compare_band.tcl`:** so cạnh shell trước/sau (bỏ vòng đệm gốc): cạnh dùng bởi nhiều element hơn trước (chồng/chéo), cạnh hở mới (sai node/nứt), cặp kề nhau gập (pháp tuyến lệch > 120°), element suy biến; kiểm cấy lỗi (`KP_MUTATE`, một element trùng) bắt `stacked 3`. Kết quả cuối: small và large đều 0 chồng, 0 hở mới, 0 gập, 0 suy biến, 12/12, overhang 0.
- **Chiều pháp tuyến:** trước đây mỗi element bản chép tự định chiều theo element host ngay dưới nó (dưới vòng đệm có cả mặt, vát, lỗ) và dải theo dấu với `N` (không ổn định khi dải gần đứng): small lệch 645 cạnh mới–mới. Nay `orient_new` lan chiều qua cạnh chung từ các hàng RC giữ lại (nút đã gộp theo `vmap`) sang dải rồi bản chép. Còn lại (đo, `compare_band`): small 21 mới–mới + 150 mới–cũ, large 18 + 179; element cũ trong các cặp này chủ yếu là thành lỗ (dốc 70–90°, comp RC), và trước imprint chúng đã lệch 91/514 cạnh chung với hàng xóm (chiều sẵn có của model). Phần mới–mới còn lại có thể do RC xung quanh vốn không đồng chiều (chưa kiểm).
- **Hồi quy cuối** (scratch, 4 phiên song song, đóng hết sau chạy): diag_native_ruled, holegap 17, imprint 184, user_case 35, user_case2 9, test4 8, test4 By area 36, chamfer hole_small riêng/sau hole_larger 12/12, compare_band small/large (0 chồng, 0 hở mới, 0 gập, 0 suy biến), gui_redo 12, gui_fix, gui_open (menu Target/Source đúng) PASS; ảnh cửa sổ đã xem (`tests/runs/e11cbc8b698e490b8e3318b992a0c381/window_1.png`). `probe_second_comp` lượt 3 (imprint hole_small lần hai chồng lên lưới đã imprint) thất bại "outline … touches itself" — người dùng nói ca này tạm chưa cần, probe giữ nguyên tiêu chí.

## Khe hẹp d/L, nút chế độ hiển thị (22/11/2026, tối)

- `narrow_gaps`: với mỗi vòng đệm, chiếu viền (ngoài và lỗ) lên mặt phẳng vòng đệm; element target ngoài vùng vòng đệm, không cắt viền, không thuộc hàng vát, không có cạnh trên mép tự do của mặt: khe tại node (cạnh viền gần nhất, L = cạnh viền, d = khoảng cách) hoặc khe dọc cạnh (node viền rơi trên cạnh, L = cạnh, d = khoảng cách lớn nhất); bắt khi L/d > *Gap L/d*. Imprint xóa chúng cùng vùng dưới vòng đệm (`gapRows`). Số đo test4: xem ticket `.scratch/elem-imprint/issues/03-narrow-gap-dl.md`.
- Hàng dưới cùng: ba nút icon *Shaded elements and mesh lines / feature lines / Shaded elements* (`*setdisplayattributes 2|3|1 0`, như nút thanh công cụ trong bản ghi lệnh).
- Probe: `compare_band.tcl` (`KP_GAPS=1`, `KP_LIM`), `gui_open.tcl` (Preview không đổi model, icon và lệnh hiển thị).

## 23/11/2026: Gap L/d chỉ bắt một lớp

- **Trước:** `narrow_gaps` lấy thêm element ở góc tam giác band hẹp qua tối đa 4 vòng, và các element mảnh nối tiếp nhau qua tối đa 6 vòng. Vì vậy nó bắt cả element ở lớp thứ hai trở ra.
- **Giờ:** chỉ element của mặt target dùng chung node với vùng bị source che hoặc cắt qua (R lúc đầu) mới được lấy. Lớp này không cần nằm dưới source. Element mảnh ở xa hơn được đánh dấu `thin_far` và không bị lấy.
- **test_5, Gap L/d = 7 (scratch HyperMesh 2022.3):** bản cũ bắt 9 element, khớp ảnh người dùng; bản mới bắt 6. Imprint vẫn 0 hở, 0 gấp. [So sánh](tests/runs/gap_one_layer_compare.png)
- **Hồi quy:** test4 8/8, lỗ khoét bậc PASS, `gui_open` PASS (Preview trên mẫu GUI: 19 → 16 element).
- **Chưa thử trong phiên người dùng.** Các dải mảnh màu cam ở mép boss và mép lỗ trong ảnh người dùng chưa tái hiện được trên `test_5.bdf`: mẫu có 1255 element target, ảnh ghi 1233.

## 23/11/2026 (sau): Gap đổi thành khoảng cách (mm)

- Theo ý người dùng: chỉ xét các element của target **kề sát vùng bị xóa** (dùng chung node với vùng bị source che hoặc cắt qua). Một element bị xóa thêm khi khoảng cách nhỏ nhất từ các đỉnh của nó tới viền source (đo 3D tới các cạnh viền) **nhỏ hơn Gap**.
- Ô giao diện đổi từ `Gap L/d >` thành `Gap (mm) <`, mặc định 1 mm; để trống thì tắt. Bỏ cách tính cũ theo tỉ lệ L/d của dải nối (`band_eval`, các vòng lặp lấy thêm).
- **Lưu ý:** nếu tool đã mở trong phiên HyperMesh từ trước, ô Gap giữ giá trị cũ (ví dụ 7) và giờ được hiểu là 7 mm.
- **test_5 (scratch HyperMesh 2022.3):** 0.5 mm bắt 2 element (đỉnh cách viền 0.17 mm); 1 mm và 2 mm bắt 4 element (thêm hai element có đỉnh cách 0.70 mm). Imprint 0 hở, 0 gấp. [Ảnh so sánh](tests/runs/gap_mm_compare.png)
- **Hồi quy:** test4 8/8, lỗ khoét bậc PASS, `gui_open` PASS (Preview trên mẫu GUI lưới mịn: 34 element ở 1 mm).
- **Chưa thử trong phiên người dùng.**

## 23/11/2026 (sau nữa): Gap xét cả element trên thành

- Gap giờ xét cả các shell **ngoài target** nằm sát vùng bị xóa: cùng component, dùng chung node với vùng bị che hoặc cắt qua, không quá xa mặt washer (ví dụ thành đứng ở mép mặt). Element nào có đỉnh gần viền source hơn Gap thì được thêm vào target để imprint xóa. Việc thêm diễn ra cả trong `do_imprint` và khi tool tự lấy thêm hàng kề.
- Chế độ "trải phẳng thành đứng" (`unfold`) giờ luôn bật. Lý do: khi các hàng thành đứng đã nằm trong target, tool không còn đi qua nhánh lấy thêm hàng, nên không tự bật chế độ này nữa. Chế độ này chỉ dời tạm node lệch khỏi mặt washer, nên ca phẳng không đổi.
- **test_5 (scratch HyperMesh 2022.3):**

  | Gap | Số element bị xóa thêm | Trong đó ngoài target | Cách dựng | Kết quả |
  |---|---|---|---|---|
  | 0.5 mm | 21 | 19 | chuẩn | 0 hở, 0 gấp |
  | 1 mm | 24 | 19 | chuẩn ra 2 element gấp, tự chuyển sang dựng trực tiếp | 0 hở, 0 gấp |

  Ảnh: `tests/runs/test5_gap1mm_*.jpg`.
- **Hồi quy:** test4 8/8, lỗ khoét bậc PASS, `gui_open` PASS.
- **Chưa thử trong phiên người dùng.**

## 23/11/2026 (tiếp): Gap đo tới cạnh, không chỉ tới đỉnh

- Người dùng báo: đo tới đỉnh chưa đủ, vì một cạnh dài có thể đi sát viền source dù hai đầu cạnh ở xa.
- **Giờ:** với mỗi element trong lớp liền kề phần bị xóa (chỉ một lớp), tool đo khoảng cách 3D nhỏ nhất giữa viền source và các cạnh nối **hai node thuộc target** của element đó (`seg_seg_dist3`). Element ngoài target không có cạnh nào như vậy thì đo tới node thuộc target của nó. Nhỏ hơn Gap (mm) thì element bị xóa thêm.
- Đã kiểm khoảng cách đoạn–đoạn trên năm ca hình học có đáp số tính tay: vuông góc, lệch nhau, thẳng hàng, cắt chéo, song song. Ép kiểu số thực để tránh chia nguyên.
- **test_5 (scratch HyperMesh 2022.3):**

  | Gap | Số element bị xóa thêm | Kết quả |
  |---|---|---|
  | 0.2 mm | 13 | 0 hở, 0 gấp |
  | 0.5 mm | 21 | 0 hở, 0 gấp |
  | 1 mm | 23 | dựng chuẩn ra 2 element gấp, tự chuyển sang dựng trực tiếp: 0 hở, 0 gấp |

- **Hồi quy:** test4 8/8, lỗ khoét bậc PASS, `gui_open` PASS.
- **Chưa thử trong phiên người dùng.** Ca trong ảnh người dùng (source `hole_small`, 768 tria3) chưa tái hiện.

## Bản old (`imprint_old.tcl`, gói `dist/imprint_old.zip`) — 23/11/2026

- **Quy tắc xóa:** chỉ xóa phần tử target bị source che. Với lỗ của target nằm dưới source, xóa thêm đúng một hàng phần tử ngoài target quanh lỗ, bất kể độ dốc (vát hay vách). Không thêm hàng vát vào target, không xóa hàng Gap, không thêm hàng Remesh. Chỉ khi cách dựng trực tiếp (dự phòng) không nối được thì tool mới xóa thêm từng hàng, để lưới vẫn nối.
- **Không chặn:** phần tử gập chỉ được báo. Nhiều patch thì làm từng patch, patch nào nối được thì giữ, patch lỗi để nguyên và báo lý do. Patch nằm ngoài target báo "This source patch is not on the target". Cả lượt Imprint là một bước Undo "Element imprint".
- **Nút Debug** (cạnh Reset): mở cửa sổ "Imprint steps" đi lại từng bước của lần Imprint gần nhất bằng `< Prev` / `Next >` (hoặc phím mũi tên). Mỗi bước có lời giải thích và tô sáng phần tử hoặc node còn trong model: target face, source, từng patch, phần tử bị che, hàng quanh lỗ, từng lần thử hỏng kèm lý do, kết quả (số cạnh hở, số phần tử gập). Debug ghi lại sau khi chạy, không dừng giữa chừng.
- Kiểm trên scratch HyperMesh 2022.3: `tests/probe_old_partial.tcl` 8/8 (gồm Debug), `probe_test4.tcl` 8/8 (12/12 patch, 27 bước "Hole row"), `probe_test5.tcl`, `probe_cbore.tcl`, `probe_old_delete.tcl` PASS (chạy với `KP_TOOL` trỏ bản old).

### Imprint bản old theo cách làm tay (23/11/2026, tối)

Nút Imprint của bản old không còn chạy quy trình cũ. Hàm `enclose_once` / `imprint` vẫn còn trong file nhưng không được gọi. Quy trình mới là `ruled_imprint`:

1. **Delete covered:** xóa phần tử bị che và hàng quanh lỗ, giống hệt nút Delete covered (Gap mm).
2. **Chép source:** dùng `*duplicatemark` để chép source vào component của target. Source gốc giữ nguyên.
3. **Tìm cạnh tự do:** làm giống Find edges nhưng không để lại PLOTEL. Viền target lấy từ phần tử còn lại quanh vùng đã xóa (cạnh có hai node thuộc phần tử vừa xóa). Viền bản chép là cạnh tự do của bản chép.
4. **Ghép cặp:** mỗi viền target đi với viền bản chép gần nó nhất (khoảng cách trung bình), mỗi viền chỉ dùng một lần.
5. **Ruled:** dùng `::MeshForge::Bridge::create`, tức native Ruled của tool Ruled Mesh, kiểu R-trias. Size bằng cạnh trung bình của viền target. Tool không can thiệp góc.

Patch source không ghép được với viền nào (nằm ngoài target) thì bản chép bị xóa và được báo. Viền ruled lỗi thì được báo, bản chép vẫn giữ để ruled tay bằng Ruled Mesh. Nếu không viền nào ruled được, mọi thứ được hoàn lại. Cả lượt là một bước Undo "Element imprint". Debug có các bước Delete covered, Copy, Free edges, Rim k ruled / failed và Patch k not joined.

Bản old cần thư mục `Bridge/` cạnh `Imprint/`, nên gói zip có kèm thư mục này.

Kiểm trên scratch HyperMesh 2022.3:
- `tests/probe_ruled_imprint.tcl`: 9/9 PASS. Tấm 10×10 kín lại (chỉ còn 40 cạnh biên ngoài), patch nằm ngoài target bị bỏ và được báo, một Undo trả lại model, ca không nối được không để lại gì.
- `tests/probe_ruled_test4.tcl` (test4.bdf):
  - hole_larger: 24/24 viền được ruled, RC không hở cạnh nào, 6,7 s. Phần ruled có 24 tam giác dưới 10° (nhỏ nhất 1°).
  - hole_small: chỉ 1 vòng đệm nằm trên mặt đã chọn; 2/2 viền của nó được ruled. 11 patch còn lại nằm ngoài mặt đó nên bị báo đúng.
- `probe_old_delete.tcl`: PASS.
- `probe_old_partial.tcl` thuộc quy trình cũ nên không còn áp dụng.

### Imprint old: tìm viền khép kín (23/11/2026, khuya) — bản trong dist

Bước 3–5 của `ruled_imprint` đã được viết lại. Sửa riêng cho `test_fail` đã bị bỏ theo yêu cầu, vì lưới mẫu đó quá xấu. Bản lưu ở scratchpad là `elem_imprint_old_after_testfail.tcl`.

- **Tìm viền:** viền RC đi tiếp dọc các cạnh hở có sẵn (lỗ RC dưới source, mép part) cho đến khi khép kín (`rim_free_edges`). Mỗi viền lấy một vòng kín qua cạnh của vùng xóa (`rim_cycle`, dùng `cycle_from_edge` / `outer_plotel_cycle` của Ruled Mesh).
- **Ghép cặp theo patch:**
  - Viền ngoài của bản chép đi với viền RC gần nhất bao quanh nó. Một viền RC có thể nhận nhiều patch; khi đó ruled với các vòng trong `extraHoles`.
  - Viền lỗ của bản chép đi với viền RC nằm trong hoặc dưới lỗ.
  - Không có viền RC nào cho lỗ: nếu dưới tâm lỗ từng là phần tử RC (song song mặt) thì lấp lỗ bằng Ruled một vòng. Nếu RC vốn có lỗ ở đó thì để hở (bước Debug "Hole left open").
- **Kiểm trên scratch HyperMesh 2022.3:** `tests/probe_ruled_any.tcl` với `KP_PICK=under` (target chọn như người dùng: một phần tử dưới mỗi patch, rồi By face):
  - test4 hole_small 24/24, test4 hole_larger 24/24, test_5 1/1, test_improve_imprint 1/1: đều PASS.
  - `probe_ruled_imprint.tcl` (tấm 10×10): PASS.
- **Đã sửa riêng lỗi id node dùng lại:** sau khi xóa phần tử, HyperMesh dùng lại id của node vừa xóa cho node của bản chép (trên `test_fail` cả 36 node). Giờ bộ nhớ tọa độ được xóa ngay sau bước xóa và khi kết thúc. Tọa độ các phần tử đã xóa được giữ riêng, không theo id. Kiểm lại cả 5 bài thử trên: PASS.
- **Giới hạn đã biết:** vùng xóa chạm mép hở của part (như `test_fail`) thì quanh vòng đệm không có viền kín, nên ghép cặp có thể sai hoặc không nối được.
- **Chẩn đoán:** `tests/diag_rims.tcl` vẽ các viền tìm được, mỗi viền một màu.

### Imprint old: luật bắt cạnh để nối (24/11/2026)

Chưa có mẫu thật bị fail, nên luật được rút từ việc soi mã và 5 ca tự dựng trên scratch (`tests/probe_ruled_cases.tcl`, chọn ca bằng `KP_CASE`). Mấy ca này cho thấy lỗi chính không nằm ở bước Ruled mà ở lưới target còn sót lại sau bước xóa.

- **Luật 1 — xóa đảo dưới bản chép:** phần tử target còn nằm trong viền ngoài của bản chép (dưới lỗ washer, hoặc mẩu sót giữa hai vùng xóa) bị xóa luôn (bước Debug "Islands"). Lỗ của bản chép sau đó được lấp nếu dưới nó vốn có lưới, để hở nếu target vốn có lỗ ở đó.
- **Luật 2 — ghép theo bao trong:** viền ngoài của bản chép đi với viền target **bao quanh nó**, xét khi nhìn dọc pháp tuyến của bản chép; có nhiều viền như vậy thì lấy viền gần nhất. Lỗ của bản chép đi với viền target lồng với nó, nằm trong hoặc ngoài lỗ, miễn là ở trong viền ngoài của bản chép. Chỉ khi không có viền nào như vậy mới quay về cách cũ (so tâm và bán kính). Các cặp được ghi ở bước Debug "Pairs".
- **Luật 3 — viền ngoài của bản chép** là viền có diện tích lớn nhất (bao các viền khác), không chọn theo độ dài.
- **Luật 4 — hai viền chạm nhau tại một node trên mặt cong:** chọn vòng có diện tích lớn nhất. Không bắt buộc các node nằm trong một mặt phẳng.
- **Luật 5 — khi Ruled gập:**
  - Thử đổi thứ tự Edge 1/Edge 2.
  - Nếu vẫn gập, lùi viền target thêm một hàng ở chỗ khe tới bản chép mỏng hơn nửa cạnh bản chép (bước Debug "Rim k moved back"), rồi thử lại. Tối đa 2 lần.
  - Phần tử chạm viền khác thì không xóa.
- **Sửa thêm:**
  - Phép thử "dưới lỗ vốn có lưới" xét đủ hai tam giác của mỗi quad.
  - Điểm được chiếu lên mặt tam giác trước khi xét, nên trên mặt cong không còn bị lọt.
  - Danh sách mặt target bỏ các id phần tử đã xóa, vì HyperMesh dùng lại các id đó cho bản chép.
- **Kiểm trên scratch HyperMesh 2022.3:**
  - Ca tự dựng: `two_close` (hai washer cách 0,6 mm), `hole_large`, `hole_small` (lỗ target lớn hơn / nhỏ hơn lỗ washer), `curved` (mặt trụ R20), `dense` (lưới target mịn một bên).
  - Bài cũ: tấm 10×10, test_5, test_improve_imprint, test4.
  - Kết quả: cả 5 ca tự dựng PASS. Trong đó `dense` cần lùi viền một lần, `hole_large` và `hole_small` để hở lỗ đúng chỗ target có lỗ.
  - Bài cũ: tấm 10×10, test_5, test_improve_imprint, test4 hole_small 24/24 và test4 hole_larger 24/24 (mỗi loại washer một phiên, `probe_ruled_any.tcl`) đều PASS.
  - Khi mới có luật ghép cặp (chưa có luật xóa đảo và lùi viền), 4/5 ca tự dựng FAIL ở bước Ruled.
  - `probe_ruled_test4.tcl` chạy hole_small ngay trên kết quả của hole_larger nên FAIL. Bản trước luật cũng FAIL đúng chỗ đó, nên đây là giới hạn của cách thử, không phải hồi quy.
- **Đã đưa vào dist (24/11/2026):** `dist/imprint_old.zip` theo yêu cầu người dùng, trước khi thử trong phiên thật.
- **Giới hạn:** `test_fail` (vùng xóa chạm mép hở của mẩu cắt) vẫn chưa nối được. Lưới nối không được tối ưu chất lượng.
