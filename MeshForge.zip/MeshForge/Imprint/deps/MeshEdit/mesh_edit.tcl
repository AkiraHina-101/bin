# Equivalence for second-order meshes (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Elements: tria3/tria6/quad4/quad8/tetra4/tetra10. Corner nodes are merged (Replace: Node 1 onto
# Node 2; Equiv: picked corner nodes closer than a tolerance, lowest id kept). Every element on a
# merged node is looked at, picked or not: an edge then shared with different midside nodes keeps one
# (the lowest id); every midside node of an edge whose corner moved is put back at the middle of the
# new corners plus its old offset from the middle of the old corners: a straight edge stays straight,
# a curved one keeps its bow. An element that would collapse (both nodes on it) is deleted. Midside
# nodes are never merged on distance alone. One Undo step "Equivalence 2nd order" per change.
# Entry point for the menu: *evaltclscript mesh_edit.tcl 0 (small window: Replace and Split; one panel picks
# Node 1 then Node 2, repeated). Set ::MeshForge_MeshEdit_load_only to load the procedures only (tests).

if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::MeshForge_MeshEdit_load_only] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}
# Create element (TriaFill) is a group of this window: its procedures only
if {![llength [info commands ::MeshForge::TriaFill::embed]]} {
    set ::MeshForge_TriaFill_no_gui 1
    # the copy in deps/ of this folder, else the tool beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; set f [file join $h deps TriaFill tria_fill.tcl]; if {[file isfile $f]} {return $f}; file join [file dirname $h] TriaFill tria_fill.tcl}} [info script]]
    unset ::MeshForge_TriaFill_no_gui
}

namespace eval ::MeshForge::MeshEdit {
    variable running ""
    variable panelOpen 0
    variable closing 0
    variable next ""
    variable stop 0
    variable W .equiv2nd
    variable label "Mesh edit"
    # corner count and the corner pairs of the midside nodes, per config
    variable layout {
        103 {3 {}}
        104 {4 {}}
        106 {3 {{0 1} {1 2} {2 0}}}
        108 {4 {{0 1} {1 2} {2 3} {3 0}}}
        204 {4 {}}
        210 {4 {{0 1} {1 2} {2 0} {0 3} {1 3} {2 3}}}
    }
    variable sel
    variable opt
    variable status ""
    variable plan {}
    if {![info exists sel(elems)]} {set sel(elems) {}}
    foreach {k v} {tol 0.01 info "Nothing selected"} {if {![info exists opt($k)]} {set opt($k) $v}}
}

proc ::MeshForge::MeshEdit::vsub {a b} {list [expr {[lindex $a 0]-[lindex $b 0]}] [expr {[lindex $a 1]-[lindex $b 1]}] [expr {[lindex $a 2]-[lindex $b 2]}]}
proc ::MeshForge::MeshEdit::vadd {a b} {list [expr {[lindex $a 0]+[lindex $b 0]}] [expr {[lindex $a 1]+[lindex $b 1]}] [expr {[lindex $a 2]+[lindex $b 2]}]}
proc ::MeshForge::MeshEdit::vscale {a s} {list [expr {[lindex $a 0]*$s}] [expr {[lindex $a 1]*$s}] [expr {[lindex $a 2]*$s}]}
proc ::MeshForge::MeshEdit::dist {a b} {set d [vsub $a $b]; expr {sqrt([lindex $d 0]**2+[lindex $d 1]**2+[lindex $d 2]**2)}}
proc ::MeshForge::MeshEdit::vdot {a b} {expr {double([lindex $a 0])*[lindex $b 0]+double([lindex $a 1])*[lindex $b 1]+double([lindex $a 2])*[lindex $b 2]}}
proc ::MeshForge::MeshEdit::vcross {a b} {
    lassign $a ax ay az; lassign $b bx by bz
    list [expr {double($ay)*$bz-double($az)*$by}] [expr {double($az)*$bx-double($ax)*$bz}] [expr {double($ax)*$by-double($ay)*$bx}]
}

proc ::MeshForge::MeshEdit::existing {ids} {
    set out {}
    foreach e $ids {if {[hm_entityinfo exist elems $e -byid]} {lappend out $e}}
    return $out
}
proc ::MeshForge::MeshEdit::xyz {nodes} {
    set out [dict create]
    if {![llength $nodes]} {return $out}
    foreach n $nodes p [hm_getvalue nodes user_ids=$nodes dataname=coordinates] {dict set out $n $p}
    return $out
}
proc ::MeshForge::MeshEdit::ufind {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}

# Rows {elem corners pairs mids} of the elements of a known config; {rows skipped}.
proc ::MeshForge::MeshEdit::rows_of {elems} {
    variable layout
    set rows {}; set skipped 0
    if {![llength $elems]} {return [list {} 0]}
    foreach e $elems c [hm_getvalue elems user_ids=$elems dataname=config] nl [hm_getvalue elems user_ids=$elems dataname=nodes] {
        if {![dict exists $layout $c]} {incr skipped; continue}
        lassign [dict get $layout $c] nc pairs
        lappend rows [list $e [lrange $nl 0 [expr {$nc-1}]] $pairs [lrange $nl $nc [expr {$nc+[llength $pairs]-1}]]]
    }
    list $rows $skipped
}
# Elements using any of the nodes (cross reference, corner nodes are enough to find them).
proc ::MeshForge::MeshEdit::elems_on {nodes} {
    if {![llength $nodes]} {return {}}
    *createmark nodes 1 {*}$nodes
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set out [hm_getmark elems 2]
    *clearmark nodes 1; *clearmark elems 2
    return $out
}

# The plan (no model change): dict merge {node keep} (corner nodes), mids {node keep} (midside nodes),
# move {node xyz} (midside nodes put back), count of elements left out (other configs), related
# (elements outside the selection on a merged node: their midside nodes are put back too).
# Only the elements on a merged corner node are looked at after the merge search (speed).
proc ::MeshForge::MeshEdit::plan_of {elems tol} {
    variable layout
    set elems [existing $elems]
    if {![llength $elems]} {error "Select the elements."}
    if {![string is double -strict $tol] || $tol <= 0} {error "Tolerance must be a number above 0."}
    lassign [rows_of $elems] rows skipped
    if {![llength $rows]} {error "None of the picked elements is tria3/tria6/quad4/quad8/tetra4/tetra10."}
    set own {}
    foreach r $rows {lappend own {*}[lindex $r 1]}
    set own [lsort -unique -integer $own]
    set P [xyz $own]
    set ownSet [dict create]; foreach n $own {dict set ownSet $n 1}
    set cells [dict create]
    foreach n $own {
        lassign [dict get $P $n] x y z
        dict lappend cells [list [expr {int(floor($x/$tol))}] [expr {int(floor($y/$tol))}] [expr {int(floor($z/$tol))}]] $n
    }
    # corner nodes of elements outside the selection within tol of a picked corner (e.g. the part
    # around a picked part): nodes in the box of the selection, kept when in a cell next to a picked
    # corner, then only the corner nodes of their elements (a midside node is never merged)
    set xs {}; set ys {}; set zs {}
    dict for {n p} $P {lappend xs [lindex $p 0]; lappend ys [lindex $p 1]; lappend zs [lindex $p 2]}
    set xs [lsort -real $xs]; set ys [lsort -real $ys]; set zs [lsort -real $zs]
    set box [list [expr {[lindex $xs 0]-$tol}] [expr {[lindex $ys 0]-$tol}] [expr {[lindex $zs 0]-$tol}] [expr {[lindex $xs end]+$tol}] [expr {[lindex $ys end]+$tol}] [expr {[lindex $zs end]+$tol}]]
    *createmark nodes 1 "by box" {*}$box 0 inside 0 1 0
    set inBox [hm_getmark nodes 1]
    *clearmark nodes 1
    set cand {}
    set boxNew {}; foreach n $inBox {if {![dict exists $ownSet $n]} {lappend boxNew $n}}
    if {[llength $boxNew]} {
        foreach n $boxNew p [hm_getvalue nodes user_ids=$boxNew dataname=coordinates] {
            lassign $p x y z
            set i [expr {int(floor($x/$tol))}]; set j [expr {int(floor($y/$tol))}]; set k [expr {int(floor($z/$tol))}]
            set near 0
            foreach di {-1 0 1} {foreach dj {-1 0 1} {foreach dk {-1 0 1} {if {[dict exists $cells [list [expr {$i+$di}] [expr {$j+$dj}] [expr {$k+$dk}]]]} {set near 1}}}}
            if {$near} {lappend cand $n; dict set P $n $p}
        }
    }
    set other {}
    if {[llength $cand]} {
        set cset [dict create]; foreach n $cand {dict set cset $n 1}
        foreach r [lindex [rows_of [elems_on $cand]] 0] {foreach n [lindex $r 1] {if {[dict exists $cset $n]} {lappend other $n}}}
        set other [lsort -unique -integer $other]
    }
    set corners [lsort -unique -integer [concat $own $other]]
    foreach n $other {
        lassign [dict get $P $n] x y z
        dict lappend cells [list [expr {int(floor($x/$tol))}] [expr {int(floor($y/$tol))}] [expr {int(floor($z/$tol))}]] $n
    }
    # corner pairs within tol (grid of cell tol); at least one of the two is a picked corner
    foreach n $corners {set parent($n) $n}
    dict for {cell ns} $cells {
        lassign $cell i j k
        foreach di {-1 0 1} {foreach dj {-1 0 1} {foreach dk {-1 0 1} {
            set c2 [list [expr {$i+$di}] [expr {$j+$dj}] [expr {$k+$dk}]]
            if {![dict exists $cells $c2]} {continue}
            foreach a $ns {
                foreach b [dict get $cells $c2] {
                    if {$a >= $b} {continue}
                    if {![dict exists $ownSet $a] && ![dict exists $ownSet $b]} {continue}
                    if {[dist [dict get $P $a] [dict get $P $b]] <= $tol} {
                        set ra [ufind $a]; set rb [ufind $b]
                        if {$ra ne $rb} {if {$ra < $rb} {set parent($rb) $ra} else {set parent($ra) $rb}}
                    }
                }
            }
        }}}
    }
    set merge [dict create]
    foreach n $corners {set k [ufind $n]; if {$k != $n} {dict set merge $n $k}}
    set picked [dict create]; foreach r $rows {dict set picked [lindex $r 0] 1}
    set out [plan_merge $merge $P]
    set rel 0; foreach e [dict get $out elems] {if {![dict exists $picked $e]} {incr rel}}
    dict set out skipped $skipped
    dict set out related $rel
    return $out
}

# The plan for a corner merge {node keep} (P: coordinates known so far): every element on a merged
# node (picked or not) is looked at; its midside nodes are merged on a shared edge and put back on
# their edge. Refuses an element whose corners would collapse.
proc ::MeshForge::MeshEdit::plan_merge {merge P} {
    set touched [dict create]
    dict for {n k} $merge {dict set touched $n 1; dict set touched $k 1}
    # the elements on a merged node: picked ones and related ones outside the selection
    set touched [dict create]
    dict for {n k} $merge {dict set touched $n 1; dict set touched $k 1}
    set onM [elems_on [dict keys $touched]]
    set rows {}
    if {[llength $onM]} {lassign [rows_of $onM] rows skip2}
    set allN {}; foreach r $rows {lappend allN {*}[lindex $r 1] {*}[lindex $r 3]}
    set P [dict merge [xyz [lsort -unique -integer $allN]] $P]
    # an element whose corners would collapse onto each other (it has both nodes) is deleted, as a
    # native replace leaves no degenerate element; its midside nodes are not looked at
    set collapse {}; set keepRows {}
    foreach r $rows {
        set m {}; foreach n [lindex $r 1] {lappend m [expr {[dict exists $merge $n] ? [dict get $merge $n] : $n}]}
        if {[llength [lsort -unique $m]] < [llength $m]} {lappend collapse [lindex $r 0]} else {lappend keepRows $r}
    }
    set rows $keepRows
    # edges by their new corner pair: midside nodes and their old offsets
    set edges [dict create]
    foreach r $rows {
        lassign $r e cn pairs mids
        foreach pr $pairs m $mids {
            if {$m eq "" || $m == 0} {continue}
            lassign $pr i j
            set a [lindex $cn $i]; set b [lindex $cn $j]
            set A [expr {[dict exists $merge $a] ? [dict get $merge $a] : $a}]
            set B [expr {[dict exists $merge $b] ? [dict get $merge $b] : $b}]
            set key [expr {$A < $B ? "$A $B" : "$B $A"}]
            set off [vsub [dict get $P $m] [vscale [vadd [dict get $P $a] [dict get $P $b]] 0.5]]
            set moved [expr {$A != $a || $B != $b}]
            dict lappend edges $key [list $m $off $moved]
        }
    }
    set mids [dict create]; set move [dict create]
    dict for {key items} $edges {
        lassign $key A B
        set ms {}; set offs {}; set anyMoved 0
        foreach it $items {
            lassign $it m off moved
            if {[lsearch -exact $ms $m] < 0} {lappend ms $m; lappend offs $off}
            if {$moved} {set anyMoved 1}
        }
        set ms2 [lsort -integer $ms]
        set keep [lindex $ms2 0]
        foreach m $ms2 {if {$m != $keep} {dict set mids $m $keep}}
        if {[llength $ms2] > 1 || $anyMoved} {
            set o {0.0 0.0 0.0}; foreach off $offs {set o [vadd $o $off]}
            set o [vscale $o [expr {1.0/[llength $offs]}]]
            dict set move $keep [vadd [vscale [vadd [dict get $P $A] [dict get $P $B]] 0.5] $o]
        }
    }
    dict create merge $merge mids $mids move $move rows [llength $rows] elems $onM collapse $collapse
}

# The plan to replace corner node n1 by corner node n2 (n1 goes onto n2, its elements take n2).
# Node 1 goes onto Node 2 and the two become one node at Node 2's place; keep (1 or 2) says whose id
# stays. An element that would collapse (it has both nodes) is deleted; midside nodes follow.
proc ::MeshForge::MeshEdit::plan_pair {n1 n2 {mode equiv} {keep 2}} {
    foreach {n w} [list $n1 "Node 1" $n2 "Node 2"] {
        if {![string is integer -strict $n] || ![hm_entityinfo exist nodes $n -byid]} {error "Pick $w."}
    }
    if {$n1 == $n2} {error "Node 1 and Node 2 are the same node."}
    set es [elems_on [list $n1 $n2]]
    set corner [dict create]; set mid [dict create]
    foreach r [lindex [rows_of $es] 0] {
        foreach n [lindex $r 1] {dict set corner $n 1}
        foreach n [lindex $r 3] {dict set mid $n 1}
    }
    foreach {n w} [list $n1 "Node 1" $n2 "Node 2"] {
        if {[dict exists $mid $n] && ![dict exists $corner $n]} {error "$w is a midside node: pick corner nodes (midside nodes follow their edges)."}
    }
    set plan [plan_merge [dict create $n1 $n2] [xyz [list $n1 $n2]]]
    # Node 1 keeps its id: after the merge the node left (Node 2) is renumbered to Node 1's id
    if {$keep == 1} {dict set plan renumber [list $n2 $n1]}
    return $plan
}
# Replace: corner node n1 moved onto n2 (kept as its own node); every midside node of an edge on n1
# put back at the middle of its new corners plus its old offset.
proc ::MeshForge::MeshEdit::plan_move {n1 n2} {
    set es [elems_on [list $n1]]
    lassign [rows_of $es] rows skip
    set allN [list $n1 $n2]; foreach r $rows {lappend allN {*}[lindex $r 1] {*}[lindex $r 3]}
    set P [xyz [lsort -unique -integer $allN]]
    set to [dict get $P $n2]
    set move [dict create]
    foreach r $rows {
        lassign $r e cn pairs mids
        foreach pr $pairs m $mids {
            if {$m eq "" || $m == 0 || [dict exists $move $m]} {continue}
            lassign $pr i j
            set a [lindex $cn $i]; set b [lindex $cn $j]
            if {$a != $n1 && $b != $n1} {continue}
            set pa [dict get $P $a]; set pb [dict get $P $b]
            set off [vsub [dict get $P $m] [vscale [vadd $pa $pb] 0.5]]
            set qa [expr {$a == $n1 ? $to : $pa}]; set qb [expr {$b == $n1 ? $to : $pb}]
            dict set move $m [vadd [vscale [vadd $qa $qb] 0.5] $off]
        }
    }
    dict create merge {} mids {} move $move corner [dict create $n1 $n2] collapse {} rows [llength $rows] elems $es
}
proc ::MeshForge::MeshEdit::history_begin {l} {
    hm_private_frwk enablehistoryfromtcl 1
    if {[catch {*startnotehistorystate $l} msg options]} {
        catch {hm_private_frwk enablehistoryfromtcl 0}
        return -options $options $msg
    }
}
proc ::MeshForge::MeshEdit::history_end {l} {catch {*endnotehistorystate $l}; catch {hm_private_frwk enablehistoryfromtcl 0}}

# Applies a plan (one Undo step): collapsing elements deleted, corner and midside nodes replaced,
# midside nodes put back; nodes no element uses any more removed. Returns {corners mids moved deleted}.
proc ::MeshForge::MeshEdit::apply {plan} {
    variable label
    set merge [dict get $plan merge]; set mids [dict get $plan mids]; set move [dict get $plan move]
    set coll [expr {[dict exists $plan collapse] ? [dict get $plan collapse] : {}}]
    set cmove [expr {[dict exists $plan corner] ? [dict get $plan corner] : {}}]
    if {![dict size $merge] && ![dict size $mids] && ![dict size $move] && ![dict size $cmove]} {return {0 0 0 0}}
    history_begin $label
    set code [catch {
        if {[llength $coll]} {*createmark elems 1 {*}$coll; *deletemark elems 1; *clearmark elems 1}
        # Replace: the corner node moved onto the other one (not merged)
        dict for {n k} $cmove {*replacenodes $n $k 0 0}
        # corners: node replaced by the kept one (moved onto it, elements take it)
        dict for {n k} $merge {*replacenodes $n $k 1 0}
        dict for {n k} $mids {*replacenodes $n $k 1 0}
        dict for {n p} $move {if {[hm_entityinfo exist nodes $n -byid]} {*nodemodify $n {*}$p}}
        # *replacenodes leaves the replaced node in the model: removed when no element uses it any more
        # (every element on the kept nodes is read in full: the cross reference misses midside nodes)
        set gone {}; foreach n [concat [dict keys $merge] [dict keys $mids]] {if {[hm_entityinfo exist nodes $n -byid]} {lappend gone $n}}
        if {[llength $gone]} {
            set near [elems_on [lsort -unique -integer [concat [dict values $merge] [dict values $mids] $gone]]]
            set used [dict create]
            if {[llength $near]} {foreach nl [hm_getvalue elems user_ids=$near dataname=nodes] {foreach x $nl {dict set used $x 1}}}
            set del {}; foreach n $gone {if {![dict exists $used $n]} {lappend del $n}}
            # (an unused node leaves the model when its temp mark is cleared)
            if {[llength $del]} {*createmark nodes 1 {*}$del; *nodemarkcleartempmark 1; *clearmark nodes 1}
        }
        if {[dict exists $plan renumber]} {
            lassign [dict get $plan renumber] from to
            if {[hm_entityinfo exist nodes $to -byid]} {error "node $to still exists, its id cannot be kept"}
            *createmark nodes 1 $from; *renumber nodes 1 $to 1 0 0; *clearmark nodes 1
        }
    } msg]
    history_end $label
    if {$code} {catch {*undohistorystate 1}; error "Equivalence failed ($msg). Nothing changed."}
    list [dict size $merge] [dict size $mids] [dict size $move] [llength $coll]
}
proc ::MeshForge::MeshEdit::run {elems tol} {apply [plan_of $elems $tol]}

# Midsides after a move: on every edge of the picked elements (and of the elements sharing their
# corner nodes) the midside node slid along its edge (part along the edge above 0.1 % of its length)
# is put back: the part along the edge removed, the part across it (the bow) kept.
proc ::MeshForge::MeshEdit::midside_plan {elems} {
    set elems [existing $elems]
    if {![llength $elems]} {error "Select the elements."}
    lassign [rows_of $elems] rows skipped
    set cn {}; foreach r $rows {lappend cn {*}[lindex $r 1]}
    set all [lsort -unique -integer [concat $elems [elems_on [lsort -unique -integer $cn]]]]
    lassign [rows_of $all] rows skip2
    set allN {}; foreach r $rows {lappend allN {*}[lindex $r 1] {*}[lindex $r 3]}
    set P [xyz [lsort -unique -integer $allN]]
    set move [dict create]
    foreach r $rows {
        lassign $r e cnr pairs mids
        foreach pr $pairs m $mids {
            if {$m eq "" || $m == 0 || [dict exists $move $m]} {continue}
            lassign $pr i j
            set pa [dict get $P [lindex $cnr $i]]; set pb [dict get $P [lindex $cnr $j]]
            set d [vsub $pb $pa]
            set L [expr {sqrt([lindex $d 0]**2+[lindex $d 1]**2+[lindex $d 2]**2)}]
            if {$L <= 0} {continue}
            set t [vscale $d [expr {1.0/$L}]]
            set M [vscale [vadd $pa $pb] 0.5]
            set off [vsub [dict get $P $m] $M]
            set ta [expr {[lindex $off 0]*[lindex $t 0]+[lindex $off 1]*[lindex $t 1]+[lindex $off 2]*[lindex $t 2]}]
            if {abs($ta) <= 1e-3*$L} {continue}
            dict set move $m [vadd $M [vsub $off [vscale $t $ta]]]
        }
    }
    dict create merge {} mids {} move $move skipped $skipped rows [llength $rows] related [expr {[llength $all]-[llength $elems]}]
}
proc ::MeshForge::MeshEdit::run_pair {n1 n2} {apply [plan_pair $n1 $n2]}

# The plan to equivalence picked nodes: corner nodes among them closer than tol are merged (lowest id
# kept, at its place); midside nodes among them are left out (they follow their edges).
proc ::MeshForge::MeshEdit::plan_nodes {nodes tol} {
    if {![string is double -strict $tol] || $tol <= 0} {error "Tolerance must be a number above 0."}
    set nodes [lsort -unique -integer $nodes]
    if {[llength $nodes] < 2} {error "Pick at least two nodes."}
    set es [elems_on $nodes]
    set corner [dict create]
    foreach r [lindex [rows_of $es] 0] {foreach n [lindex $r 1] {dict set corner $n 1}}
    set cn {}; foreach n $nodes {if {[dict exists $corner $n]} {lappend cn $n}}
    if {[llength $cn] < 2} {error "Fewer than two corner nodes picked (midside nodes follow their edges)."}
    set P [xyz $cn]
    foreach n $cn {set parent($n) $n}
    set cells [dict create]
    foreach n $cn {
        lassign [dict get $P $n] x y z
        dict lappend cells [list [expr {int(floor($x/$tol))}] [expr {int(floor($y/$tol))}] [expr {int(floor($z/$tol))}]] $n
    }
    dict for {cell ns} $cells {
        lassign $cell i j k
        foreach di {-1 0 1} {foreach dj {-1 0 1} {foreach dk {-1 0 1} {
            set c2 [list [expr {$i+$di}] [expr {$j+$dj}] [expr {$k+$dk}]]
            if {![dict exists $cells $c2]} {continue}
            foreach a $ns {foreach b [dict get $cells $c2] {
                if {$a >= $b || [dist [dict get $P $a] [dict get $P $b]] > $tol} {continue}
                set ra [ufind $a]; set rb [ufind $b]
                if {$ra ne $rb} {if {$ra < $rb} {set parent($rb) $ra} else {set parent($ra) $rb}}
            }}
        }}}
    }
    set merge [dict create]
    foreach n $cn {set k [ufind $n]; if {$k != $n} {dict set merge $n $k}}
    if {![dict size $merge]} {error "No two picked corner nodes are closer than $tol."}
    plan_merge $merge $P
}

# ---------------------------------------------------------------- menu entries (no window)
proc ::MeshForge::MeshEdit::message {text} {puts "Mesh edit: $text"; catch {hm_usermessage $text}}
proc ::MeshForge::MeshEdit::pick_one {prompt} {
    *clearmark nodes 1
    catch {::TestToolSession::panel *createmarkpanel nodes 1 $prompt}
    set n [lindex [hm_getmark nodes 1] 0]
    *clearmark nodes 1
    return $n
}
# Loop: one panel picks two nodes in order (Node 1 then Node 2); Node 1 goes onto Node 2. Again until
# the panel is left empty. mode replace keeps every element; mode equiv deletes the ones that collapse.
# Split (Node 2 is a corner, Node 1 the other node; in the panel the corner is clicked first):
# - Node 1 and Node 2 are the corners opposite the edge u-v shared by two triangles (tria3/tria6).
#   atCrossing 0: u-v is swapped for Node 1 - Node 2 (2 elements stay 2, no node is made where the two
#   lines cross). atCrossing 1: a new node where the line Node 1 - Node 2 crosses u-v (on its curve for
#   tria6), shared by every element on u-v, each split in two there (2 -> 4).
# - else Node 1 lies on or near an edge a-b (a hanging node, or a node of another part across a gap):
#   the triangle of Node 2 whose corner angle holds Node 1 gives the edge a-b opposite Node 2 (no such
#   triangle, e.g. tetras: the edge of an element on Node 2 that Node 1 lies on), and every element
#   with the edge a-b (tria3/tria6/tetra4/tetra10, e.g. all the tetras around it) is cut
#   in two at Node 1 itself (both modes use that corner). One copy has b replaced
#   by the split node, one has a replaced.
# Midside nodes: kept on unchanged edges, the ones already on a-Node 1 / Node 1-b reused (else made,
# on the curve of a-b for the crossing node), one new midside node per new edge split node - corner,
# shared by the elements on it; the old midside node of a-b goes when unused. Same component, same
# orientation. One Undo step. Returns {old new}.
proc ::MeshForge::MeshEdit::split_pair {n1 n2 {atCrossing 0}} {
    variable label
    foreach {n w} [list $n1 "Node 1" $n2 "Node 2"] {
        if {![string is integer -strict $n] || ![hm_entityinfo exist nodes $n -byid]} {error "Pick $w."}
    }
    if {$n1 == $n2} {error "Node 1 and Node 2 are the same node."}
    set p1 [lindex [xyz [list $n1]] 1]
    set p2 [lindex [xyz [list $n2]] 1]
    set cross {}
    set across [across_edge $n1 $n2]
    if {[llength $across]} {
        if {!$atCrossing} {return [flip_pair $n1 $n2]}
        lassign $across a b
        set cross [crossing $p1 $p2 $a $b [mid_of [lindex [rows_of [elems_on [list $a $b]]] 0] $a $b]]
    } else {
        # The triangle of Node 2 whose corner angle at Node 2 holds Node 1 (Node 1 = Node 2 +
        # s (a - Node 2) + t (b - Node 2), s > 0, t > 0, least squares); its edge a-b opposite Node 2 is
        # cut (Node 1 may lie past it, across a gap, or off its plane); the one with s + t nearest 1 wins.
        set best ""; set bd 1e300
        foreach r [lindex [rows_of [elems_on [list $n2]]] 0] {
            set cn [lindex $r 1]
            if {[llength $cn] != 3 || $n1 in $cn} {continue}
            set i2 [lsearch -exact $cn $n2]
            set a [lindex $cn [expr {($i2+1)%3}]]; set b [lindex $cn [expr {($i2+2)%3}]]
            set Q [xyz [list $a $b]]
            set u [vsub [dict get $Q $a] $p2]; set v [vsub [dict get $Q $b] $p2]; set w [vsub $p1 $p2]
            set uu 0.0; set uv 0.0; set vv 0.0; set wu 0.0; set wv 0.0
            foreach k {0 1 2} {
                set uu [expr {$uu+double([lindex $u $k])*[lindex $u $k]}]; set uv [expr {$uv+double([lindex $u $k])*[lindex $v $k]}]
                set vv [expr {$vv+double([lindex $v $k])*[lindex $v $k]}]; set wu [expr {$wu+double([lindex $w $k])*[lindex $u $k]}]
                set wv [expr {$wv+double([lindex $w $k])*[lindex $v $k]}]
            }
            set det [expr {$uu*$vv-$uv*$uv}]
            if {abs($det) < 1e-30} {continue}
            set sA [expr {($wu*$vv-$wv*$uv)/$det}]; set tB [expr {($wv*$uu-$wu*$uv)/$det}]
            if {$sA <= 0 || $tB <= 0} {continue}
            set f [expr {$tB/($sA+$tB)}]
            if {$f <= 0.02 || $f >= 0.98} {continue}
            set score [expr {abs($sA+$tB-1.0)}]
            if {$score < $bd} {set bd $score; set best [list $a $b]}
        }
        # no such triangle (e.g. tetras): the edge of an element on Node 2 that Node 1 lies on
        if {$best eq ""} {set best [edge_near $n1 $n2 $p1]}
        if {$best eq ""} {error "Node 1 is not on an edge, and Node 1 and Node 2 are not the opposite corners of two triangles."}
        lassign $best a b
    }
    cut_edge $a $b $n1 $cross
}
# Perpendicular cut: node p projected square onto the edge a-b (picked as two corner nodes); every
# element on a-b is cut in two at the foot of the perpendicular (a new node on the straight edge; the
# midside nodes of the halves at their middles). Returns {old new}.
proc ::MeshForge::MeshEdit::perp_cut {p a b} {
    foreach {n w} [list $p "the node to project" $a "edge node 1" $b "edge node 2"] {
        if {![string is integer -strict $n] || ![hm_entityinfo exist nodes $n -byid]} {error "Pick $w."}
    }
    if {$a == $b || $p == $a || $p == $b} {error "Pick 3 different nodes."}
    set Q [xyz [list $p $a $b]]
    set P [dict get $Q $p]; set A [dict get $Q $a]; set B [dict get $Q $b]
    set ab [vsub $B $A]; set l2 [vdot $ab $ab]
    if {$l2 <= 0} {error "The edge has no length."}
    set t [expr {[vdot [vsub $P $A] $ab]/$l2}]
    if {$t <= 0.02 || $t >= 0.98} {error [format "The foot falls outside the edge (at %.0f %% of it)." [expr {100*$t}]]}
    set on 0
    foreach r [lindex [rows_of [elems_on [list $a $b]]] 0] {
        set cc [lindex $r 1]
        if {$a in $cc && $b in $cc} {
            if {[hm_getvalue elems id=[lindex $r 0] dataname=config] in {104 108}} {error "The edge belongs to a quad: only trias and tetras are cut."}
            set on 1
        }
    }
    if {!$on} {error "Nodes $a and $b are not an edge of an element."}
    set F [vadd $A [vscale $ab $t]]
    set cross [dict create at $F a [vscale [vadd $A $F] 0.5] b [vscale [vadd $F $B] 0.5]]
    cut_edge $a $b "" $cross
}
# Split line: an element cut in two along the line between two of its nodes. Two opposite corners of a
# quad (quad4 / quad8): two trias (tria3 / tria6, a new midside node in the middle of the diagonal).
# Otherwise as Split at a node on an edge (a corner and a node on the opposite edge).
proc ::MeshForge::MeshEdit::split_line {n1 n2} {
    variable label
    foreach {n w} [list $n1 "Node 1" $n2 "Node 2"] {
        if {![string is integer -strict $n] || ![hm_entityinfo exist nodes $n -byid]} {error "Pick $w."}
    }
    if {$n1 == $n2} {error "Pick 2 different nodes."}
    set quad ""
    foreach r [lindex [rows_of [elems_on [list $n1 $n2]]] 0] {
        set cc [lindex $r 1]
        if {!($n1 in $cc && $n2 in $cc)} {continue}
        if {[hm_getvalue elems id=[lindex $r 0] dataname=config] in {104 108}} {
            set i [lsearch -exact $cc $n1]; set j [lsearch -exact $cc $n2]
            if {abs($i-$j) == 2} {set quad $r; break}
            error "Nodes $n1 and $n2 are an edge of the quad: pick opposite corners."
        }
        if {[llength $cc] == 3} {error "Nodes $n1 and $n2 are already an edge."}
    }
    if {$quad eq ""} {
        # a corner and a node on the opposite edge: the Split at a node
        if {![catch {split_pair $n2 $n1 0} r]} {return $r}
        if {![catch {split_pair $n1 $n2 0} r]} {return $r}
        error "Nodes $n1 and $n2 are not opposite corners of a quad, nor a corner and a node on its opposite edge."
    }
    lassign $quad e cc pairs mm
    set cfg [hm_getvalue elems id=$e dataname=config]
    set i [lsearch -exact $cc $n1]; set j [lsearch -exact $cc $n2]
    if {$i > $j} {lassign [list $i $j] j i}
    history_begin $label
    set code [catch {
        set cur [hm_info currentcollector components]
        if {[catch {hm_getvalue elems id=$e dataname=collector.name} comp]} {set comp [hm_getvalue comps id=[hm_getvalue elems id=$e dataname=collector] dataname=name]}
        catch {*currentcollector components $comp}
        set new {}
        set d {}
        if {$cfg == 108} {
            set at [vscale [vadd [hm_getvalue nodes id=[lindex $cc $i] dataname=coordinates] [hm_getvalue nodes id=[lindex $cc $j] dataname=coordinates]] 0.5]
            *createnode {*}$at 0 0 0
            set d [hm_latestentityid nodes]
        }
        # tria 1: corners i, i+1, j; tria 2: corners j, j+1, i (same turning sense as the quad)
        foreach {s0 s1 s2} [list $i [expr {$i+1}] $j $j [expr {($j+1)%4}] $i] {
            set corners [list [lindex $cc $s0] [lindex $cc $s1] [lindex $cc $s2]]
            set mids {}
            if {$cfg == 108} {set mids [list [lindex $mm $s0] [lindex $mm $s1] $d]}
            *createlist nodes 1 {*}$corners {*}$mids
            *createelement [expr {$cfg == 108 ? 106 : 103}] 1 1 1
            lappend new [hm_latestentityid elems]
        }
        if {$cur ne "" && [hm_entityinfo exist comps $cur -byname]} {*currentcollector components $cur}
        *createmark elems 1 $e; *deletemark elems 1; *clearmark elems 1
        if {$d ne ""} {*createmark nodes 1 $d; *nodemarkcleartempmark 1; *clearmark nodes 1}
    } msg]
    history_end $label
    if {$code} {catch {*undohistorystate 1}; error "Split line failed ($msg). Nothing changed."}
    list [list $e] $new
}

# Every element with the edge a-b cut in two at a node: Node 1 itself (n1, cross {}) or a new node
# at [dict get $cross at] (the halves' midside nodes at [dict get $cross a] / [dict get $cross b]).
# One copy has b replaced by the split node, one has a replaced. One Undo step. Returns {old new}.
proc ::MeshForge::MeshEdit::cut_edge {a b n1 cross} {
    variable label
    # every element with the edge a-b, not already using the split node (Node 1 when it is split at)
    set targets {}
    foreach r [lindex [rows_of [elems_on [list $a $b]]] 0] {
        set cc [lindex $r 1]
        if {(![llength $cross] && $n1 in $cc) || !($a in $cc) || !($b in $cc)} {continue}
        lappend targets $r
    }
    # midside nodes of Node 1's own elements (a hanging node) are reused on the halves of a-b
    set rows1 {}
    if {![llength $cross]} {set rows1 [lindex [rows_of [elems_on [list $n1]]] 0]}
    history_begin $label
    set code [catch {
        # the node the elements are split at: Node 1 itself, or the new node at the crossing
        set hn $n1
        if {[llength $cross]} {*createnode {*}[dict get $cross at] 0 0 0; set hn [hm_latestentityid nodes]}
        set new {}; set old {}; set made [dict create]; set chk {}
        set cur [hm_info currentcollector components]
        foreach r $targets {
            lassign $r ee cc pairs mm
            lappend old $ee
            set cfg [hm_getvalue elems id=$ee dataname=config]
            if {[catch {hm_getvalue elems id=$ee dataname=collector.name} comp]} {set comp [hm_getvalue comps id=[hm_getvalue elems id=$ee dataname=collector] dataname=name]}
            catch {*currentcollector components $comp}
            foreach gone [list $b $a] {
                # this copy: the corner "gone" replaced by the split node
                set c2 {}; foreach c $cc {lappend c2 [expr {$c == $gone ? $hn : $c}]}
                set m2 {}
                foreach pr $pairs m $mm {
                    lassign $pr i j
                    set u [lindex $c2 $i]; set v [lindex $c2 $j]
                    if {$u != $hn && $v != $hn} {lappend m2 $m; continue}
                    if {$m != 0 && $m ne ""} {lappend chk $m}
                    set key [lsort -integer [list $u $v]]
                    if {![dict exists $made $key]} {
                        set mx [expr {($u == $a || $v == $a || $u == $b || $v == $b) ? [mid_of $rows1 $u $v] : ""}]
                        if {$mx eq "" || $mx == 0} {
                            set at [vscale [vadd [hm_getvalue nodes id=$u dataname=coordinates] [hm_getvalue nodes id=$v dataname=coordinates]] 0.5]
                            # a half of a-b at the crossing: on the curve of a-b
                            if {[llength $cross]} {
                                if {$u == $a || $v == $a} {set at [dict get $cross a]} elseif {$u == $b || $v == $b} {set at [dict get $cross b]}
                            }
                            *createnode {*}$at 0 0 0
                            set mx [hm_latestentityid nodes]
                        }
                        dict set made $key $mx
                        lappend chk $mx
                    }
                    lappend m2 [dict get $made $key]
                }
                *createlist nodes 1 {*}$c2 {*}$m2; *createelement $cfg 1 1 1
                lappend new [hm_latestentityid elems]
            }
        }
        if {$cur ne "" && [hm_entityinfo exist comps $cur -byname]} {*currentcollector components $cur}
        *createmark elems 1 {*}$old; *deletemark elems 1; *clearmark elems 1
        # nodes made here (also the new split node) or left unused (the old midside node of a-b):
        # temp mark cleared, an unused one leaves the model
        if {$hn != $n1} {lappend chk $hn}
        set chk [lsort -unique -integer $chk]
        if {[llength $chk]} {*createmark nodes 1 {*}$chk; *nodemarkcleartempmark 1; *clearmark nodes 1}
    } msg]
    history_end $label
    if {$code} {catch {*undohistorystate 1}; error "Split failed ($msg). Nothing changed."}
    list $old $new
}
# The edge {a b} of an element on Node 2 (any config: every corner pair, or the edges of its midside
# nodes) that Node 1 (at p1) lies on: along the edge as drawn (a-m-b through its midside node), off it
# by at most 5 % of its length, not at its ends; the nearest one, {} when none.
proc ::MeshForge::MeshEdit::edge_near {n1 n2 p1} {
    set best {}; set bd 1e300
    set seen [dict create]
    foreach r [lindex [rows_of [elems_on [list $n2]]] 0] {
        lassign $r e cn pairs mm
        if {$n1 in $cn} {continue}
        set edges {}
        if {[llength $pairs]} {
            foreach pr $pairs m $mm {lappend edges [list [lindex $cn [lindex $pr 0]] [lindex $cn [lindex $pr 1]] $m]}
        } else {
            set k [llength $cn]
            for {set i 0} {$i < $k} {incr i} {for {set j [expr {$i+1}]} {$j < $k} {incr j} {lappend edges [list [lindex $cn $i] [lindex $cn $j] 0]}}
        }
        foreach ed $edges {
            lassign $ed a b m
            set key [lsort -integer [list $a $b]]
            if {[dict exists $seen $key] || $m == $n1} {continue}
            dict set seen $key 1
            set pts [list $a $b]; if {$m ne "" && $m != 0} {set pts [list $a $m $b]}
            set Q [xyz $pts]
            set len 0.0; set offMin 1e300; set tAt 0.0
            for {set q 0} {$q < [llength $pts]-1} {incr q} {
                set pa [dict get $Q [lindex $pts $q]]; set d [vsub [dict get $Q [lindex $pts [expr {$q+1}]]] $pa]
                set L2 [vdot $d $d]; set L [expr {sqrt($L2)}]
                if {$L2 > 0} {
                    set t [expr {max(0.0,min(1.0,[vdot [vsub $p1 $pa] $d]/$L2))}]
                    set off [dist $p1 [vadd $pa [vscale $d $t]]]
                    if {$off < $offMin} {set offMin $off; set tAt [expr {$len+$t*$L}]}
                }
                set len [expr {$len+$L}]
            }
            if {$len <= 0} {continue}
            set f [expr {$tAt/$len}]
            if {$f <= 0.02 || $f >= 0.98 || $offMin > 0.05*$len} {continue}
            if {$offMin < $bd} {set bd $offMin; set best [list $a $b]}
        }
    }
    return $best
}
# The edge {u v} when Node 1 and Node 2 are the corners opposite it in two triangles sharing it, else {}.
proc ::MeshForge::MeshEdit::across_edge {n1 n2} {
    set tri1 {}
    foreach r [lindex [rows_of [elems_on [list $n1]]] 0] {if {[llength [lindex $r 1]] == 3 && !($n2 in [lindex $r 1])} {lappend tri1 [lindex $r 1]}}
    foreach r [lindex [rows_of [elems_on [list $n2]]] 0] {
        set cb [lindex $r 1]
        if {[llength $cb] != 3 || $n1 in $cb} {continue}
        set i2 [lsearch -exact $cb $n2]
        set u [lindex $cb [expr {($i2+1)%3}]]; set v [lindex $cb [expr {($i2+2)%3}]]
        foreach ca $tri1 {if {$u in $ca && $v in $ca} {return [list $u $v]}}
    }
    return {}
}
# Where the line p1-p2 crosses the edge a-b (m: its midside node, "" for tria3): the point of the edge
# curve a + s (b - a) + 4 s (1 - s) (m - middle of a-b) on the plane through the line that is square to
# the surface (normal (p2 - p1) x (b - a)). Returns {at <xyz> a <xyz> b <xyz>}: the crossing and the
# midside points of the halves a-crossing and crossing-b (at s/2 and (1+s)/2 on the same curve).
proc ::MeshForge::MeshEdit::crossing {p1 p2 a b m} {
    set Q [xyz [list $a $b]]
    set pa [dict get $Q $a]; set pb [dict get $Q $b]
    set off {0.0 0.0 0.0}
    if {$m ne "" && $m != 0} {set off [vsub [lindex [xyz [list $m]] 1] [vscale [vadd $pa $pb] 0.5]]}
    set d [vsub $p2 $p1]
    set side [vcross $d [vcross $d [vsub $pb $pa]]]
    set g0 [vdot [vsub $pa $p1] $side]; set g1 [vdot [vsub $pb $p1] $side]
    if {$g0*$g1 >= 0} {error "The line Node 1 - Node 2 does not cross the edge $a - $b."}
    # bisection on the side of the plane (the curve crosses it once between a and b)
    set lo 0.0; set hi 1.0
    for {set k 0} {$k < 60} {incr k} {
        set s [expr {($lo+$hi)/2}]
        set g [vdot [vsub [vadd [vadd $pa [vscale [vsub $pb $pa] $s]] [vscale $off [expr {4*$s*(1-$s)}]]] $p1] $side]
        if {($g < 0) == ($g0 < 0)} {set lo $s} else {set hi $s}
    }
    set s [expr {($lo+$hi)/2}]
    if {$s <= 0.02 || $s >= 0.98} {error "The line Node 1 - Node 2 crosses the edge $a - $b at a corner."}
    set out [dict create]
    foreach {k t} [list at $s a [expr {$s/2}] b [expr {(1+$s)/2}]] {
        dict set out $k [vadd [vadd $pa [vscale [vsub $pb $pa] $t]] [vscale $off [expr {4*$t*(1-$t)}]]]
    }
    return $out
}
# Swap: Node 1 and Node 2 are the corners opposite the edge u-v shared by two triangles (tria3/tria6):
# the edge u-v is replaced by Node 1 - Node 2 (2 elements stay 2, orientation of the first one kept).
# tria6: the midside nodes of the four outer edges kept, a new one on Node 1 - Node 2, the old one of
# u-v goes when unused. One Undo step. Returns {old new}.
proc ::MeshForge::MeshEdit::flip_pair {n1 n2} {
    variable label
    set r1 {}; set r2 {}
    set rowsA [lindex [rows_of [elems_on [list $n1]]] 0]
    set rowsB [lindex [rows_of [elems_on [list $n2]]] 0]
    foreach ra $rowsA {
        set ca [lindex $ra 1]
        if {[llength $ca] != 3 || $n2 in $ca} {continue}
        set i [lsearch -exact $ca $n1]
        set u [lindex $ca [expr {($i+1)%3}]]; set v [lindex $ca [expr {($i+2)%3}]]
        foreach rb $rowsB {
            set cb [lindex $rb 1]
            if {[llength $cb] == 3 && $u in $cb && $v in $cb && !($n1 in $cb)} {set r1 $ra; set r2 $rb; break}
        }
        if {[llength $r1]} {break}
    }
    if {![llength $r1]} {error "Node 1 is not on an edge, and Node 1 and Node 2 are not the opposite corners of two triangles."}
    lassign $r1 e1 c1 p1 m1
    lassign $r2 e2 c2 p2 m2
    set i [lsearch -exact $c1 $n1]
    set u [lindex $c1 [expr {($i+1)%3}]]; set v [lindex $c1 [expr {($i+2)%3}]]
    set cfg [hm_getvalue elems id=$e1 dataname=config]
    set mid [dict create]
    foreach r [list $r1 $r2] {
        lassign $r e cc pp mm
        foreach pr $pp m $mm {dict set mid [lsort -integer [list [lindex $cc [lindex $pr 0]] [lindex $cc [lindex $pr 1]]]] $m}
    }
    history_begin $label
    set code [catch {
        if {[catch {hm_getvalue elems id=$e1 dataname=collector.name} comp]} {set comp [hm_getvalue comps id=[hm_getvalue elems id=$e1 dataname=collector] dataname=name]}
        set cur [hm_info currentcollector components]
        catch {*currentcollector components $comp}
        set new {}
        if {$cfg == 106} {
            *createnode {*}[vscale [vadd [hm_getvalue nodes id=$n1 dataname=coordinates] [hm_getvalue nodes id=$n2 dataname=coordinates]] 0.5] 0 0 0
            set mN [hm_latestentityid nodes]
            set mOld [dict get $mid [lsort -integer [list $u $v]]]
            *createlist nodes 1 $n1 $u $n2 [dict get $mid [lsort -integer [list $n1 $u]]] [dict get $mid [lsort -integer [list $u $n2]]] $mN; *createelement 106 1 1 1
            lappend new [hm_latestentityid elems]
            *createlist nodes 1 $n1 $n2 $v $mN [dict get $mid [lsort -integer [list $n2 $v]]] [dict get $mid [lsort -integer [list $v $n1]]]; *createelement 106 1 1 1
            lappend new [hm_latestentityid elems]
        } else {
            *createlist nodes 1 $n1 $u $n2; *createelement 103 1 1 1
            lappend new [hm_latestentityid elems]
            *createlist nodes 1 $n1 $n2 $v; *createelement 103 1 1 1
            lappend new [hm_latestentityid elems]
        }
        if {$cur ne "" && [hm_entityinfo exist comps $cur -byname]} {*currentcollector components $cur}
        *createmark elems 1 $e1 $e2; *deletemark elems 1; *clearmark elems 1
        if {$cfg == 106} {*createmark nodes 1 $mOld $mN; *nodemarkcleartempmark 1; *clearmark nodes 1}
    } msg]
    history_end $label
    if {$code} {catch {*undohistorystate 1}; error "Swap failed ($msg). Nothing changed."}
    list [list $e1 $e2] $new
}
# Midside node of edge x-y in rows, else "".
proc ::MeshForge::MeshEdit::mid_of {rows x y} {
    foreach r $rows {
        lassign $r ee cc pp mm
        foreach pr $pp m $mm {
            lassign $pr u v
            set cu [lindex $cc $u]; set cv [lindex $cc $v]
            if {($cu == $x && $cv == $y) || ($cu == $y && $cv == $x)} {return $m}
        }
    }
    return ""
}
# Two nodes in the order clicked, with no proceed: one native nodes panel; while it is open the picked
# nodes are read every 150 ms (the order of the clicks kept) and the panel is left by itself
# (hm_exitpanel) at the second node. Proceed also works (then the order is the order of the ids if it
# could not be followed). Empty list: nothing picked (return/ESC).
proc ::MeshForge::MeshEdit::pick_two {prompt} {pick_n $prompt 2}
# One panel; it is left by itself once n nodes are picked (no Proceed needed). Returns them in the
# order clicked, {} when the panel was left empty or cancelled.
proc ::MeshForge::MeshEdit::pick_n {prompt n} {
    set ::MeshForge::MeshEdit::pickCount $n
    set ::MeshForge::MeshEdit::picked {}
    set ::MeshForge::MeshEdit::accepted 0
    *clearmark nodes 1
    set ::MeshForge::MeshEdit::pollId [after 150 ::MeshForge::MeshEdit::pick_poll]
    set ::MeshForge::MeshEdit::panelOpen 1
    set cancelled [catch {::TestToolSession::panel *createmarkpanel nodes 1 $prompt}]
    set ::MeshForge::MeshEdit::panelOpen 0
    catch {after cancel $::MeshForge::MeshEdit::pollId}
    set m {}; catch {set m [hm_getmark nodes 1]}
    *clearmark nodes 1
    if {[::TestToolSession::cancelled] || ($cancelled && !$::MeshForge::MeshEdit::accepted)} {return {}}
    set out {}
    foreach n $::MeshForge::MeshEdit::picked {if {$n in $m || ![llength $m]} {lappend out $n}}
    foreach n $m {if {!($n in $out)} {lappend out $n}}
    return [lrange $out 0 [expr {$n-1}]]
}
proc ::MeshForge::MeshEdit::pick_poll {} {
    set m {}
    if {[catch {set m [hm_getmark nodes 1]}]} {return}
    foreach n $m {if {!($n in $::MeshForge::MeshEdit::picked)} {lappend ::MeshForge::MeshEdit::picked $n}}
    set keep {}; foreach n $::MeshForge::MeshEdit::picked {if {$n in $m} {lappend keep $n}}
    set ::MeshForge::MeshEdit::picked $keep
    if {[llength $keep] >= $::MeshForge::MeshEdit::pickCount} {
        set ::MeshForge::MeshEdit::accepted 1
        catch {hm_exitpanel}
        return
    }
    set ::MeshForge::MeshEdit::pollId [after 150 ::MeshForge::MeshEdit::pick_poll]
}
# A mode button while a pick panel is open: the panel is left and its picks dropped; the same mode
# stops, the other mode starts at once.
proc ::MeshForge::MeshEdit::start_mode {mode} {
    if {[info exists ::MeshForge::MeshEdit::running] && $::MeshForge::MeshEdit::running ne ""} {
        set ::MeshForge::MeshEdit::next [expr {$mode eq $::MeshForge::MeshEdit::running ? "" : $mode}]
        set ::MeshForge::MeshEdit::stop 1
        if {$::MeshForge::MeshEdit::panelOpen} {
            catch {*clearmark nodes 1}
            catch {hm_exitpanel}
        }
        return
    }
    set ::MeshForge::MeshEdit::closing 0
    set ::MeshForge::MeshEdit::next ""
    if {[catch {pair_loop $mode} e]} {set ::MeshForge::MeshEdit::running ""; status $e}
    while {$::MeshForge::MeshEdit::next ne ""} {
        set m $::MeshForge::MeshEdit::next; set ::MeshForge::MeshEdit::next ""
        if {[catch {pair_loop $m} e]} {set ::MeshForge::MeshEdit::running ""; status $e}
    }
    if {$::MeshForge::MeshEdit::closing} {close}
}
proc ::MeshForge::MeshEdit::close {} {
    variable W; variable running; variable closing; variable next; variable stop; variable panelOpen
    # a Create element pick stops first; it calls close again when it has
    if {[llength [info commands ::MeshForge::TriaFill::release]] && [::MeshForge::TriaFill::release]} {return}
    if {$running ne ""} {
        set closing 1
        set stop 1
        set next ""
        if {$panelOpen} {catch {hm_exitpanel}}
        return
    }
    if {[winfo exists $W]} {destroy $W}
}
proc ::MeshForge::MeshEdit::pair_loop {mode} {
    variable W
    # the window stays up during the panels: its line shows the result or the reason of each pick
    set word [expr {$mode eq "replace" ? "Replace" : ($mode eq "split" ? "Split" : "Equiv")}]
    set ::MeshForge::MeshEdit::running $mode; set ::MeshForge::MeshEdit::stop 0
    while {!$::MeshForge::MeshEdit::stop} {
        if {$mode eq "perp"} {
            # the node to project (the panel goes on by itself), then the two nodes of the edge
            set p [pick_n "Perpendicular: click the node to project" 1]
            if {$::MeshForge::MeshEdit::stop || ![llength $p]} {break}
            set ab [pick_n "Perpendicular: click the 2 nodes of the edge" 2]
            if {$::MeshForge::MeshEdit::stop} {break}
            if {[llength $ab] != 2} {if {[llength $ab]} {status "Pick 2 edge nodes."; continue}; break}
            if {[catch {perp_cut [lindex $p 0] {*}$ab} r]} {status "Perpendicular: $r"} else {status "Perpendicular: [llength [lindex $r 0]] -> [llength [lindex $r 1]] elements."}
            continue
        }
        if {$mode eq "line"} {
            set ns [pick_n "Split line: click 2 nodes of the element" 2]
            if {$::MeshForge::MeshEdit::stop} {break}
            if {[llength $ns] != 2} {if {[llength $ns]} {status "Pick 2 nodes."; continue}; break}
            if {[catch {split_line {*}$ns} r]} {status "Split line: $r"} else {status "Split line: [llength [lindex $r 0]] -> [llength [lindex $r 1]] elements."}
            continue
        }
        set prompt [expr {$mode eq "split" ? "Split: click the corner, then the node to split at" : "Replace: click Node 1, then Node 2"}]
        set ns [pick_two $prompt]
        if {$::MeshForge::MeshEdit::stop} {break}
        if {[llength $ns] != 2} {
            if {[llength $ns]} {status "Pick 2 nodes."; continue}
            break
        }
        lassign $ns n1 n2
        lassign $ns n1 n2
        if {$mode eq "split"} {
            set atCrossing [expr {!$::MeshForge::MeshEdit::opt(splitEquiv)}]
            if {[catch {split_pair $n2 $n1 $atCrossing} r]} {status "Split $n1 / $n2: $r"} else {status "Split [llength [lindex $r 0]] -> [llength [lindex $r 1]] elements."}
            continue
        }
        if {[catch {apply [plan_pair $n1 $n2 $mode $::MeshForge::MeshEdit::opt(keep)]} r]} {status "$word $n1 -> $n2: $r"; continue}
        lassign $r c m v d
        set kid [expr {$::MeshForge::MeshEdit::opt(keep) == 1 ? $n1 : $n2}]
        set text "$word $n1 -> $n2 (id $kid)"
        if {$d} {append text ", $d deleted"}
        status "$text."
    }
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    set ::MeshForge::MeshEdit::running ""
}
proc ::MeshForge::MeshEdit::status {text} {
    set ::MeshForge::MeshEdit::status $text
    catch {hm_usermessage "Mesh edit: $text"}
    catch {update idletasks}
    message $text
    catch {hm_redraw}
}

# ---------------------------------------------------------------- window
# Center over the HyperMesh main window on the monitor it is on, negative screen coordinates kept (a
# monitor left of or above the primary one). In 2022.3 [wm frame .] is the HyperWorks top-level window:
# its Win32 rectangle (twapi), kept inside the work area of its monitor; without twapi the area of ".".
proc ::MeshForge::MeshEdit::place_center {} {
    variable W
    update idletasks
    set w [winfo reqwidth $W]; set h [winfo reqheight $W]
    set l [winfo rootx .]; set t [winfo rooty .]
    set r [expr {$l+[winfo width .]}]; set b [expr {$t+[winfo height .]}]
    set work {}
    catch {
        package require twapi
        set host [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $host] l t r b
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $host]] -workarea]
    }
    set x [expr {($l+$r-$w)/2}]; set y [expr {($t+$b-$h)/2}]
    if {[llength $work] == 4} {
        lassign $work wl wt wr wb
        set x [expr {max($wl,min($x,$wr-$w))}]; set y [expr {max($wt,min($y,$wb-$h))}]
    }
    wm geometry $W +$x+$y
}
proc ::MeshForge::MeshEdit::show {} {
    variable W; variable label
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W $label
    wm resizable $W 0 0
    set b [frame $W.body -padx 8 -pady 6]
    foreach {k v} {keep 2 splitEquiv 0} {if {![info exists ::MeshForge::MeshEdit::opt($k)]} {set ::MeshForge::MeshEdit::opt($k) $v}}
    set run [list ::TestToolSession::run "Mesh edit"]
    # Node pair: one row per operation, its button on the left and its option on the right
    set n [labelframe $b.pair -text "Node pair" -padx 6 -pady 2]
    button $b.rep -text "Replace" -width 12 -command [concat $run [list {::MeshForge::MeshEdit::start_mode replace} 1]]
    frame $b.repOpt
    label $b.repOpt.l -text "Keep"
    radiobutton $b.repOpt.k1 -text "Node 1" -variable ::MeshForge::MeshEdit::opt(keep) -value 1
    radiobutton $b.repOpt.k2 -text "Node 2" -variable ::MeshForge::MeshEdit::opt(keep) -value 2
    pack $b.repOpt.l $b.repOpt.k1 $b.repOpt.k2 -side left -padx {0 4}
    button $b.split -text "Split" -width 12 -command [concat $run [list {::MeshForge::MeshEdit::start_mode split} 1]]
    checkbutton $b.splitOpt -text "Equivalence" -variable ::MeshForge::MeshEdit::opt(splitEquiv)
    grid $b.rep $b.repOpt -in $n -sticky w -pady 2 -padx {0 8}
    grid $b.split $b.splitOpt -in $n -sticky w -pady 2 -padx {0 8}
    raise $b.rep; raise $b.repOpt; raise $b.split; raise $b.splitOpt
    # Cut element: the two cuts side by side
    set c [labelframe $b.cut -text "Cut element" -padx 6 -pady 2]
    button $b.perp -text "Perpendicular" -width 12 -command [concat $run [list {::MeshForge::MeshEdit::start_mode perp} 1]]
    button $b.line -text "Split line" -width 12 -command [concat $run [list {::MeshForge::MeshEdit::start_mode line} 1]]
    grid $b.perp $b.line -in $c -sticky w -pady 2 -padx {0 8}
    raise $b.perp; raise $b.line
    # Create element: a tria from three corner nodes (TriaFill)
    set e [labelframe $b.tria -text "Create element" -padx 6 -pady 2]
    ::MeshForge::TriaFill::embed $e $W "Mesh edit" ::MeshForge::MeshEdit::close
    grid $e.pick $e.o1 $e.o2 -sticky w -pady 2 -padx {0 4}
    grid configure $e.pick -padx {0 8}
    grid $e.clear $e.kept - -sticky w -pady 2 -padx {0 8}
    grid $n -row 0 -column 0 -sticky ew
    grid $c -row 1 -column 0 -sticky ew -pady {4 0}
    grid $e -row 2 -column 0 -sticky ew -pady {4 0}
    grid columnconfigure $b 0 -weight 1
    pack $b -fill x
    # no status row: messages go to the HyperMesh status bar (status)
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Mesh edit" ::MeshForge::MeshEdit::close 1]
    status Ready
    ::TestToolSession::place "Mesh edit" $W
    wm deiconify $W
    ::TestToolSession::attach "Mesh edit" $W
}
if {![info exists ::MeshForge_MeshEdit_load_only]} {::MeshForge::MeshEdit::show}
