# Pattern

Chép **y hệt** các element đã chọn từ một node gốc tới nhiều node đích. HyperMesh 2022.3, profile Nastran.

- Điểm vào: [pattern.tcl](pattern.tcl). Menu: Utility → **test** → **Pattern** (MAC [pattern.mac](pattern.mac), sinh bằng bộ sinh menu).
- Bản chuyển máy: `dist/HyperMesh_Test_Tools_2022.3/Pattern` (nút **Pattern** trong gói Test Tools). Sửa Tcl ở đây thì chép lại bản đó.

## Cách dùng

Tool không mở cửa sổ. Tool mở ba panel chọn native liên tiếp:
1. Element cần chép. Sau khi chọn, element được tô màu chọn native (mark 2 `high`) trong lúc chọn node; xong thì tool xóa màu.
2. **Một** node gốc.
3. Các node đích.

Kết quả hiện trên thanh thông báo và Tcl console, ví dụ: `3 copies of 18 elements (54 new elements) in 40 ms.` Thoát panel (ESC hoặc bấm return khi chưa chọn) thì tool dừng và không đổi model. Chọn hơn một node gốc thì tool báo và không đổi model.

## Tool làm gì

- Với mỗi node đích:
  1. `*duplicatemark elems 1 0`: bản sao nằm trong đúng component của element gốc, cùng loại, cùng property và mọi thuộc tính khác.
  2. `*translatemark` dịch bản sao theo vector node gốc → node đích.
- Bản sao có node mới riêng: không gộp với model, không equivalence.
- Node đích trùng vị trí node gốc thì bỏ qua và báo.
- Toàn bộ là một bước Undo "Element pattern". Lỗi giữa chừng thì tool tự Undo phần đã làm và báo "Nothing changed".
- Runtime 2022.3: sau `*duplicatemark`, mark 1 chứa các element mới, nên tool dịch luôn từ mark đó mà không cần entity recorder.
- **Tăng tốc cho model lớn** (21/11/2026). Trên model 2,84 triệu element, mỗi lần gọi `*duplicatemark` tốn khoảng 1,1–1,4 s và `*translatemark` khoảng 0,4 s, gần như không phụ thuộc số element được chép.
  - Đã đo và không nhanh hơn: `*duplicateentities`, `*transformmark`, `hm_blockredraw`, tạm ẩn phần còn lại của model, bỏ bước Undo.
  - Cách đang dùng là nhân đôi: mỗi lần gọi chép bản gốc cùng các bản đã có (1, 2, 4, …), nên N đích chỉ cần khoảng log2(N+1) lần `*duplicatemark`.
  - Các element mới được chia theo mảnh (nối nhau qua node chung) và chữ ký (loại element + vị trí node đầu), nên mỗi bản nhận đúng một mảnh mỗi loại; element dùng chung node luôn cùng một bản.
  - Không khớp thì tool hoàn tác và làm lại theo cách một lần gọi cho mỗi đích.

## Kiểm chứng (20/11/2026, HyperMesh 2022.3, scratch riêng của agent qua `run_probe.py`)

[Probe](tests/probe_pattern.tcl), run `d12e4f34`: **14/14 PASS**.
- Dữ liệu thử: quad4, tria6 và RBE2 trong hai component, có PSHELL, chép tới 3 node đích cộng 1 đích trùng node gốc.
- Mỗi element gốc có đúng một bản sao ở mỗi đích: cùng config, component, property và thứ tự node; tọa độ đúng bằng gốc cộng vector (sai số 1e-9).
- Bản sao không dùng node cũ; element gốc giữ nguyên.
- Một Undo trả lại model.
- Element vẫn nằm trên mark 2 (highlight) trong suốt lúc chép.
- Ba ca từ chối (hai node gốc, không có đích, chỉ có đích trùng gốc) không đổi model.
- Probe sau khi tăng tốc: run `1ab97b57`, 15/15; tool chạy đường nhân đôi.
- Trên model nhỏ: 10 000 quad tới 20 đích (200 000 element mới) mất 5,4 s. Trước khi tăng tốc là 2,3 s; trên model nhỏ, phần chia mảnh bằng Tcl tốn hơn lệnh native.
- Trên bản sao `02-Test_Full_Model.hm` (2,84 triệu element, chỉ đọc), 100 shell tới 10 đích ([probe](tests/perf_pattern3.tcl), run `ab31dddb`): nhân đôi **8,5 s**, cách cũ 15,9 s; Undo về đúng số element/node.

Chưa kiểm:
- Ba panel chọn bằng tay: probe gọi thẳng `::MeshForge::Pattern::pattern` với id, đúng hàm nút gọi sau khi chọn.
- Màu highlight trên ảnh màn hình.
- Chạy trong phiên HyperMesh của người dùng.
- Tốc độ trên model rất lớn: theo ghi chép runtime, mỗi lệnh native có chi phí cố định khoảng 0,3 s trên model 2,8 triệu element, tool dùng 3 lệnh native mỗi đích.
