# Edge Sides

Tách lớp element sát một đường PLOTEL (hở hoặc vòng kín) thành **hai phía**, để chọn riêng phía này hoặc phía kia. HyperMesh 2022.3, profile Nastran. Tool **không đổi model**.

- Điểm vào: [edge_sides.tcl](edge_sides.tcl). Menu: Utility → **test** → **Edge sides** (MAC [edge_sides.mac](edge_sides.mac), sinh bằng bộ sinh menu).
- Bản chuyển máy: `dist/HyperMesh_Test_Tools_2022.3/EdgeSides`. Sửa Tcl ở đây thì chép lại bản đó.

## Cách dùng

1. **Pick...** (khung "Line or band"): chọn bằng panel native.
   - **PLOTEL** (hoặc bar, rod): tool dùng đúng phần đã chọn, một cạnh, đường hở hay vòng kín đều được. PLOTEL nửa cạnh (góc → midnode của tria6/quad8) được tính là trọn cạnh element.
   - **Dải element 2D**: dải đó làm ranh giới; hai phía là các element sát hai bên dải. Dải không thuộc phía nào, trừ khi bật **Include band**.
2. Khung **Sides** luôn có sẵn các nút, mờ khi chưa dùng được:
   - **Side 1 / Side 2** kèm **Select**.
   - **By adjacent + / −**: + lan cả hai phía thêm một lớp; − bỏ lớp vừa lan, không xuống dưới lớp đầu.
   - Giống **Unmask Adjacent** native: element nào đang bị ẩn (mask) mà thuộc lớp vừa lan thì hiện lên. Pick hiện lớp đầu, + hiện lớp tiếp, − ẩn lại phần lớp đó đã làm hiện. Mỗi lần đổi hiển thị là một bước Undo.
   - **Include band**: khi Select, thêm chính dải 2D vào phía được chọn.
   - **Mask / Unmask**.
3. Lúc chưa Select: Side 1 màu chọn native (mark 2 `high`), Side 2 xám (mark 1 `low`). Sau **Select**:
   - Phía đã chọn (cộng dải nếu bật Include band) hiện màu chọn; đường hoặc dải đã pick hiện xám.
   - Phía đó được lưu làm user mark (`hm_saveusermark`); trong panel chọn element bất kỳ, bấm **retrieve** là lấy lại.
   - Bấm + / − sau khi Select thì phía đó vẫn được chọn, theo số lớp mới.
4. **Mask** ẩn phía đang Select (một bước Undo); **Unmask** hiện lại đúng phần tool đã ẩn.
5. **Reset** trả hiển thị về như trước khi dùng tool (ẩn lại phần tool đã làm hiện, hiện lại phần Mask đã ẩn) và xóa kết quả. **Close** đóng cửa sổ và giữ nguyên hiển thị đang có.

Màu luôn được tô ở bước cuối của mọi thao tác. Theo ghi chép runtime, lệnh nào dùng lại mark element cũng xóa màu `hm_highlightmark`. Trước đây tool lưu user mark sau khi tô màu, nên bấm Select không thấy màu; người dùng báo lỗi này ngày 21/11/2026.

## Tool làm gì

- Lớp sát đường gồm các shell (tria3, quad4, tria6, quad8) dùng ít nhất một node góc của cạnh trên đường, giống cách chọn "adjacent" theo node.
- Với dải 2D: tool lấy các vòng cạnh tự do của dải. Có từ hai vòng trở lên (dải hình vành) thì mỗi vòng là một phía. Có một vòng (dải thẳng) thì vòng được cắt tại hai node xa nhau nhất thành hai nhánh, mỗi nhánh một phía. Element chạm cả hai phía bị bỏ ra.
- Một cạnh element nằm trên đường khi PLOTEL nối thẳng hai node góc của nó, hoặc đi qua midnode (góc → giữa → góc). Đây là kiểu PLOTEL HyperMesh tạo trên cạnh tria6/quad8; bản đầu chưa nhận kiểu này và báo lỗi `key ... not known in dictionary` (lỗi người dùng gặp ngày 21/11/2026).
- Hai element thuộc cùng một phía khi nối được với nhau qua cạnh chung không nằm trên đường. Vòng kín vì thế tách thành trong và ngoài.
- Với đường hở, tại mỗi đầu tự do tool cắt thêm cạnh lưới đi tiếp hướng của đường. Nếu đường cong, hướng này được xoay tiếp theo góc giữa hai cạnh cuối. Nhờ vậy hai phía không nối vòng qua đầu đường.
- Tool báo trên dòng trạng thái khi:
  - chỉ tìm được một phía (đường nằm trên mép tự do);
  - có nhiều hơn hai nhóm (đường rẽ nhánh, hoặc lưới không liền);
  - có cạnh của đường không phải là cạnh element.

## Kiểm chứng (21/11/2026, HyperMesh 2022.3, scratch riêng của agent qua `run_probe.py`)

[Probe](tests/probe_sides.tcl), run `336aa6b3`: **45/45 PASS**.
- Phía đúng được xác định độc lập bằng hình học: trọng tâm trong/ngoài vòng, trên/dưới đường, bán kính so với vòng giữa.
- PLOTEL:
  - quad4, tria3, tria6 với vòng kín và đường hở.
  - Vòng tria6 với PLOTEL qua midnode: vòng kín 32 + 32, cung hở 9 + 9.
  - Một PLOTEL nửa cạnh: một cạnh, 6 + 4 element.
- Dải 2D:
  - Dải vành (r 6–7) trong vòng đệm tria6: 32 + 32, đúng oracle, dải không thuộc phía nào.
  - Dải thẳng 6 quad trong tấm: 8 + 8, trên/dưới đúng.
- Cửa sổ (mở qua đúng điểm vào menu):
  - Trước khi pick, mọi nút đều mờ.
  - + lan thành 64 / 64; − trả về 32 / 32.
  - Sau Select, màu vẫn còn: mark 2 giữ 64 element của phía, mark 1 giữ 32 PLOTEL.
  - Include band đưa dải vào user mark và màu.
  - Mask ẩn đủ 64 element, danh sách Undo vẫn còn; Unmask hiện lại đủ 64.
  - Như ảnh người dùng gửi: ẩn hết 128 shell của vòng đệm, chỉ còn PLOTEL. Pick hiện 64 element, + hiện đủ 128, − về 64, Reset về 0, danh sách Undo vẫn còn. Ảnh `masked_pick.jpg` / `masked_plus.jpg` đã xem.
  - Ảnh cửa sổ đã xem. Ảnh JPEG xuất nền của scratch chỉ vẽ khung dây, không phân biệt rõ màu.

Chưa kiểm: thao tác tay và màu trên màn hình thật trong phiên người dùng; lưới khối (tool chỉ lấy shell). Theo yêu cầu người dùng, chỉ đưa sang dist sau khi người dùng thử OK.

## Vị trí cửa sổ (22/11/2026, ticket `02-window-on-host-monitor`)

- Lỗi cũ: căn giữa theo Tk `.` rồi kẹp `max(x,0)`/`max(y,0)`. Màn hình bên trái hoặc phía trên màn chính có tọa độ âm (máy người dùng: màn trái x từ −2560 đến 0, HyperMesh phóng to ở đó), nên cửa sổ bị đẩy sang mép trái màn chính.
- Nay `place_center` căn khung ngoài của cửa sổ (cộng viền và thanh tiêu đề theo `GetSystemMetrics`) vào giữa khung Win32 của `[wm frame .]` (cửa sổ HyperWorks; Tk `.` chỉ là vùng nội dung bên trong), giữ cửa sổ trong vùng làm việc của màn hình chứa HyperMesh và viết `+$x+$y` để giữ tọa độ âm. Không có twapi thì căn theo vùng nội dung `.`, không giới hạn vùng làm việc.
- Kiểm trên scratch HyperMesh 2022.3 riêng (chỉ thử vị trí, không đổi model): [tests/gui_place.tcl](tests/gui_place.tcl) run `49b5497980ae45e49e3fafec6019a901` **13/13 PASS**. Mở qua `*evaltclscript` như nút MAC trong ba ca: scratch ở màn chính; khung scratch dời sang màn trái tọa độ âm (`SetWindowPos`, không kích hoạt) với hình chữ nhật phóng to như HyperMesh của người dùng; rồi cửa sổ nhỏ trên màn đó. Tâm cửa sổ lệch tâm khung HyperMesh ≤ 0,5 px, cùng màn hình, nằm trong vùng làm việc, khung ngoài thực bằng khung tính trước. Ảnh ghép `overlay.png` trong run đã xem. [tests/place_math.tcl](tests/place_math.tcl) chạy bằng tclsh 8.5.9 của Altair: 11/11 bố cục có tọa độ âm (màn trái, trên, trái-trên, tràn mép, cửa sổ lớn hơn vùng làm việc).
- Chưa kiểm: mở từ menu trong phiên người dùng; hai màn khác DPI (viền tính theo DPI hệ thống).
