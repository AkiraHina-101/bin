# Edge Sides (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Pick PLOTELs (or bars/rods: one edge, an open line or a loop) or a band of 2D elements. The shell
# elements next to it (the adjacent layer) are split into its two sides; + / - grow or shrink both
# sides by one layer. Each side can be selected (with the band, if wanted): it is highlighted in the
# native selection color and saved as the user mark, so any element selector takes it with
# "retrieve". Mask / Unmask hide and show the selected side. The model itself is never changed.
# Entry point for the menu: *evaltclscript edge_sides.tcl 0. Set ::EdgeSides_no_gui to load the
# procedures without opening the window (tests).

if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::EdgeSides_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::EdgeSides {
    variable W .edgeSides
    variable lineCfg {2 60 61}
    variable shellCfg {103 104 106 108}
    variable line {}
    variable sides {}
    variable chosen ""
    variable layers 0
    variable blocked {}
    variable masked {}
    variable band {}
    variable hist {}
    variable revealed {}
    variable opt
    if {![info exists opt(include)]} {set opt(include) 0}
    variable status ""
    variable info ""
}

proc ::EdgeSides::vsub {a b} {list [expr {[lindex $a 0]-[lindex $b 0]}] [expr {[lindex $a 1]-[lindex $b 1]}] [expr {[lindex $a 2]-[lindex $b 2]}]}
proc ::EdgeSides::dot {a b} {expr {[lindex $a 0]*[lindex $b 0]+[lindex $a 1]*[lindex $b 1]+[lindex $a 2]*[lindex $b 2]}}
proc ::EdgeSides::vadd {a b} {list [expr {[lindex $a 0]+[lindex $b 0]}] [expr {[lindex $a 1]+[lindex $b 1]}] [expr {[lindex $a 2]+[lindex $b 2]}]}
proc ::EdgeSides::vscale {a s} {list [expr {[lindex $a 0]*$s}] [expr {[lindex $a 1]*$s}] [expr {[lindex $a 2]*$s}]}
proc ::EdgeSides::cross {a b} {lassign $a ax ay az; lassign $b bx by bz; list [expr {$ay*$bz-$az*$by}] [expr {$az*$bx-$ax*$bz}] [expr {$ax*$by-$ay*$bx}]}
proc ::EdgeSides::unit {a} {set l [expr {sqrt([dot $a $a])}]; if {$l <= 0} {return {0 0 0}}; list [expr {[lindex $a 0]/$l}] [expr {[lindex $a 1]/$l}] [expr {[lindex $a 2]/$l}]}
proc ::EdgeSides::key {a b} {expr {$a < $b ? "$a $b" : "$b $a"}}
proc ::EdgeSides::existing {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 {*}$ids; set o [hm_getmark elems 1]; *clearmark elems 1
    return $o
}
proc ::EdgeSides::xyz {ids} {
    set o [dict create]
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set c [lrange $ids $i [expr {$i+2047}]]
        foreach n $c x [hm_getvalue nodes user_ids=$c dataname=x] y [hm_getvalue nodes user_ids=$c dataname=y] z [hm_getvalue nodes user_ids=$c dataname=z] {dict set o $n [list $x $y $z]}
    }
    return $o
}
# corner nodes of shells (tria3/tria6: 3, quad4/quad8: 4)
proc ::EdgeSides::corners {cfg nl} {lrange $nl 0 [expr {$cfg in {103 106} ? 2 : 3}]}

# Line edges ("a b" keys) of the picked 1D elements. Errors on anything else.
proc ::EdgeSides::line_edges {ids} {
    variable lineCfg
    set ids [existing $ids]
    if {![llength $ids]} {error "Select the line (plotels)."}
    set edges [dict create]
    foreach e $ids c [hm_getvalue elems user_ids=$ids dataname=config] nl [hm_getvalue elems user_ids=$ids dataname=nodes] {
        if {$c ni $lineCfg} {error "The line has element $e that is not a plotel, bar or rod (config $c)."}
        dict set edges [key [lindex $nl 0] [lindex $nl 1]] 1
    }
    return $edges
}

# Shells using any of the nodes: {elements cornersByElement midsByElement}; mids = midside node of
# corner edge i (tria6: nodes 4-6, quad8: nodes 5-8).
proc ::EdgeSides::adjacent {nodes} {
    variable shellCfg
    set cand {}; set cn [dict create]; set mids [dict create]
    if {![llength $nodes]} {return [list $cand $cn $mids]}
    *createmark nodes 1 {*}$nodes
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set near [hm_getmark elems 2]
    *clearmark nodes 1; *clearmark elems 2
    if {[llength $near]} {
        foreach e $near c [hm_getvalue elems user_ids=$near dataname=config] nl [hm_getvalue elems user_ids=$near dataname=nodes] {
            if {$c ni $shellCfg} {continue}
            lappend cand $e
            set cs [corners $c $nl]
            dict set cn $e $cs
            if {$c in {106 108}} {dict set mids $e [lrange $nl [llength $cs] [expr {2*[llength $cs]-1}]]}
        }
    }
    list $cand $cn $mids
}

# Splits the shells next to the line (the picked elements as they are: one edge, an open line or a
# loop). A shell edge lies on the line when a picked element joins its two corners or runs from a
# corner to its midside node (plotels found on tria6/quad8 edges run corner - midside - corner). Returns a dict: sides (list of element lists,
# largest first), closed (1 when the line has no free ends), ends (number of free ends), missing
# (picked line elements that lie on no shell edge).
proc ::EdgeSides::split_sides {lineIds} {
    variable shellCfg
    set raw [line_edges $lineIds]
    set lnodes [dict create]
    dict for {k one} $raw {foreach n $k {dict set lnodes $n 1}}
    # two passes: the shells using a node of the picked elements give the element edges on the line;
    # the shells using a corner of those edges are the adjacent layer (a half-edge plotel from a corner
    # to a midside node does not touch the far corner)
    for {set pass 0} {$pass < 2} {incr pass} {
        lassign [adjacent [dict keys $lnodes]] cand cn mids
        if {![llength $cand]} {error "No shell element uses a node of the line."}
        # corner edges of the candidates (which elements use each) and the ones on the line: picked
        # corner to corner, or through the edge's midside node (both halves, or one half)
        set byEdge [dict create]; set L [dict create]; set used [dict create]
        dict for {e nl} $cn {
            set k [llength $nl]
            set ms [expr {[dict exists $mids $e] ? [dict get $mids $e] : {}}]
            for {set i 0} {$i < $k} {incr i} {
                set a [lindex $nl $i]; set b [lindex $nl [expr {($i+1)%$k}]]
                set ek [key $a $b]
                dict lappend byEdge $ek $e
                if {[dict exists $raw $ek]} {dict set L $ek 1; dict set used $ek 1; continue}
                set m [lindex $ms $i]
                if {$m eq ""} {continue}
                foreach h [list [key $a $m] [key $m $b]] {if {[dict exists $raw $h]} {dict set L $ek 1; dict set used $h 1}}
            }
        }
        set more 0
        dict for {k one} $L {foreach n $k {if {![dict exists $lnodes $n]} {dict set lnodes $n 1; set more 1}}}
        if {!$more} {break}
    }
    if {![dict size $L]} {error "The line does not follow the element edges (no element edge is covered by it)."}
    set missing 0
    dict for {k one} $raw {if {![dict exists $used $k]} {incr missing}}
    set deg [dict create]
    dict for {k one} $L {foreach n $k {dict incr deg $n}}
    # cut edges: the line, plus at each free end the edge that continues the line best
    set cut $L
    set ends {}
    dict for {n d} $deg {if {$d == 1} {lappend ends $n}}
    if {[llength $ends]} {
        set P [xyz [lsort -unique -integer [concat {*}[dict values $cn]]]]
        set adj [dict create]
        dict for {k one} $L {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}
        foreach v $ends {
            set w [lindex [dict get $adj $v] 0]
            set d1 [unit [vsub [dict get $P $v] [dict get $P $w]]]
            set dir $d1
            # a curved line goes on curving: turn the last direction by the angle between the last
            # two edges (u -> w -> v), about their common normal
            set u ""
            foreach x [dict get $adj $w] {if {$x != $v} {set u $x}}
            if {$u ne "" && [llength [dict get $adj $w]] == 2} {
                set d0 [unit [vsub [dict get $P $w] [dict get $P $u]]]
                set ax [cross $d0 $d1]
                set sn [expr {sqrt([dot $ax $ax])}]
                if {$sn > 1e-9} {
                    set ax [vscale $ax [expr {1.0/$sn}]]
                    set cs [dot $d0 $d1]
                    set dir [vadd [vadd [vscale $d1 $cs] [vscale [cross $ax $d1] $sn]] [vscale $ax [expr {[dot $ax $d1]*(1-$cs)}]]]
                }
            }
            set best ""; set bd -2.0
            dict for {k els} $byEdge {
                if {$v ni $k || [dict exists $L $k]} {continue}
                set x [lindex $k [expr {[lindex $k 0] == $v}]]
                set d [dot [unit [vsub [dict get $P $x] [dict get $P $v]]] $dir]
                if {$d > $bd} {set bd $d; set best $k}
            }
            if {$best ne ""} {dict set cut $best 1}
        }
    }
    # connected groups through edges that are not cut
    foreach e $cand {set parent($e) $e}
    dict for {k els} $byEdge {
        if {[dict exists $cut $k] || [llength $els] < 2} {continue}
        set r0 [find [lindex $els 0]]
        foreach e [lrange $els 1 end] {set r [find $e]; if {$r ne $r0} {set parent($r) $r0}}
    }
    set groups [dict create]
    foreach e $cand {dict lappend groups [find $e] $e}
    set sides {}
    dict for {r els} $groups {lappend sides [list [llength $els] [lsort -integer $els]]}
    set out {}
    foreach s [lsort -integer -decreasing -index 0 $sides] {lappend out [lindex $s 1]}
    dict create sides $out closed [expr {![llength $ends]}] ends [llength $ends] missing $missing line [existing $lineIds] edges [dict size $L]
}

# One more layer on every side, as the native "by adjacent": the shells sharing a node with a side
# and not on any side yet. A shell reached by two sides at once is left out and kept as a border
# (blocked), so the sides never cross into each other later. Returns {sides added contested blocked}:
# added = elements added per side, contested = new border elements.
proc ::EdgeSides::grow {sides {blocked {}}} {
    variable shellCfg
    set owner [dict create]
    set i 0; foreach s $sides {foreach e $s {dict set owner $e $i}; incr i}
    foreach e $blocked {dict set owner $e -1}
    set claims [dict create]
    set i 0
    foreach s $sides {
        set nodes [dict create]
        for {set j 0} {$j < [llength $s]} {incr j 2048} {
            foreach nl [hm_getvalue elems user_ids=[lrange $s $j [expr {$j+2047}]] dataname=nodes] {foreach n $nl {dict set nodes $n 1}}
        }
        if {[dict size $nodes]} {
            *createmark nodes 1 {*}[dict keys $nodes]
            *clearmark elems 2
            hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
            set near [hm_getmark elems 2]
            *clearmark nodes 1; *clearmark elems 2
            if {[llength $near]} {
                foreach e $near c [hm_getvalue elems user_ids=$near dataname=config] {
                    if {$c ni $shellCfg || [dict exists $owner $e]} {continue}
                    dict set claims $e $i 1
                }
            }
        }
        incr i
    }
    set out $sides; set added {}; foreach s $sides {lappend added 0}
    set contested 0
    dict for {e who} $claims {
        if {[dict size $who] != 1} {incr contested; lappend blocked $e; continue}
        set k [lindex [dict keys $who] 0]
        lset out $k [concat [lindex $out $k] $e]
        lset added $k [expr {[lindex $added $k]+1}]
    }
    set res {}; foreach s $out {lappend res [lsort -integer $s]}
    list $res $added $contested $blocked
}

# Splits the shells next to a picked band of 2D elements (the band is the divider and is on no side).
# The band's free-edge loops (corner nodes): with two or more loops (e.g. a ring of elements) every
# loop has its own side; with one loop (a strip) the loop is cut at its two farthest-apart nodes
# into two chains, one per side. A shell outside the band touching nodes of two sides is left out.
# Returns the same dict as split_sides, plus band (the band elements).
proc ::EdgeSides::split_band {bandIds} {
    variable shellCfg
    set band [existing $bandIds]
    if {![llength $band]} {error "Select the line (plotels) or a band of 2D elements."}
    set inBand [dict create]; set cnt [dict create]; set bnodes [dict create]
    foreach e $band c [hm_getvalue elems user_ids=$band dataname=config] nl [hm_getvalue elems user_ids=$band dataname=nodes] {
        if {$c ni $shellCfg} {error "Pick either line elements or 2D elements (element $e has config $c)."}
        dict set inBand $e 1
        foreach n $nl {dict set bnodes $n 1}
        set cs [corners $c $nl]; set k [llength $cs]
        for {set i 0} {$i < $k} {incr i} {dict incr cnt [key [lindex $cs $i] [lindex $cs [expr {($i+1)%$k}]]]}
    }
    # free-edge loops of the band
    set adj [dict create]
    dict for {k v} $cnt {if {$v == 1} {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}}
    set loops {}; set seen [dict create]
    dict for {n nb} $adj {
        if {[dict exists $seen $n]} {continue}
        set loop {}; set stack [list $n]; dict set seen $n 1
        while {[llength $stack]} {
            set x [lindex $stack end]; set stack [lrange $stack 0 end-1]; lappend loop $x
            foreach y [dict get $adj $x] {if {![dict exists $seen $y]} {dict set seen $y 1; lappend stack $y}}
        }
        lappend loops $loop
    }
    if {![llength $loops]} {error "The band has no free edge."}
    # which side each boundary node belongs to
    set sideOf [dict create]
    if {[llength $loops] >= 2} {
        set i 0; foreach L $loops {foreach n $L {dict set sideOf $n $i}; incr i}
        set nSides [llength $loops]; set closed 1
    } else {
        # one loop: ordered walk, cut at the two farthest-apart nodes
        set L [lindex $loops 0]
        set order [list [lindex $L 0]]; set prev ""; set cur [lindex $L 0]
        while {1} {
            set nxt ""
            foreach y [dict get $adj $cur] {if {$y ne $prev && $y ni $order} {set nxt $y; break}}
            if {$nxt eq ""} {break}
            lappend order $nxt; set prev $cur; set cur $nxt
        }
        set P [xyz $order]
        set best -1; set ia 0; set ib 0
        for {set i 0} {$i < [llength $order]} {incr i} {
            for {set j [expr {$i+1}]} {$j < [llength $order]} {incr j} {
                set d [dot [vsub [dict get $P [lindex $order $i]] [dict get $P [lindex $order $j]]] [vsub [dict get $P [lindex $order $i]] [dict get $P [lindex $order $j]]]]
                if {$d > $best} {set best $d; set ia $i; set ib $j}
            }
        }
        for {set i 0} {$i < [llength $order]} {incr i} {
            if {$i == $ia || $i == $ib} {continue}
            dict set sideOf [lindex $order $i] [expr {$i > $ia && $i < $ib ? 0 : 1}]
        }
        set nSides 2; set closed 0
    }
    # shells outside the band touching the band
    lassign [adjacent [dict keys $bnodes]] cand cn mids
    set groups {}; for {set i 0} {$i < $nSides} {incr i} {lappend groups {}}
    set left 0
    foreach e $cand {
        if {[dict exists $inBand $e]} {continue}
        set who [dict create]
        foreach n [dict get $cn $e] {if {[dict exists $sideOf $n]} {dict set who [dict get $sideOf $n] 1}}
        if {[dict size $who] == 1} {
            set i [lindex [dict keys $who] 0]
            lset groups $i [concat [lindex $groups $i] $e]
        } elseif {[dict size $who] > 1} {incr left}
    }
    set sides {}
    foreach g $groups {if {[llength $g]} {lappend sides [list [llength $g] [lsort -integer $g]]}}
    set out {}
    foreach s [lsort -integer -decreasing -index 0 $sides] {lappend out [lindex $s 1]}
    dict create sides $out closed $closed ends [expr {$closed ? 0 : 2}] missing 0 line $band edges 0 band $band left $left
}

# One pick: line elements (plotels, bars, rods) or a band of 2D elements.
proc ::EdgeSides::split_any {ids} {
    variable lineCfg
    set ids [existing $ids]
    if {![llength $ids]} {error "Select the line (plotels) or a band of 2D elements."}
    set cfgs [lsort -unique [hm_getvalue elems user_ids=$ids dataname=config]]
    set allLine 1; foreach c $cfgs {if {$c ni $lineCfg} {set allLine 0}}
    if {$allLine} {
        set r [split_sides $ids]
        dict set r band {}
        dict set r left 0
        return $r
    }
    split_band $ids
}

# union-find root of x in the caller's array "parent"
proc ::EdgeSides::find {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}

# ---------------------------------------------------------------- window
# Colors are set last in every action: any later command that reuses an element mark clears them.
# Before a choice: side 1 in the selection color (mark 2 high), side 2 grey (mark 1 low). After
# Select: the chosen side (plus the band when Include band is on) in the selection color, the picked
# line or band grey.
proc ::EdgeSides::show_marks {} {
    variable sides; variable chosen; variable line; variable opt
    set all [concat {*}$sides $line]
    if {$chosen ne ""} {
        set hi [existing [chosen_ids]]
        set lo [existing $line]
        if {$opt(include)} {set lo {}}
    } else {
        set hi [existing [lindex $sides 0]]
        set lo [existing [lindex $sides 1]]
    }
    foreach m {1 2} {catch {*createmark elems $m {*}$all; hm_highlightmark elems $m norm}; *clearmark elems $m}
    if {[llength $hi]} {*createmark elems 2 {*}$hi; catch {hm_highlightmark elems 2 high}}
    if {[llength $lo]} {*createmark elems 1 {*}$lo; catch {hm_highlightmark elems 1 low}}
    catch {hm_redraw}
}
proc ::EdgeSides::clear_marks {} {
    variable sides; variable line
    set all [concat {*}$sides $line]
    foreach m {1 2} {catch {*createmark elems $m {*}$all; hm_highlightmark elems $m norm}; *clearmark elems $m}
    catch {hm_redraw}
}
# the chosen side, with the band when Include band is on
proc ::EdgeSides::chosen_ids {} {
    variable sides; variable chosen; variable band; variable opt
    if {$chosen eq ""} {return {}}
    set ids [lindex $sides $chosen]
    if {$opt(include) && [llength $band]} {set ids [lsort -unique -integer [concat $ids $band]]}
    return $ids
}

proc ::EdgeSides::pick_line {} {
    variable W; variable line; variable sides; variable chosen; variable status; variable info; variable band; variable hist
    if {[winfo exists $W]} {wm withdraw $W}
    clear_marks
    *clearmark elems 1
    catch {::TestToolSession::panel *createmarkpanel elems 1 "Edge sides: plotels (one edge, a line or a loop) or a band of 2D elements"}
    set ids [hm_getmark elems 1]
    *clearmark elems 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {![llength $ids]} {refresh; return}
    use_pick $ids
}
# What Pick does with the picked elements (also called by the tests).
proc ::EdgeSides::use_pick {ids} {
    variable line; variable sides; variable chosen; variable status; variable info; variable band; variable hist
    # a new pick starts from the display as it was before the tool showed or hid anything
    restore_display
    set line $ids; set sides {}; set chosen ""; set band {}; set hist {}
    set ::EdgeSides::layers 0; set ::EdgeSides::blocked {}
    if {[catch {split_any $ids} r]} {
        set status $r; set info ""
    } else {
        set sides [dict get $r sides]
        set band [dict get $r band]
        set ::EdgeSides::blocked $band
        set ::EdgeSides::layers 1
        set ::EdgeSides::revealed [reveal [concat {*}$sides]]
        set line [dict get $r line]
        set what [expr {[llength $band] ? "band elements" : "line elements"}]
        set info "[llength $line] $what, [expr {[dict get $r closed] ? "closed" : "open"}]"
        set status ""
        if {[llength $sides] == 1} {set status "Only one side found (on a free edge, or the shells do not follow the line)."}
        if {[llength $sides] > 2} {set status "[llength $sides] groups found: the line branches or the shells are not connected."}
        if {[dict get $r missing]} {append status [string trimleft " [dict get $r missing] line elements are not on shell edges."]}
        if {[dict get $r left]} {append status [string trimleft " [dict get $r left] elements touch both sides and are left out."]}
        if {[llength $::EdgeSides::revealed]} {append status [string trimleft " [llength $::EdgeSides::revealed] masked elements shown."]}
    }
    refresh
}

proc ::EdgeSides::choose {i} {
    variable chosen; variable status
    set chosen $i
    set ids [existing [chosen_ids]]
    # the user mark: "retrieve" in any element selector gives this side
    if {[llength $ids]} {*createmark elems 1 {*}$ids; hm_saveusermark elems 1; *clearmark elems 1}
    set status "Side [expr {$i+1}]: [llength $ids] elements selected (retrieve in any selector)."
    refresh
}

# + one more layer on both sides; - takes the last layer off again (not below the first layer).
proc ::EdgeSides::grow_layer {} {
    variable sides; variable chosen; variable status; variable layers; variable blocked; variable hist
    if {![llength $sides]} {return}
    set old [dict create]; foreach e [concat {*}$sides] {dict set old $e 1}
    set prev [list $sides $blocked]
    lassign [grow $sides $blocked] sides added contested blocked
    # like the native Unmask Adjacent: the new layer is shown when it was masked
    set new {}; foreach e [concat {*}$sides] {if {![dict exists $old $e]} {lappend new $e}}
    set shown [reveal $new]
    lappend hist [concat $prev [list $shown]]
    incr layers
    set status "Layer $layers: +[join $added { / +}] elements."
    if {[llength $shown]} {append status " [llength $shown] shown."}
    if {$contested} {append status " $contested elements touch both sides and are left out."}
    refresh_choice
}
proc ::EdgeSides::shrink_layer {} {
    variable sides; variable status; variable layers; variable blocked; variable hist
    if {![llength $hist]} {return}
    clear_marks
    lassign [lindex $hist end] sides blocked shown
    set hist [lrange $hist 0 end-1]
    # what that layer showed is masked again
    hide $shown
    incr layers -1
    set status "Layer $layers."
    if {[llength $shown]} {append status " [llength $shown] masked again."}
    refresh_choice
}

# Shows (unmasks) the masked elements among ids; one Undo step. Returns the ones shown.
proc ::EdgeSides::reveal {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 displayed
    set d [dict create]; foreach e [hm_getmark elems 1] {dict set d $e 1}
    *clearmark elems 1
    set hidden {}; foreach e $ids {if {![dict exists $d $e]} {lappend hidden $e}}
    if {![llength $hidden]} {return {}}
    history_begin "Edge sides show"
    catch {*createmark elems 1 {*}$hidden; *unmaskentitymark elems 1 0; *clearmark elems 1}
    history_end "Edge sides show"
    return $hidden
}
# Masks ids again (one Undo step).
proc ::EdgeSides::hide {ids} {
    set ids [existing $ids]
    if {![llength $ids]} {return}
    history_begin "Edge sides hide"
    catch {*createmark elems 1 {*}$ids; *maskentitymark elems 1 0; *clearmark elems 1}
    history_end "Edge sides hide"
}
# Back to the display before the tool: what Mask hid is shown, what the layers showed is hidden.
proc ::EdgeSides::restore_display {} {
    variable masked; variable revealed; variable hist
    if {[llength $masked]} {unmask}
    set back $revealed
    foreach h $hist {lappend back {*}[lindex $h 2]}
    if {[llength $back]} {hide [lsort -unique -integer $back]}
    set revealed {}; set hist {}
}
# keep a chosen side selected (user mark updated) after the layers change
proc ::EdgeSides::refresh_choice {} {
    variable chosen
    if {$chosen ne ""} {choose $chosen} else {refresh}
}

proc ::EdgeSides::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::EdgeSides::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}
# Mask hides the selected side (one Undo step; outside a note step a mask would empty the Undo list);
# Unmask shows again only what this tool masked.
proc ::EdgeSides::mask_side {} {
    variable chosen; variable masked; variable status
    if {$chosen eq ""} {return}
    set ids [existing [chosen_ids]]
    if {![llength $ids]} {return}
    history_begin "Edge sides mask"
    set rc [catch {*createmark elems 1 {*}$ids; *maskentitymark elems 1 0; *clearmark elems 1} m]
    history_end "Edge sides mask"
    if {$rc} {set status "Mask failed: $m"; refresh; return}
    lappend masked {*}$ids
    set status "Side [expr {$chosen+1}] masked ([llength $ids] elements)."
    refresh
}
proc ::EdgeSides::unmask {} {
    variable masked; variable status
    set ids [existing [lsort -unique -integer $masked]]
    set masked {}
    if {[llength $ids]} {
        history_begin "Edge sides unmask"
        set rc [catch {*createmark elems 1 {*}$ids; *unmaskentitymark elems 1 0; *clearmark elems 1} m]
        history_end "Edge sides unmask"
        set status [expr {$rc ? "Unmask failed: $m" : "[llength $ids] elements shown again."}]
    }
    refresh
}

# Reset puts the display back as it was before the tool; Close keeps the display as it is.
proc ::EdgeSides::reset {} {
    variable line; variable sides; variable chosen; variable status; variable info; variable layers; variable masked; variable band; variable hist
    restore_display
    clear_marks
    set line {}; set sides {}; set chosen ""; set status ""; set info ""; set layers 0; set band {}; set hist {}; set ::EdgeSides::blocked {}
    refresh
}
proc ::EdgeSides::close_window {} {
    variable W; variable line; variable sides; variable chosen; variable masked; variable layers; variable band; variable hist
    clear_marks
    set line {}; set sides {}; set chosen ""; set masked {}; set layers 0; set band {}; set hist {}; set ::EdgeSides::blocked {}
    set ::EdgeSides::revealed {}
    destroy $W
}

# The side rows, + / -, Include band, Mask and Unmask are always there; they are off until there is
# something to act on. The colors come last.
proc ::EdgeSides::refresh {} {
    variable W; variable sides; variable chosen; variable layers; variable masked; variable band; variable hist
    if {![winfo exists $W]} {return}
    set counts {}; foreach s $sides {lappend counts [llength [existing $s]]}
    set f $W.body.sides
    foreach c [winfo children $f] {destroy $c}
    set rows [expr {max(2,[llength $sides])}]
    for {set r 0} {$r < $rows} {incr r} {
        set has [expr {$r < [llength $sides]}]
        label $f.l$r -text "Side [expr {$r+1}]" -anchor w -width 8
        label $f.n$r -text [expr {$has ? "[lindex $counts $r] elements" : "-"}] -anchor w -width 14
        button $f.b$r -text "Select" -width 8 -command [list ::TestToolSession::run "Edge sides" [list ::EdgeSides::choose $r]] -state [expr {$has ? "normal" : "disabled"}]
        if {$chosen ne "" && $chosen == $r} {$f.l$r configure -font [list {*}[font actual [$f.l$r cget -font]] -weight bold]}
        grid $f.l$r -row $r -column 0 -sticky w -pady 2
        grid $f.n$r -row $r -column 1 -columnspan 2 -sticky w
        grid $f.b$r -row $r -column 3 -sticky e -padx {8 0}
    }
    set on [expr {[llength $sides] ? "normal" : "disabled"}]
    label $f.adj -text "By adjacent" -anchor w
    button $f.plus -text "+" -width 3 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::grow_layer] -state $on
    button $f.minus -text "-" -width 3 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::shrink_layer] -state [expr {[llength $hist] ? "normal" : "disabled"}]
    label $f.layers -text [expr {$layers ? "Layers $layers" : ""}] -anchor e
    grid $f.adj -row $rows -column 0 -sticky w -pady {6 0}
    grid $f.plus -row $rows -column 1 -sticky w -pady {6 0}
    grid $f.minus -row $rows -column 2 -sticky w -padx {4 0} -pady {6 0}
    grid $f.layers -row $rows -column 3 -sticky e -pady {6 0}
    checkbutton $f.inc -text "Include band" -variable ::EdgeSides::opt(include) -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::refresh_choice] -anchor w \
        -state [expr {[llength $band] ? "normal" : "disabled"}]
    grid $f.inc -row [expr {$rows+1}] -column 0 -columnspan 3 -sticky w -pady {4 0}
    button $f.mask -text "Mask" -width 8 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::mask_side] -state [expr {$chosen ne "" ? "normal" : "disabled"}]
    button $f.unmask -text "Unmask" -width 8 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::unmask] -state [expr {[llength $masked] ? "normal" : "disabled"}]
    grid $f.mask -row [expr {$rows+2}] -column 0 -sticky w -pady {4 0}
    grid $f.unmask -row [expr {$rows+2}] -column 3 -sticky e -pady {4 0}
    grid columnconfigure $f 2 -weight 1
    show_marks
}

proc ::EdgeSides::show {} {
    variable W; variable status
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Edge Sides"
    wm resizable $W 0 0
    frame $W.body -padx 12 -pady 10
    pack $W.body -fill both -expand 1
    set s [labelframe $W.body.line -text "Line or band" -padx 8 -pady 6]
    button $s.pick -text "Pick..." -width 10 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::pick_line]
    label $s.info -textvariable ::EdgeSides::info -anchor w -width 24
    grid $s.pick -row 0 -column 0 -sticky w -pady 2
    grid $s.info -row 0 -column 1 -sticky w -padx {8 0}
    grid $s -row 0 -column 0 -sticky ew
    labelframe $W.body.sides -text "Sides" -padx 8 -pady 6
    grid $W.body.sides -row 1 -column 0 -sticky ew -pady {8 0}
    grid columnconfigure $W.body 0 -weight 1
    frame $W.foot -padx 12 -pady 8
    label $W.foot.status -textvariable ::EdgeSides::status -anchor nw -justify left -height 2 -wraplength 260
    frame $W.foot.buttons
    button $W.foot.close -text "Close" -width 8 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::close_window]
    button $W.foot.reset -text "Reset" -width 8 -command [list ::TestToolSession::run "Edge sides" ::EdgeSides::reset]
    pack $W.foot.close $W.foot.reset -in $W.foot.buttons -side right -padx {6 0}
    pack $W.foot.status -side top -fill x
    pack $W.foot.buttons -side top -fill x -pady {6 0}
    pack $W.foot -fill x
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Edge sides" ::EdgeSides::close_window]
    set status ""
    refresh
    ::TestToolSession::place "Edge sides" $W
    wm deiconify $W
    ::TestToolSession::attach "Edge sides" $W
}

# Center over the HyperMesh main window, inside the work area of the monitor that holds it.
# A monitor left of or above the primary one has negative coordinates: no clamp to 0, and
# "+$x+$y" keeps them absolute ("%+d" of a negative number counts from the right edge).
proc ::EdgeSides::place_center {} {
    variable W
    update idletasks
    $W.foot.status configure -wraplength [expr {max(200,[winfo reqwidth $W.body]-24)}]
    update idletasks
    # Host: the Win32 frame of "." (the HyperWorks top-level window; "." is only its content area),
    # else that content area. wm geometry places the outer frame of W: add its border
    # (SM_CXSIZEFRAME + SM_CXPADDEDBORDER) and caption.
    set host [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $frame] l t r b
        set host [list $l $t [expr {$r - $l}] [expr {$b - $t}]]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set w [expr {[winfo reqwidth $W] + 2*$border}]
    set h [expr {[winfo reqheight $W] + $caption + 2*$border}]
    lassign [fit_box $host $work $w $h] x y
    wm geometry $W +$x+$y
}
# Top-left corner of a w x h frame centered on host {x y width height}, kept inside
# work {left top right bottom} when known (the top-left corner wins if the frame is larger).
proc ::EdgeSides::fit_box {host work w h} {
    lassign $host hx hy hw hh
    set x [expr {$hx + ($hw - $w) / 2}]
    set y [expr {$hy + ($hh - $h) / 2}]
    if {[llength $work] == 4} {
        lassign $work left top right bottom
        set x [expr {max($left, min($x, $right - $w))}]
        set y [expr {max($top, min($y, $bottom - $h))}]
    }
    list $x $y
}

if {![info exists ::EdgeSides_no_gui]} {::EdgeSides::show}
