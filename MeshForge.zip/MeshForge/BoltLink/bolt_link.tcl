# RBE2 - CBAR - RBE2 link tool for HyperMesh 2022.3 (Nastran).
# Pick several ends on side A in order, then the same number on side B in order; Create links
# A1-B1, A2-B2, ... Each end is one of:
#   3 nodes  - one ordered node-list panel, 3 nodes per hole, hole after hole; the RBE2 takes the
#              corner nodes of displayed 2D/3D elements on the circle plane within k*R; its
#              independent node is a new node at the exact circle center.
#   Circle and RBE2 selection can proceed through consecutive ends.
#   2D elems - the element panel reopens for each end (return with nothing selected to finish);
#              the RBE2 takes the corner nodes of the 2D elements; independent node at their centroid.
#   Attached - single-element panel, reopened after each click (one click per end, return to
#              finish); the end is the whole connected
#              region of 2D elements in the clicked element's component; RBE2 on its corner nodes,
#              independent node at their centroid.
#   RBE2     - one ordered element-list panel; existing RBE2s are reused, no new RBE2.
# Midside nodes are never dependent nodes. Picked ends stay visible as native lowlight (nodes mark 2)
# while the other side is picked. Create writes, as one undo step, every new RBE2 into a new
# component RBE2_<its id> and every CBAR (automatic orientation) into CBAR_<its id>. The CBAR property
# is picked from the PBAR/PBARL properties of the model, or left empty with "(none)".
# Opening the window and picking never change the model.

if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::MeshForge_BoltLink_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::MeshForge::BoltLink {
    variable W .rbeBarLink
    variable E
    variable ends
    variable status
    variable dofs 123456
    variable noProp "(none)"
    variable barProp
    if {![info exists barProp]} {set barProp "(none)"}
    if {![info exists status]} {set status ""}
    foreach side {A B} {
        foreach {key value} {mode circle shape disk factor 1.0 tol 2.0 info "0 picked"} {
            if {![info exists E($side,$key)]} {set E($side,$key) $value}
        }
        if {![info exists ends($side)]} {set ends($side) {}}
    }
    variable shellConfigs {103 104 106 108}
    # Corner node count by element config: midside nodes follow the corners in HyperMesh order.
    variable corners {103 3 104 4 106 3 108 4 204 4 210 4 205 5 213 5 206 6 215 6 208 8 220 8}
}

# ---------------------------------------------------------------- vectors
proc ::MeshForge::BoltLink::vadd {a b} {set o {}; foreach x $a y $b {lappend o [expr {$x+$y}]}; return $o}
proc ::MeshForge::BoltLink::vsub {a b} {set o {}; foreach x $a y $b {lappend o [expr {$x-$y}]}; return $o}
proc ::MeshForge::BoltLink::vscale {a s} {set o {}; foreach x $a {lappend o [expr {$x*$s}]}; return $o}
proc ::MeshForge::BoltLink::dot {a b} {set o 0.0; foreach x $a y $b {set o [expr {$o+$x*$y}]}; return $o}
proc ::MeshForge::BoltLink::cross {a b} {
    lassign $a ax ay az; lassign $b bx by bz
    list [expr {$ay*$bz-$az*$by}] [expr {$az*$bx-$ax*$bz}] [expr {$ax*$by-$ay*$bx}]
}
proc ::MeshForge::BoltLink::norm {a} {expr {sqrt([dot $a $a])}}
proc ::MeshForge::BoltLink::unit {a {what "Vector"}} {
    set m [norm $a]
    if {$m < 1.0e-12} {error "$what has zero length."}
    vscale $a [expr {1.0/$m}]
}

# Circle through three points: {center radius unitNormal}.
proc ::MeshForge::BoltLink::circumcircle {a b c} {
    set u [vsub $b $a]; set v [vsub $c $a]
    set w [cross $u $v]
    set ww [dot $w $w]
    set scale [expr {max([dot $u $u],[dot $v $v])}]
    if {$scale < 1.0e-24 || $ww < 1.0e-12*$scale*$scale} {error "the 3 nodes are collinear or coincident"}
    set offset [vscale [vadd [vscale [cross $v $w] [dot $u $u]] [vscale [cross $w $u] [dot $v $v]]] [expr {0.5/$ww}]]
    set center [vadd $a $offset]
    list $center [norm [vsub $a $center]] [unit $w]
}

proc ::MeshForge::BoltLink::centroid {points} {
    set c {0.0 0.0 0.0}
    foreach p $points {set c [vadd $c $p]}
    vscale $c [expr {1.0/[llength $points]}]
}

# ---------------------------------------------------------------- model reads (no changes)
# Runtime 2022.3 on a 4.7M-node model: user_ids= reads are ~0.1 ms for 32 nodes, while
# *createmark with an id list (~28 ms) plus mark=1 reads (~50 ms) scan the whole model.
proc ::MeshForge::BoltLink::coordinates {ids} {
    set ids [lsort -unique -integer $ids]
    if {![llength $ids]} {error "No nodes."}
    set result [dict create]
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set chunk [lrange $ids $i [expr {$i+2047}]]
        if {[catch {
            set xs [hm_getvalue nodes user_ids=$chunk dataname=x]
            set ys [hm_getvalue nodes user_ids=$chunk dataname=y]
            set zs [hm_getvalue nodes user_ids=$chunk dataname=z]
        }] || [llength $xs] != [llength $chunk]} {error "Some nodes no longer exist."}
        foreach id $chunk x $xs y $ys z $zs {dict set result $id [list $x $y $z]}
    }
    return $result
}

# One value of one element by id (user_ids= lookup, no mark).
proc ::MeshForge::BoltLink::ev {eid dataname} {
    set v [hm_getvalue elems user_ids=[list $eid] dataname=$dataname]
    if {![llength $v]} {error "Element $eid does not exist."}
    lindex $v 0
}

proc ::MeshForge::BoltLink::points {ids} {
    set c [coordinates $ids]
    set out {}
    foreach id $ids {lappend out [dict get $c $id]}
    return $out
}

# Rows {config nodes} of elements, read in chunks.
proc ::MeshForge::BoltLink::elem_rows {eids} {
    set out {}
    for {set i 0} {$i < [llength $eids]} {incr i 1024} {
        set chunk [lrange $eids $i [expr {$i+1023}]]
        foreach c [hm_getvalue elems user_ids=$chunk dataname=config] n [hm_getvalue elems user_ids=$chunk dataname=nodes] {
            lappend out [list $c $n]
        }
    }
    return $out
}

# Corner nodes only (never midside) of element rows.
proc ::MeshForge::BoltLink::corner_nodes {rows} {
    variable corners
    set out [dict create]
    foreach row $rows {
        lassign $row cfg ns
        set k [expr {[dict exists $corners $cfg] ? [dict get $corners $cfg] : [llength $ns]}]
        foreach n [lrange $ns 0 [expr {$k-1}]] {dict set out $n 1}
    }
    lsort -integer [dict keys $out]
}

# Corner nodes of displayed 2D/3D elements inside the disk of radius factor*R (+tolerance) on the
# circle plane.
# 1. nodes in the bounding box (all, fast)  2. exact disk/plane test on their coordinates
# 3. elements that reference those nodes (cross-reference, no display change)
# 4. keep elements that are displayed and 2D/3D; keep disk nodes that are their corner nodes.
# Never *findmark: it displays what it finds and would unhide hidden parts.
# shape disk: whole disk within factor*R; shape rim: only nodes on the circle (|r-R| <= tolerance).
proc ::MeshForge::BoltLink::disk_nodes {circle factor tolPct {shape disk}} {
    lassign $circle center radius normal
    set tol [expr {$radius*$tolPct/100.0}]
    if {$shape eq "rim"} {set factor 1.0}
    set reach [expr {$factor*$radius + $tol}]
    lassign $center cx cy cz
    set pad [expr {$reach + $tol}]
    *createmark nodes 1 "by box" [expr {$cx-$pad}] [expr {$cy-$pad}] [expr {$cz-$pad}] [expr {$cx+$pad}] [expr {$cy+$pad}] [expr {$cz+$pad}] 0 inside 0 1 0
    set boxNodes [hm_getmark nodes 1]
    *clearmark nodes 1
    if {![llength $boxNodes]} {return {}}
    set inside {}
    dict for {n p} [coordinates $boxNodes] {
        set d [vsub $p $center]
        set h [dot $d $normal]
        if {abs($h) > $tol} {continue}
        set r [norm [vsub $d [vscale $normal $h]]]
        if {$shape eq "rim" ? abs($r-$radius) <= $tol : $r <= $reach} {lappend inside $n}
    }
    if {![llength $inside]} {return {}}
    # Output must differ from the input mark (runtime 2022.3). Only elements are found, so nodes
    # mark 2 (the lowlight preview) is not touched.
    *createmark nodes 1 {*}$inside
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    *clearmark nodes 1
    if {![hm_marklength elems 2]} {return {}}
    *createmark elems 1 "displayed"
    *markintersection elems 2 elems 1
    set shownAll [hm_getmark elems 2]
    *clearmark elems 1; *clearmark elems 2
    # Only 2D/3D elements (config >= 100): skip RBE2 centers, bars, masses.
    set rows {}
    foreach row [elem_rows $shownAll] {if {[lindex $row 0] >= 100} {lappend rows $row}}
    set cornerSet [dict create]
    foreach n [corner_nodes $rows] {dict set cornerSet $n 1}
    set result {}
    foreach n $inside {if {[dict exists $cornerSet $n]} {lappend result $n}}
    lsort -integer $result
}

# Number of nodes already dependent on an existing RBE2 (a Nastran error if both are kept).
proc ::MeshForge::BoltLink::shared_dependents {nodes} {
    if {![llength $nodes]} {return 0}
    *createmark elems 2 "by config" 55
    set rigid [hm_getmark elems 2]
    *clearmark elems 2
    if {![llength $rigid]} {return 0}
    set set [dict create]
    foreach n $nodes {dict set set $n 1}
    set count 0
    for {set i 0} {$i < [llength $rigid]} {incr i 1024} {
        foreach dep [hm_getvalue elems user_ids=[lrange $rigid $i [expr {$i+1023}]] dataname=dependentnodes] {
            foreach n $dep {if {[dict exists $set $n]} {incr count; dict unset set $n}}
        }
    }
    return $count
}

# ---------------------------------------------------------------- ends (pure, used by probes)
# An end is a dict: kind (circle|elems|rbe2), nodes (dependent), center, radius, rbe2, indep, picked.
proc ::MeshForge::BoltLink::circle_end {nodeIds factor tolPct {shape disk}} {
    if {[llength [lsort -unique $nodeIds]] != 3} {error "needs 3 different nodes"}
    if {![string is double -strict $factor] || $factor <= 0 || ![string is double -strict $tolPct] || $tolPct <= 0} {
        error "Radius x and Tolerance % must be positive numbers"
    }
    set circle [circumcircle {*}[points $nodeIds]]
    set nodes [disk_nodes $circle $factor $tolPct $shape]
    if {![llength $nodes]} {error "no corner nodes of displayed elements on the circle"}
    lassign $circle center radius normal
    dict create kind circle nodes $nodes center $center radius $radius rbe2 0 indep 0 picked $nodeIds shape $shape removed {}
}

proc ::MeshForge::BoltLink::elems_end {eids} {
    variable shellConfigs
    set eids [lsort -unique -integer $eids]
    set rows {}
    foreach row [elem_rows $eids] {if {[lindex $row 0] in $shellConfigs} {lappend rows $row}}
    if {![llength $rows]} {error "no 2D elements (tria/quad) in the selection"}
    set nodes [corner_nodes $rows]
    set pts [points $nodes]
    set center [centroid $pts]
    set size 0.0
    foreach p $pts {set size [expr {max($size,[norm [vsub $p $center]])}]}
    dict create kind elems nodes $nodes center $center radius $size rbe2 0 indep 0 picked $eids
}

# Whole connected region of 2D elements (sharing any node) in the component of the clicked element.
proc ::MeshForge::BoltLink::attached_end {eid} {
    variable shellConfigs
    if {![string is integer -strict $eid] || $eid < 1 || [catch {ev $eid config} config]} {error "element $eid does not exist"}
    if {$config ni $shellConfigs} {error "element $eid is not a 2D element (tria/quad)"}
    set cid [ev $eid collector.id]
    *createmark elems 1 "by collector id" $cid
    set compElems [hm_getmark elems 1]
    *clearmark elems 1
    # Corner node -> elements map of the 2D elements of that component (corners are enough for
    # connectivity). Breadth-first walk by index with Tcl arrays: a list-popping queue was quadratic
    # (31.7 s for a 91,768-element component, runtime 2022.3).
    variable corners
    array set conn {}; array set byNode {}; array set seen {}
    for {set i 0} {$i < [llength $compElems]} {incr i 2048} {
        set chunk [lrange $compElems $i [expr {$i+2047}]]
        foreach e $chunk c [hm_getvalue elems user_ids=$chunk dataname=config] ns [hm_getvalue elems user_ids=$chunk dataname=nodes] {
            if {$c ni $shellConfigs} {continue}
            set cs [lrange $ns 0 [expr {[dict get $corners $c]-1}]]
            set conn($e) $cs
            foreach n $cs {lappend byNode($n) $e}
        }
    }
    set queue [list $eid]
    set seen($eid) 1
    set head 0
    while {$head < [llength $queue]} {
        set e [lindex $queue $head]
        incr head
        foreach n $conn($e) {
            foreach f $byNode($n) {
                if {![info exists seen($f)]} {set seen($f) 1; lappend queue $f}
            }
        }
    }
    array set cornerSet {}
    foreach e $queue {foreach n $conn($e) {set cornerSet($n) 1}}
    set nodes [lsort -integer [array names cornerSet]]
    set pts [points $nodes]
    set center [centroid $pts]
    set size 0.0
    foreach p $pts {set size [expr {max($size,[norm [vsub $p $center]])}]}
    dict create kind attached nodes $nodes center $center radius $size rbe2 0 indep 0 \
        picked [lsort -integer $queue] clicked $eid
}

proc ::MeshForge::BoltLink::rbe2_end {eid} {
    if {![string is integer -strict $eid] || $eid < 1 || [catch {ev $eid config} config]} {error "element $eid does not exist"}
    if {$config != 55} {error "element $eid is not an RBE2"}
    set indep [ev $eid independentnode.id]
    set nodes [lsort -integer [ev $eid dependentnodes]]
    dict create kind rbe2 nodes $nodes center [lindex [points [list $indep]] 0] radius 0.0 rbe2 $eid indep $indep picked [list $eid]
}

# Appends ends to a side. Circle: node list, 3 per hole. RBE2: element list. Elems: one end.
# All-or-nothing: an invalid item leaves the side unchanged and names the item.
proc ::MeshForge::BoltLink::add_circles {side nodeList} {
    variable ends; variable E
    if {[llength $nodeList] % 3} {error "Side $side: picked [llength $nodeList] nodes; pick 3 nodes per circle."}
    set new {}
    for {set i 0} {$i < [llength $nodeList]} {incr i 3} {
        set n [expr {[llength $ends($side)]+$i/3+1}]
        if {[catch {circle_end [lrange $nodeList $i [expr {$i+2}]] $E($side,factor) $E($side,tol) $E($side,shape)} end]} {error "Side $side, circle $n: $end."}
        lappend new $end
    }
    foreach end $new {lappend ends($side) $end}
    return [llength $new]
}

proc ::MeshForge::BoltLink::add_rbe2s {side eids} {
    variable ends
    set new {}
    foreach eid $eids {
        set n [expr {[llength $ends($side)]+[llength $new]+1}]
        if {[catch {rbe2_end $eid} end]} {error "Side $side, item $n: $end."}
        lappend new $end
    }
    foreach end $new {lappend ends($side) $end}
    return [llength $new]
}

# One end per clicked element, in click order. Two clicks in the same region are refused.
proc ::MeshForge::BoltLink::add_attached {side eids} {
    variable ends
    set new {}
    foreach eid $eids {
        set n [expr {[llength $ends($side)]+[llength $new]+1}]
        if {[catch {attached_end $eid} end]} {error "Side $side, end $n: $end."}
        foreach old [concat $ends($side) $new] {
            if {[dict get $old kind] eq "attached" && $eid in [dict get $old picked]} {
                error "Side $side, end $n: element $eid is in the same region as an earlier end."
            }
        }
        lappend new $end
    }
    foreach end $new {lappend ends($side) $end}
    return [llength $new]
}

proc ::MeshForge::BoltLink::add_elems {side eids} {
    variable ends
    set n [expr {[llength $ends($side)]+1}]
    if {[catch {elems_end $eids} end]} {error "Side $side, group $n: $end."}
    lappend ends($side) $end
    return 1
}

# Removes nodes from the dependent nodes of every new-RBE2 end of a side (existing RBE2 ends are
# not changed). An end may not lose all its nodes. For 2D elems / Attached ends the independent node
# moves to the centroid of the remaining nodes; a 3 nodes end keeps the circle center.
proc ::MeshForge::BoltLink::remove_nodes {side ids} {
    variable ends
    set drop [dict create]
    foreach n $ids {dict set drop $n 1}
    set out {}
    set total 0
    set i 0
    foreach end $ends($side) {
        incr i
        if {[dict get $end kind] ne "rbe2"} {
            set keep {}; set gone {}
            foreach n [dict get $end nodes] {if {[dict exists $drop $n]} {lappend gone $n} else {lappend keep $n}}
            if {[llength $gone]} {
                if {![llength $keep]} {error "Side $side, end $i: cannot remove every node of an end."}
                set removed [expr {[dict exists $end removed] ? [dict get $end removed] : {}}]
                dict set end nodes $keep
                dict set end removed [lsort -unique -integer [concat $removed $gone]]
                if {[dict get $end kind] ne "circle"} {dict set end center [centroid [points $keep]]}
                incr total [llength $gone]
            }
        }
        lappend out $end
    }
    set ends($side) $out
    return $total
}

proc ::MeshForge::BoltLink::clear_side {side} {
    variable ends
    set ends($side) {}
}

# Re-run the disk search of the circle ends of a side after Radius x / Tolerance % change.
proc ::MeshForge::BoltLink::recompute_circles {side} {
    variable ends; variable E
    set out {}
    set i 0
    foreach end $ends($side) {
        incr i
        if {[dict get $end kind] eq "circle"} {
            if {[catch {circle_end [dict get $end picked] $E($side,factor) $E($side,tol) $E($side,shape)} new]} {error "Side $side, circle $i: $new."}
            # Nodes the user removed stay removed.
            set removed [expr {[dict exists $end removed] ? [dict get $end removed] : {}}]
            if {[llength $removed]} {
                set keep {}
                foreach n [dict get $new nodes] {if {$n ni $removed} {lappend keep $n}}
                if {![llength $keep]} {error "Side $side, circle $i: every node was removed."}
                dict set new nodes $keep
                dict set new removed $removed
            }
            set end $new
        }
        lappend out $end
    }
    set ends($side) $out
}

# ---------------------------------------------------------------- preview (native lowlight)
# Every picked end stays visible as lowlight on nodes mark 2 (the native "previous selection"
# look, e.g. Altair FillHole), also while the other side's panel is open.
proc ::MeshForge::BoltLink::show_picked {} {
    variable ends
    set all [dict create]
    foreach side {A B} {
        foreach end $ends($side) {
            foreach n [dict get $end nodes] {dict set all $n 1}
            if {[dict get $end indep]} {dict set all [dict get $end indep] 1}
        }
    }
    catch {hm_highlightmark nodes 2 norm}
    *clearmark nodes 2
    if {[dict size $all]} {
        *createmark nodes 2 {*}[dict keys $all]
        hm_highlightmark nodes 2 lowlight
    }
    catch {hm_redraw}
}

proc ::MeshForge::BoltLink::clear_picked {} {
    catch {hm_highlightmark nodes 2 norm}
    catch {*clearmark nodes 2}
    catch {hm_redraw}
}

# ---------------------------------------------------------------- model writes
proc ::MeshForge::BoltLink::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::MeshForge::BoltLink::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}

# Orientation vector perpendicular to the bar: the global axis least parallel to it.
proc ::MeshForge::BoltLink::orientation {axis} {
    set best {}; set bestDot 2.0
    foreach g {{1.0 0.0 0.0} {0.0 1.0 0.0} {0.0 0.0 1.0}} {
        set d [expr {abs([dot $g $axis])}]
        if {$d < $bestDot} {set bestDot $d; set best $g}
    }
    unit [vsub $best [vscale $axis [dot $best $axis]]]
}

# New component <prefix>_<its id>.
proc ::MeshForge::BoltLink::new_comp {prefix} {
    set id [expr {[hm_entitymaxid comps 1]+1}]
    while {[hm_entityinfo exist comps $id -byid] || [hm_entityinfo exist comps ${prefix}_$id -byname]} {incr id}
    *createentity comps id=$id name=${prefix}_$id
    if {![hm_entityinfo exist comps ${prefix}_$id -byname]} {error "Component ${prefix}_$id was not created."}
    return ${prefix}_$id
}

# New node exactly at center, then *rigidlink. Runtime 2022.3 on 2.8M elements: *createnode 8 ms +
# *rigidlink ~350 ms, versus *rigidlinkinodecalandcreate ~360-540 ms, *setvalue node ~1.5 s.
# The new node keeps its temp marker until create clears all of them in one call; clearing it
# before *rigidlink makes *rigidlink fail (runtime 2022.3).
proc ::MeshForge::BoltLink::create_rbe2 {nodes dofs center createdNodesVar createdElemsVar} {
    upvar 1 $createdNodesVar createdNodes $createdElemsVar createdElems
    set before [hm_latestentityid elems]
    set beforeNode [hm_latestentityid nodes]
    *createnode {*}$center 0 0 0
    set indep [hm_latestentityid nodes]
    if {$indep < 1 || $indep == $beforeNode} {error "Center node was not created."}
    lappend createdNodes $indep
    *createmark nodes 1 {*}$nodes
    *rigidlink $indep 1 $dofs
    *clearmark nodes 1
    set eid [hm_latestentityid elems]
    if {$eid < 1 || $eid == $before} {error "RBE2 was not created."}
    lappend createdElems $eid
    if {[ev $eid config] != 55} {error "Element $eid is not an RBE2 (readback)."}
    if {[lsort -integer [ev $eid dependentnodes]] ne [lsort -integer $nodes]} {error "RBE2 $eid dependent nodes differ (readback)."}
    if {[ev $eid dofs] != $dofs} {error "RBE2 $eid DOF readback differs."}
    if {[ev $eid independentnode.id] != $indep} {error "RBE2 $eid independent node differs (readback)."}
    set p [lindex [points [list $indep]] 0]
    if {[norm [vsub $p $center]] > 1.0e-9*max(1.0,[norm $center])} {error "RBE2 $eid center node position differs (readback)."}
    list $eid $indep
}

# Names of the properties a CBAR can use (card PBAR or PBARL), sorted.
proc ::MeshForge::BoltLink::bar_props {} {
    *createmark props 1 all
    set ids [hm_getmark props 1]
    *clearmark props 1
    if {![llength $ids]} {return {}}
    set cards [hm_getvalue props user_ids=$ids dataname=cardimage]
    set names [hm_getvalue props user_ids=$ids dataname=name]
    set out {}
    foreach c $cards n $names {if {$c in {PBAR PBARL}} {lappend out $n}}
    lsort -dictionary $out
}

# Property id for a CBAR property name ("" = none). Errors when it is not a PBAR/PBARL of the model.
proc ::MeshForge::BoltLink::bar_prop_id {name} {
    if {$name eq ""} {return 0}
    if {![hm_entityinfo exist props $name -byname]} {error "Property $name does not exist: pick it again."}
    set id [hm_getvalue props name=$name dataname=id]
    set card [hm_getvalue props id=$id dataname=cardimage]
    if {$card ni {PBAR PBARL}} {error "Property $name is $card, not PBAR or PBARL."}
    return $id
}

# Links A1-B1, A2-B2, ... prop: CBAR property name, "" for none.
# Returns dict: rbe2Comp barComp rbe2s bars pairs prop.
proc ::MeshForge::BoltLink::create {{prop ""}} {
    variable ends; variable dofs
    set n [llength $ends(A)]
    if {!$n} {error "Pick side A first."}
    set propId [bar_prop_id $prop]
    if {$n != [llength $ends(B)]} {error "Side A has $n, side B has [llength $ends(B)]: pick the same number."}
    set needRbe 0
    for {set i 0} {$i < $n} {incr i} {
        set a [lindex $ends(A) $i]; set b [lindex $ends(B) $i]
        if {[dict get $a rbe2] && [dict get $a rbe2] == [dict get $b rbe2]} {error "Pair [expr {$i+1}]: both ends are RBE2 [dict get $a rbe2]."}
        if {[norm [vsub [dict get $a center] [dict get $b center]]] < 1.0e-9} {error "Pair [expr {$i+1}]: both ends have the same center."}
        foreach e [list $a $b] {
            if {[dict get $e kind] eq "rbe2"} {rbe2_end [dict get $e rbe2]} else {coordinates [dict get $e nodes]; set needRbe 1}
        }
    }
    set previous [hm_info currentcollector comps]
    set previousName ""
    if {$previous ne "" && $previous ne "0"} {catch {set previousName [hm_getvalue comps id=$previous dataname=name]}}
    set createdElems {}; set createdNodes {}; set comps {}
    set rbe2s {}; set bars {}
    set result [dict create rbe2Comp "" barComp ""]
    history_begin "RBE2-CBAR link"
    set code [catch {
        if {$needRbe} {
            set rc [new_comp RBE2]; lappend comps $rc; dict set result rbe2Comp $rc
            *currentcollector comps $rc
        }
        set links {}
        for {set i 0} {$i < $n} {incr i} {
            set link {}
            foreach side {A B} {
                set e [lindex $ends($side) $i]
                if {[dict get $e kind] eq "rbe2"} {
                    lappend link [dict get $e indep]
                } else {
                    lassign [create_rbe2 [dict get $e nodes] $dofs [dict get $e center] createdNodes createdElems] eid indep
                    lappend rbe2s $eid
                    lappend link $indep
                }
            }
            lappend links $link
        }
        set bc [new_comp CBAR]; lappend comps $bc; dict set result barComp $bc
        *currentcollector comps $bc
        *elementtype 60 1
        foreach link $links {
            lassign $link nA nB
            if {$nA == $nB} {error "A pair resolves to the same node $nA."}
            lassign [points $link] pA pB
            *createvector 1 {*}[orientation [unit [vsub $pB $pA] "Bar"]]
            set before [hm_latestentityid elems]
            *barelement $nA $nB 1 0 0 0 0 $prop
            set bar [hm_latestentityid elems]
            if {$bar < 1 || $bar == $before} {error "CBAR was not created."}
            lappend createdElems $bar
            if {[ev $bar config] != 60} {error "Element $bar is not a bar (readback)."}
            if {[ev $bar nodes] ne $link} {error "CBAR $bar nodes differ (readback)."}
            if {[ev $bar property.id] != $propId} {error "CBAR $bar property differs (readback)."}
            lappend bars $bar
        }
    } err opts]
    if {$code} {
        if {[llength $createdElems]} {catch {*createmark elems 1 {*}$createdElems; *deletemark elems 1}}
        if {[llength $createdNodes]} {catch {*createmark nodes 1 {*}$createdNodes; *deletemark nodes 1}}
        foreach c $comps {catch {*createmark comps 1 "by name only" $c; *deletemark comps 1}}
        catch {*clearmark elems 1}; catch {*clearmark nodes 1}; catch {*clearmark comps 1}
    } elseif {[llength $createdNodes]} {
        # One temp-marker clear for all new center nodes (each call ~0.3 s on big models).
        catch {*createmark nodes 1 {*}$createdNodes; *nodemarkcleartempmark 1}
        catch {*clearmark nodes 1}
    }
    if {$previousName ne ""} {catch {*currentcollector comps $previousName}}
    history_end "RBE2-CBAR link"
    if {$code} {return -options $opts $err}
    dict set result rbe2s $rbe2s
    dict set result bars $bars
    dict set result pairs $n
    dict set result prop $prop
    return $result
}

# ---------------------------------------------------------------- GUI callbacks
proc ::MeshForge::BoltLink::panel_hide {} {variable W; if {[winfo exists $W]} {wm withdraw $W}}
proc ::MeshForge::BoltLink::panel_show {} {variable W; if {[winfo exists $W]} {wm deiconify $W; raise $W}}

# Native pick for one side. return/ESC makes a panel raise an error ("0"); marks and lists are
# cleared first, so an empty result means cancel.
proc ::MeshForge::BoltLink::pick {side} {
    variable E; variable status
    sync_circle_options
    show_picked
    panel_hide
    set rc [catch {
        switch -- $E($side,mode) {
            circle -
            rbe2 {
                set mode $E($side,mode)
                if {$mode eq "circle"} {
                    set entity nodes
                    set prompt "pick three edge nodes"
                    set add add_circles
                } else {
                    set entity elems
                    set prompt "pick RBE2 elements in order"
                    set add add_rbe2s
                }
                set added 0
                while 1 {
                    *clearlist $entity 1
                    set k [expr {[llength $::MeshForge::BoltLink::ends($side)]+1}]
                    catch {::TestToolSession::panel *createlistpanel $entity 1 "Side $side, end $k: $prompt (return with nothing selected to finish)"}
                    set ids [hm_getlist $entity 1]
                    *clearlist $entity 1
                    if {![llength $ids]} {break}
                    incr added [$add $side $ids]
                    show_picked
                }
            }
            attached {
                # One click per end: the single-entity panel returns on the click (Altair pattern:
                # error = cancelled, else hm_info lastselectedentity). The region is shown at once,
                # then the panel reopens for the next end; return/ESC finishes.
                set added 0
                # A panel left without a click may still report the previous selection: a value equal
                # to the last one seen (including before the first click) means finish.
                set last [hm_info lastselectedentity elems]
                while 1 {
                    set k [expr {[llength $::MeshForge::BoltLink::ends($side)]+1}]
                    if {[catch {::TestToolSession::panel *createentitypanel elems "Side $side, end $k: click one element (return to finish)"}]} {break}
                    set id [hm_info lastselectedentity elems]
                    if {$id eq "" || $id == 0 || $id eq $last} {break}
                    set last $id
                    if {[catch {add_attached $side [list $id]} err]} {
                        set ::MeshForge::BoltLink::status $err
                        catch {hm_usermessage $err}
                        continue
                    }
                    incr added
                    show_picked
                }
            }
            elems {
                set added 0
                while 1 {
                    *clearmark elems 1
                    set k [expr {[llength $::MeshForge::BoltLink::ends($side)]+1}]
                    catch {::TestToolSession::panel *createmarkpanel elems 1 "Side $side, end $k: 2D elements (return with nothing selected to finish)"}
                    set ids [hm_getmark elems 1]
                    *clearmark elems 1
                    if {![llength $ids]} {break}
                    incr added [add_elems $side $ids]
                    show_picked
                }
            }
        }
        set added
    } r]
    panel_show
    show_picked
    if {$rc} {set status $r} elseif {!$r} {set status "Side $side: nothing added."} else {
        set status "Side $side: added $r."
        set shared [shared_dependents [side_nodes $side]]
        if {$shared} {append status " Warning: $shared nodes already belong to an RBE2."}
    }
    refresh
}

proc ::MeshForge::BoltLink::side_nodes {side} {
    variable ends
    set out {}
    foreach e $ends($side) {if {[dict get $e kind] ne "rbe2"} {foreach n [dict get $e nodes] {lappend out $n}}}
    return $out
}

proc ::MeshForge::BoltLink::do_remove {side} {
    variable status; variable ends
    if {![llength $ends($side)]} {set status "Side $side: nothing picked."; return}
    show_picked
    panel_hide
    *clearmark nodes 1
    catch {::TestToolSession::panel *createmarkpanel nodes 1 "Side $side: nodes to remove from the RBE2s"}
    set ids [hm_getmark nodes 1]
    *clearmark nodes 1
    panel_show
    if {![llength $ids]} {set status "Remove cancelled."; show_picked; refresh; return}
    if {[catch {remove_nodes $side $ids} n]} {set status $n} else {set status "Side $side: removed $n nodes."}
    show_picked
    refresh
}

proc ::MeshForge::BoltLink::do_clear {side} {
    variable status
    clear_side $side
    show_picked
    set status "Side $side cleared."
    refresh
}

# Hole options: "Edge only" / "Edge + inside" is chosen per side (E(side,shape) rim|disk);
# Inside radius x and Tolerance % are shared by both sides.
if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::MeshForge_BoltLink_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::MeshForge::BoltLink {
    variable C
    foreach {key value} {factor 1.0 tol 2.0} {if {![info exists C($key)]} {set C($key) $value}}
}

proc ::MeshForge::BoltLink::sync_circle_options {} {
    variable C; variable E
    foreach side {A B} {foreach k {factor tol} {set E($side,$k) $C($k)}}
}

proc ::MeshForge::BoltLink::reapply_all {} {
    variable status
    sync_circle_options
    foreach side {A B} {
        if {[catch {recompute_circles $side} err]} {set status $err; break}
    }
    show_picked
    refresh
}

proc ::MeshForge::BoltLink::select_circle_shape {side index} {
    variable E
    set E($side,shape) [lindex {rim disk} $index]
    reapply_all
}

proc ::MeshForge::BoltLink::mode_selected {side} {refresh}

proc ::MeshForge::BoltLink::do_create {} {
    variable status; variable ends; variable barProp; variable noProp
    set status "Creating..."
    update idletasks
    set prop [expr {$barProp eq $noProp ? "" : $barProp}]
    if {[catch {create $prop} r]} {set status $r; return}
    set text "Created [dict get $r pairs] links: [llength [dict get $r rbe2s]] RBE2"
    if {[dict get $r rbe2Comp] ne ""} {append text " in [dict get $r rbe2Comp]"}
    append text ", [llength [dict get $r bars]] CBAR in [dict get $r barComp]"
    append text [expr {$prop eq "" ? " (no property)." : " ($prop)."}]
    set status $text
    clear_side A; clear_side B
    clear_picked
    refresh
}

proc ::MeshForge::BoltLink::reset {} {
    variable status
    clear_side A; clear_side B
    clear_picked
    set status "Inputs cleared."
    refresh
}

proc ::MeshForge::BoltLink::close {} {
    variable W
    clear_picked
    destroy $W
}

proc ::MeshForge::BoltLink::refresh {} {
    variable W; variable E; variable ends; variable C
    if {![winfo exists $W]} {return}
    set holeUsed 0; set insideUsed 0
    foreach side {A B} {
        set f $W.body.side$side
        set n [llength $ends($side)]
        set kinds [dict create]
        foreach e $ends($side) {dict incr kinds [dict get $e kind]}
        set parts {}
        foreach {k one many} {circle circle circles elems group groups attached region regions rbe2 RBE2 RBE2} {
            if {[dict exists $kinds $k]} {set c [dict get $kinds $k]; lappend parts "$c [expr {$c == 1 ? $one : $many}]"}
        }
        set E($side,info) [expr {$n ? [join $parts {, }] : "Nothing picked"}]
        set hole [expr {$E($side,mode) eq "circle"}]
        $f.shape configure -state [expr {$hole ? "readonly" : "disabled"}]
        $f.shape current [expr {$E($side,shape) eq "disk"}]
        if {$hole || [dict exists $kinds circle]} {
            set holeUsed 1
            if {$E($side,shape) eq "disk"} {set insideUsed 1}
        }
        foreach w {remove clear} {$f.$w configure -state [expr {$n ? "normal" : "disabled"}]}
    }
    set c $W.body.hole
    foreach w {tol l_tol} {$c.$w configure -state [expr {$holeUsed ? "normal" : "disabled"}]}
    foreach w {factor l_factor} {$c.$w configure -state [expr {$insideUsed ? "normal" : "disabled"}]}
    set nA [llength $ends(A)]; set nB [llength $ends(B)]
    set E(pairs) "A $nA  /  B $nB"
    $W.foot.create configure -state [expr {$nA && $nA == $nB ? "normal" : "disabled"}]
}

# ---------------------------------------------------------------- window
# Layout: Side A | Side B next to each other (same grid, so A1-B1 is easy to compare). In each side
# the source radio buttons and a circle shape dropdown. Then the shared circle settings and actions.
proc ::MeshForge::BoltLink::side_block {parent side} {
    set f [labelframe $parent.side$side -text "Side $side" -padx 8 -pady 6]
    grid columnconfigure $f {0 1} -uniform col -weight 1
    set r 0
    foreach {value text} {circle "3 edge nodes" elems "2D elems" attached "Attached" rbe2 "RBE2"} {
        radiobutton $f.m_$value -text $text -value $value -variable ::MeshForge::BoltLink::E($side,mode) \
            -command [list ::TestToolSession::run "Bolt link" [list ::MeshForge::BoltLink::mode_selected $side]] -anchor w
        grid $f.m_$value -row $r -column 0 -columnspan 2 -sticky w
        incr r
        if {$value eq "circle"} {
            ttk::combobox $f.shape -state readonly -width 16 -values {"Edge only" "Edge + inside"}
            bind $f.shape <<ComboboxSelected>> [format {::TestToolSession::run "Bolt link" [list ::MeshForge::BoltLink::select_circle_shape %s [%%W current]]} $side]
            grid $f.shape -row $r -column 0 -columnspan 2 -sticky w -padx {22 0} -pady {0 2}
            incr r
        }
    }
    button $f.select -text "Select..." -width 9 -command [list ::TestToolSession::run "Bolt link" [list ::MeshForge::BoltLink::pick $side]]
    label $f.info -textvariable ::MeshForge::BoltLink::E($side,info) -anchor w
    button $f.remove -text "Remove..." -width 9 -command [list ::TestToolSession::run "Bolt link" [list ::MeshForge::BoltLink::do_remove $side]]
    button $f.clear -text "Clear" -width 9 -command [list ::TestToolSession::run "Bolt link" [list ::MeshForge::BoltLink::do_clear $side]]
    grid $f.select -row $r -column 0 -sticky ew -padx {0 4} -pady {6 2}
    grid $f.info -row $r -column 1 -sticky w -padx {4 0} -pady {6 2}
    incr r
    grid $f.remove -row $r -column 0 -sticky ew -padx {0 4} -pady 2
    grid $f.clear -row $r -column 1 -sticky ew -padx {4 0} -pady 2
    return $f
}

proc ::MeshForge::BoltLink::hole_block {parent} {
    set c [labelframe $parent.hole -text "3 edge nodes" -padx 8 -pady 6]
    label $c.l_factor -text "Inside radius x" -anchor w
    entry $c.factor -width 6 -justify right -textvariable ::MeshForge::BoltLink::C(factor)
    label $c.l_tol -text "Tolerance %" -anchor w
    entry $c.tol -width 6 -justify right -textvariable ::MeshForge::BoltLink::C(tol)
    foreach w {factor tol} {
        bind $c.$w <Return> [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::reapply_all]
        bind $c.$w <FocusOut> [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::reapply_all 0 0]
    }
    grid $c.l_factor -row 0 -column 0 -sticky w -padx {0 6}
    grid $c.factor -row 0 -column 1 -sticky w -padx {0 24}
    grid $c.l_tol -row 0 -column 2 -sticky w -padx {0 6}
    grid $c.tol -row 0 -column 3 -sticky w
    return $c
}

# CBAR property dropdown: "(none)" + the model's PBAR/PBARL names, reread each time it opens.
proc ::MeshForge::BoltLink::fill_props {} {
    variable W; variable barProp; variable noProp
    set names {}
    catch {set names [bar_props]}
    if {[winfo exists $W.body.bar.prop]} {$W.body.bar.prop configure -values [linsert $names 0 $noProp]}
    if {$barProp ne $noProp && $barProp ni $names} {set barProp $noProp}
}

proc ::MeshForge::BoltLink::bar_block {parent} {
    set c [labelframe $parent.bar -text "CBAR" -padx 8 -pady 6]
    label $c.l_prop -text "Property" -anchor w
    ttk::combobox $c.prop -state readonly -width 24 -textvariable ::MeshForge::BoltLink::barProp \
        -postcommand ::MeshForge::BoltLink::fill_props
    grid $c.l_prop -row 0 -column 0 -sticky w -padx {0 6}
    grid $c.prop -row 0 -column 1 -sticky w
    return $c
}

proc ::MeshForge::BoltLink::show {} {
    variable W; variable status; variable E
    if {[winfo exists $W]} {destroy $W}
    clear_side A; clear_side B
    clear_picked
    sync_circle_options
    toplevel $W
    wm withdraw $W
    wm title $W "Bolt Link"
    wm resizable $W 0 0
    frame $W.body -padx 12 -pady 10
    pack $W.body -fill both -expand 1
    grid columnconfigure $W.body {0 1} -weight 1 -uniform side
    grid [side_block $W.body A] -row 0 -column 0 -sticky nsew -padx {0 6}
    grid [side_block $W.body B] -row 0 -column 1 -sticky nsew -padx {6 0}
    grid [hole_block $W.body] -row 1 -column 0 -columnspan 2 -sticky ew -pady {8 0}
    grid [bar_block $W.body] -row 2 -column 0 -columnspan 2 -sticky ew -pady {8 0}
    # Property box starts in the same column as the "Inside radius x" entry above it.
    grid columnconfigure $W.body.bar 0 -minsize [expr {[winfo reqwidth $W.body.hole.l_factor]+6}]
    fill_props
    frame $W.foot -padx 12 -pady 8
    label $W.foot.status -textvariable ::MeshForge::BoltLink::status -anchor w -justify left -height 2 -wraplength 200
    label $W.foot.pairs -textvariable ::MeshForge::BoltLink::E(pairs) -anchor e
    button $W.foot.close -text "Close" -width 8 -command [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::close]
    button $W.foot.reset -text "Reset" -width 8 -command [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::reset]
    button $W.foot.create -text "Create" -width 8 -command [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::do_create]
    pack $W.foot.close $W.foot.reset $W.foot.create -side right -padx {6 0}
    pack $W.foot.pairs -side right -padx {0 10}
    pack $W.foot.status -side left -fill x -expand 1
    pack $W.foot -fill x
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Bolt link" ::MeshForge::BoltLink::close]
    set status "Pick side A, then side B in the same order."
    foreach side {A B} {if {$E($side,shape) ni {rim disk}} {set E($side,shape) disk}}
    refresh
    ::TestToolSession::place "Bolt link" $W
    wm deiconify $W
    ::TestToolSession::attach "Bolt link" $W
}

# Center over the HyperMesh main window, inside the work area of the monitor that holds it.
# A monitor left of or above the primary one has negative coordinates: no clamp to 0, and
# "+$x+$y" keeps them absolute ("%+d" of a negative number counts from the right edge).
proc ::MeshForge::BoltLink::place_center {} {
    variable W
    update idletasks
    $W.foot.status configure -wraplength [expr {max(160,[winfo reqwidth $W]-[winfo reqwidth $W.foot.pairs]-300)}]
    update idletasks
    # Host: the Win32 frame of "." (the HyperWorks top-level window; "." is only its content area),
    # else that content area. wm geometry places the outer frame of W: add its border
    # (SM_CXSIZEFRAME + SM_CXPADDEDBORDER) and caption.
    set host [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $frame] l t r b
        set host [list $l $t [expr {$r - $l}] [expr {$b - $t}]]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set w [expr {[winfo reqwidth $W] + 2*$border}]
    set h [expr {[winfo reqheight $W] + $caption + 2*$border}]
    lassign [fit_box $host $work $w $h] x y
    wm geometry $W +$x+$y
}
# Top-left corner of a w x h frame centered on host {x y width height}, kept inside
# work {left top right bottom} when known (the top-left corner wins if the frame is larger).
proc ::MeshForge::BoltLink::fit_box {host work w h} {
    lassign $host hx hy hw hh
    set x [expr {$hx + ($hw - $w) / 2}]
    set y [expr {$hy + ($hh - $h) / 2}]
    if {[llength $work] == 4} {
        lassign $work left top right bottom
        set x [expr {max($left, min($x, $right - $w))}]
        set y [expr {max($top, min($y, $bottom - $h))}]
    }
    list $x $y
}


if {![info exists ::MeshForge_BoltLink_no_gui]} {
    ::MeshForge::BoltLink::show
}
