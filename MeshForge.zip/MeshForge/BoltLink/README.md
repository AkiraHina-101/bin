# BoltLink (RBE2 – CBAR – RBE2)

Tạo hàng loạt liên kết kiểu bu lông RBE2 – CBAR – RBE2 (mỗi cặp hai RBE2 và một CBAR nối hai node độc lập) trong HyperMesh 2022.3, profile Nastran.

- Điểm vào: [bolt_link.tcl](bolt_link.tcl). Menu: Utility → **test** → **RBE2 bar** (trang của thư mục [05-Test](../README.md), MAC [../menu_page.mac](../menu_page.mac) sinh bằng `menu_builder/build_menu.py`).
- Mở cửa sổ và chọn không đổi model. Chỉ nút **Create** ghi vào model, gộp thành một bước undo "RBE2-CBAR link".

## Cách dùng

Cửa sổ: **Side A** và **Side B** đặt cạnh nhau. Mỗi bên chọn nguồn bằng nút radio: **3 edge nodes** (kèm dropdown, chỉ bật khi chọn mục này: **Edge only** / **Edge + inside**), **2D elems**, **Attached**, **RBE2**; dưới đó là Select... + số đã chọn, Remove... / Clear. Nhóm **3 edge nodes** chung cho hai bên: **Inside radius x** (chỉ dùng cho Edge + inside) và **Tolerance %**. Chân cửa sổ: trạng thái, số cặp "A n / B m", Create / Reset / Close.


1. **Side A**: chọn chế độ rồi **Select...**. Bấm Select lần nữa để chọn thêm, **Clear** để chọn lại từ đầu.
   - **3 edge nodes**: panel node list mở lại sau mỗi lần Proceed. Chọn ba node mép cho mỗi lỗ rồi Proceed. Để dừng, thoát panel khi chưa chọn node.
     Hai kiểu (chọn riêng cho mỗi bên): **Edge + inside** (corner node trong đĩa `Inside radius x`·R) hoặc **Edge only** (chỉ corner node trên viền, |r − R| ≤ `Tolerance %`·R; ô Inside radius x khóa nếu không bên nào dùng Edge + inside). Đổi kiểu hoặc số thì các lỗ đã chọn được tìm lại.
   - **2D elems**: panel chọn element mở lại liên tục, mỗi lần proceed là một nhóm; return khi không chọn gì để dừng.
   - **Attached**: panel chọn một element; click 1 element là xong một end, vùng của nó hiện mờ ngay, panel tự mở lại cho end kế tiếp (return/ESC để dừng). Tool lấy cả vùng element 2D liền nhau (chung node) trong cùng component với element đó, dùng corner node của vùng, node độc lập ở trọng tâm. Hai click trong cùng một vùng bị từ chối.
   - **RBE2**: chọn RBE2 có sẵn theo thứ tự. Panel mở lại sau Proceed để chọn tiếp, thoát khi chưa chọn để dừng.
2. **Side B**: làm như trên, cùng số lượng và cùng thứ tự với A.
   - **Remove...**: panel chọn node native; các node được chọn bị bỏ khỏi RBE2 của mọi end bên đó (RBE2 có sẵn không đổi). Không được bỏ hết node của một end. Với 2D elems / Attached, node độc lập dời về trọng tâm phần còn lại; 3 nodes giữ tâm đường tròn. Node đã bỏ vẫn bị bỏ khi đổi Disk/Rim, Radius x, Tolerance %.
3. **Create**: nối A1–B1, A2–B2, … Chỉ bật khi số A bằng số B.

- Các nhóm đã chọn (cả A và B) hiện mờ kiểu native (`hm_highlightmark nodes 2 lowlight`, cách Altair dùng trong FillHole), kể cả lúc panel của bên kia đang mở.
- Node phụ thuộc chỉ là corner node; node giữa (midside của tria6/quad8, tet10…) không bao giờ được lấy. 3 nodes: corner node của element 2D/3D đang hiển thị, cùng mặt phẳng, cách tâm ≤ `Radius x`·R (+ `Tolerance %` của R); node độc lập là node mới đúng tâm đường tròn. 2D elems: corner node của các element; node độc lập ở trọng tâm. RBE2: dùng nguyên RBE2 đó.
- Mỗi lần Create: mọi RBE2 mới vào một component mới `RBE2_<id của nó>`, mọi CBAR vào `CBAR_<id>`. CBAR lấy property chọn ở ô **CBAR → Property** (danh sách PBAR/PBARL đang có trong model, đọc lại mỗi lần mở danh sách; chọn `(none)` thì để trống), hướng tự tính (trục toàn cục ít song song với thanh nhất). DOF RBE2 là 123456. Tất cả là một bước undo "RBE2-CBAR link".
- Cửa sổ có owner là cửa sổ HyperMesh: luôn nằm trên HyperMesh, không đè ứng dụng khác. Cửa sổ tự ẩn khi panel chọn mở.
- Thoát panel bằng return/ESC là hủy (panel báo lỗi "0", tool coi là hủy).

## Giới hạn

- Node component bị ẩn hoặc element bị mask không được lấy; node chỉ thuộc RBE2/bar/mass cũng không.
- Status cảnh báo khi node đã là dependent của RBE2 khác.
- Mỗi lệnh native tạo phần tử trên model 2,8 triệu element tốn cố định khoảng 0,25–0,35 s; n cặp mất khoảng n × (2 RBE2 + 1 CBAR).

## Kiểm chứng (18/11/2026, bản nhiều cặp)

Công cụ: viết mã Tcl; chạy thật trong HyperMesh 2022.3.0.24 trên phiên scratch riêng của agent; MAC `--check` đạt.

- [tests/probe_logic.tcl](tests/probe_logic.tcl) trên model [tests/build_plate_model.tcl](tests/build_plate_model.tcl) (2 lỗ quad4 và 1 lỗ quad8 mỗi tấm): **24/24 PASS**. Gồm: vòng 16/32 node theo `Radius x`; bỏ vòng ẩn và vòng lệch mặt phẳng; lỗ quad8 chỉ lấy 16 corner node, kể cả khi 3 node bấm là midside; 2D elems quad8 chỉ lấy corner; chọn 2 lỗ theo thứ tự; số node không chia hết cho 3, 3 node thẳng hàng, phần tử không phải RBE2 thì không thêm gì; lowlight đúng số node, không đổi model; Create 3 cặp: `RBE2_<id>` chứa 6 RBE2, `CBAR_<id>` chứa 3 CBAR không property, cặp nối đúng thứ tự, không dependent nào là midside; dùng lại RBE2 hai bên thì chỉ tạo CBAR; số lượng lệch và cùng RBE2 báo lỗi, không đổi model; một undo gỡ hết; component ẩn vẫn ẩn.
- GUI mở qua đường MAC, panel thật của side B mở (tự thoát bằng `hm_exitpanel` sau 9 s) và đã xem ảnh: 3 lỗ của A hiện xám đậm trong lúc panel B mở; cửa sổ 440×298 giữa HyperMesh, owner HyperMesh.
- Attached (thêm sau): probe thêm 5 ca, tổng **29/29 PASS** (lặp 3 lần): click 1 element chỉ lấy đúng vòng chứa nó dù cùng component có vòng khác (48 element, 64 corner node, tâm đúng); vùng quad8 không lấy midside; hai click cùng vùng bị từ chối; tạo 2 cặp đúng thứ tự; undo gỡ hết. Trên `02-Test_Full_Model.hm` (không lưu), click vào PSHELL_165 (91.768 element) lấy vùng 91.764 element, 45.796 corner node trong 2,55 s (bản đầu 31,7 s do hàng đợi bị chép lại mỗi bước).
- Vòng chọn Attached: đã mở panel thật (ảnh: panel "element" mở, vùng end trước hiện mờ) và thoát bằng `hm_exitpanel` thì dừng gọn, cửa sổ hiện lại. Chưa xác nhận bằng click thật rằng panel một element trả về ngay sau click (theo mẫu Altair, không cần proceed).
- Rim/Remove (thêm sau): probe tổng **36/36 PASS**: Rim chỉ lấy 16 node viền (quad4 và quad8, không midside); Remove bỏ đúng 2 node, giữ sau khi đổi Radius x và Disk/Rim; bỏ hết node bị từ chối; 2D elems dời trọng tâm. Panel Remove mở thật và thoát gọn (đã xem ảnh).
- Property CBAR (19/11/2026): probe tổng **40/40 PASS** (HyperMesh 2022.3.0.24, scratch riêng): danh sách chỉ gồm PBAR/PBARL (PSHELL không có); tên không tồn tại hoặc không phải PBAR/PBARL bị từ chối, không đổi model; CBAR đọc lại đúng `property.id`; để trống vẫn cho `property.id` 0. Kiểm đối chứng: bản sửa hỏng (bỏ property) FAIL đúng ca `bar_property_set`. Đã mở tool qua điểm vào thật và xem ảnh: khung CBAR, ô Property thẳng cột với ô "Inside radius x". Chưa bấm mở danh sách bằng chuột.
- Chưa kiểm: click chuột thật trên các panel; số liệu tốc độ của bản nhiều cặp trên model đầy đủ (các phép đo cũ ở trên vẫn đúng cho từng lệnh).

## Thử nghiệm của agent

[tests/agent_session.py](tests/agent_session.py) `start` mở một phiên scratch riêng (Nastran, dựng model thử, nối menu) và giữ mở; `send <run> <tệp.tcl>` chạy một tệp Tcl trong phiên đó. Phiên chỉ đọc yêu cầu trong thư mục run của nó, không mở hay lưu model người dùng.

## Vị trí cửa sổ (22/11/2026, ticket `02-window-on-host-monitor`)

- Bản cũ không kẹp tọa độ về 0 nên vẫn mở đúng màn (suy từ mã, chưa đo bằng bản cũ), nhưng căn theo vùng nội dung Tk `.`, bỏ qua viền và thanh tiêu đề, không giới hạn trong vùng làm việc, và lùi về giữa màn chính khi `.` hẹp hơn 50 px.
- Nay `place_center` căn khung ngoài của cửa sổ (cộng viền và thanh tiêu đề theo `GetSystemMetrics`) vào giữa khung Win32 của `[wm frame .]` (cửa sổ HyperWorks; Tk `.` chỉ là vùng nội dung bên trong), giữ cửa sổ trong vùng làm việc của màn hình chứa HyperMesh và viết `+$x+$y` để giữ tọa độ âm. Không có twapi thì căn theo vùng nội dung `.`, không giới hạn vùng làm việc.
- Kiểm trên scratch HyperMesh 2022.3 riêng (chỉ thử vị trí, không đổi model): [tests/gui_place.tcl](tests/gui_place.tcl) run `c74bb18750a84546bf0cd7b9c28afb23` **13/13 PASS**. Mở qua `*evaltclscript` như nút MAC trong ba ca: scratch ở màn chính; khung scratch dời sang màn trái tọa độ âm (`SetWindowPos`, không kích hoạt) với hình chữ nhật phóng to như HyperMesh của người dùng; rồi cửa sổ nhỏ trên màn đó. Tâm cửa sổ lệch tâm khung HyperMesh ≤ 0,5 px, cùng màn hình, nằm trong vùng làm việc, khung ngoài thực bằng khung tính trước. Ảnh ghép `overlay.png` trong run đã xem. [tests/place_math.tcl](tests/place_math.tcl) chạy bằng tclsh 8.5.9 của Altair: 11/11 bố cục có tọa độ âm (màn trái, trên, trái-trên, tràn mép, cửa sổ lớn hơn vùng làm việc).
- Chưa kiểm: mở từ menu trong phiên người dùng; hai màn khác DPI (viền tính theo DPI hệ thống).
