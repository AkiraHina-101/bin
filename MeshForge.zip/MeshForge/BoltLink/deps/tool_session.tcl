# Marks, the native pick panel, and history recording are shared by the HyperMesh interpreter.
# One MeshForge tool at a time, and it behaves as a native HyperMesh dialog (hmtk::dialog, the native
# entity selector; HyperMesh 2022.3 hm/scripts/hmtk):
#   - Escape in a tool window closes the tool (native dialogs: Escape = Cancel); Escape in a pick panel
#     ends the pick only and the window comes back.
#   - The window is owned by the HyperMesh main window (above HyperMesh only, never topmost over other
#     applications) and is hidden while a pick panel of the tool is open; it comes back when the tool
#     operation ends.
#   - Opening another tool closes the one open before (as a native tool exits the active one); a button
#     of the same tool pressed during its pick ends that pick and runs the button.
#   - A HyperMesh shortcut (F1-F12) during a pick or with a tool open: the tool ends and the shortcut
#     opens its HyperMesh feature.
#   - Entering a native HyperMesh tool (ContextEntered) or a new model (BeforeDatabaseMajorChange) closes
#     the tool and its pick, as native dialogs do on ContextExited / -autoclose; a pick exits an active
#     native tool first (as the native entity selector does).
namespace eval ::TestToolSession {
    variable active ""
    variable reservedTool ""
    variable reservedWindow ""
    variable pauseReservation ""
    variable panelOpen 0
    variable cancelled 0
    variable pending ""
    # tool -> its window (attach); the window hidden for a pick, shown again when the run ends
    variable windows
    if {![info exists windows]} {set windows [dict create]}
    variable hidden ""
    # tool -> its entry script (attach), to close the other tools when one is opened from the menu
    variable scripts
    if {![info exists scripts]} {set scripts [dict create]}
    variable hooked
    if {![info exists hooked]} {set hooked 0}
    # tool -> {x y} where the user left its window (place)
    variable places
    if {![info exists places]} {set places [dict create]}
}

# HyperMesh's own DLLs (hmobj.dll, hwdplugin.dll) call ::hw::SetFocusToGraphics, which no Tcl script of
# 2022.3 defines ("invalid command name"; the session has ::hw::SetFocusGraphics); defined here when
# missing: the focus goes to the graphics.
if {![llength [info commands ::hw::SetFocusToGraphics]]} {
    namespace eval ::hw {}
    proc ::hw::SetFocusToGraphics {args} {
        if {[llength [info commands ::hw::SetFocusGraphics]]} {
            catch {::hw::SetFocusGraphics}
        } else {
            catch {focus [::hw::GetGraphicsWindow]}
        }
        return
    }
}

proc ::TestToolSession::owner {} {
    variable active; variable reservedTool; variable reservedWindow
    if {$active ne ""} {return $active}
    if {$reservedWindow ne "" && [winfo exists $reservedWindow]} {return $reservedTool}
    return ""
}

proc ::TestToolSession::reserve {tool window pause} {
    variable reservedTool $tool
    variable reservedWindow $window
    variable pauseReservation $pause
}

proc ::TestToolSession::yield_reservation {} {
    variable active; variable reservedTool; variable reservedWindow; variable pauseReservation
    if {$active ne "" || $pauseReservation eq ""} {return 0}
    if {[catch {run $reservedTool $pauseReservation} message]} {
        puts "MeshForge: $message"
        return 0
    }
    set reservedWindow ""
    return 1
}

proc ::TestToolSession::report {tool} {
    # Report inside the Tcl event loop without re-entering a native panel.
    set text "MeshForge: $tool is still working; wait for it to finish."
    puts $text
    catch {hm_usermessage $text}
}

proc ::TestToolSession::cancelled {} {variable cancelled; return $cancelled}

proc ::TestToolSession::handoff {script} {
    variable panelOpen; variable cancelled; variable pending
    if {!$panelOpen} {return 0}
    set pending $script
    if {!$cancelled} {
        set cancelled 1
        if {[catch {hm_exitpanel}]} {set cancelled 0; set pending ""; return 0}
    }
    return 1
}

proc ::TestToolSession::context {} {
    if {[catch {::hm::context::GetActiveContext} c]} {return ""}
    return $c
}

# HyperMesh shortcuts F1-F12 (F2 Delete, F3 Replace, ...) open another HyperMesh feature. HyperMesh
# ignores them while a Tcl pick panel waits: every key goes through ::hw::KeyPressBinding (bind all
# <KeyPress>), which is wrapped once. During a tool pick the pick and the tool end first and the key is
# sent again; with only a tool window open the tool closes and the key goes on. Other keys go on as they are.
proc ::TestToolSession::install_keys {} {
    if {![llength [info commands ::hw::KeyPressBinding]] || [llength [info commands ::TestToolSession::hw_keypress]]} {return}
    rename ::hw::KeyPressBinding ::TestToolSession::hw_keypress
    proc ::hw::KeyPressBinding {args} {
        if {[::TestToolSession::shortcut $args]} {return}
        set code [catch {uplevel 1 [list ::TestToolSession::hw_keypress {*}$args]} value options]
        return -options $options $value
    }
}

# 1 when the key was taken (sent again once the pick has ended).
proc ::TestToolSession::shortcut {argv} {
    variable panelOpen; variable active; variable windows
    if {![regexp {^F([1-9]|1[0-2])$} [lindex $argv 6]]} {return 0}
    set replay [list ::TestToolSession::hw_keypress {*}$argv]
    if {$panelOpen && $active ne ""} {
        if {[handoff [list ::TestToolSession::replay_shortcut $replay]]} {return 1}
        return 0
    }
    if {[dict size $windows] && $active eq ""} {close_all}
    return 0
}

proc ::TestToolSession::replay_shortcut {replay} {
    close_all
    after idle [list catch $replay]
}

proc ::TestToolSession::panel {command args} {
    variable active; variable panelOpen; variable cancelled; variable windows; variable hidden
    install_keys
    # a native tool still active would share the graphics with this pick: it is left first
    if {[context] ni {"" Panel}} {catch {::hm::context::ExitActiveContext}}
    if {$active eq ""} {return [uplevel #0 [list $command {*}$args]]}
    if {$cancelled} {return -code error 0}
    # the tool window is hidden for the pick (shown again when the run ends)
    if {[dict exists $windows $active]} {
        set w [dict get $windows $active]
        if {[winfo exists $w] && [winfo ismapped $w]} {wm withdraw $w; set hidden $w}
    }
    set panelOpen 1
    set code [catch {uplevel #0 [list $command {*}$args]} value options]
    set panelOpen 0
    if {$cancelled} {
        switch -- $command {
            *createmarkpanel -
            *editmarkpanel {*clearmark {*}[lrange $args 0 1]}
            *createlistpanel -
            *createlistbypathpanel {*clearlist {*}[lrange $args 0 1]}
        }
        return -code error 0
    }
    if {$code} {return -options $options $value}
    return $value
}

proc ::TestToolSession::can_open {path} {
    variable windows; variable scripts
    set current [owner]
    if {$current ne "" && ![yield_reservation]} {
        if {![handoff [list *evaltclscript $path 0]]} {report $current}
        return 0
    }
    # the tool opened from the menu replaces the open one
    set path [file normalize $path]
    foreach t [dict keys $windows] {
        if {![dict exists $scripts $t] || [dict get $scripts $t] ne $path} {close_window $t}
    }
    return 1
}

proc ::TestToolSession::run {tool script {allowControl 0} {allowHandoff 1}} {
    variable active; variable cancelled; variable pending; variable hidden; variable windows
    set current [owner]
    if {$active ne ""} {
        if {$allowControl && $active eq $tool} {return [uplevel #0 $script]}
        # another button (of this tool or another one) during a pick: the pick ends, then the button runs
        if {$allowHandoff && [handoff [list ::TestToolSession::run $tool $script $allowControl]]} {return}
        if {$allowHandoff} {report $active}
        return
    }
    if {$current ne "" && $current ne $tool} {
        if {!$allowHandoff} {return}
        if {![yield_reservation]} {report $current; return}
    }
    set active $tool
    set code [catch {uplevel #0 $script} value options]
    set active ""
    set cancelled 0
    # the window hidden for a pick comes back when nothing follows (a button pressed during the pick
    # runs next and shows it at its end), unless the tool was closed meanwhile
    if {$hidden ne "" && $pending eq ""} {
        set w $hidden
        set hidden ""
        if {[winfo exists $w] && $w in [dict values $windows]} {wm deiconify $w; raise $w}
    }
    if {$pending ne ""} {
        after idle $pending
        set pending ""
    }
    if {$code} {return -options $options $value}
    return $value
}

# ---------------------------------------------------------------- tool windows
# A tool window, once built and its WM_DELETE_WINDOW close set: the other tool windows are closed, the
# window is owned by HyperMesh, Escape closes it, and native tools close it.
proc ::TestToolSession::attach {tool w} {
    variable windows
    dict for {t x} $windows {if {$t ne $tool} {close_window $t}}
    dict set windows $tool $w
    if {[info script] ne ""} {dict set scripts $tool [file normalize [info script]]}
    own $w
    bind $w <Key-Escape> [list ::TestToolSession::escape $tool $w %W]
    hook
    install_keys
}

# Where a tool window opens, as native HyperMesh dialogs (they are not centred again once moved):
# where the user last left it in this HyperMesh session, when that is still on the monitor of the
# HyperMesh window; else at the top left of the graphics area of that HyperMesh window (12 px in), so
# the middle of the model stays free. Always inside the work area of that monitor.
proc ::TestToolSession::place {tool w} {
    variable places
    if {![info exists places]} {set places [dict create]}
    update idletasks
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set ww [expr {[winfo reqwidth $w] + 2*$border}]
    set wh [expr {[winfo reqheight $w] + $caption + 2*$border}]
    set g [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    catch {
        set gw [::hw::GetGraphicsWindow]
        if {[winfo ismapped $gw] && [winfo width $gw] > 50} {
            set g [list [winfo rootx $gw] [winfo rooty $gw] [winfo width $gw] [winfo height $gw]]
        }
    }
    lassign $g gx gy
    set x [expr {$gx + 12}]
    set y [expr {$gy + 12}]
    if {[dict exists $places $tool]} {
        lassign [dict get $places $tool] px py
        if {![llength $work]} {
            set x $px; set y $py
        } else {
            lassign $work l t r b
            if {$px >= $l && $px + $ww <= $r && $py >= $t && $py + $wh <= $b} {set x $px; set y $py}
        }
    }
    if {[llength $work] == 4} {
        lassign $work l t r b
        set x [expr {max($l, min($x, $r - $ww))}]
        set y [expr {max($t, min($y, $b - $wh))}]
    }
    wm geometry $w +$x+$y
    if {[string first ::TestToolSession::moved [bind $w <Configure>]] < 0} {
        bind $w <Configure> +[list ::TestToolSession::moved $tool $w %W]
    }
}

# The place the user moves a tool window to is kept for the next opening.
proc ::TestToolSession::moved {tool w target} {
    variable places
    if {$target ne $w || ![winfo ismapped $w]} {return}
    if {[regexp {^\d+x\d+\+(-?\d+)\+(-?\d+)$} [wm geometry $w] -> x y]} {dict set places $tool [list $x $y]}
}

# HyperMesh main window as Win32 owner: above HyperMesh only, minimised and restored with it.
proc ::TestToolSession::own {w} {
    if {[catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $w]}] HWND] -8 [expr {[wm frame .]}]
    }]} {catch {wm transient $w .}}
}

# Escape in the tool window: the tool closes (not in a dropdown list, which closes itself).
proc ::TestToolSession::escape {tool w target} {
    if {[winfo toplevel $target] ne $w} {return}
    if {[winfo class $target] in {TCombobox ComboboxPopdown}} {return}
    close_window $tool
}

# The tool's own close (its WM_DELETE_WINDOW), else the window is destroyed; the focus goes back to the
# graphics as after a native dialog.
proc ::TestToolSession::close_window {tool} {
    variable windows
    if {![dict exists $windows $tool]} {return}
    set w [dict get $windows $tool]
    dict unset windows $tool
    if {![winfo exists $w]} {return}
    set cmd [wm protocol $w WM_DELETE_WINDOW]
    if {$cmd eq "" || [catch {uplevel #0 $cmd}]} {catch {destroy $w}}
    if {[winfo exists $w] && [winfo ismapped $w]} {wm withdraw $w}
    catch {::hw::SetFocusToGraphics}
}

proc ::TestToolSession::close_all {} {
    variable windows
    foreach t [dict keys $windows] {close_window $t}
}

# Native signals, connected once per HyperMesh session. Connect returns the connection object: it is
# kept, or the connection ends when the object is freed (as soon as this procedure returns).
proc ::TestToolSession::hook {} {
    variable hooked; variable connections
    if {$hooked} {return}
    if {[catch {
        set h [::hm::signals::SigSlotHandler_S_GetSigSlotHandler]
        set connections [list             [[$h cget -ContextEntered] Connect [list ::MeshForge_session_signal native_context]]             [[$h cget -BeforeDatabaseMajorChange] Connect [list ::MeshForge_session_signal native_model]]]
    }]} {return}
    set hooked 1
}

# The slot of a signal is a global command and a word (as native callbacks: "command word"); a bare
# namespace procedure name was not called by HyperMesh 2022.3.
proc ::MeshForge_session_signal {handler args} {::TestToolSession::$handler {*}$args}

# A native tool entered (the user moved to HyperMesh): the open tool and its pick close.
proc ::TestToolSession::native_context {args} {
    variable windows; variable panelOpen
    if {(![dict size $windows] && !$panelOpen) || [lindex $args 0] in {"" Panel}} {return}
    after idle ::TestToolSession::leave
}

# A new model (or another major database change not made by a tool): the open tool closes.
proc ::TestToolSession::native_model {args} {
    variable windows; variable active; variable panelOpen
    if {(![dict size $windows] && !$panelOpen) || ($active ne "" && !$panelOpen)} {return}
    after idle ::TestToolSession::leave
}

proc ::TestToolSession::leave {} {
    variable panelOpen
    if {$panelOpen && [handoff ::TestToolSession::close_all]} {return}
    close_all
}
