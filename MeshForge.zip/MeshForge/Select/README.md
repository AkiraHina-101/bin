# Select (Advanced Select)

Công cụ hỗ trợ chọn phần tử nâng cao và thao tác nhanh sau khi chọn cho HyperMesh 2022.3, profile Nastran.

- Điểm vào: [select.tcl](select.tcl), thư viện hình học/kết nối/edge sides: [mesh_selection.tcl](mesh_selection.tcl).
- Menu: Utility → **test** → **Advanced Select** (MAC [select.mac](select.mac), sinh bằng `build_cae_menus.py`), hoặc nút **Advanced Select** trong cửa sổ **Toolbox**.
- Mở cửa sổ và thực hiện các phép chọn cơ bản không làm thay đổi mô hình hay lịch sử Undo. Kết quả chọn được lưu vào native user mark (`hm_saveusermark elems 1`) để bấm **Retrieve** trong bất kỳ panel chọn element nào của HyperMesh, đồng thời được tô sáng trên mark 2 (`high`).

## Bố cục giao diện (Trái: Actions · Phải: Các nhóm chọn)

### Cột bên trái: Lưới nút thao tác 2 cột × 4 hàng (không tiêu đề khung)
Các thao tác hậu kỳ trên tập phần tử đã chọn hoặc hiển thị (mỗi thao tác sửa/hiển thị ghi 1 bước Undo):
- Hàng 1: **Mask** (ẩn phần tử đang chọn) | **Reverse** (đảo hiển thị toàn bộ phần tử đang hiện/ẩn trong model).
- Hàng 2: **Unmask all** (hiện toàn bộ phần tử đang ẩn) | **Delete** (xóa phần tử đang chọn và làm trống lựa chọn).
- Hàng 3: **New comp** (tạo `select_comp`, kế thừa property nếu phần tử nguồn cùng 1 comp, gán màu đã chọn và chuyển sang bằng `*movemark`) | **Clear** (bỏ chọn, trả hiển thị tạm của Edge sides).
- Hàng 4: **Color** (áp màu đang chọn cho phần tử/component) | ô chọn màu native `hwtk::colorbutton`.

### Cột bên phải: 4 nhóm chọn xếp theo hàng dọc (tên ngắn gọn, không đánh số)
1. **Region** (chọn phần tử hiển thị có tâm góc nằm trong vùng hình học trên mặt phẳng biên, độ sâu ±0,3R):
   - **By area**: chọn từ 3 node biên trở lên theo thứ tự đa giác (`*createlistpanel`).
   - **Circle**: chọn 3 node không thẳng hàng trên đường tròn.
   - **Annulus**: chọn 3 node trên đường tròn ngoài rồi 3 node trên đường tròn trong (vành khăn).
2. **Expand** (mở rộng vùng chọn):
   - Hàng 1: **Elements...** (chọn phần tử seed) | **By face** + ô góc `deg` (`0–90°`, mở rộng từ seed gốc, tự khôi phục `feature_angle`).
   - Hàng 2: **By adjacent** (mở rộng 1 lớp kề) | **By attached** (mở rộng toàn cụm nối liền).
3. **Edge sides** (gộp từ công cụ Edge Sides):
   - Hàng 1: **Line / band...** (chọn đường 1D `PLOTEL`/`CBAR`/`CROD` kể cả nửa cạnh bậc 2, hoặc dải phần tử 2D) | nhãn thông tin | ô tích **Include band**.
   - Hàng 2: **Side 1** | **Side 2** (hiện kèm số phần tử mỗi phía) | **`+`** / **`-`** (lan/thu từng lớp kề, tự hiện phần tử đang mask giống Unmask Adjacent).
4. **Filter**:
   - **Shared faces** (chọn 1 hoặc nhiều component để lấy phần tử 2D/3D có mặt chung) | **By config** + combobox (`Tria3`, `Tria6`, `Quad4`, `Quad8`, `Tet4`, `Tet10`).

## Chân cửa sổ và vị trí

- Chân cửa sổ (`foot`) ngăn cách bằng đường kẻ ngang `1 px` màu `#AFBAC2`, dưới cùng là thanh **status** luôn cố định ở đáy cửa sổ.
- Cửa sổ mở ở chính giữa khung Win32 của HyperMesh trên màn hình hiện tại (giữ tọa độ âm nếu ở màn hình phụ bên trái/trên) và luôn nổi trên cửa sổ HyperMesh (`keep_above_host`).

## Kiểm chứng (22/11/2026, HyperMesh 2022.3, scratch riêng qua `run_probe.py`)

- **Bộ kiểm chức năng & giao diện**: [tests/probe_select.tcl](tests/probe_select.tcl), run `6df4d843d2274ccebc3f9d3634d47150`: **38/38 PASS**, ảnh chụp cửa sổ [window_1.png](tests/runs/6df4d843d2274ccebc3f9d3634d47150/window_1.png) đã xem.
- **Mô phỏng luồng thao tác người dùng trên lưới thật `test3.bdf` (706 phần tử tria6)**: [tests/probe_user_workflow.tcl](tests/probe_user_workflow.tcl), run `efbd17774496488bb2b49db6a346ed08`: **21/21 PASS** (`Expand` seed → adjacent → attached; lọc `By config` trực tiếp tại chỗ không mở lại panel; `Circle` trên node lưới thật; `Edge sides` trên dải 2D có `+` / `-` / `Include band`; `Reverse` tự cô lập vùng chọn khi chưa có gì bị ẩn rồi bấm lại để đảo hiển thị; `Unmask all`, `Mask`, `New comp` + Undo, `Color`, `Delete` + Undo).
- **Nâng cấp nóng trong cùng phiên (`legacy.button_cleaned`)**: tự động gỡ thủ tục `::MeshForge::Select::button` cũ nếu còn trong bộ nhớ và dùng `::button` chuẩn của Tk để không bao giờ bị lỗi `wrong # args: should be "button path label mode"`.
- **By region**: `polygon`, `circle`, `annulus`, từ chối 3 node thẳng hàng và vòng tròn trong nằm ngoài vòng ngoài.
- **By component & config**: `shared_elements` với cặp component, 1 component kiểm tất cả đối tác, 3 component (không sinh phần tử tạm); lọc `by_config` với `Tria3`, `Tria6`, `Tet4`, `Tet10`.
- **Expand selection**: `adjacent` (1 lớp), `attached` (toàn cụm), `By face` qua GUI với góc rộng (`70°`) và góc hẹp (`15°`) tính lại từ seed gốc, khôi phục `feature_angle` của host và không làm thay đổi lịch sử Undo.
- **By edge sides**: tách lưới shell hai bên đường PLOTEL (`edge.split_sides`), chọn `Side 1` / `Side 2` qua GUI cập nhật user mark và highlight.
- **Actions on selection & display**:
  - `Mask` ẩn đúng phần tử đang chọn (`Side 2`).
  - `Reverse` đảo hiển thị toàn bộ phần tử (chỉ hiện `Side 2`, ẩn phần còn lại).
  - `Unmask all` hiện lại toàn bộ phần tử trong mô hình.
  - `Move to new comp` tạo `select_comp`, kế thừa property `PS_STRIP` của component nguồn, chuyển phần tử sang bằng `*movemark` và 1 bước Undo khôi phục về component `Strip`.
  - `Apply color` đổi màu phần tử/component thông qua `hwtk::colorbutton`.
  - `Delete` xóa đúng các phần tử đang chọn và 1 bước Undo khôi phục đủ số lượng phần tử.
- **Bố cục chân cửa sổ**: xác nhận `$w.foot.line` (`1 px` `#AFBAC2`) và `$w.foot.status` nằm cuối cùng ở đáy cửa sổ.
- Chưa kiểm: thao tác chuột trực tiếp và chưa nạp vào phiên người dùng.
