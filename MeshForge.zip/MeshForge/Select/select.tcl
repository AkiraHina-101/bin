# Advanced Select for HyperMesh 2022.3 / Nastran.
# Unified selection assistant:
#   1. Region: By area (polygon), Circle (3 nodes), Annulus (6 nodes)
#   2. Expand: Pick elements... (seed), By face (angle from seed), By adjacent, By attached
#   3. Edge sides: Pick line/band..., Side 1 / Side 2, + / - layers, Include band
#   4. Filter: Shared faces... (by components), By config... (Tria3, Tria6, Quad4, Quad8, Tet4, Tet10)
#   5. Actions on selection / display: Mask, Reverse, Unmask all, Delete, Move to new comp, Color
# Results are saved to the native element user mark (Retrieve) and highlighted on mark 2.
if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::MeshForge_Select_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}
source [file join [file dirname [file normalize [info script]]] mesh_selection.tcl]

namespace eval ::MeshForge::Select {
    # Remove any legacy ::MeshForge::Select::button procedure so Tk's global ::button is never shadowed.
    if {[llength [info commands ::MeshForge::Select::button]]} {rename ::MeshForge::Select::button ""}
    variable W .advancedSelect
    variable label "Select"
    variable seed {}
    variable result {}
    variable model {}
    variable angle 30
    variable config Tria3
    variable status "Pick a selection method."
    variable edgeLine {}
    variable edgeSides {}
    variable edgeChosen ""
    variable edgeLayers 0
    variable edgeBlocked {}
    variable edgeBand {}
    variable edgeHist {}
    variable edgeRevealed {}
    variable edgeInclude 0
    variable edgeInfo "none"
    variable tkColor 4
}

proc ::MeshForge::Select::history_begin {note} {
    catch {hm_private_frwk enablehistoryfromtcl 1}
    catch {*startnotehistorystate $note}
}
proc ::MeshForge::Select::history_end {note} {
    catch {*endnotehistorystate $note}
    catch {hm_private_frwk enablehistoryfromtcl 0}
}

proc ::MeshForge::Select::pick_mark {entity text} {
    variable W
    if {[winfo exists $W]} {wm withdraw $W}
    *clearmark $entity 1
    set code [catch {::TestToolSession::panel *createmarkpanel $entity 1 $text} message options]
    set ids [hm_getmark $entity 1]
    *clearmark $entity 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {$code && $message ne "0"} {return -options $options $message}
    return $ids
}

proc ::MeshForge::Select::pick_boundary {text} {
    variable W
    if {[winfo exists $W]} {wm withdraw $W}
    *clearlist nodes 1
    set code [catch {::TestToolSession::panel *createlistpanel nodes 1 $text} message options]
    set ids [hm_getlist nodes 1]
    *clearlist nodes 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {$code && $message ne "0"} {return -options $options $message}
    return $ids
}

proc ::MeshForge::Select::clear_highlight {} {
    variable result; variable edgeSides; variable edgeLine
    set all [lsort -integer -unique [concat $result {*}$edgeSides $edgeLine]]
    foreach m {1 2} {
        if {[llength $all]} {catch {*createmark elems $m "by id only" {*}$all; hm_highlightmark elems $m norm}}
        catch {hm_highlightmark elems $m norm}
        *clearmark elems $m
    }
    catch {hm_redraw}
}

proc ::MeshForge::Select::show_highlights {{lowIds {}}} {
    variable result
    set result [existing $result]
    set lowIds [existing $lowIds]
    foreach m {1 2} {
        catch {hm_highlightmark elems $m norm}
        *clearmark elems $m
    }
    if {[llength $result]} {
        *createmark elems 2 "by id only" {*}$result
        catch {hm_highlightmark elems 2 high}
    }
    if {[llength $lowIds]} {
        *createmark elems 1 "by id only" {*}$lowIds
        catch {hm_highlightmark elems 1 low}
    }
    catch {hm_redraw}
}

proc ::MeshForge::Select::publish {ids {lowIds {}} {customStatus ""}} {
    variable result; variable status; variable model
    set model [hm_getcurrentmodel]
    clear_highlight
    set result [lsort -integer -unique [existing $ids]]
    *clearmark elems 1
    if {[llength $result]} {*createmark elems 1 "by id only" {*}$result}
    hm_saveusermark elems 1
    *clearmark elems 1
    show_highlights $lowIds
    if {$customStatus ne ""} {
        set status $customStatus
    } else {
        set status "[llength $result] elements selected. Use Retrieve in an element selector."
    }
    refresh_ui
}

proc ::MeshForge::Select::clear_edge_state {{restoreDisplay 0}} {
    variable edgeLine; variable edgeSides; variable edgeChosen; variable edgeLayers
    variable edgeBlocked; variable edgeBand; variable edgeHist; variable edgeRevealed; variable edgeInfo
    if {$restoreDisplay} {edge_restore_display}
    set edgeLine {}; set edgeSides {}; set edgeChosen ""; set edgeLayers 0
    set edgeBlocked {}; set edgeBand {}; set edgeHist {}; set edgeRevealed {}
    set edgeInfo "none"
}

# ---------------------------------------------------------------- Edge sides controller
proc ::MeshForge::Select::edge_reveal {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 displayed
    set d [dict create]; foreach e [hm_getmark elems 1] {dict set d $e 1}
    *clearmark elems 1
    set hidden {}; foreach e $ids {if {![dict exists $d $e]} {lappend hidden $e}}
    if {![llength $hidden]} {return {}}
    history_begin "Advanced select show"
    catch {*createmark elems 1 "by id only" {*}$hidden; *unmaskentitymark elems 1 0; *clearmark elems 1}
    history_end "Advanced select show"
    return $hidden
}

proc ::MeshForge::Select::edge_hide {ids} {
    set ids [existing $ids]
    if {![llength $ids]} {return}
    history_begin "Advanced select hide"
    catch {*createmark elems 1 "by id only" {*}$ids; *maskentitymark elems 1 0; *clearmark elems 1}
    history_end "Advanced select hide"
}

proc ::MeshForge::Select::edge_restore_display {} {
    variable edgeRevealed; variable edgeHist
    set back $edgeRevealed
    foreach h $edgeHist {lappend back {*}[lindex $h 2]}
    if {[llength $back]} {edge_hide [lsort -unique -integer $back]}
    set edgeRevealed {}; set edgeHist {}
}

proc ::MeshForge::Select::edge_chosen_ids {} {
    variable edgeSides; variable edgeChosen; variable edgeBand; variable edgeInclude
    if {$edgeChosen eq "" || $edgeChosen >= [llength $edgeSides]} {return {}}
    set ids [lindex $edgeSides $edgeChosen]
    if {$edgeInclude && [llength $edgeBand]} {
        set ids [lsort -unique -integer [concat $ids $edgeBand]]
    }
    return $ids
}

proc ::MeshForge::Select::use_edge_pick {ids} {
    variable edgeLine; variable edgeSides; variable edgeChosen; variable edgeLayers
    variable edgeBlocked; variable edgeBand; variable edgeHist; variable edgeRevealed
    variable edgeInfo; variable seed; variable status
    clear_highlight
    clear_edge_state 1
    set r [split_any $ids]
    set edgeSides [dict get $r sides]
    set edgeBand [dict get $r band]
    set edgeBlocked $edgeBand
    set edgeLayers 1
    set edgeRevealed [edge_reveal [concat {*}$edgeSides]]
    set edgeLine [dict get $r line]
    set what [expr {[llength $edgeBand] ? "band" : "line"}]
    set edgeInfo "[llength $edgeLine] $what ([expr {[dict get $r closed] ? "closed" : "open"}])"
    set msg ""
    if {[llength $edgeSides] == 1} {
        set msg "Only one side found (free edge)."
    } elseif {[llength $edgeSides] > 2} {
        set msg "[llength $edgeSides] groups found."
    }
    if {[dict get $r missing]} {append msg [string trimleft " [dict get $r missing] line elements not on shell edges."]}
    if {[dict get $r left]} {append msg [string trimleft " [dict get $r left] elements touch both sides."]}
    if {[llength $edgeRevealed]} {append msg [string trimleft " [llength $edgeRevealed] masked elements shown."]}
    set edgeChosen 0
    set chosenIds [edge_chosen_ids]
    set seed $chosenIds
    set other [expr {[llength $edgeSides] > 1 ? [lindex $edgeSides 1] : $edgeLine}]
    set baseMsg "Side 1: [llength $chosenIds] elements selected."
    if {$msg ne ""} {append baseMsg " $msg"}
    publish $chosenIds $other $baseMsg
}

proc ::MeshForge::Select::choose_side {index} {
    variable edgeSides; variable edgeChosen; variable edgeLine; variable edgeInclude; variable seed
    if {$index < 0 || $index >= [llength $edgeSides]} {return}
    set edgeChosen $index
    set ids [existing [edge_chosen_ids]]
    set seed $ids
    set low [expr {$edgeInclude ? {} : $edgeLine}]
    publish $ids $low "Side [expr {$index+1}]: [llength $ids] elements selected (Retrieve in any selector)."
}

proc ::MeshForge::Select::grow_edge_layer {} {
    variable edgeSides; variable edgeChosen; variable edgeLayers; variable edgeBlocked; variable edgeHist
    if {![llength $edgeSides]} {return}
    set old [dict create]; foreach e [concat {*}$edgeSides] {dict set old $e 1}
    set prev [list $edgeSides $edgeBlocked]
    lassign [grow_sides $edgeSides $edgeBlocked] edgeSides added contested edgeBlocked
    set new {}; foreach e [concat {*}$edgeSides] {if {![dict exists $old $e]} {lappend new $e}}
    set shown [edge_reveal $new]
    lappend edgeHist [concat $prev [list $shown]]
    incr edgeLayers
    set msg "Layer $edgeLayers: +[join $added { / +}] elements."
    if {[llength $shown]} {append msg " [llength $shown] shown."}
    if {$contested} {append msg " $contested border elements left out."}
    if {$edgeChosen eq ""} {set edgeChosen 0}
    set ids [existing [edge_chosen_ids]]
    set ::MeshForge::Select::seed $ids
    publish $ids [expr {$::MeshForge::Select::edgeInclude ? {} : $::MeshForge::Select::edgeLine}] $msg
}

proc ::MeshForge::Select::shrink_edge_layer {} {
    variable edgeSides; variable edgeChosen; variable edgeLayers; variable edgeBlocked; variable edgeHist
    if {![llength $edgeHist]} {return}
    clear_highlight
    lassign [lindex $edgeHist end] edgeSides edgeBlocked shown
    set edgeHist [lrange $edgeHist 0 end-1]
    edge_hide $shown
    incr edgeLayers -1
    set msg "Layer $edgeLayers."
    if {[llength $shown]} {append msg " [llength $shown] masked again."}
    if {$edgeChosen eq ""} {set edgeChosen 0}
    set ids [existing [edge_chosen_ids]]
    set ::MeshForge::Select::seed $ids
    publish $ids [expr {$::MeshForge::Select::edgeInclude ? {} : $::MeshForge::Select::edgeLine}] $msg
}

proc ::MeshForge::Select::toggle_include_band {} {
    variable edgeChosen; variable edgeSides
    if {![llength $edgeSides]} {return}
    if {$edgeChosen eq ""} {set edgeChosen 0}
    choose_side $edgeChosen
}

# ---------------------------------------------------------------- Selection modes
proc ::MeshForge::Select::select {mode} {
    variable seed; variable result; variable model; variable angle; variable config
    if {$model ne [hm_getcurrentmodel]} {
        set seed {}; set result {}; set model [hm_getcurrentmodel]
        clear_edge_state 0
    }
    set result [existing $result]
    set seed [existing $seed]
    switch -- $mode {
        polygon - circle - annulus {
            set prompt [dict get {
                polygon "Pick polygon corners in order."
                circle "Pick three nodes on the circle."
                annulus "Pick three nodes on the outer circle, then three on the inner circle."
            } $mode]
            set nodes [pick_boundary $prompt]
            if {![llength $nodes]} {return}
            clear_edge_state 0
            set ids [by_region $mode $nodes]
        }
        shared {
            set comps [pick_mark comps "Pick components. One component checks all its interfaces."]
            if {![llength $comps]} {return}
            clear_edge_state 0
            set ids [shared_elements $comps]
        }
        elements {
            set ids [pick_mark elems "Select elements. Use the native area selector to sweep a region."]
            if {![llength $ids]} {return}
            clear_edge_state 0
        }
        config {
            if {[llength $result]} {
                set base $result
                set filtered [by_config $base $config]
                clear_edge_state 0
                set seed $filtered
                publish $filtered {} "Filtered [llength $base] -> [llength $filtered] $config elements."
                return
            }
            set ids [pick_mark elems "Select elements to filter by $config."]
            if {![llength $ids]} {return}
            clear_edge_state 0
            set filtered [by_config $ids $config]
            set seed $filtered
            publish $filtered {} "Filtered [llength $ids] -> [llength $filtered] $config elements."
            return
        }
        edge_pick {
            set ids [pick_mark elems "Edge sides: select PLOTELs (1 edge, line, loop) or a band of 2D elements."]
            if {![llength $ids]} {return}
            use_edge_pick $ids
            return
        }
        side1 {choose_side 0; return}
        side2 {choose_side 1; return}
        edge_plus {grow_edge_layer; return}
        edge_minus {shrink_edge_layer; return}
        face - adjacent - attached {
            if {![llength $seed]} {
                set seed [pick_mark elems "Select seed elements."]
                if {![llength $seed]} {return}
                set base $seed
            } elseif {$mode eq "face"} {
                set base $seed
            } else {
                set base [expr {[llength $result] ? $result : $seed}]
            }
            clear_edge_state 0
            publish [expand $mode $base [string trim $angle]]
            return
        }
        clear {
            clear_edge_state 1
            set seed {}
            publish {} {} "Selection cleared."
            return
        }
        default {error "Unknown selection method."}
    }
    set seed $ids
    publish $ids
}

# ---------------------------------------------------------------- Post-selection actions
proc ::MeshForge::Select::mask_selected {} {
    variable result; variable status
    set ids [existing $result]
    if {![llength $ids]} {error "No elements selected to mask."}
    clear_highlight
    history_begin "Advanced select mask"
    set rc [catch {
        *createmark elems 1 "by id only" {*}$ids
        *maskentitymark elems 1 0
        *clearmark elems 1
    } err opts]
    history_end "Advanced select mask"
    if {$rc} {return -options $opts $err}
    catch {hm_redraw}
    set status "Masked [llength $ids] selected elements."
    refresh_ui
}

proc ::MeshForge::Select::reverse_display {} {
    variable result; variable status
    set all [marked elems 1 all]
    if {![llength $all]} {error "No elements in the model."}
    set shown [marked elems 1 displayed]
    set shownSet [dict create]; foreach e $shown {dict set shownSet $e 1}
    set hidden {}; foreach e $all {if {![dict exists $shownSet $e]} {lappend hidden $e}}
    set sel [existing $result]
    # If nothing is hidden yet and user has an active selection, Reverse isolates the selection
    # (equivalent to masking everything else), otherwise it swaps shown <-> hidden like native Reverse.
    if {![llength $hidden] && [llength $sel]} {
        set selSet [dict create]; foreach e $sel {dict set selSet $e 1}
        set toMask {}; foreach e $shown {if {![dict exists $selSet $e]} {lappend toMask $e}}
        if {![llength $toMask]} {
            set status "All elements are already selected."
            return
        }
        clear_highlight
        history_begin "Advanced select reverse"
        set rc [catch {
            *createmark elems 1 "by id only" {*}$toMask
            *maskentitymark elems 1 0
            *clearmark elems 1
        } err opts]
        history_end "Advanced select reverse"
        if {$rc} {return -options $opts $err}
        show_highlights
        set status "Isolated [llength $sel] selected elements ([llength $toMask] masked)."
        refresh_ui
        return
    }
    clear_highlight
    history_begin "Advanced select reverse"
    set rc [catch {
        if {[llength $hidden]} {
            *createmark elems 1 "by id only" {*}$hidden
            *unmaskentitymark elems 1 0
            *clearmark elems 1
        }
        if {[llength $shown]} {
            *createmark elems 1 "by id only" {*}$shown
            *maskentitymark elems 1 0
            *clearmark elems 1
        }
    } err opts]
    history_end "Advanced select reverse"
    if {$rc} {return -options $opts $err}
    show_highlights
    set status "Reversed display ([llength $hidden] shown, [llength $shown] masked)."
    refresh_ui
}

proc ::MeshForge::Select::unmask_all {} {
    variable status
    set all [marked elems 1 all]
    if {![llength $all]} {error "No elements in the model."}
    set shown [marked elems 1 displayed]
    set shownSet [dict create]; foreach e $shown {dict set shownSet $e 1}
    set hidden {}; foreach e $all {if {![dict exists $shownSet $e]} {lappend hidden $e}}
    if {![llength $hidden]} {
        set status "All elements are already displayed."
        return
    }
    history_begin "Advanced select unmask all"
    set rc [catch {
        *createmark elems 1 "by id only" {*}$hidden
        *unmaskentitymark elems 1 0
        *clearmark elems 1
    } err opts]
    history_end "Advanced select unmask all"
    if {$rc} {return -options $opts $err}
    show_highlights
    set status "Unmasked all elements ([llength $hidden] shown)."
    refresh_ui
}

proc ::MeshForge::Select::delete_selected {} {
    variable result; variable seed; variable status
    set ids [existing $result]
    if {![llength $ids]} {error "No elements selected to delete."}
    clear_highlight
    clear_edge_state 0
    history_begin "Advanced select delete"
    set rc [catch {
        *createmark elems 1 "by id only" {*}$ids
        *deletemark elems 1
        *clearmark elems 1
    } err opts]
    history_end "Advanced select delete"
    if {$rc} {return -options $opts $err}
    set result {}; set seed {}
    *clearmark elems 1
    hm_saveusermark elems 1
    catch {hm_redraw}
    set status "Deleted [llength $ids] elements."
    refresh_ui
}

proc ::MeshForge::Select::new_comp_name {} {
    set n select_comp; set i 0
    while {[hm_entityinfo exist comps $n -byname]} {incr i; set n select_comp_$i}
    return $n
}

proc ::MeshForge::Select::move_to_new_comp {{color ""}} {
    variable result; variable status
    set ids [existing $result]
    if {![llength $ids]} {error "No elements selected to move."}
    if {$color eq ""} {set color [chosen_color]}
    set cur [hm_info currentcomponent]
    set comp [new_comp_name]
    set srcComps [lsort -unique [hm_getvalue elems user_ids=$ids dataname=collector.id]]
    clear_highlight
    history_begin "Advanced select move"
    set rc [catch {
        *createentity comps name=$comp
        if {$color ne "" && [string is integer -strict $color]} {
            *createmark comps 1 "by name only" $comp
            catch {*colormark comps 1 $color}
            *clearmark comps 1
        }
        if {[llength $srcComps] == 1} {
            set pname ""
            catch {set pname [hm_getvalue comps id=[lindex $srcComps 0] dataname=property.name]}
            if {$pname ne "" && $pname ne "0"} {
                *createmark comps 1 "by name only" $comp
                catch {*propertyupdate comps 1 $pname}
                *clearmark comps 1
            }
        }
        for {set i 0} {$i < [llength $ids]} {incr i 4096} {
            set chunk [lrange $ids $i [expr {$i+4095}]]
            *createmark elems 1 "by id only" {*}$chunk
            *movemark elems 1 $comp
            *clearmark elems 1
        }
        if {$cur ne "" && [hm_entityinfo exist comps $cur -byname]} {
            *currentcollector components $cur
        }
    } err opts]
    history_end "Advanced select move"
    if {$rc} {return -options $opts $err}
    publish $ids {} "Moved [llength $ids] elements to $comp."
    return $comp
}

proc ::MeshForge::Select::set_color {color} {
    variable W; variable tkColor
    set tkColor $color
    if {[winfo exists $W.body.act.color]} {
        if {[winfo class $W.body.act.color] ne "Button"} {
            catch {$W.body.act.color configure -color $color}
        } else {
            catch {
                set rgb [lrange [lindex [hm_winfo entitycolors] [expr {$color - 1}]] 0 2]
                $W.body.act.color configure -background [format "#%02x%02x%02x" {*}$rgb]
            }
        }
    }
}

proc ::MeshForge::Select::chosen_color {} {
    variable W; variable tkColor
    if {[winfo exists $W.body.act.color] && [winfo class $W.body.act.color] ne "Button"} {
        if {![catch {$W.body.act.color color} c] && $c ne ""} {return $c}
        if {![catch {$W.body.act.color cget -color} c] && $c ne ""} {return $c}
    }
    return $tkColor
}

proc ::MeshForge::Select::pick_color_tk {} {
    variable tkColor; variable W
    set hex [tk_chooseColor -parent $W]
    if {$hex eq ""} {return}
    scan $hex "#%2x%2x%2x" r g b
    set bestRGB {}; set bestD 1e30; set i 0
    foreach rgb [hm_winfo entitycolors] {
        incr i
        if {[llength $rgb] < 3} {continue}
        set d 0.0
        foreach a [lrange $rgb 0 2] c [list $r $g $b] {set d [expr {$d+($a-$c)*($a-$c)}]}
        if {$d < $bestD} {set bestD $d; set best $i; set bestRGB [lrange $rgb 0 2]}
    }
    if {![llength $bestRGB]} {return}
    set tkColor $best
    if {[winfo exists $W.body.act.color] && [winfo class $W.body.act.color] eq "Button"} {
        $W.body.act.color configure -background [format "#%02x%02x%02x" {*}$bestRGB]
    }
}

proc ::MeshForge::Select::color_selected {{color ""}} {
    variable result; variable status
    set ids [existing $result]
    if {![llength $ids]} {error "No elements selected to color."}
    if {$color eq ""} {set color [chosen_color]}
    set comps [lsort -unique -integer [hm_getvalue elems user_ids=$ids dataname=collector.id]]
    clear_highlight
    history_begin "Advanced select color"
    set rc [catch {
        *createmark elems 1 "by id only" {*}$ids
        catch {*colormark elems 1 $color}
        *clearmark elems 1
        if {[llength $comps]} {
            *createmark comps 1 "by id only" {*}$comps
            *colormark comps 1 $color
            *clearmark comps 1
        }
    } err opts]
    history_end "Advanced select color"
    if {$rc} {return -options $opts $err}
    publish $ids {} "Colored [llength $ids] elements ([llength $comps] component[expr {[llength $comps] == 1 ? "" : "s"}])."
}

proc ::MeshForge::Select::action {cmd args} {
    variable status
    if {[catch {$cmd {*}$args} message]} {
        set status $message
        refresh_ui
    }
}

proc ::MeshForge::Select::run_btn {path label cmd {width 0}} {
    set opts [list -text $label -command [list ::TestToolSession::run "Select" [concat [list ::MeshForge::Select::action] $cmd]]]
    if {$width > 0} {lappend opts -width $width}
    ::button $path {*}$opts
}

proc ::MeshForge::Select::refresh_ui {} {
    variable W; variable result; variable edgeSides; variable edgeChosen; variable edgeLayers; variable edgeBand; variable edgeHist
    if {![winfo exists $W]} {return}
    set result [existing $result]
    set hasSel [expr {[llength $result] > 0}]
    set e $W.body.sel.edge
    if {[winfo exists $e]} {
        set s1 [expr {[llength $edgeSides] >= 1 ? [llength [existing [lindex $edgeSides 0]]] : 0}]
        set s2 [expr {[llength $edgeSides] >= 2 ? [llength [existing [lindex $edgeSides 1]]] : 0}]
        $e.s1 configure -text [expr {$s1 ? "Side 1 ($s1)" : "Side 1"}] -state [expr {$s1 ? "normal" : "disabled"}]
        $e.s2 configure -text [expr {$s2 ? "Side 2 ($s2)" : "Side 2"}] -state [expr {$s2 ? "normal" : "disabled"}]
        $e.plus configure -state [expr {[llength $edgeSides] ? "normal" : "disabled"}]
        $e.minus configure -state [expr {[llength $edgeHist] ? "normal" : "disabled"}]
        $e.layers configure -text [expr {$edgeLayers ? "L$edgeLayers" : ""}]
        $e.inc configure -state [expr {[llength $edgeBand] ? "normal" : "disabled"}]
    }
    set a $W.body.act
    if {[winfo exists $a]} {
        foreach btn {mask delete move applyColor} {
            if {[winfo exists $a.$btn]} {
                $a.$btn configure -state [expr {$hasSel ? "normal" : "disabled"}]
            }
        }
    }
}

proc ::MeshForge::Select::close {} {
    variable W; variable seed; variable result; variable model
    clear_highlight
    clear_edge_state 0
    set seed {}; set result {}; set model {}
    destroy $W
}

proc ::MeshForge::Select::place_center {} {
    variable W
    update idletasks
    $W.foot.status configure -wraplength [expr {max(260,[winfo reqwidth $W.body]-24)}]
    update idletasks
    set host [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $frame] l t r b
        set host [list $l $t [expr {$r - $l}] [expr {$b - $t}]]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set w [expr {[winfo reqwidth $W] + 2*$border}]
    set h [expr {[winfo reqheight $W] + $caption + 2*$border}]
    lassign [fit_box $host $work $w $h] x y
    wm geometry $W +$x+$y
}

proc ::MeshForge::Select::fit_box {host work w h} {
    lassign $host hx hy hw hh
    set x [expr {$hx + ($hw - $w) / 2}]
    set y [expr {$hy + ($hh - $h) / 2}]
    if {[llength $work] == 4} {
        lassign $work left top right bottom
        set x [expr {max($left, min($x, $right - $w))}]
        set y [expr {max($top, min($y, $bottom - $h))}]
    }
    list $x $y
}


proc ::MeshForge::Select::show {} {
    variable W; variable tkColor
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Select"
    wm resizable $W 0 0
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Select" ::MeshForge::Select::close]

    set b [frame $W.body -padx 12 -pady 10]
    pack $b -fill both -expand 1

    # Left pane: 2xN grid of actions (no group frame title)
    set a [frame $b.act]
    run_btn $a.mask "Mask" {mask_selected} 9
    run_btn $a.reverse "Reverse" {reverse_display} 9
    run_btn $a.unmaskAll "Unmask all" {unmask_all} 9
    run_btn $a.delete "Delete" {delete_selected} 9
    run_btn $a.move "New comp" {move_to_new_comp} 9
    run_btn $a.clear "Clear" {select clear} 9
    run_btn $a.applyColor "Color" {color_selected} 9
    if {[catch {hwtk::colorbutton $a.color -startindex 1 -color $tkColor}]} {
        set rgb {220 40 40}
        catch {set rgb [lrange [lindex [hm_winfo entitycolors] [expr {$tkColor - 1}]] 0 2]}
        ::button $a.color -text "Pick..." -width 8 \
            -command [list ::TestToolSession::run "Select" ::MeshForge::Select::pick_color_tk] \
            -background [format "#%02x%02x%02x" {*}$rgb]
    }
    grid $a.mask      $a.reverse   -row 0 -sticky ew -padx 2 -pady 2
    grid $a.unmaskAll $a.delete    -row 1 -sticky ew -padx 2 -pady 2
    grid $a.move      $a.clear     -row 2 -sticky ew -padx 2 -pady 2
    grid $a.applyColor $a.color    -row 3 -sticky ew -padx 2 -pady 2
    grid columnconfigure $a {0 1} -weight 1 -uniform act

    # Vertical 1px separator between left actions and right selection groups
    frame $b.vline -width 1 -background #AFBAC2

    # Right pane: stacked selection groups (no numbers, concise HyperMesh labels)
    set sel [frame $b.sel]

    # Region
    set r [labelframe $sel.region -text "Region" -padx 8 -pady 6]
    grid [run_btn $r.polygon "By area" {select polygon}] \
         [run_btn $r.circle "Circle" {select circle}] \
         [run_btn $r.ring "Annulus" {select annulus}] -sticky ew -padx 2
    grid columnconfigure $r {0 1 2} -weight 1 -uniform reg
    grid $r -row 0 -column 0 -sticky ew

    # Expand
    set e [labelframe $sel.expand -text "Expand" -padx 8 -pady 6]
    run_btn $e.seed "Elements..." {select elements} 10
    run_btn $e.face "By face" {select face} 10
    set fdeg [frame $e.fdeg]
    entry $fdeg.angle -textvariable ::MeshForge::Select::angle -width 5 -justify right
    bind $fdeg.angle <Return> [list ::TestToolSession::run "Select" {::MeshForge::Select::action select face}]
    label $fdeg.degrees -text "deg" -anchor w
    pack $fdeg.angle -side left
    pack $fdeg.degrees -side left -padx {4 0}
    grid $e.seed $e.face $fdeg -row 0 -sticky ew -padx 2 -pady {0 4}
    run_btn $e.adjacent "By adjacent" {select adjacent} 10
    run_btn $e.attached "By attached" {select attached} 10
    grid $e.adjacent $e.attached -row 1 -sticky ew -padx 2
    grid columnconfigure $e {0 1} -weight 1 -uniform exp
    grid $e -row 1 -column 0 -sticky ew -pady {6 0}

    # Edge sides
    set s [labelframe $sel.edge -text "Edge sides" -padx 8 -pady 6]
    run_btn $s.pick "Line / band..." {select edge_pick} 11
    label $s.info -textvariable ::MeshForge::Select::edgeInfo -anchor w -width 16
    checkbutton $s.inc -text "Include band" -variable ::MeshForge::Select::edgeInclude \
        -command [list ::TestToolSession::run "Select" {::MeshForge::Select::action toggle_include_band}] -anchor w
    grid $s.pick -row 0 -column 0 -columnspan 2 -sticky ew -padx 2 -pady {0 4}
    grid $s.info -row 0 -column 2 -columnspan 2 -sticky w -padx {6 2} -pady {0 4}
    grid $s.inc  -row 0 -column 4 -sticky e -padx 2 -pady {0 4}
    run_btn $s.s1 "Side 1" {select side1} 9
    run_btn $s.s2 "Side 2" {select side2} 9
    run_btn $s.plus "+" {select edge_plus} 3
    run_btn $s.minus "-" {select edge_minus} 3
    label $s.layers -text "" -anchor e -width 3
    grid $s.s1 -row 1 -column 0 -sticky ew -padx 2
    grid $s.s2 -row 1 -column 1 -sticky ew -padx 2
    grid $s.plus -row 1 -column 2 -sticky w -padx {6 2}
    grid $s.minus -row 1 -column 3 -sticky w -padx 2
    grid $s.layers -row 1 -column 4 -sticky e -padx 2
    grid columnconfigure $s {0 1} -weight 1
    grid $s -row 2 -column 0 -sticky ew -pady {6 0}

    # Filter
    set f [labelframe $sel.filter -text "Filter" -padx 8 -pady 6]
    run_btn $f.shared "Shared faces" {select shared} 11
    run_btn $f.apply "By config" {select config} 10
    ttk::combobox $f.config -textvariable ::MeshForge::Select::config \
        -values {Tria3 Tria6 Quad4 Quad8 Tet4 Tet10} -state readonly -width 7
    bind $f.config <<ComboboxSelected>> {
        if {[llength [::MeshForge::Select::existing $::MeshForge::Select::result]]} {
            ::TestToolSession::run "Select" {::MeshForge::Select::action select config}
        }
    }
    grid $f.shared $f.apply $f.config -sticky ew -padx 2
    grid columnconfigure $f {0 1} -weight 1
    grid $f -row 3 -column 0 -sticky ew -pady {6 0}

    grid columnconfigure $sel 0 -weight 1

    grid $a -row 0 -column 0 -sticky n -padx {0 10}
    grid $b.vline -row 0 -column 1 -sticky ns -padx {0 10}
    grid $sel -row 0 -column 2 -sticky ew
    grid columnconfigure $b 2 -weight 1

    # Footer: 1px horizontal line and status bar always at the bottom
    frame $W.foot -padx 12 -pady 6
    frame $W.foot.line -height 1 -background #AFBAC2
    label $W.foot.status -textvariable ::MeshForge::Select::status -anchor nw -justify left -height 2 -wraplength 420
    pack $W.foot.line -side top -fill x -pady {0 5}
    pack $W.foot.status -side bottom -fill x
    pack $W.foot -fill x

    refresh_ui
    ::TestToolSession::place "Select" $W
    wm deiconify $W
    ::TestToolSession::attach "Select" $W
}

if {![info exists ::MeshForge_Select_no_gui]} {::MeshForge::Select::show}
