# MeshForge cho HyperMesh 2022.3

Bộ tool lưới cho HyperMesh 2022.3, solver profile Nastran. Cập nhật 25/11/2026, chép từ `01_CAE_TOOLS/05-Test`.

| Nút | Folder | Công dụng |
| --- | --- | --- |
| **MeshForge** | `MeshForge/` | Cửa sổ nhỏ, mỗi tool bên dưới là một nút. Không đổi model. |
| **Select** | `Select/` | Chọn element theo vùng, mở rộng, phía của đường PLOTEL, mặt chung hoặc loại, rồi ẩn, xóa, chuyển hay đổi màu. |
| **Mesh edit** | `MeshEdit/` | Replace, Split, Cut element (Perpendicular, Split line) và Create element (tạo tria từ 3 node). |
| **Center node** | `CenterNode/` | Tạo node tại tâm lỗ hoặc tâm viền ngoài của element 2D đã chọn. |
| **Translate** | `Translate/` | Dịch hoặc chép element hay node theo vector node 1 → node 2; có Axes, Distance, Duplicate. |
| **Pattern** | `Pattern/` | Chép các element đã chọn từ một node gốc tới nhiều node đích. |
| **Imprint** | `Imprint/` | Đắp lưới mặt nguồn (ví dụ washer) lên mặt đích để hai mặt chung node. Bản cũ theo luật ghép cạnh: `Imprint/imprint_old.tcl` (không có nút). |
| **Bridge** | `Bridge/` | Lấp viền kín hoặc tạo lưới giữa hai viền; có Find edges để tạo PLOTEL viền. |
| **Shared faces** | `SharedFaces/` | Tạo các mặt chung với màu đang chọn. |
| **Bolt link** | `BoltLink/` | Tạo kết nối RBE2–CBAR–RBE2. |

`EdgeSides/` (tách element hai phía đường PLOTEL) và `TriaFill/` (tạo tria từ 3 node) cũng chạy riêng được, nhưng không có nút trên menu.

## Cài và dùng

1. Chép nguyên thư mục `MeshForge` sang máy dùng, giữ cấu trúc bên trong. Đường dẫn có thể có khoảng trắng nhưng **không nên có chữ có dấu**: `*evaltclscript` (lệnh các nút gọi) từng bị treo với đường dẫn như vậy.
2. Mở **HyperMesh 2022.3** với profile **Nastran**.
3. Tại **Tcl Console**, chạy (thay đường dẫn theo chỗ đã chép):

```tcl
source {D:/CAE Tools/MeshForge/Load_MeshForge.tcl}
```

Trang **TEST** (trang 15) của **Utility** hiện các nút trên. Lệnh nạp thay menu Utility mà phiên đang dùng; muốn trở lại menu cũ, nạp lại MAC cũ. Mỗi phiên HyperMesh mới, hoặc sau khi chuyển thư mục, chạy lại lệnh `source`.

Không cần menu:

- Chỉ mở cửa sổ MeshForge: `source {D:/CAE Tools/MeshForge/MeshForge/meshforge.tcl}`.
- Mở thẳng một tool: `source` tệp `.tcl` của tool đó, ví dụ `Imprint/imprint.tcl`.

## Mỗi tool chạy độc lập

Mỗi folder tool chép riêng ra chỗ khác vẫn chạy được. Những tệp nó cần từ ngoài được chép sẵn vào `<tool>/deps/`, kèm `deps/SOURCES.txt` ghi nguồn và hash. Không sửa tệp trong `deps/`; bản gốc nằm ở `01_CAE_TOOLS/05-Test`.

- `tool_session.tcl` ở gốc là quy tắc chung cho mọi cửa sổ tool.
- `Load_MeshForge.tcl` đọc `MeshForge.mac.in`, kiểm tra đủ tệp mà các nút gọi, thay `@PACKAGE_ROOT@` bằng đường dẫn thật, ghi MAC vào thư mục TEMP rồi nạp vào phiên.

## Ứng xử chung của cửa sổ tool

- **Esc:** trong cửa sổ, Esc đóng tool. Trong panel chọn, Esc chỉ kết thúc lần chọn, rồi cửa sổ hiện lại.
- **Một tool một lúc:** mở tool khác thì tool đang mở đóng lại.
- **Nút trong lúc chọn:** bấm nút trong lúc đang chọn thì lần chọn kết thúc, rồi nút chạy.
- **Lệnh native:** vào một tool native của HyperMesh, hoặc mở model mới, thì tool và panel chọn của nó thoát hẳn.
- **Phím tắt F1–F12** (ví dụ F2 Delete): tool đóng trước, rồi phím mở tính năng HyperMesh tương ứng.
- **Ẩn và nằm trên:** cửa sổ chỉ nằm trên HyperMesh, ẩn trong lúc chọn và hiện lại khi xong.
- **Vị trí:** lần đầu mở ở góc trên trái vùng đồ họa. Các lần sau mở ở chỗ bạn kéo tới lần trước.
- **Còn hạn chế:** mở panel classic bằng menu (không qua phím tắt) thì tool chưa tự thoát.

## Kiểm chứng (25/11/2026)

- Mọi tệp `.tcl` đạt kiểm cú pháp Tcl 8.5. Mọi tệp chép giống từng byte với bản nguồn trong `01_CAE_TOOLS/05-Test`.
- Từng folder tool chép riêng ra thư mục tạm đều nạp được (tclsh 8.5, giả lập lệnh HyperMesh) và không đọc tệp ngoài folder.
- Bài thử `01_CAE_TOOLS/05-Test/MeshForge/tests/probe_dist.tcl`, lần chạy `8a0437783d6b42c2a08dc177195a0ece`, đạt **2/2** trên HyperMesh 2022.3 scratch:
  - `Load_MeshForge.tcl` tạo MAC có 10 nút, mọi nút trỏ tới tệp có thật trong gói.
  - Cửa sổ MeshForge mở từ gói với 9 nút, mỗi nút trỏ tới tệp trong gói.
- **Chưa thử:** máy khác, đường dẫn có khoảng trắng, bấm nút trên trang Utility bằng chuột thật, và các tool từ gói này trong phiên làm việc thật.
- `../toolbox/` và các tệp ZIP cạnh đây (`toolbox.zip`, `RuledMesh.zip`, `elem_imprint_old.zip`, `HyperMesh_Test_Tools_2022.3.zip`) là bản cũ, dùng tên cũ.
