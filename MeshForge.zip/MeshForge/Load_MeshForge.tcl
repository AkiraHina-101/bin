# Source this file from the HyperMesh Tcl Console to load the MeshForge Utility menu (page 15).
namespace eval ::MeshForgeLoader {}

proc ::MeshForgeLoader::load {root} {
    set build [string trim [hm_info -appinfo DISPLAYVERSION]]
    if {![regexp {^2022\.3(\.[0-9]+)*$} $build]} {
        error "MeshForge requires HyperMesh 2022.3 (found $build)."
    }

    set root [file normalize $root]
    set input [open [file join $root MeshForge.mac.in] r]
    fconfigure $input -encoding utf-8
    set template [read $input]
    close $input
    # every Tcl file the menu calls must exist in the package
    foreach {all relative} [regexp -all -inline {"@PACKAGE_ROOT@/([^"]+)"} $template] {
        if {![file isfile [file join $root $relative]]} {
            error "Missing file in the MeshForge package: $relative"
        }
    }

    set temp [pwd]
    foreach name {TEMP TMP} {
        if {[info exists ::env($name)] && [file isdirectory $::env($name)]} {
            set temp $::env($name)
            break
        }
    }
    set macro [file normalize [file join $temp "MeshForge_[pid]_[clock clicks].mac"]]
    set output [open $macro {WRONLY CREAT EXCL}]
    fconfigure $output -encoding utf-8 -translation lf
    set code [catch {
        puts -nonewline $output [string map [list @PACKAGE_ROOT@ $root] $template]
    } message options]
    set closeCode [catch {close $output} closeResult closeOptions]
    if {$code} {return -options $options $message}
    if {$closeCode} {return -options $closeOptions $closeResult}

    *setmacrofile $macro
    puts "MeshForge loaded in Utility, page 15 ($build)."
    return $macro
}

::MeshForgeLoader::load [file dirname [file normalize [info script]]]
