# Center Node

Tạo node tại **tâm lỗ** hoặc **tâm viền ngoài** của các element 2D đã chọn, ví dụ mặt vòng đệm. Tâm do lệnh native `*createbestcirclecenternode` của HyperMesh tính và tạo. HyperMesh 2022.3, profile Nastran.

- Điểm vào: [center_node.tcl](center_node.tcl). Menu: Utility → **test** → **Center node** (MAC [center_node.mac](center_node.mac), sinh bằng bộ sinh menu).
- Bản chuyển máy: `dist/HyperMesh_Test_Tools_2022.3/CenterNode`. Sửa Tcl ở đây thì chép lại bản đó.
- Cửa sổ mở giữa cửa sổ HyperMesh. Chọn và xem trước không đổi model; chỉ **Create** ghi vào model.

## Cách dùng

1. **Elements...**: chọn element 2D (tria3, tria6, quad4, quad8) bằng panel native. Chọn được nhiều mặt cùng lúc; mỗi mặt rời nhau (không chung node) cho một tâm. Dòng bên cạnh báo số element và số mặt.
2. **Center of**: chọn **Hole** (mặc định) hoặc **Outer edge**.
   - Node của viền sẽ dùng hiện màu chọn native; element đã chọn hiện xám.
   - Đổi lựa chọn thì màu đổi ngay, để bạn kiểm tool đã lấy đúng viền chưa.
   - Mặt không có lỗ, hoặc có nhiều lỗ, thì dùng viền ngoài và báo trên dòng trạng thái.
3. **Create**: tạo node tâm, mỗi lần bấm một bước Undo "Center node". Node mới hiện màu chọn. Dòng trạng thái báo số node và độ lệch lớn nhất so với tâm qua 3 node. Tcl console in từng node: tọa độ, bán kính, độ lệch của node viền so với đường tròn, số node viền và độ lệch 3 node.
4. Bấm **Elements...** lần nữa để chọn tiếp. **Reset** bỏ lựa chọn và màu; **Close** đóng cửa sổ.

Node tâm không thuộc element nào nên HyperMesh hiện nó như node tạm (chấm vàng).

## Tool làm gì

- Tìm viền (Tcl, chỉ đọc model):
  - Lấy cạnh tự do của từng mặt, chỉ dùng node góc. Midnode của tria6/quad8 nằm trên dây cung chứ không nằm trên đường tròn, nên bị bỏ.
  - Nối cạnh tự do thành các vòng kín và đo bán kính bằng `hm_getbestcirclecenter`. Vòng lớn nhất là viền ngoài; các vòng còn lại là lỗ.
- Tạo tâm (native): đặt node của viền đã chọn lên mark rồi gọi `*createbestcirclecenternode nodes 1 0 1 0`. HyperMesh fit đường tròn tốt nhất qua mọi node viền, bỏ qua dung sai cleanup, và tạo node tâm.
- Tự kiểm: `hm_getbestcirclecenter` trên 3 node xa nhau nhất của viền (cặp xa nhất, cộng node xa cả hai nhất). Khoảng cách tới tâm native được in ra.

## Kiểm chứng (21/11/2026, HyperMesh 2022.3, scratch riêng của agent qua `run_probe.py`)

**Vòng dựng sẵn** ([probe](tests/probe_center.tcl), run `035bc82a`): **71/71 PASS**.
- Tâm thật là node tạo khi dựng vòng; ở ca nghiêng, node này được xoay cùng vòng.
- Đối chiếu độc lập trong [oracle_circle.tcl](tests/oracle_circle.tcl): fit bình phương tối thiểu tự viết, và tâm qua 3 node do probe tự chọn.

| Ca (Hole và Outer) | Sai số tâm native | Native so với fit tự viết | Sai số tâm 3 node |
|---|---|---|---|
| quad, tria3, tria6, 8 cạnh, nghiêng 35°, hai vòng | ≤ 5e-16 | ≤ 1e-13 | ≤ 3e-13 |
| Viền ngoài méo ±0,05, Hole | 0 | 4e-15 | 4e-16 |
| Viền ngoài méo ±0,05, Outer | 0,0135 | 8e-14 | 0,0135 |

- Mỗi tâm đúng một node mới, không tạo line, point hay element; một Undo trả lại model.
- Mặt không có lỗ thì Hole tự dùng viền ngoài và báo "no hole, outer edge used".
- Chọn element khối hoặc chọn rỗng bị từ chối.
- Kết luận: `*createbestcirclecenternode` chính là fit bình phương tối thiểu qua mọi node viền, trùng với fit tự viết tới 1e-13.

**Model `01_CAE_TOOLS/03-Meshing_tool/models/test3.bdf`** (706 tria6, 12 vòng đệm, chỉ đọc):
- [GUI probe](tests/gui_center.tcl), run `bfde155f`, 5/5 PASS, mở qua đúng điểm vào menu:
  - Hole tô 96 node, tất cả ở bán kính 3,985–4,001 quanh tâm của vòng mình.
  - Outer edge tô 248 node, ở bán kính 8,366–8,501.
  - Create tạo 12 node, trùng fit tự viết của lỗ tới 4e-12; độ lệch 3 node lớn nhất 0,0016; một Undo.
  - Ảnh xem trước Hole / Outer / sau Create (`preview_hole.jpg`, `preview_outer.jpg`, `created.jpg` trong run) và ảnh cửa sổ đã xem.
- [Probe model](tests/probe_test3.tcl), run `e2d9fe18` (bản fit tự viết trước đó): viền ngoài của lưới lệch tâm so với lỗ khoảng 0,05 mm (trung bình), lớn nhất 0,075 mm. Vì vậy Hole là mặc định.

Chưa kiểm: chọn bằng tay trên panel, màu trên màn hình thật của phiên người dùng.

## Vị trí cửa sổ (22/11/2026, ticket `02-window-on-host-monitor`)

- Lỗi cũ: căn giữa theo Tk `.` rồi kẹp `max(x,0)`/`max(y,0)`. Màn hình bên trái hoặc phía trên màn chính có tọa độ âm (máy người dùng: màn trái x từ −2560 đến 0, HyperMesh phóng to ở đó), nên cửa sổ bị đẩy sang mép trái màn chính.
- Nay `place_center` căn khung ngoài của cửa sổ (cộng viền và thanh tiêu đề theo `GetSystemMetrics`) vào giữa khung Win32 của `[wm frame .]` (cửa sổ HyperWorks; Tk `.` chỉ là vùng nội dung bên trong), giữ cửa sổ trong vùng làm việc của màn hình chứa HyperMesh và viết `+$x+$y` để giữ tọa độ âm. Không có twapi thì căn theo vùng nội dung `.`, không giới hạn vùng làm việc.
- Kiểm trên scratch HyperMesh 2022.3 riêng (chỉ thử vị trí, không đổi model): [tests/gui_place.tcl](tests/gui_place.tcl) run `96d51b2a792a47a4964f7559b99d8ddd` **13/13 PASS**. Mở qua `*evaltclscript` như nút MAC trong ba ca: scratch ở màn chính; khung scratch dời sang màn trái tọa độ âm (`SetWindowPos`, không kích hoạt) với hình chữ nhật phóng to như HyperMesh của người dùng; rồi cửa sổ nhỏ trên màn đó. Tâm cửa sổ lệch tâm khung HyperMesh ≤ 0,5 px, cùng màn hình, nằm trong vùng làm việc, khung ngoài thực bằng khung tính trước. Ảnh ghép `overlay.png` trong run đã xem. [tests/place_math.tcl](tests/place_math.tcl) chạy bằng tclsh 8.5.9 của Altair: 11/11 bố cục có tọa độ âm (màn trái, trên, trái-trên, tràn mép, cửa sổ lớn hơn vùng làm việc).
- Chưa kiểm: mở từ menu trong phiên người dùng; hai màn khác DPI (viền tính theo DPI hệ thống).
