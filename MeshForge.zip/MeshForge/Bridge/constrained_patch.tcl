# Triangulate in the fitted shell frame. The original rim segments are hard constraints.
proc ::MeshForge::Bridge::polygon_area2 {polygon} {
    set area 0.0
    set previous [lindex $polygon end]
    foreach point $polygon {
        set area [expr {$area+[signed_area2 {0 0} $previous $point]}]
        set previous $point
    }
    return $area
}

proc ::MeshForge::Bridge::polygon_scan_index {polygon} {
    if {![llength $polygon]} {return {}}
    set ymin Inf
    set ymax -Inf
    foreach point $polygon {
        set y [lindex $point 1]
        set ymin [expr {min($ymin,$y)}]
        set ymax [expr {max($ymax,$y)}]
    }
    if {$ymin == $ymax} {return {}}
    set count [expr {max(1,int(sqrt([llength $polygon])))}]
    set scale [expr {$count/($ymax-$ymin)}]
    set bins {}
    set previous [lindex $polygon end]
    foreach point $polygon {
        lassign $previous ax ay
        lassign $point bx by
        set previous $point
        if {$ay == $by} {continue}
        set low [expr {min($count-1,int((min($ay,$by)-$ymin)*$scale))}]
        set high [expr {min($count-1,int((max($ay,$by)-$ymin)*$scale))}]
        set edge [list $ax $ay $bx $by]
        for {set slot $low} {$slot <= $high} {incr slot} {dict lappend bins $slot $edge}
    }
    return [list $ymin $ymax $scale $count $bins]
}

proc ::MeshForge::Bridge::point_in_polygon {index x y} {
    if {$index eq {}} {return 0}
    lassign $index ymin ymax scale count bins
    if {$y < $ymin || $y >= $ymax} {return 0}
    set slot [expr {min($count-1,int(($y-$ymin)*$scale))}]
    if {![dict exists $bins $slot]} {return 0}
    set inside 0
    foreach edge [dict get $bins $slot] {
        lassign $edge ax ay bx by
        if {($ay > $y) != ($by > $y) && $x < $ax+($y-$ay)*($bx-$ax)/($by-$ay)} {
            set inside [expr {!$inside}]
        }
    }
    return $inside
}

proc ::MeshForge::Bridge::segments_intersect {a b c d} {
    lassign $a ax ay
    lassign $b bx by
    lassign $c cx cy
    lassign $d dx dy
    set eps 1.0e-10
    if {max($ax,$bx)+$eps < min($cx,$dx) || max($cx,$dx)+$eps < min($ax,$bx) ||
        max($ay,$by)+$eps < min($cy,$dy) || max($cy,$dy)+$eps < min($ay,$by)} {
        return 0
    }
    set u [signed_area2 $a $b $c]
    set v [signed_area2 $a $b $d]
    set s [signed_area2 $c $d $a]
    set t [signed_area2 $c $d $b]
    return [expr {!(min($u,$v)>$eps || max($u,$v)<-$eps || min($s,$t)>$eps || max($s,$t)<-$eps)}]
}

proc ::MeshForge::Bridge::xy_distance2 {a b} {
    lassign $a ax ay
    lassign $b bx by
    return [expr {($ax-$bx)**2+($ay-$by)**2}]
}

proc ::MeshForge::Bridge::polygon_points {loop points} {
    set polygon {}
    foreach id $loop {lappend polygon [dict get $points $id]}
    return $polygon
}

proc ::MeshForge::Bridge::visible_connector {a b points edges outside island} {
    set p [dict get $points $a]
    set q [dict get $points $b]
    lassign $p px py
    lassign $q qx qy
    set x [expr {($px+$qx)*0.5}]
    set y [expr {($py+$qy)*0.5}]
    if {![point_in_polygon $outside $x $y] || [point_in_polygon $island $x $y]} {return 0}
    foreach edge $edges {
        lassign $edge u v
        if {$a in $edge || $b in $edge} {continue}
        if {[segments_intersect $p $q [dict get $points $u] [dict get $points $v]]} {return 0}
    }
    return 1
}

# Two non-crossing segments split the annulus into simple polygons. They are
# internal edges and can be flipped later to improve the triangulation.
proc ::MeshForge::Bridge::annular_polygons {outer inner points outside island {obstacles {}}} {
    if {[polygon_area2 $outside]*[polygon_area2 $island] < 0} {set inner [lreverse $inner]}
    set outside [polygon_scan_index $outside]
    set island [polygon_scan_index $island]
    set edges [concat [path_edges [concat $outer [lindex $outer 0]]] \
        [path_edges [concat $inner [lindex $inner 0]]] $obstacles]
    set pairs {}
    foreach a $outer {
        foreach b $inner {lappend pairs [list [xy_distance2 [dict get $points $a] [dict get $points $b]] $a $b]}
    }
    set first {}
    foreach pair [lsort -real -index 0 $pairs] {
        lassign $pair width a b
        if {[visible_connector $a $b $points $edges $outside $island]} {
            set first [list $a $b]
            break
        }
    }
    if {![llength $first]} {error "There is no visible connector between the selected loops."}
    lassign $first a b
    set outer [rotate $outer [lsearch -exact $outer $a]]
    set inner [rotate $inner [lsearch -exact $inner $b]]
    set p [dict get $points $a]
    set q [dict get $points $b]
    set indexA {}
    set indexB {}
    set i 0
    foreach id $outer {dict set indexA $id [incr i]}
    set j 0
    foreach id $inner {dict set indexB $id [incr j]}
    set ranked {}
    foreach pair $pairs {
        lassign $pair width u v
        if {$u == $a || $v == $b} {continue}
        set i [expr {[dict get $indexA $u]-1}]
        set j [expr {[dict get $indexB $v]-1}]
        set offset [expr {abs(double($i)/[llength $outer]-0.5)+abs(double($j)/[llength $inner]-0.5)}]
        lappend ranked [list [expr {$offset+0.25*$width}] $i $j $u $v]
    }
    foreach item [lsort -real -index 0 $ranked] {
        lassign $item score i j u v
        if {[segments_intersect $p $q [dict get $points $u] [dict get $points $v]] ||
            ![visible_connector $u $v $points $edges $outside $island]} {continue}
        set left [concat [lrange $outer 0 $i] [lreverse [lrange $inner 0 $j]]]
        set right [concat [lrange $outer $i end] $a $b [lreverse [lrange $inner $j end]]]
        return [list $left $right]
    }
    error "The selected loops do not have two non-crossing connectors."
}

proc ::MeshForge::Bridge::triangle_quality {a b c} {
    lassign $a ax ay
    lassign $b bx by
    lassign $c cx cy
    set ab [expr {($ax-$bx)**2+($ay-$by)**2}]
    set bc [expr {($bx-$cx)**2+($by-$cy)**2}]
    set ca [expr {($cx-$ax)**2+($cy-$ay)**2}]
    set length [expr {$ab+$bc+$ca}]
    if {$length <= 0} {return 0}
    return [expr {(($bx-$ax)*($cy-$ay)-($by-$ay)*($cx-$ax))/$length}]
}

proc ::MeshForge::Bridge::inside_triangle {p a b c threshold} {
    expr {[signed_area2 $a $b $p] > $threshold && [signed_area2 $b $c $p] > $threshold &&
        [signed_area2 $c $a $p] > $threshold}
}

proc ::MeshForge::Bridge::ear_triangles {loop points} {
    if {[polygon_area2 [polygon_points $loop $points]] < 0} {set loop [lreverse $loop]}
    set rows {}
    set earData {}
    while {[llength $loop] > 3} {
        set candidates {}
        set i 0
        set from [lindex $loop end]
        foreach node $loop to [concat [lrange $loop 1 end] [lindex $loop 0]] {
            # Only the two neighbors of a clipped vertex change their ear geometry.
            if {![dict exists $earData $node]} {
                set ear [list $from $node $to]
                lassign [polygon_points $ear $points] a b c
                set area [signed_area2 $a $b $c]
                set data {}
                if {$area > 1.0e-10} {
                    lassign $a ax ay
                    lassign $b bx by
                    lassign $c cx cy
                    set span [expr {max(max($ax,$bx,$cx)-min($ax,$bx,$cx),max($ay,$by,$cy)-min($ay,$by,$cy))}]
                    set margin [expr {1.0e-10+2.0e-10*$span/$area}]
                    set bounds [list [expr {min($ax,$bx,$cx)-$margin}] [expr {max($ax,$bx,$cx)+$margin}] \
                        [expr {min($ay,$by,$cy)-$margin}] [expr {max($ay,$by,$cy)+$margin}]]
                    set data [list [triangle_quality $a $b $c] $ear $a $b $c $bounds]
                }
                dict set earData $node $data
            }
            set data [dict get $earData $node]
            if {$data ne {}} {lappend candidates [linsert $data 1 $i]}
            set from $node
            incr i
        }
        set best -1
        foreach candidate [lsort -real -decreasing -index 0 $candidates] {
            lassign $candidate score i ear a b c bounds
            lassign $bounds xmin xmax ymin ymax
            set valid 1
            foreach other $loop {
                if {$other in $ear} {continue}
                set p [dict get $points $other]
                lassign $p x y
                if {$x < $xmin || $x > $xmax || $y < $ymin || $y > $ymax} {continue}
                if {[inside_triangle $p $a $b $c -1.0e-10]} {
                    set valid 0
                    break
                }
            }
            if {$valid} {
                set best $i
                set face $ear
                break
            }
        }
        if {$best < 0} {error "The projected boundary is not a simple meshable polygon."}
        lappend rows $face
        foreach node $face {dict unset earData $node}
        set loop [lreplace $loop $best $best]
    }
    lappend rows $loop
    return $rows
}

proc ::MeshForge::Bridge::triangle_edges {row} {
    lassign $row a b c
    return [list [edge_key $a $b] [edge_key $b $c] [edge_key $c $a]]
}

proc ::MeshForge::Bridge::improve_triangles {rows points} {
    # Flip internal diagonals if both resulting triangles are valid and the
    # worse triangle improves. No original boundary edge is eligible.
    set scores {}
    set rowEdges {}
    foreach row $rows {
        lappend scores [triangle_quality {*}[polygon_points $row $points]]
        lappend rowEdges [triangle_edges $row]
    }
    for {set pass 0} {$pass < 24} {incr pass} {
        set edges {}
        set i 0
        foreach row $rows keys $rowEdges {
            lassign $row a b c
            lassign $keys ab bc ca
            dict lappend edges $ab [list $i $a $b $c]
            dict lappend edges $bc [list $i $b $c $a]
            dict lappend edges $ca [list $i $c $a $b]
            incr i
        }
        set used {}
        dict for {edge sides} $edges {
            if {[llength $sides] != 2} {continue}
            lassign [lindex $sides 0] i a b c
            lassign [lindex $sides 1] j b2 a2 d
            if {$a != $a2 || $b != $b2 || [dict exists $used $i] || [dict exists $used $j] ||
                [dict exists $edges [edge_key $c $d]]} {continue}
            set pa [dict get $points $a]
            set pb [dict get $points $b]
            set pc [dict get $points $c]
            set pd [dict get $points $d]
            set before [expr {min([lindex $scores $i],[lindex $scores $j])}]
            set scoreI [triangle_quality $pc $pd $pb]
            set scoreJ [triangle_quality $pd $pc $pa]
            if {min($scoreI,$scoreJ) <= $before+1.0e-9} {continue}
            set rowI [list $c $d $b]
            set rowJ [list $d $c $a]
            lset rows $i $rowI
            lset rows $j $rowJ
            lset rowEdges $i [triangle_edges $rowI]
            lset rowEdges $j [triangle_edges $rowJ]
            lset scores $i $scoreI
            lset scores $j $scoreJ
            dict set used $i 1
            dict set used $j 1
        }
        if {![dict size $used]} {break}
    }
    return $rows
}

proc ::MeshForge::Bridge::refine_triangles {rows pointsVar surface spacing {sizeFloor 0}} {
    upvar 1 $pointsVar points
    set rows [improve_triangles $rows $points]
    if {![surface_is_curved $surface $spacing]} {return $rows}
    lassign $surface frame coefficients
    set scale [lindex $frame end]
    lassign [lrange $coefficients 3 5] xx xy yy
    set curvature [expr {max(2*abs($xx)+abs($xy),2*abs($yy)+abs($xy))/$scale}]
    set step [expr {max($sizeFloor,sqrt(8.0*0.012*$spacing/$curvature)/$scale)}]
    # Insert a node only where this triangle's interior has room at the
    # curvature spacing. HyperMesh applies the requested element size later.
    set id 0
    set refined {}
    foreach row $rows {
        lassign $row u v w
        lassign [polygon_points $row $points] a b c
        set area [signed_area2 $a $b $c]
        set longest [expr {sqrt(max([xy_distance2 $a $b],[xy_distance2 $b $c],[xy_distance2 $c $a]))}]
        if {$area <= 1.0e-10 || $longest <= 0 || ($area/$longest < 0.40*$step ||
            $area < 0.75*$step*$step)} {
            lappend refined $row
            continue
        }
        set point [center_of [list $a $b $c]]
        dict set points [incr id -1] $point
        lappend refined [list $u $v $id] [list $v $w $id] [list $w $u $id]
    }
    if {!$id && [llength $rows] > 0} {
        set largest 0.0
        set chosen -1
        set i 0
        foreach row $rows {
            lassign [polygon_points $row $points] a b c
            set area [signed_area2 $a $b $c]
            if {$area > $largest} {
                set largest $area
                set chosen $i
                set point [center_of [list $a $b $c]]
            }
            incr i
        }
        if {$chosen >= 0} {
            dict set points -1 $point
            lassign [lindex $rows $chosen] u v w
            set refined [lreplace $rows $chosen $chosen [list $u $v -1] [list $v $w -1] [list $w $u -1]]
        }
    }
    return [improve_triangles $refined $points]
}

proc ::MeshForge::Bridge::patch_within_size {rows points size} {
    set boundary [free_edges $rows]
    set limit2 [expr {(1.2*$size)**2}]
    foreach row $rows {
        lassign $row a b c
        foreach u [list $a $b $c] v [list $b $c $a] {
            if {![dict exists $boundary [edge_key $u $v]] &&
                [xy_distance2 [dict get $points $u] [dict get $points $v]] > $limit2} {
                return 0
            }
        }
    }
    return 1
}

proc ::MeshForge::Bridge::refine_patch_size {rows pointsVar size} {
    upvar 1 $pointsVar points
    # A boundary edge may be longer than the target size. Keep it intact
    # and use its length as a local floor for splitting its triangle.
    set boundary [free_edges $rows]
    set nextId [expr {min(0,[lindex [lsort -integer [dict keys $points]] 0])}]
    set size2 [expr {$size*$size}]
    set direction [expr {[polygon_area2 [polygon_points [lindex $rows 0] $points]] > 0 ? 1 : -1}]
    if {$direction < 0} {
        set flipped {}
        foreach row $rows {lappend flipped [lreverse $row]}
        set rows $flipped
    }
    for {set pass 0} {$pass < 8} {incr pass} {
        set candidates {}
        set incidence {}
        set i 0
        foreach row $rows {
            lassign $row a b c
            set area [signed_area2 {*}[polygon_points $row $points]]
            set limit $size2
            set lengths {}
            foreach u [list $a $b $c] v [list $b $c $a] w [list $c $a $b] {
                set key [edge_key $u $v]
                set length [xy_distance2 [dict get $points $u] [dict get $points $v]]
                if {[dict exists $boundary $key]} {set limit [expr {max($limit,$length)}]}
                lappend lengths [list $key $length $u $v $w]
            }
            foreach item $lengths {
                lassign $item key length u v w
                dict lappend incidence $key [list $i $u $v $w $area]
                if {$length > 1.20*$limit && abs($area) >= $size2 &&
                    ![dict exists $boundary $key]} {
                    dict set candidates $key 1
                }
            }
            incr i
        }
        set splits {}
        foreach key [dict keys $candidates] {
            lassign [dict get $incidence $key] first second
            lassign $first i a b c areaI
            lassign $second j d e f areaJ
            if {$second eq {} || [dict exists $splits $i] || [dict exists $splits $j]} {continue}
            if {min(abs($areaI),abs($areaJ)) < $size2} {continue}
            set id [incr nextId -1]
            dict set points $id [center_of [polygon_points $key $points]]
            dict set splits $i [list [list $a $id $c] [list $id $b $c]]
            dict set splits $j [list [list $d $id $f] [list $id $e $f]]
        }
        if {![dict size $splits]} {break}
        set refined {}
        set i 0
        foreach row $rows {
            if {[dict exists $splits $i]} {
                lappend refined {*}[dict get $splits $i]
            } else {
                lappend refined $row
            }
            incr i
        }
        set rows $refined
    }
    set rows [improve_triangles $rows $points]
    if {$direction < 0} {
        set flipped {}
        foreach row $rows {lappend flipped [lreverse $row]}
        return $flipped
    }
    return $rows
}

proc ::MeshForge::Bridge::split_patch_holes {outer holes points} {
    set polygons [list $outer]
    set boundaries [list $outer]
    foreach hole $holes {
        set loop [polygon_points $hole $points]
        foreach boundary $boundaries {
            set other [polygon_points $boundary $points]
            lassign [lindex $loop 0] x y
            set inside [point_in_polygon [polygon_scan_index $other] $x $y]
            lassign [lindex $other 0] x y
            if {$inside != ($boundary eq $outer) ||
                    ($boundary ne $outer && [point_in_polygon [polygon_scan_index $loop] $x $y])} {
                error "Edge 2 loops must be separate and inside Edge 1."
            }
            foreach edge [path_edges [concat $hole [lindex $hole 0]]] {
                lassign [polygon_points $edge $points] a b
                foreach side [path_edges [concat $boundary [lindex $boundary 0]]] {
                    lassign [polygon_points $side $points] c d
                    if {[segments_intersect $a $b $c $d]} {error "Selected loops touch or cross."}
                }
            }
        }
        lappend boundaries $hole
    }
    foreach hole $holes {
        lassign [dict get $points [lindex $hole 0]] x y
        set index 0
        foreach polygon $polygons {
            set outside [polygon_points $polygon $points]
            if {[point_in_polygon [polygon_scan_index $outside] $x $y]} {break}
            incr index
        }
        if {$index == [llength $polygons]} {error "Could not locate an inner loop inside the patch."}
        set obstacles {}
        foreach other $holes {
            if {$other ne $hole} {lappend obstacles {*}[path_edges [concat $other [lindex $other 0]]]}
        }
        set split [annular_polygons $polygon $hole $points $outside [polygon_points $hole $points] $obstacles]
        set polygons [lreplace $polygons $index $index {*}$split]
    }
    return $polygons
}

proc ::MeshForge::Bridge::constrained_patch {outer inner points surface spacing {extraHoles {}} {sizeFloor 0}} {
    set outside [polygon_points $outer $points]
    set island [polygon_points $inner $points]
    set area [expr {abs([polygon_area2 $outside])-abs([polygon_area2 $island])}]
    set polygons [list $outer]
    if {[llength $extraHoles]} {
        set polygons [split_patch_holes $outer [linsert $extraHoles 0 $inner] $points]
        foreach loop $extraHoles {set area [expr {$area-abs([polygon_area2 [polygon_points $loop $points]])}]}
    } elseif {[llength $inner]} {
        set polygons [annular_polygons $outer $inner $points $outside $island]
    }
    set rows {}
    foreach polygon $polygons {lappend rows {*}[ear_triangles $polygon $points]}
    set rows [refine_triangles $rows points $surface $spacing $sizeFloor]

    set actual 0.0
    foreach row $rows {
        lassign [polygon_points $row $points] a b c
        set face [signed_area2 $a $b $c]
        if {$face <= 1.0e-10} {error "The triangulation contains a degenerate triangle."}
        set actual [expr {$actual+$face}]
    }
    if {$area <= 0 || abs($actual-$area) > 1.0e-7*$area} {error "The triangulation does not cover the selected region."}
    set free [free_edges $rows]
    foreach loop [concat [list $outer $inner] $extraHoles] {
        if {[llength $loop]} {remove_path_edges free [concat $loop [lindex $loop 0]]}
    }
    if {[dict size $free]} {error "The triangulation did not preserve the selected boundary."}
    if {[polygon_area2 $outside] < 0} {
        set reversed {}
        foreach row $rows {lappend reversed [lreverse $row]}
        set rows $reversed
    }
    return [list $rows $points]
}

proc ::MeshForge::Bridge::store_constrained_patch {rows points surface} {
    lassign $surface frame coefficients
    lassign $frame center u v normal scale
    set ids {}
    dict for {id point} $points {
        if {$id >= 0} {continue}
        lassign $point x y
        set z [height_at $coefficients $x $y]
        set xyz {}
        foreach p $center a $u b $v c $normal {
            lappend xyz [expr {$p+$scale*($a*$x+$b*$y+$c*$z)}]
        }
        *createnode {*}$xyz 0 0 0
        dict set ids $id [hm_latestentityid nodes]
    }
    hm_entityrecorder elems on
    set code [catch {
        # Verified for config 103 in HyperMesh 2022.3/Nastran.
        for {set i 0} {$i < [llength $rows]} {incr i 1024} {
            set flat {}
            foreach row [lrange $rows $i $i+1023] {
                foreach n $row {
                    if {$n < 0} {set n [dict get $ids $n]}
                    lappend flat $n
                }
            }
            *createarray [llength $flat] {*}$flat
            *createelements 103 1 1 [llength $flat]
        }
    } result options]
    hm_entityrecorder elems off
    if {$code} {return -options $options $result}
    return [hm_entityrecorder elems ids]
}

# ---------------------------------------------------------------- sized planar patch
# Interior nodes for a flat patch at the requested element size. The selected loops stay as they are
# (their nodes and edges). The local size grows from the boundary edge length by at most "grade" per
# unit of distance and never exceeds the requested size, so a region smaller than the size gets the
# best triangles it can hold instead of being forced to the size. Delaunay refinement: a triangle
# much larger than the local size gets a node at its circumcentre (its centroid when that falls
# across a boundary edge), legalised by edge flips that never touch a boundary edge; then smoothing.
proc ::MeshForge::Bridge::circumcircle {a b c} {
    lassign $a ax ay; lassign $b bx by; lassign $c cx cy
    set d [expr {2.0*($ax*($by-$cy)+$bx*($cy-$ay)+$cx*($ay-$by))}]
    if {abs($d) < 1.0e-300} {return {}}
    set a2 [expr {$ax*$ax+$ay*$ay}]; set b2 [expr {$bx*$bx+$by*$by}]; set c2 [expr {$cx*$cx+$cy*$cy}]
    set x [expr {($a2*($by-$cy)+$b2*($cy-$ay)+$c2*($ay-$by))/$d}]
    set y [expr {($a2*($cx-$bx)+$b2*($ax-$cx)+$c2*($bx-$ax))/$d}]
    list $x $y [expr {($ax-$x)**2+($ay-$y)**2}]
}

proc ::MeshForge::Bridge::sized_patch {rows pointsVar size {grade 0.5}} {
    upvar 1 $pointsVar points
    variable sp_tri; variable sp_edge
    # counter-clockwise rows
    set direction [expr {[signed_area2 {*}[polygon_points [lindex $rows 0] $points]] > 0 ? 1 : -1}]
    if {$direction < 0} {set r2 {}; foreach row $rows {lappend r2 [lreverse $row]}; set rows $r2}
    set boundary [free_edges $rows]
    # boundary nodes and their local edge length
    set hb {}
    dict for {key one} $boundary {
        lassign $key u v
        set l [expr {sqrt([xy_distance2 [dict get $points $u] [dict get $points $v]])}]
        foreach n [list $u $v] {dict lappend hb $n $l}
    }
    set bnodes {}
    dict for {n ls} $hb {
        set s 0.0; foreach l $ls {set s [expr {$s+$l}]}
        lassign [dict get $points $n] x y
        lappend bnodes [list $x $y [expr {$s/[llength $ls]}]]
    }
    set ::MeshForge::Bridge::sp_b $bnodes
    set ::MeshForge::Bridge::sp_size $size
    set ::MeshForge::Bridge::sp_grade $grade
    array unset sp_tri; array unset sp_edge
    set ::MeshForge::Bridge::sp_next 0
    foreach row $rows {sp_add $row}
    # (constrained) Delaunay first
    foreach t [array names sp_tri] {if {[info exists sp_tri($t)]} {sp_legalize_tri $t points $boundary}}
    set nextId [expr {min(0,[lindex [lsort -integer [dict keys $points]] 0])}]
    set inserted 0
    for {set pass 0} {$pass < 40} {incr pass} {
        set bad {}
        foreach t [array names sp_tri] {
            set row $sp_tri($t)
            lassign [polygon_points $row $points] a b c
            set cc [circumcircle $a $b $c]
            if {$cc eq {}} {continue}
            set R [expr {sqrt([lindex $cc 2])}]
            set g [center_of [list $a $b $c]]
            set limit [expr {0.62*[sp_field [lindex $g 0] [lindex $g 1]]}]
            # a triangle on a boundary edge cannot be smaller than that edge allows
            foreach u $row v [concat [lrange $row 1 end] [lindex $row 0]] {
                if {[dict exists $boundary [edge_key $u $v]]} {
                    set limit [expr {max($limit,0.62*sqrt([xy_distance2 [dict get $points $u] [dict get $points $v]]))}]
                }
            }
            if {$R > 1.05*$limit} {lappend bad [list [expr {$R/$limit}] $t $row]}
        }
        if {![llength $bad]} {break}
        set did 0
        foreach item [lsort -real -decreasing -index 0 $bad] {
            lassign $item ratio t row
            if {![info exists sp_tri($t)] || $sp_tri($t) ne $row} {continue}
            lassign [polygon_points $row $points] a b c
            lassign [circumcircle $a $b $c] x y
            set p [list $x $y]
            set host [sp_locate $t $p $points $boundary]
            if {$host ne ""} {
                # on an edge of its triangle (e.g. the centre of a regular polygon): the centroid instead
                lassign [polygon_points $sp_tri($host) $points] h1 h2 h3
                set tol [expr {1.0e-6*[xy_distance2 $h1 $h2]}]
                if {min([signed_area2 $h1 $h2 $p],[signed_area2 $h2 $h3 $p],[signed_area2 $h3 $h1 $p]) <= $tol} {set host ""}
            }
            if {$host eq ""} {set p [lrange [center_of [list $a $b $c]] 0 1]; set host $t}
            lassign [polygon_points $sp_tri($host) $points] h1 h2 h3
            # not on top of an existing node
            set s [sp_field {*}$p]
            set near 0
            foreach q [list $h1 $h2 $h3] {if {[xy_distance2 $p $q] < (0.3*$s)**2} {set near 1}}
            if {$near} {continue}
            if {min([signed_area2 $h1 $h2 $p],[signed_area2 $h2 $h3 $p],[signed_area2 $h3 $h1 $p]) <= 1.0e-12*$s*$s} {continue}
            dict set points [incr nextId -1] [list {*}$p 0.0]
            sp_split $host $nextId points $boundary
            incr inserted; incr did
            if {$inserted > 20000} {error "The requested element size is too small for this region."}
        }
        if {!$did} {break}
    }
    set rows {}
    foreach t [lsort -integer [array names sp_tri]] {lappend rows $sp_tri($t)}
    array unset sp_tri; array unset sp_edge
    set rows [sp_smooth $rows points $boundary]
    set rows [improve_triangles $rows $points]
    if {$direction < 0} {set r2 {}; foreach row $rows {lappend r2 [lreverse $row]}; set rows $r2}
    return $rows
}

proc ::MeshForge::Bridge::sp_field {x y} {
    # from each boundary edge length towards the requested size, by "grade" per unit of distance
    # (growing where the size is larger, shrinking where it is smaller)
    set size $::MeshForge::Bridge::sp_size; set g $::MeshForge::Bridge::sp_grade
    set up 1e300; set down 0.0
    foreach b $::MeshForge::Bridge::sp_b {
        lassign $b bx by h
        set d [expr {hypot($x-$bx,$y-$by)}]
        set up [expr {min($up,$h+$g*$d)}]
        set down [expr {max($down,$h-$g*$d)}]
    }
    expr {max(min($size,$up),min($down,$up))}
}
proc ::MeshForge::Bridge::sp_add {row} {
    variable sp_tri; variable sp_edge
    set t [incr ::MeshForge::Bridge::sp_next]
    set sp_tri($t) $row
    foreach u $row v [concat [lrange $row 1 end] [lindex $row 0]] {lappend sp_edge([edge_key $u $v]) $t}
    return $t
}
proc ::MeshForge::Bridge::sp_remove {t} {
    variable sp_tri; variable sp_edge
    set row $sp_tri($t)
    foreach u $row v [concat [lrange $row 1 end] [lindex $row 0]] {
        set k [edge_key $u $v]
        set l $sp_edge($k); set i [lsearch -exact $l $t]
        set sp_edge($k) [lreplace $l $i $i]
        if {![llength $sp_edge($k)]} {unset sp_edge($k)}
    }
    unset sp_tri($t)
}
# the triangle across edge u-v from t, or ""
proc ::MeshForge::Bridge::sp_across {t u v} {
    variable sp_edge
    set k [edge_key $u $v]
    if {![info exists sp_edge($k)]} {return ""}
    foreach o $sp_edge($k) {if {$o != $t} {return $o}}
    return ""
}
# walk from t to the triangle holding p; "" when the walk meets a boundary edge
proc ::MeshForge::Bridge::sp_locate {t p points boundary} {
    variable sp_tri
    for {set i 0} {$i < 10000} {incr i} {
        set row $sp_tri($t)
        set moved 0
        foreach u $row v [concat [lrange $row 1 end] [lindex $row 0]] {
            if {[signed_area2 [dict get $points $u] [dict get $points $v] $p] < 0} {
                if {[dict exists $boundary [edge_key $u $v]]} {return ""}
                set o [sp_across $t $u $v]
                if {$o eq ""} {return ""}
                set t $o; set moved 1; break
            }
        }
        if {!$moved} {return $t}
    }
    return ""
}
proc ::MeshForge::Bridge::sp_split {t n pointsVar boundary} {
    upvar 1 $pointsVar points
    variable sp_tri
    lassign $sp_tri($t) a b c
    sp_remove $t
    sp_add [list $a $b $n]; sp_add [list $b $c $n]; sp_add [list $c $a $n]
    sp_legalize [list [list $a $b] [list $b $c] [list $c $a]] points $boundary
}
# Lawson flips of the edges in stack (pairs u v); boundary edges are never flipped
proc ::MeshForge::Bridge::sp_legalize {stack pointsVar boundary} {
    upvar 1 $pointsVar points
    variable sp_tri; variable sp_edge
    set guard 0
    while {[llength $stack] && [incr guard] < 100000} {
        lassign [lindex $stack end] u v
        set stack [lrange $stack 0 end-1]
        set k [edge_key $u $v]
        if {[dict exists $boundary $k] || ![info exists sp_edge($k)] || [llength $sp_edge($k)] != 2} {continue}
        set t1 ""; set c ""; set d ""
        foreach t $sp_edge($k) {
            set row $sp_tri($t)
            set i [lsearch -exact $row $u]
            if {[lindex $row [expr {($i+1)%3}]] == $v} {set t1 $t; set c [lindex $row [expr {($i+2)%3}]]} else {set t2 $t; set d [lindex $row [expr {($i+1)%3}]]}
        }
        if {$t1 eq "" || $c eq "" || $d eq ""} {continue}
        set pu [dict get $points $u]; set pv [dict get $points $v]; set pc [dict get $points $c]; set pd [dict get $points $d]
        set cc [circumcircle $pu $pv $pc]
        if {$cc eq {}} {continue}
        lassign $cc x y r2c
        if {($x-[lindex $pd 0])**2+($y-[lindex $pd 1])**2 >= $r2c*(1-1.0e-12)} {continue}
        # the flip must give two valid triangles (a convex quad)
        if {[signed_area2 $pc $pd $pv] <= 0 || [signed_area2 $pd $pc $pu] <= 0} {continue}
        if {[info exists sp_edge([edge_key $c $d])]} {continue}
        sp_remove $t1; sp_remove $t2
        sp_add [list $c $d $v]; sp_add [list $d $c $u]
        lappend stack [list $u $d] [list $d $v] [list $v $c] [list $c $u]
    }
}
proc ::MeshForge::Bridge::sp_legalize_tri {t pointsVar boundary} {
    upvar 1 $pointsVar points
    variable sp_tri
    lassign $sp_tri($t) a b c
    sp_legalize [list [list $a $b] [list $b $c] [list $c $a]] points $boundary
}
# Laplacian smoothing of the new nodes; a move is kept only when no triangle around the node gets
# worse than the worst one before
proc ::MeshForge::Bridge::sp_smooth {rows pointsVar boundary} {
    upvar 1 $pointsVar points
    set around {}; set nbr {}
    set i 0
    foreach row $rows {
        foreach u $row v [concat [lrange $row 1 end] [lindex $row 0]] {
            dict lappend around $u $i
            dict set nbr $u $v 1; dict set nbr $v $u 1
        }
        incr i
    }
    set fixed {}
    dict for {k one} $boundary {foreach n $k {dict set fixed $n 1}}
    for {set pass 0} {$pass < 6} {incr pass} {
        dict for {n ts} $around {
            if {[dict exists $fixed $n] || $n >= 0} {continue}
            set sx 0.0; set sy 0.0; set k 0
            foreach m [dict keys [dict get $nbr $n]] {lassign [dict get $points $m] x y; set sx [expr {$sx+$x}]; set sy [expr {$sy+$y}]; incr k}
            if {!$k} {continue}
            set old [dict get $points $n]
            set worst 1e300
            foreach t $ts {set worst [expr {min($worst,[triangle_quality {*}[polygon_points [lindex $rows $t] $points]])}]}
            dict set points $n [list [expr {$sx/$k}] [expr {$sy/$k}] 0.0]
            set after 1e300
            foreach t $ts {set after [expr {min($after,[triangle_quality {*}[polygon_points [lindex $rows $t] $points]])}]}
            if {$after < $worst} {dict set points $n $old}
        }
    }
    return $rows
}
