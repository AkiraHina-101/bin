# Ordered node paths and connectivity checks independent of HyperMesh.
namespace eval ::MeshForge::Bridge {}

proc ::MeshForge::Bridge::distance2 {a b} {
    lassign $a ax ay az
    lassign $b bx by bz
    expr {($ax-$bx)**2 + ($ay-$by)**2 + ($az-$bz)**2}
}

proc ::MeshForge::Bridge::rotate {path at} {
    concat [lrange $path $at end] [lrange $path 0 $at-1]
}

proc ::MeshForge::Bridge::arc_lengths {path coordinates} {
    set lengths {0.0}
    set total 0.0
    set previous [lindex $path 0]
    foreach node [lrange $path 1 end] {
        set step [distance2 [dict get $coordinates $previous] [dict get $coordinates $node]]
        if {$step <= 0} {error "Nodes $previous and $node occupy the same point."}
        set total [expr {$total + sqrt($step)}]
        lappend lengths $total
        set previous $node
    }
    return $lengths
}

proc ::MeshForge::Bridge::path_spacing {paths coordinates} {
    set length 0.0
    set edges 0
    foreach path $paths {
        set length [expr {$length+[lindex [arc_lengths $path $coordinates] end]}]
        incr edges [expr {[llength $path]-1}]
    }
    return [expr {$length/$edges}]
}

# Arc-length sampling compares direction even when the two paths have different node densities.
proc ::MeshForge::Bridge::samples {path lengths coordinates} {
    set points {}
    set j 1
    set total [lindex $lengths end]
    for {set i 0} {$i <= 32} {incr i} {
        set target [expr {$total * $i / 32.0}]
        while {$j < [llength $lengths]-1 && [lindex $lengths $j] < $target} {incr j}
        set start [lindex $lengths $j-1]
        set fraction [expr {($target - $start) / ([lindex $lengths $j] - $start)}]
        set point {}
        foreach p [dict get $coordinates [lindex $path $j-1]] q [dict get $coordinates [lindex $path $j]] {
            lappend point [expr {$p + $fraction * ($q - $p)}]
        }
        lappend points $point
    }
    return $points
}

proc ::MeshForge::Bridge::alignment_cost {reference path lengths coordinates} {
    set cost 0.0
    foreach p $reference q [samples $path $lengths $coordinates] {
        set cost [expr {$cost + [distance2 $p $q]}]
    }
    return $cost
}

proc ::MeshForge::Bridge::midpoint_index {lengths} {
    set target [expr {[lindex $lengths end] / 2.0}]
    set best 1
    for {set i 2} {$i < [llength $lengths]-1} {incr i} {
        if {abs([lindex $lengths $i] - $target) < abs([lindex $lengths $best] - $target)} {
            set best $i
        }
    }
    return $best
}

proc ::MeshForge::Bridge::plan {a b closed coordinates} {
    foreach side {a b} {
        set path [set $side]
        if {$closed && [lindex $path 0] eq [lindex $path end]} {set path [lrange $path 0 end-1]}
        if {[llength $path] < 2 + $closed} {error "Select enough nodes on both paths."}
        if {[llength [lsort -integer -unique $path]] != [llength $path]} {
            error "A path visits a node more than once."
        }
        set $side $path
    }
    set all [concat $a $b]
    if {[llength [lsort -integer -unique $all]] != [llength $all]} {
        error "The two paths must have distinct nodes."
    }

    if {$closed} {
        set best Inf
        set i 0
        foreach na $a {
            set pointA [dict get $coordinates $na]
            set j 0
            foreach nb $b {
                set gap [distance2 $pointA [dict get $coordinates $nb]]
                if {$gap < $best} {set best $gap; set firstA $i; set firstB $j}
                incr j
            }
            incr i
        }
        set a [rotate $a $firstA]
        set b [rotate $b $firstB]
        lappend a [lindex $a 0]
        lappend b [lindex $b 0]
    }

    set lengthsA [arc_lengths $a $coordinates]
    set lengthsB [arc_lengths $b $coordinates]
    set reference [samples $a $lengthsA $coordinates]
    set reversed [lreverse $b]
    set reverseLengths [arc_lengths $reversed $coordinates]
    if {[alignment_cost $reference $reversed $reverseLengths $coordinates] <
        [alignment_cost $reference $b $lengthsB $coordinates]} {
        set b $reversed
        set lengthsB $reverseLengths
    }
    if {!$closed} {
        set start [distance2 [dict get $coordinates [lindex $a 0]] [dict get $coordinates [lindex $b 0]]]
        set end [distance2 [dict get $coordinates [lindex $a end]] [dict get $coordinates [lindex $b end]]]
        if {$end < $start} {
            set a [lreverse $a]
            set b [lreverse $b]
        }
    }
    set patches [list [list $a $b]]
    if {$closed} {
        set i [midpoint_index $lengthsA]
        set j [midpoint_index $lengthsB]
        set patches [list [list [lrange $a 0 $i] [lrange $b 0 $j]] \
            [list [lrange $a $i end] [lrange $b $j end]]]
    }
    return [dict create a $a b $b patches $patches]
}

proc ::MeshForge::Bridge::edge_key {a b} {
    if {$a < $b} {return [list $a $b]}
    return [list $b $a]
}

proc ::MeshForge::Bridge::path_edges {path} {
    set edges {}
    foreach a [lrange $path 0 end-1] b [lrange $path 1 end] {
        lappend edges [edge_key $a $b]
    }
    return $edges
}

# Reject duplicate triangles, non-manifold edges, and inconsistent interior edge directions.
proc ::MeshForge::Bridge::free_edges {rows} {
    set counts {}
    set directions {}
    set triangles {}
    foreach nodes $rows {
        set key [lsort -integer -unique $nodes]
        if {[llength $key] != 3 || [dict exists $triangles $key]} {
            error "The generated mesh contains an invalid or duplicate triangle."
        }
        dict set triangles $key 1
        lassign $nodes a b c
        foreach from [list $a $b $c] to [list $b $c $a] {
            set edge [edge_key $from $to]
            dict incr counts $edge
            dict incr directions $edge [expr {$from < $to ? 1 : -1}]
        }
    }
    set free {}
    dict for {edge count} $counts {
        if {$count == 1} {
            dict set free $edge 1
        } elseif {$count != 2 || [dict get $directions $edge] != 0} {
            error "The mesh has inconsistent connectivity at edge $edge."
        }
    }
    return $free
}

proc ::MeshForge::Bridge::remove_path_edges {freeVar path} {
    upvar 1 $freeVar free
    foreach key [path_edges $path] {
        if {![dict exists $free $key]} {error "The mesh did not keep input edge $key."}
        dict unset free $key
    }
}

proc ::MeshForge::Bridge::seam_paths {a b rows} {
    set free [free_edges $rows]
    remove_path_edges free $a
    remove_path_edges free $b
    set adjacent {}
    foreach edge [dict keys $free] {
        lassign $edge u v
        dict lappend adjacent $u $v
        dict lappend adjacent $v $u
    }
    set seams {}
    foreach endpoint {0 end} {
        set node [lindex $a $endpoint]
        set stop [lindex $b $endpoint]
        set previous {}
        set path [list $node]
        while {$node != $stop} {
            set next {}
            if {[dict exists $adjacent $node]} {
                foreach candidate [dict get $adjacent $node] {
                    if {$candidate ne $previous && [dict exists $free [edge_key $node $candidate]]} {
                        lappend next $candidate
                    }
                }
            }
            if {[llength $next] != 1} {error "The mesh does not have a continuous connecting edge."}
            set next [lindex $next 0]
            dict unset free [edge_key $node $next]
            set previous $node
            set node $next
            lappend path $node
        }
        lappend seams $path
    }
    if {[dict size $free]} {error "The patch has an unexpected free edge."}
    return $seams
}
