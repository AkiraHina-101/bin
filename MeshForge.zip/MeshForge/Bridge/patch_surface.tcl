# Fit a local height surface to the shell around the selected edge.
proc ::MeshForge::Bridge::dot {a b} {
    lassign $a x y z
    lassign $b u v w
    return [expr {$x*$u+$y*$v+$z*$w}]
}

proc ::MeshForge::Bridge::difference {a b} {
    lassign $a x y z
    lassign $b u v w
    return [list [expr {$x-$u}] [expr {$y-$v}] [expr {$z-$w}]]
}

proc ::MeshForge::Bridge::cross {a b} {
    lassign $a x y z
    lassign $b u v w
    return [list [expr {$y*$w-$z*$v}] [expr {$z*$u-$x*$w}] [expr {$x*$v-$y*$u}]]
}

proc ::MeshForge::Bridge::unit {a} {
    set length [expr {sqrt([dot $a $a])}]
    if {$length == 0} {return {}}
    set result {}
    foreach x $a {lappend result [expr {$x/$length}]}
    return $result
}

proc ::MeshForge::Bridge::center_of {points} {
    set center {0.0 0.0 0.0}
    set count [llength $points]
    foreach point $points {
        set next {}
        foreach x $point c $center {lappend next [expr {$c+double($x)/$count}]}
        set center $next
    }
    return $center
}

# Read the bounding neighborhood once for free-edge validation, fitting and overlap checks.
proc ::MeshForge::Bridge::shell_neighborhood {rim spacing} {
    set lo {Inf Inf Inf}
    set hi {-Inf -Inf -Inf}
    foreach point [dict values $rim] {
        set lower {}; set upper {}
        foreach x $point low $lo high $hi {
            lappend lower [expr {min($x,$low)}]
            lappend upper [expr {max($x,$high)}]
        }
        set lo $lower
        set hi $upper
    }
    set lower {}; set upper {}
    foreach low $lo high $hi {
        lappend lower [expr {$low-2.0*$spacing}]
        lappend upper [expr {$high+2.0*$spacing}]
    }
    set saved [hm_getmark elems 1]
    set code [catch {
        *createmark elems 1 "by box" {*}$lower {*}$upper 0 inside 0 1 0
        hm_getmark elems 1
    } ids options]
    *clearmark elems 1
    if {[llength $saved]} {*createmark elems 1 "by id only" {*}$saved}
    if {$code} {return -options $options $ids}
    set shells {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set chunk [lrange $ids $i $i+1023]
        set configs [hm_getvalue elems user_ids=$chunk dataname=config]
        set rows [hm_getvalue elems user_ids=$chunk dataname=nodes]
        foreach id $chunk cfg $configs row $rows {
            if {$cfg ni {103 104 106 108}} {continue}
            set corners [lrange $row 0 [expr {$cfg in {103 106} ? 2 : 3}]]
            dict set shells $id [list $corners $row]
        }
    }
    return $shells
}

proc ::MeshForge::Bridge::project {frame point} {
    lassign $frame center u v normal scale
    set offset [difference $point $center]
    return [list [expr {[dot $offset $u]/$scale}] [expr {[dot $offset $v]/$scale}] \
        [expr {[dot $offset $normal]/$scale}]]
}

proc ::MeshForge::Bridge::height_terms {x y} {
    return [list 1.0 $x $y [expr {$x*$x}] [expr {$x*$y}] [expr {$y*$y}]]
}

proc ::MeshForge::Bridge::height_at {coefficients x y} {
    set result 0.0
    set terms [height_terms $x $y]
    foreach coef [lrange $coefficients 0 5] value [lrange $terms 0 [expr {min(5,[llength $coefficients]-1)}]] {
        set result [expr {$result+$coef*$value}]
    }
    if {[llength $coefficients] == 9} {
        lassign [lrange $coefficients 6 8] xz yz zz
        set linear [expr {1.0-$xz*$x-$yz*$y}]
        set discriminant [expr {$linear*$linear-4.0*$zz*$result}]
        if {$discriminant <= 1.0e-8 || $linear+sqrt($discriminant) <= 1.0e-4} {
            error "The fitted sheet is not single-valued here."
        }
        set result [expr {2.0*$result/($linear+sqrt($discriminant))}]
    }
    return $result
}

proc ::MeshForge::Bridge::fit_height {samples columns} {
    set matrix [lrepeat $columns [lrepeat [expr {$columns+1}] 0.0]]
    foreach point $samples {
        lassign $point x y z
        set terms [lrange [height_terms $x $y] 0 $columns-1]
        if {$columns == 9} {lappend terms [expr {$x*$z}] [expr {$y*$z}] [expr {$z*$z}]}
        set termsAndHeight [concat $terms $z]
        set row 0
        foreach term $terms accum $matrix {
            set out {}
            foreach a $accum b $termsAndHeight {lappend out [expr {$a+$term*$b}]}
            lset matrix $row $out
            incr row
        }
    }
    # Pivoted elimination on the small, scaled normal system.
    for {set col 0} {$col < $columns} {incr col} {
        set pivot $col
        for {set row [expr {$col+1}]} {$row < $columns} {incr row} {
            if {abs([lindex $matrix $row $col]) > abs([lindex $matrix $pivot $col])} {set pivot $row}
        }
        set p [lindex $matrix $pivot $col]
        if {abs($p) < 1.0e-9} {return {}}
        set normalized {}
        foreach value [lindex $matrix $pivot] {lappend normalized [expr {$value/$p}]}
        lset matrix $pivot [lindex $matrix $col]
        lset matrix $col $normalized
        for {set row 0} {$row < $columns} {incr row} {
            if {$row == $col} {continue}
            set factor [lindex $matrix $row $col]
            set out {}
            foreach a [lindex $matrix $row] b $normalized {
                lappend out [expr {$a-$factor*$b}]
            }
            lset matrix $row $out
        }
    }
    set coefficients {}
    foreach row $matrix {lappend coefficients [lindex $row end]}
    return $coefficients
}

proc ::MeshForge::Bridge::surface_error {samples coefficients} {
    set peak 0.0
    foreach sample $samples {
        lassign $sample x y z
        set peak [expr {max($peak,abs($z-[height_at $coefficients $x $y]))}]
    }
    return $peak
}

# A tilted quadric need not be quadratic as an explicit height in this frame.
# Accept the implicit fit only when it actually explains the support samples
# and describes a single surface over the extended patch domain.
proc ::MeshForge::Bridge::rotated_quadric {samples tolerance} {
    set candidate [fit_height $samples 9]
    if {$candidate eq {}} {return {}}
    lassign [lrange $candidate 6 8] xz yz zz
    if {abs($xz)+abs($yz)+abs($zz) > 0.7} {return {}}
    if {[catch {
        set peak [surface_error $samples $candidate]
        foreach x {-1.5 -0.75 0.0 0.75 1.5} {
            foreach y {-1.5 -0.75 0.0 0.75 1.5} {height_at $candidate $x $y}
        }
    }] || $peak > $tolerance} {return {}}
    return $candidate
}

# Prefer a single plane when the selected boundary is nearly coplanar.
proc ::MeshForge::Bridge::boundary_plane {rim spacing} {
    set points [dict values $rim]
    set frame [rim_projection_frame $points]
    if {$frame eq {}} {return {}}
    set local {}
    foreach point $points {lappend local [project $frame $point]}
    set coefficients [fit_height $local 3]
    if {$coefficients eq {}} {return {}}
    lassign $coefficients height slopeU slopeV
    lassign $frame center u v normal scale
    set origin {}
    set adjustedNormal {}
    foreach c $center a $u b $v n $normal {
        lappend origin [expr {$c+$scale*$height*$n}]
        lappend adjustedNormal [expr {$n-$slopeU*$a-$slopeV*$b}]
    }
    set normal [unit $adjustedNormal]
    set v [unit [cross $normal $u]]
    set frame [list $origin [cross $v $normal] $v $normal $scale]
    foreach point $points {
        if {abs([lindex [project $frame $point] 2])*$scale > 0.01*$spacing} {return {}}
    }
    return [list $frame {0.0 0.0 0.0}]
}

proc ::MeshForge::Bridge::reference_surface {rim shells spacing {preferArea 0}} {
    set points $rim
    set support {}
    set samples {}
    dict for {id shell} $shells {
        set corners [lindex $shell 0]
        foreach n $corners {
            if {[dict exists $rim $n]} {
                lappend support $corners
                lappend samples {*}$corners
                break
            }
        }
    }
    if {![llength $support]} {return {}}
    set missing {}
    foreach n [lsort -integer -unique $samples] {
        if {![dict exists $points $n]} {lappend missing $n}
    }
    set points [dict merge $points [coordinates $missing]]
    set normal {0.0 0.0 0.0}
    set weighted $normal
    set normals {}
    foreach row $support {
        lassign $row a b c
        set origin [dict get $points $a]
        set face [cross [difference [dict get $points $b] $origin] \
            [difference [dict get $points $c] $origin]]
        set axis [unit $face]
        if {$axis eq {}} {continue}
        set sign [expr {[dot $axis $normal] < 0 ? -1 : 1}]
        set next {}
        foreach x $axis y $normal {lappend next [expr {$y+$sign*$x}]}
        set normal $next
        set next {}
        foreach x $face y $weighted {lappend next [expr {$y+$sign*$x}]}
        set weighted $next
        lappend normals $axis
    }
    set candidates [list [unit $normal] [unit $weighted]]
    # Opposite open strips can sample the same area at very different
    # edge densities. Give the physical area priority for their fit.
    if {$preferArea} {set candidates [lreverse $candidates]}
    foreach candidate $candidates {
        if {$candidate eq {}} {continue}
        set surface [fit_reference_normal $candidate $normals $rim $points $samples $spacing]
        if {$surface ne {}} {return $surface}
    }
    return {}
}

proc ::MeshForge::Bridge::fit_reference_normal {normal normals rim points samples spacing} {
    foreach axis $normals {
        if {abs([dot $axis $normal]) < 0.55} {return {}}
    }
    set helper {1.0 0.0 0.0}
    if {abs([lindex $normal 0]) > 0.8} {set helper {0.0 1.0 0.0}}
    set u [unit [cross $helper $normal]]
    set v [cross $normal $u]
    set center [center_of [dict values $rim]]
    set scale $spacing
    foreach point [dict values $rim] {set scale [expr {max($scale,sqrt([distance2 $point $center]))}]}
    set frame [list $center $u $v $normal $scale]
    set projected {}
    foreach n [lsort -integer -unique $samples] {
        lappend projected [project $frame [dict get $points $n]]
    }
    set coefficients [fit_height $projected 6]
    if {$coefficients eq {}} {set coefficients [fit_height $projected 3]}
    if {$coefficients eq {}} {return {}}
    set peak [surface_error $projected $coefficients]
    if {$peak*$scale > 0.001*$spacing && [llength $projected] >= 12} {
        set quadric [rotated_quadric $projected [expr {0.0002*$spacing/$scale}]]
        if {$quadric ne {}} {return [list $frame $quadric]}
    }
    if {$peak*$scale > 0.15*$spacing} {return {}}
    return [list $frame $coefficients]
}

proc ::MeshForge::Bridge::on_surface {surface point} {
    lassign $surface frame coefficients
    lassign [project $frame $point] x y z
    set shift [expr {([height_at $coefficients $x $y]-$z)*[lindex $frame end]}]
    set result {}
    foreach coord $point axis [lindex $frame 3] {lappend result [expr {$coord+$shift*$axis}]}
    return $result
}

proc ::MeshForge::Bridge::connector_sag {surface a b} {
    lassign $surface frame coefficients
    lassign [project $frame $a] ax ay
    lassign [project $frame $b] bx by
    set az [height_at $coefficients $ax $ay]
    set bz [height_at $coefficients $bx $by]
    set sag 0.0
    foreach t {0.25 0.5 0.75} {
        set x [expr {$ax+$t*($bx-$ax)}]
        set y [expr {$ay+$t*($by-$ay)}]
        set chord [expr {$az+$t*($bz-$az)}]
        set sag [expr {max($sag,abs([height_at $coefficients $x $y]-$chord))}]
    }
    return [expr {$sag*[lindex $frame end]}]
}

proc ::MeshForge::Bridge::circle_frame {first second third} {
    set a [difference $second $first]
    set b [difference $third $first]
    set scale [expr {sqrt(max([dot $a $a],[dot $b $b]))}]
    if {$scale <= 0} {error "Choose three distinct nodes on the circle."}
    set scaledA {}
    set scaledB {}
    foreach x $a y $b {
        lappend scaledA [expr {$x/$scale}]
        lappend scaledB [expr {$y/$scale}]
    }
    set normal [cross $scaledA $scaledB]
    set normal2 [dot $normal $normal]
    if {$normal2 < 1.0e-20} {error "The three nodes are collinear or too close to a straight line."}
    set center {}
    set radial {}
    set a2 [dot $scaledA $scaledA]
    set b2 [dot $scaledB $scaledB]
    foreach p $first x [cross $scaledB $normal] y [cross $normal $scaledA] {
        set offset [expr {$scale*($a2*$x+$b2*$y)/(2.0*$normal2)}]
        lappend center [expr {$p+$offset}]
        lappend radial [expr {-$offset}]
    }
    set radius [expr {sqrt([dot $radial $radial])}]
    set u [unit $radial]
    set normal [unit $normal]
    return [list $center $u [cross $normal $u] $normal $radius]
}

proc ::MeshForge::Bridge::circle_points {anchors count angle {requestedRadius {}}} {
    if {![string is integer -strict $count] || $count < 3} {error "Enter at least three ring nodes."}
    set angle [number $angle "rotation angle" -Inf Inf]
    if {abs($angle) == Inf} {error "Enter a finite rotation angle."}
    lassign [circle_frame {*}$anchors] center u v normal radius
    if {$requestedRadius ne {}} {
        set radius [number $requestedRadius radius 0 Inf]
        if {$radius <= 0} {error "Enter a positive radius."}
    }
    set points [list $center]
    set pi [expr {acos(-1.0)}]
    set phase [expr {fmod($angle,360.0)*$pi/180.0}]
    for {set i 0} {$i < $count} {incr i} {
        set theta [expr {$phase+2.0*$pi*$i/$count}]
        set point {}
        foreach p $center x $u y $v {
            lappend point [expr {$p+$radius*($x*cos($theta)+$y*sin($theta))}]
        }
        lappend points $point
    }
    return $points
}

proc ::MeshForge::Bridge::signed_area2 {a b c} {
    lassign $a ax ay
    lassign $b bx by
    lassign $c cx cy
    return [expr {($bx-$ax)*($cy-$ay)-($by-$ay)*($cx-$ax)}]
}

proc ::MeshForge::Bridge::validate_projection {rows points surface} {
    set flat {}
    dict for {id p} $points {dict set flat $id [project [lindex $surface 0] $p]}
    set sign 0
    foreach row $rows {
        lassign [polygon_points $row $flat] p q r
        set area [signed_area2 $p $q $r]
        set side2 [expr {max([xy_distance2 $p $q],[xy_distance2 $q $r],[xy_distance2 $r $p])}]
        if {abs($area) <= 1.0e-12*$side2 || ($sign != 0 && $sign*$area <= 0)} {
            return -code error -errorcode {RULEDMESH FOLDED_PROJECTION} \
                "The generated mesh folds or crosses on the fitted surface."
        }
        set sign [expr {$area > 0 ? 1 : -1}]
    }
}

# Compare the patch extent and curvature without moving an input node.
proc ::MeshForge::Bridge::surface_is_curved {surface spacing} {
    lassign $surface frame coefficients
    lassign [lrange $coefficients 3 5] xx xy yy
    if {[llength $coefficients] < 6} {return 0}
    return [expr {max(abs($xx),abs($xy),abs($yy))*[lindex $frame end] > 0.004*$spacing}]
}

proc ::MeshForge::Bridge::build_support_surface {surface points} {
    lassign $surface frame coefficients
    lassign $frame center u v normal scale
    set xmin Inf
    set xmax -Inf
    set ymin Inf
    set ymax -Inf
    foreach p [dict values $points] {
        lassign [project $frame $p] x y
        set xmin [expr {min($xmin,$x)}]
        set xmax [expr {max($xmax,$x)}]
        set ymin [expr {min($ymin,$y)}]
        set ymax [expr {max($ymax,$y)}]
    }
    # An implicit quadric requires denser sampling for accurate projection.
    set parts [expr {[llength $coefficients] == 9 ? 6 : 2}]
    set dx [expr {($xmax-$xmin)/$parts}]
    set dy [expr {($ymax-$ymin)/$parts}]
    set samples {}
    # Extend the sample grid one step past the patch to keep it away from the spline trim.
    for {set i -1} {$i <= $parts+1} {incr i} {
        for {set j -1} {$j <= $parts+1} {incr j} {
            set x [expr {$xmin+$i*$dx}]
            set y [expr {$ymin+$j*$dy}]
            set z [height_at $coefficients $x $y]
            set point {}
            foreach a $center b $u c $v d $normal {
                lappend point [expr {$a+($b*$x+$c*$y+$d*$z)*$scale}]
            }
            *createnode {*}$point 0 0 0
            lappend samples [hm_latestentityid nodes]
        }
    }
    *createmark nodes 1 "by id only" {*}$samples
    *surfacemode 4
    hm_entityrecorder surfs on
    set code [catch {*surfacesplinefrompoints nodes 1 0} result options]
    hm_entityrecorder surfs off
    if {$code} {return -options $options $result}
    set ids [hm_entityrecorder surfs ids]
    if {[llength $ids] != 1} {error "HyperMesh could not build one temporary support surface."}
    return [list [lindex $ids 0] $samples]
}

proc ::MeshForge::Bridge::project_patch {rows points surface support spacing pinned} {
    validate_projection $rows $points $surface
    # Only the input nodes are fixed. A new open connector belongs on
    # the fitted face just like the other generated nodes.
    set targets {}
    dict for {id p} $points {
        if {![dict exists $pinned $id]} {lappend targets $id}
    }
    if {![llength $targets]} {return}
    set surf [lindex $support 0]
    *createmark nodes 1 "by id only" {*}$targets
    *createvector 1 {*}[lindex [lindex $surface 0] 3]
    *markprojecttosurface nodes 1 1 $surf
    dict for {id actual} [coordinates $targets] {
        set expected [on_surface $surface [dict get $points $id]]
        if {[distance2 $actual $expected] > (0.01*$spacing)**2} {
            error "A patch node did not reach the reconstructed surface."
        }
    }
}

proc ::MeshForge::Bridge::delete_support_surface {support} {
    lassign $support surf samples
    set deleteElems [hm_getoption delete_surface_with_elements]
    set deleteMode [hm_getoption delete_elements_mode]
    set code [catch {
        *setoption delete_surface_with_elements=0 delete_elements_mode=0
        *createmark surfs 1 "by id only" $surf
        *deletemark surfs 1
    } result options]
    *setoption delete_surface_with_elements=$deleteElems delete_elements_mode=$deleteMode
    if {$code} {return -options $options $result}
    *createmark nodes 1 "by id only" {*}$samples
    *nodemarkcleartempmark 1
    foreach id $samples {
        if {[hm_entityinfo exist nodes $id -byid]} {error "A temporary support node is still present."}
    }
}
