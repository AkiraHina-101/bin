# Element Translate (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Moves the selected elements (their nodes, so connected elements follow, as the native translate
# panel does), or the selected nodes, by node 2 - node 1 of two picked nodes (the pick order gives the
# direction). X / Y / Z
# keep only those components. Distance fixes the length of the resulting vector. With Duplicate the elements
# are copied first (*duplicatemark: same type, property, every attribute, own new nodes) and the copy
# is moved; the copy goes to the elements' own components, the current component or a new component.
# Every Translate is one Undo step "Element translate"; the selection stays (native highlight) so
# Translate can be pressed again.
# Entry point for the menu: *evaltclscript translate.tcl 0. Set ::MeshForge_Translate_no_gui to load
# the procedures without opening the window (tests).

if {![llength [info commands ::TestToolSession::attach]]} {
    # tool_session.tcl: the copy in deps/ of this folder, else the one beside the folder
    source [apply {{s} {set h [file dirname [file normalize $s]]; foreach f [list [file join $h deps tool_session.tcl] [file join [file dirname $h] tool_session.tcl]] {if {[file isfile $f]} {return $f}}; file join $h deps tool_session.tcl}} [info script]]
}
if {![info exists ::MeshForge_Translate_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::MeshForge::Translate {
    variable W .elemTranslate
    variable label "Element translate"
    variable sel
    variable opt
    variable status
    if {![info exists status]} {set status ""}
    # elems or move (nodes to move): one of the two is used, the last selected; nodes: the direction
    foreach {k v} {elems {} nodes {} move {} kind elems} {if {![info exists sel($k)]} {set sel($k) $v}}
    foreach {k v} {x 1 y 1 z 1 axes All useDistance 0 distance {} info,elems "" info,nodes "" dup 0 dupTo same dupLabel "Same comp"} {
        if {![info exists opt($k)]} {set opt($k) $v}
    }
}

# No status row in the window: every message goes to the HyperMesh status bar
proc ::MeshForge::Translate::show_status {args} {
    variable status
    if {[info exists ::MeshForge_Translate_no_gui]} {return}
    catch {hm_usermessage "Element Translate: $status"}
}
trace remove variable ::MeshForge::Translate::status write ::MeshForge::Translate::show_status
trace add variable ::MeshForge::Translate::status write ::MeshForge::Translate::show_status

proc ::MeshForge::Translate::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::MeshForge::Translate::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}
proc ::MeshForge::Translate::xyz {n} {list [hm_getvalue nodes id=$n dataname=x] [hm_getvalue nodes id=$n dataname=y] [hm_getvalue nodes id=$n dataname=z]}
proc ::MeshForge::Translate::existing {ids {type elems}} {
    if {![llength $ids]} {return {}}
    *createmark $type 1 {*}$ids; set o [hm_getmark $type 1]; *clearmark $type 1
    return $o
}

# The move: node 2 - node 1, only the components in axes (a list of x y z; empty = all).
# Returns {dx dy dz}.
proc ::MeshForge::Translate::motion {nodes {axes {}}} {
    if {[llength $nodes] != 2} {error "Pick two nodes (node 1, then node 2)."}
    lassign $nodes a b
    set v {}; foreach x [xyz $b] y [xyz $a] {lappend v [expr {$x-$y}]}
    if {[llength $axes]} {
        set out {}
        foreach c {x y z} d $v {lappend out [expr {$c in $axes ? $d : 0.0}]}
        set v $out
    }
    return $v
}

proc ::MeshForge::Translate::distance_motion {nodes axes distance} {
    # no axis given: along the whole vector node 1 -> node 2
    set distance [string trim $distance]
    if {![string is double -strict $distance] || !($distance > 0 && $distance < Inf)} {
        error "Enter a positive distance in mm."
    }
    set vector [motion $nodes $axes]
    lassign $vector x y z
    set length [expr {sqrt($x*$x+$y*$y+$z*$z)}]
    if {$length <= 1e-12} {error "The picked nodes give no direction along the selected axes."}
    set move {}
    foreach component $vector {lappend move [expr {$component / $length * $distance}]}
    return $move
}

# A component name not used yet: translate_copy, translate_copy_1, ...
proc ::MeshForge::Translate::new_comp_name {} {
    set n translate_copy; set i 0
    while {[hm_entityinfo exist comps $n -byname]} {incr i; set n translate_copy_$i}
    return $n
}

# Moves the elements, or a copy of them (dup: "" = move, same = copy into the elements' own
# components, current = into the current component, new = into a new component, which takes the
# property of the source component when all elements come from one). One Undo step. Returns a dict:
# vector {dx dy dz}, created (copy ids), comp (the new component name, if any).
# type nodes: elems holds node ids; a copy (any dup) is a set of new nodes, no component.
proc ::MeshForge::Translate::translate {elems nodes {axes {}} {dup ""} {distance {}} {type elems}} {
    variable label
    if {$type ni {elems nodes}} {error "Unknown entity type $type."}
    set elems [existing $elems $type]
    if {![llength $elems]} {error [expr {$type eq "nodes" ? "Select the nodes to move." : "Select the elements."}]}
    if {$dup ni {"" same current new}} {error "Unknown copy target $dup."}
    if {$type eq "nodes" && $dup ne ""} {set dup same}
    if {$distance eq {}} {
        lassign [motion $nodes $axes] dx dy dz
    } else {
        lassign [distance_motion $nodes $axes $distance] dx dy dz
    }
    set d [expr {sqrt($dx*$dx+$dy*$dy+$dz*$dz)}]
    if {$d <= 1e-12 && $dup eq ""} {error "The move is 0[expr {[llength $axes] ? " along [string toupper [join $axes {}]]" : ""}]: nothing to move."}
    if {$d > 1e-12} {set ux [expr {$dx/$d}]; set uy [expr {$dy/$d}]; set uz [expr {$dz/$d}]} else {set d 0}
    set cur [hm_info currentcomponent]
    set created {}; set comp ""
    set before [list [hm_count elems all 0 0] [hm_count comps all 0 0] [hm_count nodes all 0 0]]
    history_begin $label
    set code [catch {
        if {$type eq "nodes"} {
            set maxN [hm_entitymaxid nodes]
            *createmark nodes 1 {*}$elems
            if {$dup ne ""} {
                *duplicatemark nodes 1 0
                # the new nodes: ids above the old largest one (the mark is not relied on)
                *createmark nodes 1 "by id" "[expr {$maxN+1}]-[expr {$maxN+10000000}]"
                set created [hm_getmark nodes 1]
                if {[llength $created] != [llength $elems]} {error "duplicating gave [llength $created] new nodes"}
            }
            if {$d != 0} {
                *createvector 1 $ux $uy $uz
                *translatemark nodes 1 1 $d
            }
            *clearmark nodes 1
            return
        }
        *createmark elems 1 {*}$elems
        if {$dup ne ""} {
            if {$dup eq "new"} {
                set comp [new_comp_name]
                set srcComps [lsort -unique [hm_getvalue elems user_ids=$elems dataname=collector.id]]
                *createentity comps name=$comp
                if {[llength $srcComps] == 1} {
                    set pname ""
                    catch {set pname [hm_getvalue comps id=[lindex $srcComps 0] dataname=property.name]}
                    if {$pname ne "" && $pname ne "0"} {*createmark comps 1 $comp; catch {*propertyupdate comps 1 $pname}; *clearmark comps 1}
                }
                *currentcollector components $comp
                *createmark elems 1 {*}$elems
            }
            # *duplicatemark leaves the new elements on the mark (runtime 2022.3)
            *duplicatemark elems 1 [expr {$dup eq "same" ? 0 : 1}]
            set created [hm_getmark elems 1]
            if {[llength $created] != [llength $elems] || [lindex $created 0] in $elems} {error "duplicating gave [llength $created] new elements"}
        }
        if {$d != 0} {
            *createvector 1 $ux $uy $uz
            *translatemark elems 1 1 $d
        }
        *clearmark elems 1
        if {$cur ne "" && [hm_entityinfo exist comps $cur -byname]} {*currentcollector components $cur}
    } msg]
    history_end $label
    # the nodes branch ends with return (code 2): done
    if {$code == 2} {set code 0}
    if {$code} {
        # a copy half made is undone (only when this step wrote something)
        if {[list [hm_count elems all 0 0] [hm_count comps all 0 0] [hm_count nodes all 0 0]] ne $before} {catch {*undohistorystate 1}}
        error "Translating failed: $msg"
    }
    dict create vector [list $dx $dy $dz] created $created comp $comp
}

# ---------------------------------------------------------------- window
# What moves: the selected elements or the selected nodes (sel(kind)), highlighted natively
proc ::MeshForge::Translate::moving {} {
    variable sel
    expr {$sel(kind) eq "nodes" ? [existing $sel(move) nodes] : [existing $sel(elems)]}
}
proc ::MeshForge::Translate::highlight {} {
    variable sel
    *clearmark elems 2; *clearmark nodes 2
    set ids [moving]
    if {[llength $ids]} {*createmark $sel(kind) 2 {*}$ids; catch {hm_highlightmark $sel(kind) 2 high}}
    catch {hm_redraw}
}
proc ::MeshForge::Translate::clear_highlight {} {
    variable sel
    foreach type {elems nodes} ids [list [existing $sel(elems)] [existing $sel(move) nodes]] {
        if {[llength $ids]} {catch {*createmark $type 2 {*}$ids; hm_highlightmark $type 2 norm}}
        *clearmark $type 2
    }
    catch {hm_redraw}
}

# Select elements / Select nodes: the native mark panel; the new selection replaces the other kind
proc ::MeshForge::Translate::pick_move {type} {
    variable W; variable sel; variable status
    if {[winfo exists $W]} {wm withdraw $W}
    clear_highlight
    set key [expr {$type eq "nodes" ? "move" : "elems"}]
    *clearmark $type 1
    if {$sel(kind) eq $type && [llength [existing $sel($key) $type]]} {*createmark $type 1 {*}[existing $sel($key) $type]}
    catch {::TestToolSession::panel *createmarkpanel $type 1 "Translate: $type to move"}
    set ids [hm_getmark $type 1]
    *clearmark $type 1
    if {[llength $ids]} {
        set sel($key) $ids
        set sel(kind) $type
        if {$type eq "nodes"} {set sel(elems) {}} else {set sel(move) {}}
    }
    set status ""
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    copy_state
    refresh
}
proc ::MeshForge::Translate::pick_elems {} {pick_move elems}
# node 1 then node 2, in that order (a list keeps the pick order, a mark does not)
proc ::MeshForge::Translate::pick_nodes {} {
    variable W; variable sel; variable opt; variable status
    if {[winfo exists $W]} {wm withdraw $W}
    *clearlist nodes 1
    catch {::TestToolSession::panel *createlistpanel nodes 1 "Translate: node 1, then node 2 (direction 1 -> 2)"}
    set ids {}
    catch {set ids [hm_getlist nodes 1]}
    *clearlist nodes 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {[llength $ids] == 2} {
        set sel(nodes) $ids
        set status ""
    } elseif {[llength $ids]} {
        set status "Pick exactly two nodes ([llength $ids] picked)."
    }
    refresh
}

proc ::MeshForge::Translate::do_translate {} {
    variable sel; variable opt; variable status
    set dup [expr {$opt(dup) ? $opt(dupTo) : ""}]
    set ids [expr {$sel(kind) eq "nodes" ? $sel(move) : $sel(elems)}]
    if {[catch {
        set axes [selected_axes]
        set distance {}
        if {$opt(useDistance)} {
            set distance [string trim $opt(distance)]
            if {$distance eq {}} {error "Enter a positive distance in mm."}
        }
        translate $ids $sel(nodes) $axes $dup $distance $sel(kind)
    } r]} {
        set status $r
    } else {
        lassign [dict get $r vector] dx dy dz
        set v "([format %.6g $dx], [format %.6g $dy], [format %.6g $dz])"
        set what [expr {$sel(kind) eq "nodes" ? "nodes" : "elements"}]
        if {$dup eq ""} {
            set status "Moved [llength [moving]] $what by $v."
        } else {
            set status "Copied [llength [dict get $r created]] $what by $v"
            if {[dict get $r comp] ne ""} {append status " into [dict get $r comp]"}
            append status "."
        }
    }
    refresh
}

# Axes drop-down: All = the whole vector, else the components named (X, Y, Z, XY, XZ, YZ)
proc ::MeshForge::Translate::selected_axes {} {
    variable opt
    if {$opt(axes) eq "All"} {return {}}
    set axes {}
    foreach axis {x y z} {if {[string first [string toupper $axis] $opt(axes)] >= 0} {lappend axes $axis}}
    return $axes
}

proc ::MeshForge::Translate::update_action {} {
    variable W; variable sel; variable opt
    if {![winfo exists $W.foot.run]} {return}
    $W.body.dist configure -state [expr {$opt(useDistance) ? "normal" : "disabled"}]
    set ready [expr {[llength [moving]] && [llength $sel(nodes)] == 2}]
    $W.foot.run configure -state [expr {$ready ? "normal" : "disabled"}]
}

# Where a copy goes: only elements have components (a node copy is just new nodes)
proc ::MeshForge::Translate::copy_state {} {
    variable W; variable opt; variable sel
    set opt(dupTo) [dict get {"Same comp" same "Current comp" current "New comp" new} $opt(dupLabel)]
    if {![winfo exists $W.body.dupTo]} {return}
    $W.body.dupTo configure -state [expr {$opt(dup) && $sel(kind) eq "elems" ? "readonly" : "disabled"}]
}

proc ::MeshForge::Translate::reset {} {
    variable sel; variable status
    clear_highlight
    set sel(elems) {}; set sel(move) {}; set sel(nodes) {}; set sel(kind) elems
    set status Ready
    copy_state
    refresh
}
proc ::MeshForge::Translate::close {} {
    variable W
    reset
    destroy $W
}

proc ::MeshForge::Translate::refresh {} {
    variable W; variable sel; variable opt; variable status
    if {$status eq ""} {set status Ready}
    set n [llength [moving]]
    set opt(info,elems) [expr {$n ? "$n [expr {$sel(kind) eq "nodes" ? "nodes" : "elements"}]" : "nothing selected"}]
    if {[llength $sel(nodes)] == 2} {
        set v ""
        catch {lassign [motion $sel(nodes)] vx vy vz; set v "([format %.4g $vx], [format %.4g $vy], [format %.4g $vz])"}
        set opt(info,nodes) $v
    } else {
        set opt(info,nodes) "pick node 1, node 2"
    }
    if {![winfo exists $W]} {return}
    update_action
    highlight
}

# One grid in the order of use: what moves (elements or nodes, and how many), the direction (two
# nodes, the vector shown), how far (axes kept, an exact distance), and whether a copy moves.
proc ::MeshForge::Translate::show {} {
    variable W; variable status
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Translate"
    wm resizable $W 0 0
    set g [frame $W.body -padx 8 -pady 6]
    pack $g -fill x
    set run [list ::TestToolSession::run "Translate"]
    # what moves
    button $g.pickE -text "Select elements" -width 13 -command [concat $run ::MeshForge::Translate::pick_elems]
    button $g.pickN -text "Select nodes" -width 13 -command [concat $run [list {::MeshForge::Translate::pick_move nodes}]]
    label $g.info -textvariable ::MeshForge::Translate::opt(info,elems) -anchor w
    grid $g.pickE -row 0 -column 0 -sticky w -pady 2
    grid $g.pickN -row 0 -column 1 -sticky w -padx {4 0} -pady 2
    grid $g.info -row 1 -column 0 -columnspan 2 -sticky w -pady {0 4}
    # the direction: node 1 -> node 2
    button $g.nodes -text "By node" -width 13 -command [concat $run ::MeshForge::Translate::pick_nodes]
    label $g.vec -textvariable ::MeshForge::Translate::opt(info,nodes) -anchor w
    grid $g.nodes -row 2 -column 0 -sticky w -pady 2
    grid $g.vec -row 2 -column 1 -sticky w -padx {4 0}
    # how far: the axes kept (All = the whole vector) and an exact distance along it
    frame $g.ax
    label $g.ax.l -text "Axes"
    ttk::combobox $g.ax.c -width 4 -state readonly -values {All X Y Z XY XZ YZ} -textvariable ::MeshForge::Translate::opt(axes)
    bind $g.ax.c <<ComboboxSelected>> ::MeshForge::Translate::update_action
    pack $g.ax.l -side left -padx {0 4}
    pack $g.ax.c -side left
    frame $g.d
    checkbutton $g.useDist -text "Distance" -variable ::MeshForge::Translate::opt(useDistance) -command ::MeshForge::Translate::update_action
    entry $g.dist -textvariable ::MeshForge::Translate::opt(distance) -width 6 -justify right
    label $g.mm -text "mm"
    pack $g.useDist $g.dist $g.mm -in $g.d -side left
    raise $g.useDist; raise $g.dist; raise $g.mm
    grid $g.ax -row 3 -column 0 -sticky w -pady 2
    grid $g.d -row 3 -column 1 -sticky w -padx {4 0} -pady 2
    # a copy moves instead (where it goes: elements only)
    checkbutton $g.dup -text "Duplicate" -variable ::MeshForge::Translate::opt(dup) -command [concat $run ::MeshForge::Translate::copy_state]
    ttk::combobox $g.dupTo -width 12 -state readonly -values {"Same comp" "Current comp" "New comp"} -textvariable ::MeshForge::Translate::opt(dupLabel)
    bind $g.dupTo <<ComboboxSelected>> ::MeshForge::Translate::copy_state
    grid $g.dup -row 4 -column 0 -sticky w -pady 2
    grid $g.dupTo -row 4 -column 1 -sticky w -padx {4 0} -pady 2
    copy_state

    # Translate (green) on the left, Reset (light red) on the right
    frame $W.foot -padx 8 -pady 6
    button $W.foot.run -text "Translate" -width 10 -background #A8DDB0 -activebackground #8FD19E -command [concat $run ::MeshForge::Translate::do_translate]
    button $W.foot.reset -text "Reset" -width 8 -background #F2B8B5 -activebackground #E89E9A -command [concat $run ::MeshForge::Translate::reset]
    pack $W.foot.run -side left
    pack $W.foot.reset -side right
    pack $W.foot -fill x
    wm protocol $W WM_DELETE_WINDOW [concat $run ::MeshForge::Translate::close]
    set status ""
    refresh
    ::TestToolSession::place "Translate" $W
    wm deiconify $W
    ::TestToolSession::attach "Translate" $W
}

# Center over the HyperMesh main window, inside the work area of the monitor that holds it.
# A monitor left of or above the primary one has negative coordinates: no clamp to 0, and
# "+$x+$y" keeps them absolute ("%+d" of a negative number counts from the right edge).
proc ::MeshForge::Translate::place_center {} {
    variable W
    update idletasks
    update idletasks
    # Host: the Win32 frame of "." (the HyperWorks top-level window; "." is only its content area),
    # else that content area. wm geometry places the outer frame of W: add its border
    # (SM_CXSIZEFRAME + SM_CXPADDEDBORDER) and caption.
    set host [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $frame] l t r b
        set host [list $l $t [expr {$r - $l}] [expr {$b - $t}]]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set w [expr {[winfo reqwidth $W] + 2*$border}]
    set h [expr {[winfo reqheight $W] + $caption + 2*$border}]
    lassign [fit_box $host $work $w $h] x y
    wm geometry $W +$x+$y
}
# Top-left corner of a w x h frame centered on host {x y width height}, kept inside
# work {left top right bottom} when known (the top-left corner wins if the frame is larger).
proc ::MeshForge::Translate::fit_box {host work w h} {
    lassign $host hx hy hw hh
    set x [expr {$hx + ($hw - $w) / 2}]
    set y [expr {$hy + ($hh - $h) / 2}]
    if {[llength $work] == 4} {
        lassign $work left top right bottom
        set x [expr {max($left, min($x, $right - $w))}]
        set y [expr {max($top, min($y, $bottom - $h))}]
    }
    list $x $y
}

if {![info exists ::MeshForge_Translate_no_gui]} {::MeshForge::Translate::show}
