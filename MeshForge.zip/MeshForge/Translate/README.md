# Translate

Dịch element hoặc node đã chọn theo vector **node 2 − node 1** của hai node bạn chọn. Thứ tự chọn node quyết định chiều. HyperMesh 2022.3, profile Nastran.

- Điểm vào: [translate.tcl](translate.tcl). Menu: Utility → **test** → **Translate** (MAC [translate.mac](translate.mac), sinh bằng bộ sinh menu), hoặc Toolbox → **Translate**.
- Cửa sổ mở giữa cửa sổ HyperMesh. Mở cửa sổ và chọn không đổi model; chỉ nút **Translate** ghi vào model. Thông báo hiện ở thanh trạng thái của HyperMesh.

## Cách dùng (cập nhật 23/11/2026)

Cửa sổ xếp theo thứ tự thao tác, mỗi hàng một bước:

1. **Select elements** hoặc **Select nodes**: chọn thứ cần dịch bằng panel native. Lựa chọn mới thay cho loại kia (chỉ dịch element hoặc chỉ dịch node). Dòng dưới hiện số lượng, ví dụ `12 elements` hoặc `2 nodes`. Thứ đang chọn được tô sáng tới khi bấm **Reset**.
   - Dịch element: dời mọi node của các element đó, element nối với chúng giãn theo (như panel translate native).
   - Dịch node: chỉ các node đã chọn dời đi, các element trên chúng giãn theo.
2. **By node**: chọn node 1 rồi node 2. Bên cạnh hiện vector, ví dụ `(3, -4, 12)`.
3. **Axes**: `All` dùng cả vector; `X`, `Y`, `Z`, `XY`, `XZ`, `YZ` chỉ giữ các thành phần đó. **Distance** (cùng hàng): khi tích, vector đã lọc trục được đưa về đúng độ dài này (mm), chiều vẫn từ node 1 sang node 2.
4. **Duplicate**: chép trước rồi dịch bản chép, bản gốc giữ nguyên.
   - Element: chọn nơi đặt bản chép: `Same comp`, `Current comp` hoặc `New comp` (`translate_copy`, lấy property của component nguồn khi mọi element cùng một component).
   - Node: bản chép là các node mới, không có component, nên ô chọn nơi đặt bị tắt.
5. **Translate** (xanh, bên trái) ghi vào model, mỗi lần là một bước Undo `Element translate`. **Reset** (đỏ nhạt, bên phải) bỏ lựa chọn.

## Kiểm chứng (21–22/11/2026, HyperMesh 2022.3, scratch riêng của agent qua `run_probe.py`)

- Bản cập nhật ngày 22/11/2026 (khung **Select** / **Translate**, bắt buộc chọn ít nhất 1 trục `Axes`, tuỳ chọn `Distance (mm)`, giữ `Duplicate` và đưa thanh `status` xuống dưới đường kẻ ngang `1 px` `#AFBAC2`): [Probe](tests/probe_translate.tcl), run `67c1136a73b04f9dadd9f226df428925`: **44/44 PASS**, ảnh [window_1.png](tests/runs/67c1136a73b04f9dadd9f226df428925/window_1.png) đã xem.
- Bản ngày 21/11/2026: [Probe](tests/probe_translate.tcl), run `845e1926`: **30/30 PASS**.
- Dịch theo hai node chênh (3, −4, 12):
  - Không tích ô nào: (3, −4, 12). Only X: (3, 0, 0). Only Y Z: (0, −4, 12). Đủ ba ô: (3, −4, 12). Đảo thứ tự node: (−3, 4, −12).
  - Mọi node của element đã chọn dịch đúng vector (1e-9), node khác giữ nguyên; mỗi lần một Undo.
  - Năm ca từ chối, model không đổi: không có element; không có node; một node; hai node trùng; Only X khi dx = 0.
- Duplicate (Same / Current / New comp):
  - 2 bản chép (Only X với hai node chênh x 5), mỗi bản trùng một element gốc dịch đúng +5 (1e-9); bản gốc không đổi.
  - Bản chép nằm đúng component P / CUR / translate_copy; New comp nhận property PSHELL của P.
  - Component hiện hành vẫn là CUR; một Undo gỡ bản chép và component mới.
- Cửa sổ mở qua đúng điểm vào menu; highlight trên mark 2; ảnh đã xem (khung Move với Nodes... và Only X / Y / Z; ô Duplicate làm tiêu đề khung).

Chưa kiểm: chọn bằng tay trên panel trong phiên người dùng. Theo yêu cầu người dùng, chỉ đưa sang dist sau khi thử OK.

## Vị trí cửa sổ (22/11/2026, ticket `02-window-on-host-monitor`)

- Lỗi cũ: căn giữa theo Tk `.` rồi kẹp `max(x,0)`/`max(y,0)`. Màn hình bên trái hoặc phía trên màn chính có tọa độ âm (máy người dùng: màn trái x từ −2560 đến 0, HyperMesh phóng to ở đó), nên cửa sổ bị đẩy sang mép trái màn chính.
- Nay `place_center` căn khung ngoài của cửa sổ (cộng viền và thanh tiêu đề theo `GetSystemMetrics`) vào giữa khung Win32 của `[wm frame .]` (cửa sổ HyperWorks; Tk `.` chỉ là vùng nội dung bên trong), giữ cửa sổ trong vùng làm việc của màn hình chứa HyperMesh và viết `+$x+$y` để giữ tọa độ âm. Không có twapi thì căn theo vùng nội dung `.`, không giới hạn vùng làm việc.
- Kiểm trên scratch HyperMesh 2022.3 riêng (chỉ thử vị trí, không đổi model): [tests/gui_place.tcl](tests/gui_place.tcl) run `54abacc20db24127b85cd6c80041cd28` **13/13 PASS**. Mở qua `*evaltclscript` như nút MAC trong ba ca: scratch ở màn chính; khung scratch dời sang màn trái tọa độ âm (`SetWindowPos`, không kích hoạt) với hình chữ nhật phóng to như HyperMesh của người dùng; rồi cửa sổ nhỏ trên màn đó. Tâm cửa sổ lệch tâm khung HyperMesh ≤ 0,5 px, cùng màn hình, nằm trong vùng làm việc, khung ngoài thực bằng khung tính trước. Ảnh ghép `overlay.png` trong run đã xem. [tests/place_math.tcl](tests/place_math.tcl) chạy bằng tclsh 8.5.9 của Altair: 11/11 bố cục có tọa độ âm (màn trái, trên, trái-trên, tràn mép, cửa sổ lớn hơn vùng làm việc).
- Chưa kiểm: mở từ menu trong phiên người dùng; hai màn khác DPI (viền tính theo DPI hệ thống).

## Cập nhật 22/11/2026 (giao diện)

- Bỏ các group. Thứ tự hàng: **Select elements**; **By node** (chỉ hiện vector); Axes (danh sách All, X, Y, Z, XY, XZ, YZ) cùng hàng với Distance; Duplicate cùng danh sách Same comp / Current comp / New comp.
- Distance với Axes = All: dịch đúng khoảng cách đó theo hướng vector node 1 → node 2 (trước đây báo lỗi khi không chọn trục).
- Translate (xanh nhạt) bên trái, Reset (đỏ nhạt) bên phải; bỏ Close (đóng bằng nút X). Không còn dòng status trong cửa sổ: thông báo hiện trên thanh status của HyperMesh (`hm_usermessage`).
- Kiểm: `tests/probe_translate.tcl` trên scratch HyperMesh 2022.3, 44/44 PASS, đã xem ảnh cửa sổ.


## Cập nhật 23/11/2026: chọn node, xếp lại cửa sổ

- Thêm **Select nodes**: `translate ... nodes` dời các node đã chọn; Duplicate dùng `*duplicatemark nodes 1 0`, node mới là các id lớn hơn id lớn nhất trước đó.
- Cửa sổ xếp lại thành một lưới hai cột theo thứ tự thao tác (chọn → hướng → khoảng cách → nhân bản), bỏ khoảng trống thừa. Kích thước khoảng 296 × 233 px.
- [probe_translate.tcl](tests/probe_translate.tcl) đạt **50/50** trên scratch HyperMesh 2022.3. Có thêm ca dịch node, nhân bản node (mỗi node gốc có đúng một node mới ở vị trí + vector), một Undo, từ chối khi chưa chọn, và dịch node qua cửa sổ. [Kết quả](tests/runs/3cd27d4855244c35a5fd6c149462cdc2/checks.txt) · [Ảnh cửa sổ](tests/runs/3cd27d4855244c35a5fd6c149462cdc2/window_1.png)
- Chưa thử bằng chuột thật trong phiên người dùng.