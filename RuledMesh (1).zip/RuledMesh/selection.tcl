# Extract corner-node paths from native node and PLOTEL selection.
proc ::RuledMesh::corner_nodes {nodes} {
    if {![llength $nodes]} {return {}}
    # An edge marker or a linear element can also reference a shell midside.
    set saved [hm_getmark elems 1]
    set code [catch {
        *createmark elems 1 "by node" {*}[lsort -integer -unique $nodes]
        set attached [hm_getmark elems 1]
        set midsides {}
        for {set i 0} {$i < [llength $attached]} {incr i 1024} {
            set batch [lrange $attached $i $i+1023]
            set shells {}
            foreach id $batch config [hm_getvalue elems user_ids=$batch dataname=config] {
                if {$config in {106 108}} {lappend shells $id}
            }
            if {![llength $shells]} {continue}
            foreach row [hm_getvalue elems user_ids=$shells dataname=nodes] {
                foreach id [lrange $row [expr {[llength $row]/2}] end] {
                    dict set midsides $id 1
                }
            }
        }
    } message options]
    *clearmark elems 1
    if {[llength $saved]} {*createmark elems 1 "by id only" {*}$saved}
    if {$code} {return -options $options $message}
    set result {}
    foreach node $nodes {
        if {[llength $result] && $node == [lindex $result end]} {continue}
        if {![dict exists $midsides $node] && ![hm_nodeismidnode $node]} {lappend result $node}
    }
    return $result
}

proc ::RuledMesh::edge_adjacency {edges} {
    set adjacent {}
    foreach edge [lsort -unique $edges] {
        lassign $edge a b
        if {$a == $b} {error "A selected edge has coincident node IDs."}
        dict lappend adjacent $a $b
        dict lappend adjacent $b $a
    }
    return $adjacent
}

proc ::RuledMesh::trace_edge_path {edges start closed} {
    set adjacent [edge_adjacency $edges]
    if {![dict exists $adjacent $start]} {error "The selection did not contain an edge path."}

    set visited {}
    set queue [list $start]
    set ends {}
    for {set i 0} {$i < [llength $queue]} {incr i} {
        set node [lindex $queue $i]
        if {[dict exists $visited $node]} {continue}
        dict set visited $node 1
        set next [dict get $adjacent $node]
        if {[llength $next] > 2} {error "The picked edge connects to a branch. Select an unbranched rim."}
        if {[llength $next] == 1} {lappend ends $node}
        lappend queue {*}$next
    }
    if {$closed && [llength $ends]} {error "This rim is open. Complete the selection or clear Closed loops."}
    if {!$closed && [llength $ends] != 2} {error "This rim is closed. Enable Closed loops."}
    if {!$closed} {set start [lindex $ends 0]}

    set result {}
    set previous {}
    set node $start
    while {$node ne {}} {
        lappend result $node
        set next {}
        foreach other [dict get $adjacent $node] {
            if {$other ne $previous && $other ne $start} {set next $other; break}
        }
        set previous $node
        set node $next
    }
    if {[llength $result] != [dict size $visited]} {error "The edge path is incomplete."}
    return $result
}

proc ::RuledMesh::path_between {adjacent start stop excluded} {
    set parent [dict create $start {}]
    set queue [list $start]
    for {set i 0} {$i < [llength $queue]} {incr i} {
        set node [lindex $queue $i]
        if {$node == $stop} {
            set path [list $node]
            while {$node != $start} {
                set node [dict get $parent $node]
                lappend path $node
            }
            return [lreverse $path]
        }
        foreach next [dict get $adjacent $node] {
            if {![dict exists $parent $next] && [edge_key $node $next] ni $excluded} {
                dict set parent $next $node
                lappend queue $next
            }
        }
    }
    return {}
}

proc ::RuledMesh::cycle_from_edge {edges a b} {
    set adjacent [edge_adjacency $edges]
    set seed [edge_key $a $b]
    if {$seed ni $edges} {error "The selected PLOTEL segment is unavailable."}
    set path [path_between $adjacent $a $b [list $seed]]
    if {![llength $path]} {error "This rim is open. Complete the selection or clear Closed loops."}
    # A second path would produce a different cycle through the exact picked segment.
    # This allows another rim to meet at one node without following that rim.
    foreach node [lrange $path 0 end-1] edge [path_edges $path] {
        if {[llength [dict get $adjacent $node]] > 2 &&
            [llength [path_between $adjacent $a $b [list $seed $edge]]]} {
            return -code error -errorcode {RULEDMESH AMBIGUOUS_PLOTEL} \
                "More than one rim passes through this PLOTEL segment."
        }
    }
    return $path
}

# A simple cycle can never leave the biconnected block containing its seed.
proc ::RuledMesh::cycle_block {adjacent a b} {
    set seed [edge_key $a $b]
    if {![dict exists $adjacent $a] || $b ni [dict get $adjacent $a]} {return {}}
    set depth [dict create $a 1]
    set low $depth
    set parents {}
    set clock 1
    set stack [list $a]
    set offsets {0}
    set edges {}
    while {[llength $stack]} {
        set u [lindex $stack end]
        set index [lindex $offsets end]
        set neighbors [dict get $adjacent $u]
        if {$index < [llength $neighbors]} {
            lset offsets end [expr {$index+1}]
            set v [lindex $neighbors $index]
            if {![dict exists $depth $v]} {
                dict set parents $v $u
                dict set depth $v [incr clock]
                dict set low $v $clock
                lappend edges [edge_key $u $v]
                lappend stack $v
                lappend offsets 0
            } elseif {[dict get $depth $v] < [dict get $depth $u] &&
                (![dict exists $parents $u] || [dict get $parents $u] != $v)} {
                dict set low $u [expr {min([dict get $low $u],[dict get $depth $v])}]
                lappend edges [edge_key $u $v]
            }
            continue
        }
        set stack [lrange $stack 0 end-1]
        set offsets [lrange $offsets 0 end-1]
        if {![dict exists $parents $u]} {continue}
        set parent [dict get $parents $u]
        set reach [dict get $low $u]
        dict set low $parent [expr {min([dict get $low $parent],$reach)}]
        if {$reach >= [dict get $depth $parent]} {
            set first [edge_key $parent $u]
            set block {}
            while {[llength $edges]} {
                set key [lindex $edges end]
                set edges [lrange $edges 0 end-1]
                lappend block $key
                if {$key eq $first} {break}
            }
            if {$seed in $block} {return $block}
        }
    }
    return {}
}

proc ::RuledMesh::cycles_through_edge {edges a b hint limit} {
    set block [cycle_block [edge_adjacency $edges] $a $b]
    if {[llength $block] < 3 || ($hint ne {} && $hint ni $block)} {return {}}
    set adjacent [edge_adjacency $block]
    set seed [edge_key $a $b]
    set path [list $a]
    set nextIndex {0}
    set visited [dict create $a 1]
    set match {}
    set steps 0
    while {[llength $path]} {
        set node [lindex $path end]
        set neighbors [dict get $adjacent $node]
        set index [lindex $nextIndex end]
        if {$index >= [llength $neighbors]} {
            dict unset visited $node
            set path [lrange $path 0 end-1]
            set nextIndex [lrange $nextIndex 0 end-1]
            continue
        }
        lset nextIndex end [expr {$index+1}]
        set next [lindex $neighbors $index]
        if {[dict exists $visited $next] || [edge_key $node $next] eq $seed} {continue}
        if {[incr steps] > 50000} {
            error "Too many connected edge paths. Pick an unshared outer segment or use By path."
        }
        if {$next == $b} {
            set candidate [concat $path $b]
            if {$hint eq {} || $hint in [path_edges $candidate]} {
                lappend match $candidate
                if {[llength $match] >= $limit} {return $match}
            }
            continue
        }
        lappend path $next
        lappend nextIndex 0
        dict set visited $next 1
    }
    return $match
}

proc ::RuledMesh::cycle_through_two_edges {edges a b hint} {
    set matches [cycles_through_edge $edges $a $b $hint 2]
    if {![llength $matches]} {error "The two segments do not belong to the same closed rim."}
    if {[llength $matches] > 1} {
        set outer [outer_plotel_cycle $edges $a $b $hint]
        if {[llength $outer]} {return $outer}
        error "Both segments still belong to multiple rims. Pick a segment farther around the intended rim."
    }
    return [lindex $matches 0]
}

proc ::RuledMesh::outer_plotel_cycle {edges a b {hint {}}} {
    set cycles [cycles_through_edge $edges $a $b $hint 17]
    if {[llength $cycles] == 17 || ![llength $cycles]} {return {}}
    if {[llength $cycles] == 1} {return [lindex $cycles 0]}
    set ids [lsort -integer -unique [concat {*}$cycles]]
    set xyz [coordinates $ids]
    set frame [rim_projection_frame [polygon_points $ids $xyz]]
    if {$frame eq {}} {return {}}
    set points {}
    dict for {id xyzPoint} $xyz {
        set local [project $frame $xyzPoint]
        if {abs([lindex $local 2]) > 0.25} {return {}}
        dict set points $id $local
    }
    set ranked {}
    foreach cycle $cycles {
        lappend ranked [list [expr {abs([polygon_area2 [polygon_points $cycle $points]])}] $cycle]
    }
    set ranked [lsort -real -decreasing -index 0 $ranked]
    lassign [lindex $ranked 0] area outer
    if {$area <= 1.0e-8 || $area-[lindex $ranked 1 0] <= 1.0e-8} {return {}}
    set polygon [polygon_points $outer $points]
    set index [polygon_scan_index $polygon]
    set outerPairs [path_edges [concat $outer [lindex $outer 0]]]
    set count [llength $outerPairs]
    for {set i 0} {$i < $count} {incr i} {
        for {set j [expr {$i+2}]} {$j < $count} {incr j} {
            if {$i == 0 && $j == $count-1} {continue}
            lassign [polygon_points [lindex $outerPairs $i] $points] p q
            lassign [polygon_points [lindex $outerPairs $j] $points] r s
            if {[segments_intersect $p $q $r $s]} {return {}}
        }
    }
    foreach candidate [lrange $ranked 1 end] {
        set path [lindex $candidate 1]
        foreach id $path {
            if {$id in $outer} {continue}
            lassign [dict get $points $id] x y
            if {![point_in_polygon $index $x $y]} {return {}}
        }
        foreach key [path_edges [concat $path [lindex $path 0]]] {
            if {$key in $outerPairs} {continue}
            lassign [polygon_points $key $points] p q
            lassign $p px py
            lassign $q qx qy
            if {![point_in_polygon $index [expr {($px+$qx)/2.0}] [expr {($py+$qy)/2.0}]]} {return {}}
            foreach edge $outerPairs {
                lassign $edge u v
                if {$u in $key || $v in $key} {continue}
                lassign [polygon_points $edge $points] r s
                if {[segments_intersect $p $q $r $s]} {return {}}
            }
        }
    }
    return $outer
}

proc ::RuledMesh::visible_plotel_segments {segments} {
    set byId {}
    dict for {key ids} $segments {
        foreach id $ids {dict set byId $id $key}
    }
    set saved [hm_getmark elems 1]
    set code [catch {
        *createmark elems 1 displayed
        hm_getmark elems 1
    } displayed options]
    *clearmark elems 1
    if {[llength $saved]} {*createmark elems 1 "by id only" {*}$saved}
    if {$code} {return -options $options $displayed}
    set filtered {}
    foreach id $displayed {
        if {[dict exists $byId $id]} {dict lappend filtered [dict get $byId $id] $id}
    }
    return $filtered
}

# Mixed-order shells can emit both a corner-to-corner PLOTEL and two
# PLOTELs through the same midside. They represent one boundary edge.
proc ::RuledMesh::normalize_plotel_segments {segments {classificationVar {}}} {
    if {$classificationVar ne {}} {upvar 1 $classificationVar classification}
    set classification {}
    set adjacent [edge_adjacency [dict keys $segments]]
    set splitEdges {}
    dict for {node neighbors} $adjacent {
        if {[llength $neighbors] != 2} {continue}
        set direct [edge_key {*}$neighbors]
        if {[dict exists $segments $direct]} {dict set splitEdges $node $direct}
    }
    set candidates [dict keys $splitEdges]
    if {$classificationVar ne {}} {lappend candidates {*}[concat {*}[dict values $splitEdges]]}
    set candidates [lsort -integer -unique $candidates]
    foreach node $candidates {dict set classification $node 0}
    foreach node [corner_nodes $candidates] {dict set classification $node 1}
    dict for {node direct} $splitEdges {
        if {[dict get $classification $node]} {continue}
        foreach corner $direct {
            set half [edge_key $node $corner]
            if {[dict exists $segments $half] && [dict exists $segments $direct]} {
                dict lappend segments $direct {*}[dict get $segments $half]
                dict unset segments $half
            }
        }
    }
    return $segments
}

proc ::RuledMesh::plotel_segments {ids {strict 0} {classificationVar {}}} {
    if {$classificationVar ne {}} {upvar 1 $classificationVar classification}
    set segments {}
    for {set i 0} {$i < [llength $ids]} {incr i 1024} {
        set chunk [lrange $ids $i $i+1023]
        set types [hm_getvalue elems user_ids=$chunk dataname=typename]
        set rows [hm_getvalue elems user_ids=$chunk dataname=nodes]
        foreach id $chunk type $types nodes $rows {
            if {$type eq "PLOTEL" && [llength $nodes] == 2} {
                dict lappend segments [edge_key {*}$nodes] $id
            } elseif {$strict} {
                error "Select only valid red PLOTEL segments."
            }
        }
    }
    if {$classificationVar ne {}} {return [normalize_plotel_segments $segments classification]}
    return [normalize_plotel_segments $segments]
}

# The PLOTELs of one collector joined to seed through shared nodes. The PLOTELs of the collector
# are read once (a few chunked reads) and kept in plotelCache while the collector holds the same
# elements (count and largest id); the network is then walked in Tcl. Growing it layer by layer with
# the native cross reference cost one native call per layer: fast on a short loop, very slow on a
# long one.
proc ::RuledMesh::plotel_component {seed collector} {
    variable plotelCache
    if {![info exists plotelCache]} {set plotelCache [dict create]}
    *createmark elems 1 "by collector id" $collector
    set all [hm_getmark elems 1]
    *clearmark elems 1
    set key [list [hm_getcurrentmodel] [llength $all] [expr {[llength $all] ? [tcl::mathfunc::max {*}$all] : 0}]]
    if {![dict exists $plotelCache $collector] || [lindex [dict get $plotelCache $collector] 0] ne $key} {
        set byNode [dict create]; set nodesOf [dict create]
        for {set i 0} {$i < [llength $all]} {incr i 4096} {
            set chunk [lrange $all $i [expr {$i+4095}]]
            foreach e $chunk type [hm_getvalue elems user_ids=$chunk dataname=typename] row [hm_getvalue elems user_ids=$chunk dataname=nodes] {
                if {$type ne "PLOTEL"} {continue}
                dict set nodesOf $e $row
                foreach n $row {dict lappend byNode $n $e}
            }
        }
        dict set plotelCache $collector [list $key $byNode $nodesOf]
    }
    lassign [dict get $plotelCache $collector] key byNode nodesOf
    if {![dict exists $nodesOf $seed]} {return [plotel_component_native $seed $collector]}
    set done [dict create $seed 1]
    set front [list $seed]
    while {[llength $front]} {
        set next {}
        foreach e $front {
            foreach n [dict get $nodesOf $e] {
                foreach f [dict get $byNode $n] {if {![dict exists $done $f]} {dict set done $f 1; lappend next $f}}
            }
        }
        set front $next
    }
    dict keys $done
}
# The older walk (native cross reference per layer), kept for a seed the cache does not know.
proc ::RuledMesh::plotel_component_native {seed collector} {
    set done [dict create $seed 1]
    set front [list $seed]
    set seenNodes [dict create]
    while {[llength $front]} {
        set nodes {}
        foreach row [hm_getvalue elems user_ids=$front dataname=nodes] {
            foreach n $row {if {![dict exists $seenNodes $n]} {dict set seenNodes $n 1; lappend nodes $n}}
        }
        if {![llength $nodes]} {break}
        *createmark nodes 1 "by id only" {*}$nodes
        *clearmark elems 2
        hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
        set near [hm_getmark elems 2]
        *clearmark nodes 1; *clearmark elems 2
        set new {}
        foreach e $near {if {![dict exists $done $e]} {lappend new $e}}
        set front {}
        if {[llength $new]} {
            foreach e $new type [hm_getvalue elems user_ids=$new dataname=typename]                     c [hm_getvalue elems user_ids=$new dataname=collector.id] {
                if {$type eq "PLOTEL" && $c == $collector} {dict set done $e 1; lappend front $e}
            }
        }
    }
    dict keys $done
}

proc ::RuledMesh::loop_from_plotel {seed {closed 1} {segmentsVar {}} {hint {}} {indexVar {}}} {
    if {$indexVar ne {}} {upvar 1 $indexVar index}
    set collector [hm_getvalue elems id=$seed dataname=collector.id]
    if {![info exists index] || ![dict exists $index $collector] ||
            ![dict exists [lindex [dict get $index $collector] 1] $seed]} {
        # only the PLOTELs joined to the picked one (not the whole free-edge collector)
        set ids [plotel_component $seed $collector]
        set segments [plotel_segments $ids 0 classification]
        set byId {}
        dict for {edge plotels} $segments {
            foreach id $plotels {dict set byId $id $edge}
        }
        dict set index $collector [list $segments $byId $classification]
    }
    lassign [dict get $index $collector] segments byId classification
    if {![dict exists $byId $seed]} {error "Pick one red PLOTEL free-edge segment."}
    lassign [dict get $byId $seed] a b
    set edges [dict keys $segments]
    # Walk the raw segments first, since a quadratic edge can be two PLOTELs.
    if {$closed && $hint ne {}} {
        if {![dict exists $byId $hint]} {
            error "Pick a second red PLOTEL segment from the same free-edge collector."
        }
        set hintEdge [dict get $byId $hint]
        if {$hintEdge eq [edge_key $a $b]} {
            return -code error -errorcode {RULEDMESH SAME_PLOTEL} "Pick a different segment on the intended rim."
        }
        set visible [visible_plotel_segments $segments]
        if {[dict exists $visible [edge_key $a $b]] && [dict exists $visible $hintEdge] &&
                [dict size $visible] < [dict size $segments] &&
                ![catch {cycle_through_two_edges [dict keys $visible] $a $b $hintEdge} rawPath]} {
            set segments $visible
        } else {
            set rawPath [cycle_through_two_edges $edges $a $b $hintEdge]
        }
    } elseif {$closed} {
        if {[catch {cycle_from_edge $edges $a $b} rawPath options]} {
            if {[dict get $options -errorcode] ne {RULEDMESH AMBIGUOUS_PLOTEL}} {
                return -options $options $rawPath
            }
            if {![catch {
                set visible [visible_plotel_segments $segments]
                set visibleEdges [dict keys $visible]
                if {[catch {cycle_from_edge $visibleEdges $a $b} resolved visibleOptions] &&
                    [dict get $visibleOptions -errorcode] eq {RULEDMESH AMBIGUOUS_PLOTEL}} {
                    set resolved [outer_plotel_cycle $visibleEdges $a $b]
                }
            }] && [info exists resolved] && [llength $resolved] >= 3 &&
                    [lindex $resolved 0] eq $a && [lindex $resolved end] eq $b} {
                set rawPath $resolved
                set segments $visible
            } elseif {![catch {outer_plotel_cycle $edges $a $b} inferred] && [llength $inferred]} {
                set rawPath $inferred
            } else {
                return -options $options $rawPath
            }
        }
    } else {
        set rawPath [trace_edge_path $edges $a 0]
    }
    set unclassified {}
    foreach node $rawPath {
        if {![dict exists $classification $node]} {lappend unclassified $node}
    }
    foreach node $unclassified {dict set classification $node 0}
    foreach node [corner_nodes $unclassified] {dict set classification $node 1}
    dict set index $collector [list [lindex [dict get $index $collector] 0] $byId $classification]
    set path {}
    foreach node $rawPath {
        if {[dict get $classification $node]} {lappend path $node}
    }
    if {[llength $path] < 2 + $closed} {error "The selected rim has too few corner nodes."}
    if {$segmentsVar ne {}} {
        upvar 1 $segmentsVar pickedSegments
        if {$closed} {lappend rawPath [lindex $rawPath 0]}
        set pickedSegments {}
        foreach edge [path_edges $rawPath] {lappend pickedSegments {*}[dict get $segments $edge]}
    }
    return $path
}

proc ::RuledMesh::selected_shell_edges {nodes shells} {
    set selected {}
    foreach node $nodes {dict set selected $node 1}
    set counts {}
    set directed {}
    set touches 0
    dict for {id shell} $shells {
        set corners [lindex $shell 0]
        foreach a $corners b [concat [lrange $corners 1 end] [lindex $corners 0]] {
            if {![dict exists $selected $a]} {continue}
            set touches 1
            if {[dict exists $selected $b]} {
                set key [edge_key $a $b]
                dict incr counts $key
                dict set directed $key [list $a $b]
            }
        }
    }
    return [list $counts $directed $touches]
}

proc ::RuledMesh::order_shell_boundary {nodes closed shells {allowFreeNodes 0}} {
    if {[llength $nodes] < 2 + $closed} {error "Select a free-edge path with enough corner nodes."}
    lassign [selected_shell_edges $nodes $shells] counts directed touches
    if {!$touches && $allowFreeNodes} {return $nodes}
    set edges {}
    dict for {edge count} $counts {
        if {$count == 1} {lappend edges $edge}
    }
    set path [trace_edge_path $edges [lindex $nodes 0] $closed]
    if {[llength $path] != [llength [lsort -integer -unique $nodes]]} {error "Select one connected free-edge path."}
    if {$closed} {
        lassign $path a b
        if {[dict get $directed [edge_key $a $b]] eq [list $a $b]} {
            set path [linsert [lreverse [lrange $path 1 end]] 0 $a]
        }
    }
    return $path
}

proc ::RuledMesh::shell_free_edges {shells} {
    set counts {}
    dict for {id shell} $shells {
        set corners [lindex $shell 0]
        foreach a $corners b [concat [lrange $corners 1 end] [lindex $corners 0]] {
            dict incr counts [edge_key $a $b]
        }
    }
    set free {}
    dict for {key count} $counts {
        if {$count == 1} {lappend free $key}
    }
    return $free
}

proc ::RuledMesh::complete_free_loop {nodes shells} {
    set free [shell_free_edges $shells]
    set first [lindex $nodes 0]
    set adjacent [edge_adjacency $free]
    if {![dict exists $adjacent $first]} {return $nodes}
    set loops {}
    foreach next [dict get $adjacent $first] {
        if {[catch {cycle_from_edge $free $first $next} loop]} {continue}
        set present 1
        foreach id $nodes {
            if {$id ni $loop} {set present 0; break}
        }
        if {$present} {dict set loops [lsort -integer $loop] $loop}
    }
    if {[dict size $loops] == 1} {return [lindex [dict values $loops] 0]}
    foreach id $nodes {
        if {![dict exists $adjacent $id]} {return $nodes}
    }
    error "The selected nodes do not identify one closed free edge. Pick a red segment with By edge, or clear Closed loops for open paths."
}

proc ::RuledMesh::rim_projection_frame {points} {
    set center [center_of $points]
    set longest 0.0
    set offsets {}
    foreach point $points {
        set offset [difference $point $center]
        lappend offsets $offset
        set length [dot $offset $offset]
        if {$length > $longest} {set longest $length; set axis $offset}
    }
    if {$longest <= 0} {return {}}
    set widest 0.0
    foreach offset $offsets {
        set candidate [cross $axis $offset]
        set length [dot $candidate $candidate]
        if {$length > $widest} {set widest $length; set normal $candidate}
    }
    if {$widest <= 1.0e-16*$longest*$longest} {return {}}
    set u [unit $axis]
    set normal [unit $normal]
    return [list $center $u [cross $normal $u] $normal [expr {sqrt($longest)}]]
}

proc ::RuledMesh::order_planar_ring {nodes xyz} {
    set points [polygon_points $nodes $xyz]
    set frame [rim_projection_frame $points]
    if {$frame eq {}} {return $nodes}
    set angular {}
    foreach id $nodes point $points {
        lassign [project $frame $point] x y z
        if {abs($z) > 1.0e-6} {return $nodes}
        lappend angular [list [expr {atan2($y,$x)}] $id [list $x $y]]
    }
    set sorted [lsort -real -index 0 $angular]
    set ring [concat $sorted [lrange $sorted 0 1]]
    set ordered {}
    foreach a $sorted b [lrange $ring 1 end-1] c [lrange $ring 2 end] {
        if {[signed_area2 [lindex $a 2] [lindex $b 2] [lindex $c 2]] < -1.0e-10} {
            # An unattached concave ring needs its supplied path order.
            return $nodes
        }
        lappend ordered [lindex $a 1]
    }
    set ordered [rotate $ordered [lsearch -exact $ordered [lindex $nodes 0]]]
    if {$ordered eq [linsert [lreverse [lrange $nodes 1 end]] 0 [lindex $nodes 0]]} {return $nodes}
    return $ordered
}

proc ::RuledMesh::order_selected_path {nodes closed shells xyz} {
    set chosen {}
    foreach id $nodes {dict set chosen $id 1}
    set nodes [dict keys $chosen]
    if {[llength $nodes] < 2 + $closed} {error "Select enough corner nodes for each path."}
    lassign [selected_shell_edges $nodes $shells] counts directed touches
    if {!$touches} {
        if {$closed} {return [order_planar_ring $nodes $xyz]}
        return $nodes
    }
    set free {}
    dict for {key count} $counts {
        if {$count == 1} {lappend free $key}
    }
    foreach edges [list $free [dict keys $counts]] {
        if {![catch {trace_edge_path $edges [lindex $nodes 0] $closed} ordered] &&
            [llength $ordered] == [llength $nodes]} {return $ordered}
    }
    # An ordered selection can skip shell nodes or intentionally cross gaps.
    return $nodes
}

proc ::RuledMesh::path_from_plotels {ids closed} {
    set edges [dict keys [plotel_segments $ids 1]]
    set selected [edge_adjacency $edges]
    set path [trace_edge_path $edges [lindex [dict keys $selected] 0] $closed]
    if {[llength $path] != [dict size $selected]} {error "Select segments from one connected edge."}
    set path [corner_nodes $path]
    if {[llength $path] < 2 + $closed} {error "The selected edge has too few corner nodes."}
    return $path
}

proc ::RuledMesh::pick_selection {mode label closed {previousNodes {}} {previousElements {}}} {
    variable pendingPlotel
    if {$mode ne "edge" && [info exists pendingPlotel($label)]} {unset pendingPlotel($label)}
    if {$mode in {path nodes}} {
        if {[llength $previousNodes]} {
            lassign [edit_selection_mark nodes $previousNodes "$label: add or remove nodes."] accepted ids
            if {!$accepted} {return {}}
            set selected {}
            foreach id $ids {dict set selected $id 1}
            set order {}
            foreach id $previousNodes {
                if {[dict exists $selected $id]} {lappend order $id; dict unset selected $id}
            }
            return [dict create nodes [corner_nodes [concat $order [dict keys $selected]]] elements {}]
        }
        if {$mode eq "path"} {
            set panel *createlistbypathpanel
            set prompt "$label: pick nodes along the path."
        } else {
            set panel *createlistpanel
            set prompt "$label: pick corner nodes in order."
        }
        set nodes [corner_nodes [pick_node_list $panel $prompt]]
        if {![llength $nodes]} {return {}}
        return [dict create nodes $nodes elements {}]
    }
    if {[llength $previousElements]} {
        lassign [edit_selection_mark elems $previousElements "$label: add or remove PLOTEL segments."] accepted ids
        if {!$accepted} {return {}}
        set nodes {}
        foreach id $ids {
            if {[hm_getvalue elems id=$id dataname=typename] ne "PLOTEL"} {error "Select only red PLOTEL segments."}
            foreach node [hm_getvalue elems id=$id dataname=nodes] {dict set nodes $node 1}
        }
        return [dict create nodes [corner_nodes [dict keys $nodes]] elements $ids]
    }
    if {[info exists pendingPlotel($label)] &&
        (!$closed || [lindex $pendingPlotel($label) 0] ne [hm_getcurrentmodel])} {
        unset pendingPlotel($label)
    }
    if {![info exists pendingPlotel($label)]} {
        set seed [pick_plotel_segment "$label: pick one red PLOTEL segment."]
        if {$seed eq {}} {return {}}
        if {![catch {loop_from_plotel $seed $closed elements} nodes options]} {
            return [dict create nodes $nodes elements $elements]
        }
        if {[dict get $options -errorcode] ne {RULEDMESH AMBIGUOUS_PLOTEL}} {
            return -options $options $nodes
        }
        set pendingPlotel($label) [list [hm_getcurrentmodel] $seed]
    }
    set seed [lindex $pendingPlotel($label) 1]
    set prompt "$label: first segment kept. Pick a different segment farther along the outer rim."
    while {1} {
        set hint [pick_plotel_segment $prompt]
        if {$hint eq {}} {
            return [dict create pending "First segment kept. Reopen $label to finish, or Clear to restart."]
        }
        if {![catch {loop_from_plotel $seed $closed elements $hint} nodes options]} {break}
        if {[dict get $options -errorcode] ne {RULEDMESH SAME_PLOTEL}} {
            return -options $options $nodes
        }
    }
    unset pendingPlotel($label)
    return [dict create nodes $nodes elements $elements]
}

proc ::RuledMesh::pick_plotel_segments {message} {
    set saved [hm_getmark elems 1]
    *clearmark elems 1
    set code [catch {
        ::TestToolSession::panel *createmarkpanel elems 1 $message 0 1
        hm_getmark elems 1
    } result options]
    *clearmark elems 1
    if {[llength $saved]} {*createmark elems 1 "by id only" {*}$saved}
    if {$code && $result ne "0"} {return -options $options $result}
    if {$code} {return {}}
    return $result
}

proc ::RuledMesh::pick_plotel_segment {message} {
    set ids [pick_plotel_segments $message]
    if {[llength $ids] > 1} {error "Pick exactly one red PLOTEL segment."}
    return [lindex $ids 0]
}

proc ::RuledMesh::pick_inner_loops {} {
    set loops {}
    set traced {}
    # Reuse connectivity only within this Proceed. Find Edges can replace IDs before the next pick.
    set index {}
    set seeds [pick_plotel_segments "Edge 2: pick one red segment per inner loop, then proceed."]
    foreach seed $seeds {
        if {[dict exists $traced $seed]} {continue}
        if {[catch {loop_from_plotel $seed 1 elements {} index} nodes options]} {
            if {[llength $seeds] != 1 || [dict get $options -errorcode] ne {RULEDMESH AMBIGUOUS_PLOTEL}} {
                return -options $options $nodes
            }
            set hint [pick_plotel_segment "Edge 2: pick a second segment on this same loop."]
            if {$hint eq {}} {return {}}
            set nodes [loop_from_plotel $seed 1 elements $hint]
        }
        lappend loops [dict create nodes $nodes elements $elements]
        foreach id $elements {dict set traced $id 1}
    }
    return $loops
}

proc ::RuledMesh::pick_node_list {panel message} {
    set saved [hm_getlist nodes 1]
    *clearlist nodes 1
    set code [catch {
        ::TestToolSession::panel $panel nodes 1 $message
        hm_getlist nodes 1
    } result options]
    *clearlist nodes 1
    if {[llength $saved]} {*createlist nodes 1 {*}$saved}
    if {$code && $result eq "0"} {return {}}
    return -options $options $result
}

proc ::RuledMesh::edit_selection_mark {kind previous message} {
    set saved [hm_getmark $kind 1]
    set code [catch {
        *createmark $kind 1 "by id only" {*}$previous
        # Mark 1 is owned by the native editor. The other edge stays on mark 2.
        ::TestToolSession::panel *editmarkpanel $kind 1 $message 0 1
        hm_getmark $kind 1
    } result options]
    *clearmark $kind 1
    if {[llength $saved]} {*createmark $kind 1 "by id only" {*}$saved}
    if {$code && $result eq "0"} {return [list 0 {}]}
    if {$code} {return -options $options $result}
    return [list 1 $result]
}
