"""Excel desktop runner for Python 3.8+ and pywin32."""

import argparse
import json
import subprocess
import sys
import shutil
from time import monotonic, perf_counter, sleep
from pathlib import Path
from uuid import uuid4

from tools.excel_package import inspect_package, publish_new, publish_replace
from tools.excel_task import Task, digest, read_json, write_json as durable_json


ROOT = Path(__file__).resolve().parent


def write_json(path, value):
    durable_json(path, value, durable=False)


def configure():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeout", type=int, default=90, help="Worker timeout in seconds (5–1800)")
    parser.add_argument("--task-id", help="Record a checkpoint before starting this command")
    parser.add_argument("--step", help="Unique step ID for a tracked command")
    parser.add_argument("--intent", help="Expected effect of a tracked command")
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("doctor")
    commands.add_parser("operations", help="Print the supported operation fields as JSON")
    task = commands.add_parser("task", help="Resume or compact a task without chat history")
    sub = task.add_subparsers(dest="task_action", required=True)
    start = sub.add_parser("start")
    start.add_argument("id")
    request_source = start.add_mutually_exclusive_group(required=True)
    request_source.add_argument("--request")
    request_source.add_argument("--request-file", type=Path)
    start.add_argument("--next", required=True)
    sub.add_parser("resume").add_argument("id")
    begin = sub.add_parser("begin")
    begin.add_argument("id")
    begin.add_argument("step_id")
    begin.add_argument("--description", required=True)
    update = sub.add_parser("update")
    update.add_argument("id")
    latest = update.add_mutually_exclusive_group(required=True)
    latest.add_argument("--request")
    latest.add_argument("--request-file", type=Path)
    resolve = sub.add_parser("resolve")
    resolve.add_argument("id")
    resolve.add_argument("step_id")
    resolve.add_argument("--next", default="")
    resolve.add_argument("--disposition", choices=("verified", "needs-work"), default="verified")
    resolve.add_argument("--evidence", default="")
    resolve.add_argument("--complete", action="store_true")
    compact = sub.add_parser("compact")
    compact.add_argument("id")
    compact.add_argument("--summary", type=Path, required=True)
    compact.add_argument("--revision", type=int, required=True)
    package = commands.add_parser("inspect")
    package.add_argument("workbook", type=Path)
    package.add_argument("--verify-crc", action="store_true")
    inventory = commands.add_parser("inventory")
    inventory.add_argument("workbook", type=Path)
    inventory.add_argument("--sheet")
    inventory.add_argument("--kind", action="append")
    preview = commands.add_parser("plan")
    preview.add_argument("workbook", type=Path)
    preview.add_argument("--ops", type=Path, required=True)
    apply = commands.add_parser("apply")
    apply.add_argument("--plan", type=Path, required=True)
    apply.add_argument("--output", type=Path, required=True)
    diff = commands.add_parser("vba-diff", help="Preview exact line-block changes to existing VBA code")
    diff.add_argument("workbook", type=Path)
    diff.add_argument("--patch", type=Path, required=True)
    patch = commands.add_parser("vba-patch", help="Compile and test a scoped VBA patch on a disposable copy")
    patch.add_argument("--preview", type=Path, required=True)
    patch.add_argument("--output", type=Path, required=True)
    patch.add_argument("--entry", required=True, help="Existing public Sub that generates the workbook test output")
    patch.add_argument("--expect", type=Path, required=True)
    patch.add_argument("--expect-csv", type=Path, help="Expected CSV contents for the report generated beside the workbook")
    patch.add_argument("--trusted-test", action="store_true", required=True)
    powerpoint = commands.add_parser("ppt", help="PowerPoint VBA and RibbonX runner")
    ppt_actions = powerpoint.add_subparsers(dest="ppt_action", required=True)
    ppt_actions.add_parser("doctor")
    for name in ("inspect", "export"):
        ppt_actions.add_parser(name).add_argument("presentation", type=Path)
    for name in ("test", "build"):
        command = ppt_actions.add_parser(name)
        command.add_argument("--source", type=Path, required=True)
        command.add_argument("--entry", default="PowerPointSmoke.Smoke")
        command.add_argument("--trusted-test", action="store_true", required=True)
        command.add_argument("--skip-compile", action="store_true")
        if name == "build":
            command.add_argument("--ribbon", type=Path, required=True)
            command.add_argument("--output", type=Path, required=True)
        else:
            command.add_argument("--output", type=Path, help="Save the verified PPTM at a new path")
    for name in ("export", "read", "run"):
        command = commands.add_parser(name)
        command.add_argument("workbook", type=Path)
        if name == "run":
            command.add_argument("entry")
            command.add_argument("--trusted-test", action="store_true", required=True,
                                 help="Confirm this file is an approved, disposable test workbook")
            command.add_argument("--expect", type=Path, help="JSON file with expected cells after the macro")
            command.add_argument("--events", action="store_true", help="Enable workbook events in the disposable Excel process")
        if name == "read":
            command.add_argument("--sheet", required=True)
            command.add_argument("--range", dest="address", required=True)

    for name in ("test", "build"):
        command = commands.add_parser(name)
        command.add_argument("--source", type=Path, default=ROOT / "vba")
        command.add_argument("--skip-compile", action="store_true")
        if name == "test":
            command.add_argument("--tests", type=Path, default=ROOT / "tests" / "vba")
            command.add_argument("--entry", default="KitTests.Smoke")
            command.add_argument("--expect", type=Path, help="JSON file with expected cells after the macro")
            command.add_argument("--workbook", type=Path, help="Use a staged copy of a trusted XLSM instead of a blank workbook")
            command.add_argument("--documents", type=Path, help="Directory with CodeName.document.cls source files")
            command.add_argument("--events", action="store_true", help="Enable events during the test macro")
        else:
            command.add_argument("--entry", default="Kit_SelfTest")
            command.add_argument("--ribbon", type=Path, default=ROOT / "ribbon" / "customUI.xml")
            command.add_argument("--output", type=Path, default=ROOT / "output" / "ExcelAIKit.xlam")
    args = parser.parse_args()
    if not 5 <= args.timeout <= 1800:
        parser.error("--timeout must be between 5 and 1800 seconds")
    tracking = [args.task_id, args.step, args.intent]
    if any(tracking) and (not all(tracking) or args.action == "task"):
        parser.error("Tracking a runner command requires --task-id, --step and --intent before the action.")
    return {k: str(v.resolve()) if isinstance(v, Path) else v for k, v in vars(args).items()}


def main():
    request = configure()
    try:
        if request["action"] == "task":
            print(json.dumps(task_command(request), ensure_ascii=True, indent=2))
            return 0
        if request["task_id"]:
            checkpoint = Task(ROOT, request["task_id"])
            with checkpoint.lock():
                run = ROOT / "runs" / ("python-" + uuid4().hex)
                checkpoint.begin(request["step"], request["intent"], run)
                return run_command(request, run)
        return run_command(request, ROOT / "runs" / ("python-" + uuid4().hex))
    except (OSError, ValueError, KeyError) as error:
        print(json.dumps({"status": "FAIL", "stage": "checkpoint", "message": str(error)}, ensure_ascii=True))
        return 1


def task_command(request):
    task = Task(ROOT, request["id"])
    action = request["task_action"]
    if action in ("start", "update"):
        original = request["request"]
        if request["request_file"]:
            original = Path(request["request_file"]).read_text(encoding="utf-8-sig")
        return task.start(original, request["next"]) if action == "start" else task.update(original)
    if action == "resume":
        return task.resume()
    if action == "compact":
        return task.compact(read_json(Path(request["summary"])), request["revision"])
    if action == "resolve":
        return task.resolve(request["step_id"], request["next"], request["disposition"],
                            request["evidence"], request["complete"])
    with task.lock():
        task.begin(request["step_id"], request["description"], None)
    return task.resume()


def run_command(request, run):
    started = perf_counter()
    run.mkdir(parents=True)
    if request["action"] == "inspect":
        try:
            result = {"status": "PASS", "stage": "inspect",
                      "package": inspect_package(request["workbook"], request["verify_crc"])}
        except Exception as error:
            result = {"status": "FAIL", "stage": "inspect", "message": str(error)}
    elif request["action"] == "ppt" and request["ppt_action"] == "inspect":
        try:
            result = {"status": "PASS", "stage": "inspect",
                      "package": inspect_package(request["presentation"], True, "ppt")}
        except Exception as error:
            result = {"status": "FAIL", "stage": "inspect", "message": str(error)}
    elif request["action"] == "operations":
        from tools.excel_schema import SCHEMA, KINDS
        result = {"status": "PASS", "stage": "operations", "inventory_kinds": sorted(KINDS),
                  "operations": {kind: {"required": required.split(), "optional": optional.split()}
                                 for kind, (required, optional) in SCHEMA.items()}}
    else:
        result = supervise(run, request)
        if request["action"] == "ppt":
            # PowerPoint has exited here; drop add-in registrations a killed worker left behind.
            try:
                from tools.excel_powerpoint import remove_addin_registrations
                removed = remove_addin_registrations(ROOT / "runs")
                if removed:
                    result["removed_addin_registrations"] = removed
            except (ImportError, OSError) as error:
                result["addin_registration_cleanup_error"] = str(error)
    result.update(action=request["action"], run=str(run), elapsed_ms=round((perf_counter() - started) * 1000))
    write_json(run / "result.json", result)
    print(json.dumps(result, ensure_ascii=True, indent=2))
    return {"PASS": 0, "TIMEOUT": 124}.get(result["status"], 1)


def supervise(run, request):
    try:
        from pywintypes import error as windows_error
        from tools.excel_windows import launch_excel, stop_owned_excel
    except ImportError as error:
        return {"status": "FAIL", "stage": "python-dependencies", "message": str(error)}

    try:
        bootstrap = run / ("Bootstrap-" + run.name[-12:] + ".xlsx")
        if request["action"] == "ppt":
            from tools.excel_powerpoint import launch_powerpoint
            bootstrap = bootstrap.with_suffix(".pptx")
            excel = launch_powerpoint(bootstrap)
        else:
            excel = launch_excel(bootstrap)
    except (OSError, RuntimeError, windows_error) as error:
        return {"status": "FAIL", "stage": "excel-start", "message": str(error)}
    state_path = run / "state.json"

    def state():
        return json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}

    try:
        request["excel_pid"] = excel.pid
        request["bootstrap"] = str(bootstrap)
        write_json(run / "request.json", request)
        with (run / "worker.log").open("w", encoding="utf-8") as log:
            with subprocess.Popen([sys.executable, str(ROOT / "ExcelKit.py"), "--worker", str(run)],
                                  stdout=log, stderr=subprocess.STDOUT) as worker:
                try:
                    excel.attach_worker(worker)
                    (run / "worker-ready").touch()
                    code = worker.wait(timeout=request["timeout"])
                except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                    worker.kill()
                    worker.wait()
                    current = state()
                    return dict(status="TIMEOUT" if isinstance(error, subprocess.TimeoutExpired) else "CANCELLED",
                                stage=current.get("stage", "startup"), timeout_seconds=request["timeout"],
                                **stop_owned_excel(excel, current))
                except (OSError, windows_error):
                    if worker.poll() is None:
                        worker.kill()
                    raise

        report = run / "worker-result.json"
        if code == 0 and report.exists():
            result = json.loads(report.read_text(encoding="utf-8"))
            try:
                excel.wait(timeout=3)
            except subprocess.TimeoutExpired:
                result.update(stop_owned_excel(excel, state()))
                if not result["stopped_test_excel"]:
                    result.update(status="FAIL", stage="cleanup")
            staged = result.pop("staged_output", None)
            if staged and result["status"] == "PASS":
                try:
                    durable_json(run / "publication.json",
                                 {"path": request["output"], "sha256": digest(Path(staged))})
                    if request["action"] == "build":
                        publish_replace(Path(staged), Path(request["output"]))
                    else:
                        publish_new(Path(staged), Path(request["output"]))
                    result["output"] = request["output"]
                except OSError as error:
                    result.update(status="FAIL", stage="publish", message=str(error))
            return result
        current = state()
        return dict(status="FAIL", stage=current.get("stage", "startup"),
                    message="Worker exited before writing a result. See worker.log.", worker_exit=code,
                    **stop_owned_excel(excel, current))
    except (OSError, windows_error) as error:
        return dict(status="FAIL", stage="worker-start", message=str(error),
                    **stop_owned_excel(excel, state()))
    finally:
        try:
            if excel.poll() is None:
                stop_owned_excel(excel, state())
            if excel.poll() is not None:
                scratch = run / "work"
                if scratch.is_dir():
                    shutil.rmtree(scratch, ignore_errors=True)
        finally:
            excel.close()


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        work_dir = Path(sys.argv[2])
        deadline = monotonic() + 5
        while not (work_dir / "worker-ready").is_file():
            if monotonic() >= deadline:
                sys.exit(1)
            sleep(0.05)
        if read_json(work_dir / "request.json")["action"] == "ppt":
            from tools.excel_powerpoint import execute
        else:
            from tools.excel_worker import execute
        write_json(work_dir / "worker-result.json", execute(work_dir, write_json))
    else:
        sys.exit(main())
