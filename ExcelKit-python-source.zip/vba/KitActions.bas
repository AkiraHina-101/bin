Attribute VB_Name = "KitActions"
Option Explicit

' Demo buttons for the Excel AI Kit ribbon. Each callback reports through the status bar
' and never raises an error to the user.

Public Sub Kit_StampDateTime(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    If Application.ActiveWorkbook Is Nothing Then
        Application.StatusBar = "Excel AI Kit: open a workbook first."
        Exit Sub
    End If
    ActiveCell.NumberFormat = "yyyy-mm-dd hh:mm"
    ActiveCell.Value2 = CDbl(Now)
    Application.StatusBar = "Excel AI Kit: stamped " & ActiveCell.Address(False, False)
    Exit Sub
Failed:
    Application.StatusBar = "Excel AI Kit: " & Err.Number & " " & Err.Description
End Sub

Public Sub Kit_AutofitColumns(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    If Application.ActiveWorkbook Is Nothing Then
        Application.StatusBar = "Excel AI Kit: open a workbook first."
        Exit Sub
    End If
    If TypeName(Application.ActiveSheet) <> "Worksheet" Then
        Application.StatusBar = "Excel AI Kit: select a worksheet."
        Exit Sub
    End If
    ActiveSheet.UsedRange.Columns.AutoFit
    Application.StatusBar = "Excel AI Kit: columns fitted on " & ActiveSheet.Name
    Exit Sub
Failed:
    Application.StatusBar = "Excel AI Kit: " & Err.Number & " " & Err.Description
End Sub

Public Sub Kit_ToggleFreezeTopRow(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    If Application.ActiveWorkbook Is Nothing Then
        Application.StatusBar = "Excel AI Kit: open a workbook first."
        Exit Sub
    End If
    With ActiveWindow
        If .FreezePanes Then
            .FreezePanes = False
            Application.StatusBar = "Excel AI Kit: panes unfrozen."
        Else
            .FreezePanes = False
            .SplitColumn = 0
            .SplitRow = 1
            .FreezePanes = True
            Application.StatusBar = "Excel AI Kit: top row frozen."
        End If
    End With
    Exit Sub
Failed:
    Application.StatusBar = "Excel AI Kit: " & Err.Number & " " & Err.Description
End Sub

Public Sub Kit_About(ByVal control As Office.IRibbonControl)
    MsgBox "Excel AI Kit add-in" & vbCrLf & "Demo buttons: Run Self-Test, Stamp Date/Time, " _
        & "Autofit Columns, Freeze Top Row.", vbInformation, "Excel AI Kit"
End Sub
