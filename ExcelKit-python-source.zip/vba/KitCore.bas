Attribute VB_Name = "KitCore"
Option Explicit

Public Function KitWorkbookSummary(ByVal book As Workbook) As String
    If book Is Nothing Then
        KitWorkbookSummary = "No workbook is active."
        Exit Function
    End If

    KitWorkbookSummary = book.Name & " | Worksheets: " & CStr(book.Worksheets.Count) _
        & " | Read-only: " & CStr(book.ReadOnly)
End Function
