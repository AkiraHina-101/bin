Attribute VB_Name = "KitRibbon"
Option Explicit

Public Sub Kit_RunSelfTest(ByVal control As Office.IRibbonControl)
    Application.StatusBar = Kit_SelfTest()
End Sub

Public Function Kit_SelfTest() As String
    On Error GoTo Failed
    If KitWorkbookSummary(Nothing) <> "No workbook is active." Then
        Err.Raise vbObjectError + 100, "Kit_SelfTest", "Unexpected empty-workbook summary"
    End If
    Kit_SelfTest = "PASS"
    Exit Function
Failed:
    Kit_SelfTest = "FAIL | " & Err.Number & " | " & Err.Source & " | " & Err.Description
End Function
