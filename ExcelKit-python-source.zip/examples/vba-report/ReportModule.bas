Attribute VB_Name = "ReportModule"
Option Explicit

Public Sub ExportReport()
    Dim entries As Worksheet
    Dim report As Worksheet
    Dim total As Long
    Dim handle As Integer

    Set entries = ThisWorkbook.Worksheets("Input")
    Set report = ThisWorkbook.Worksheets("Report")
    total = CLng(Application.Sum(entries.Range("B2:B4")))
    report.Range("B5").Value2 = total

    handle = FreeFile
    Open ThisWorkbook.Path & "\Report.csv" For Output As #handle
    Print #handle, "Region,Total"
    Print #handle, CStr(report.Range("B2").Value2) & "," & CStr(total)
    Close #handle
End Sub

Public Sub ReportRibbon(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    ReportOptions.Show
    Exit Sub
Failed:
    Application.StatusBar = "ExportReport failed: " & Err.Number & " " & Err.Description
End Sub
