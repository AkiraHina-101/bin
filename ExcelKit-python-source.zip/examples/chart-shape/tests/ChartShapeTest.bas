Attribute VB_Name = "ChartShapeTest"
Option Explicit

Public Function Smoke() As String
    On Error GoTo Failed
    Dim sheet As Worksheet
    Dim container As ChartObject
    Dim graph As Chart
    Dim guide As Series
    Dim chartRectangle As Shape
    Dim sheetRectangle As Shape
    Dim marker As Point
    Dim markerCenter As Double
    Dim widthBefore As Double

10  Set sheet = ThisWorkbook.Worksheets.Item(1)
20  Set container = sheet.ChartObjects.Add(175, 50, 440, 270)
30  Set graph = container.Chart
    graph.ChartType = xlXYScatterLines
40  Set guide = graph.SeriesCollection.NewSeries
    guide.Name = "Reference Line"
    guide.XValues = Array(20#, 20#)
    guide.Values = Array(1#, 8#)
    guide.MarkerStyle = xlMarkerStyleCircle
    guide.MarkerSize = 8
50  With graph.Axes(xlCategory, xlPrimary)
        .MinimumScale = 0#
        .MaximumScale = 100#
    End With
60  Set chartRectangle = graph.Shapes.AddShape(msoShapeRectangle, 2, 10, 26, 10)
    Set sheetRectangle = sheet.Shapes.AddShape(msoShapeRectangle, 2, 23, 46, 12)
    widthBefore = sheetRectangle.Width

70  CenterRectangleOnSeries container, "Reference Line", chartRectangle.Name
80  CenterRectangleOnSeries container, "Reference Line", sheetRectangle.Name, False
90  Set marker = guide.Points.Item(1)
    markerCenter = marker.Left + marker.Width / 2#
100 CheckCenter chartRectangle, markerCenter
110 CheckCenter sheetRectangle, container.Left + markerCenter
120 If Abs(sheetRectangle.Top - 23#) > 0.01 Or Abs(sheetRectangle.Width - widthBefore) > 0.01 Then
        Err.Raise vbObjectError + 230, "ChartShapeTest.Smoke", "Unexpected rectangle geometry."
    End If

130 graph.Axes(xlCategory, xlPrimary).ReversePlotOrder = True
    graph.Axes(xlCategory, xlPrimary).MaximumScale = 80#
    container.Width = 500
140 CenterRectangleOnSeries container, "Reference Line", chartRectangle.Name
    Set marker = guide.Points.Item(1)
150 CheckCenter chartRectangle, marker.Left + marker.Width / 2#
160 CheckInvalidSeries container, guide, chartRectangle
    Smoke = "PASS"
    Exit Function
Failed:
    Smoke = "FAIL | " & Err.Number & " | " & Err.Source & " | line " & Erl & " | " & Err.Description
End Function

Private Sub CheckCenter(ByVal rectangle As Shape, ByVal expected As Double)
    Dim actual As Double
    actual = rectangle.Left + rectangle.Width / 2#
    If Abs(actual - expected) > 1# Then
        Err.Raise vbObjectError + 231, "ChartShapeTest.CheckCenter", _
            "Expected " & expected & " pt, got " & actual & " pt."
    End If
End Sub

Private Sub CheckInvalidSeries(ByVal container As ChartObject, _
        ByVal guide As Series, ByVal rectangle As Shape)
    Dim originalLeft As Double
    Dim errorNumber As Long
    originalLeft = rectangle.Left
    guide.XValues = Array(20#, 40#)
    On Error Resume Next
    CenterRectangleOnSeries container, guide.Name, rectangle.Name
    errorNumber = Err.Number
    On Error GoTo 0
    If errorNumber <> vbObjectError + 216 Or rectangle.Left <> originalLeft Then
        Err.Raise vbObjectError + 232, "ChartShapeTest.CheckInvalidSeries", "Expected a rejected nonvertical series."
    End If
End Sub
