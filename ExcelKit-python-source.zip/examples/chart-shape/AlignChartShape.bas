Attribute VB_Name = "AlignChartShape"
Option Explicit

' Centers a rectangle horizontally on a two-point vertical XY series.
' chartOwnsShape selects Chart.Shapes or the host Worksheet.Shapes.
Public Sub CenterRectangleOnSeries(ByVal container As Excel.ChartObject, _
        ByVal seriesName As String, ByVal shapeName As String, _
        Optional ByVal chartOwnsShape As Boolean = True)
    Dim graph As Excel.Chart
    Dim candidate As Excel.Series
    Dim guide As Excel.Series
    Dim horizontal As Excel.Axis
    Dim rectangle As Excel.Shape
    Dim xValues As Variant
    Dim yValues As Variant
    Dim firstIndex As Long
    Dim x As Double
    Dim minimum As Double
    Dim maximum As Double
    Dim fraction As Double
    Dim center As Double

    Set graph = container.Chart
    For Each candidate In graph.SeriesCollection
        If StrComp(candidate.Name, seriesName, vbTextCompare) = 0 Then
            If Not guide Is Nothing Then
                Err.Raise vbObjectError + 210, "CenterRectangleOnSeries", "Series name is ambiguous."
            End If
            Set guide = candidate
        End If
    Next candidate
    If guide Is Nothing Then
        Err.Raise vbObjectError + 211, "CenterRectangleOnSeries", "Series not found: " & seriesName
    End If
    Select Case guide.ChartType
        Case xlXYScatterLines, xlXYScatterLinesNoMarkers
        Case Else
            Err.Raise vbObjectError + 212, "CenterRectangleOnSeries", "Expected a straight-line XY scatter series."
    End Select
    If guide.AxisGroup <> xlPrimary Or guide.Points.Count <> 2 Then
        Err.Raise vbObjectError + 213, "CenterRectangleOnSeries", "Expected two points on the primary axes."
    End If
    xValues = guide.XValues
    firstIndex = LBound(xValues)
    If UBound(xValues) <> firstIndex + 1 Then
        Err.Raise vbObjectError + 214, "CenterRectangleOnSeries", "Expected exactly two X values."
    End If
    If Not IsNumeric(xValues(firstIndex)) Or Not IsNumeric(xValues(firstIndex + 1)) Then
        Err.Raise vbObjectError + 215, "CenterRectangleOnSeries", "X values must be numeric."
    End If
    x = CDbl(xValues(firstIndex))
    If x <> CDbl(xValues(firstIndex + 1)) Then
        Err.Raise vbObjectError + 216, "CenterRectangleOnSeries", "The two X values must match."
    End If
    yValues = guide.Values
    firstIndex = LBound(yValues)
    If UBound(yValues) <> firstIndex + 1 Then
        Err.Raise vbObjectError + 220, "CenterRectangleOnSeries", "Expected exactly two Y values."
    End If
    If Not IsNumeric(yValues(firstIndex)) Or Not IsNumeric(yValues(firstIndex + 1)) Then
        Err.Raise vbObjectError + 220, "CenterRectangleOnSeries", "Y values must be numeric."
    End If
    If CDbl(yValues(firstIndex)) = CDbl(yValues(firstIndex + 1)) Then
        Err.Raise vbObjectError + 220, "CenterRectangleOnSeries", "The two Y values must differ."
    End If

    graph.Refresh
    Set horizontal = graph.Axes(xlCategory, xlPrimary)
    If horizontal.ScaleType <> xlScaleLinear Then
        Err.Raise vbObjectError + 217, "CenterRectangleOnSeries", "Expected a linear X axis."
    End If
    minimum = horizontal.MinimumScale
    maximum = horizontal.MaximumScale
    If maximum <= minimum Or x < minimum Or x > maximum Or graph.PlotArea.InsideWidth <= 0 Then
        Err.Raise vbObjectError + 218, "CenterRectangleOnSeries", "Series X is outside the visible plot."
    End If
    fraction = (x - minimum) / (maximum - minimum)
    If horizontal.ReversePlotOrder Then fraction = 1# - fraction
    center = graph.PlotArea.InsideLeft + fraction * graph.PlotArea.InsideWidth

    If chartOwnsShape Then
        Set rectangle = graph.Shapes.Item(shapeName)
    Else
        Set rectangle = container.Parent.Shapes.Item(shapeName)
        center = container.Left + center
    End If
    If rectangle.Type <> msoAutoShape Then
        Err.Raise vbObjectError + 219, "CenterRectangleOnSeries", "Expected a rectangle AutoShape."
    End If
    If rectangle.AutoShapeType <> msoShapeRectangle Then
        Err.Raise vbObjectError + 219, "CenterRectangleOnSeries", "Expected a rectangle AutoShape."
    End If
    rectangle.Left = CSng(center - rectangle.Width / 2#)
End Sub
