Attribute VB_Name = "KitActions"
Option Explicit

' Demo buttons for the PowerPoint Kit ribbon. Callbacks show a message instead of raising errors.

Private Function OpenDeck() As PowerPoint.Presentation
    If Application.Presentations.Count = 0 Then Exit Function
    Set OpenDeck = Application.ActivePresentation
End Function

Public Sub KitAddBlankSlide(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    Dim deck As PowerPoint.Presentation
    Set deck = OpenDeck()
    If deck Is Nothing Then
        MsgBox "Open or create a presentation first.", vbInformation, "PowerPoint Kit"
        Exit Sub
    End If
    deck.Slides.Add deck.Slides.Count + 1, ppLayoutBlank
    Exit Sub
Failed:
    MsgBox "PowerPoint Kit: " & Err.Number & " " & Err.Description, vbExclamation
End Sub

Public Sub KitStampDate(ByVal control As Office.IRibbonControl)
    On Error GoTo Failed
    Dim deck As PowerPoint.Presentation
    Dim page As PowerPoint.Slide
    Dim stamp As PowerPoint.Shape
    Set deck = OpenDeck()
    If deck Is Nothing Or deck.Slides.Count = 0 Then
        MsgBox "Open a presentation with at least one slide first.", vbInformation, "PowerPoint Kit"
        Exit Sub
    End If
    Set page = Application.ActiveWindow.View.Slide
    Set stamp = page.Shapes.AddTextbox(msoTextOrientationHorizontal, deck.PageSetup.SlideWidth - 220, _
        deck.PageSetup.SlideHeight - 40, 200, 28)
    stamp.Name = "KitDateStamp"
    stamp.TextFrame.TextRange.Text = Format(Date, "yyyy-mm-dd")
    stamp.TextFrame.TextRange.ParagraphFormat.Alignment = ppAlignRight
    Exit Sub
Failed:
    MsgBox "PowerPoint Kit: " & Err.Number & " " & Err.Description, vbExclamation
End Sub

Public Sub KitSlideCount(ByVal control As Office.IRibbonControl)
    Dim deck As PowerPoint.Presentation
    Set deck = OpenDeck()
    If deck Is Nothing Then
        MsgBox "No presentation is open.", vbInformation, "PowerPoint Kit"
    Else
        MsgBox deck.Name & ": " & deck.Slides.Count & " slide(s)", vbInformation, "PowerPoint Kit"
    End If
End Sub

Public Sub KitAbout(ByVal control As Office.IRibbonControl)
    MsgBox "PowerPoint Kit add-in" & vbCrLf & "Demo buttons: Add verification slide, Add blank slide, " _
        & "Date stamp, Slide count.", vbInformation, "PowerPoint Kit"
End Sub
