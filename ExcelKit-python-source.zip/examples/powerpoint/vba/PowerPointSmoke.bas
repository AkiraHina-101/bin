Attribute VB_Name = "PowerPointSmoke"
Option Explicit

Public Function Smoke() As String
    On Error GoTo Failed
    Dim target As PowerPoint.Presentation
    Dim page As PowerPoint.Slide
    Dim title As PowerPoint.Shape
    Set target = Application.ActivePresentation
    Set page = target.Slides.Add(target.Slides.Count + 1, ppLayoutBlank)
    Set title = page.Shapes.AddTextbox(msoTextOrientationHorizontal, 40, 40, 480, 45)
    title.Name = "KitResult"
    title.TextFrame.TextRange.Text = "PowerPoint VBA verified"
    If page.Shapes("KitResult").TextFrame.TextRange.Text <> "PowerPoint VBA verified" Then
        Err.Raise 5, "Smoke", "Output text differs."
    End If
    Smoke = "PASS"
    Exit Function
Failed:
    Smoke = "FAIL | " & Err.Number & " | " & Err.Description
End Function

Public Sub KitRunSmoke(ByVal control As Office.IRibbonControl)
    Dim result As String
    result = Smoke()
    If result <> "PASS" Then MsgBox result, vbExclamation
End Sub
