Attribute VB_Name = "DashboardSmoke"
Option Explicit

Private reviewForm As KitSampleForm

Public Function DashboardSelfTest() As String
    On Error GoTo Failed
    Dim testForm As KitSampleForm
    Set testForm = New KitSampleForm
    Load testForm
    If Len(testForm.Caption) = 0 Then Err.Raise 5, "DashboardSelfTest", "Form caption is missing."
    Unload testForm
    DashboardSelfTest = "PASS"
    Exit Function
Failed:
    DashboardSelfTest = "FAIL | " & Err.Number & " | " & Err.Description
End Function

Public Function VerifyDashboard() As String
    On Error GoTo Failed
    Dim dashboard As Workbook
    Set dashboard = Application.ActiveWorkbook
    If dashboard Is Nothing Then Err.Raise 5, "VerifyDashboard", "Open the dashboard."
    If dashboard Is ThisWorkbook Then Err.Raise 5, "VerifyDashboard", "Select the dashboard."
    If dashboard.Worksheets("Report").Range("B5").Value2 <> 30 Then
        Err.Raise 5, "VerifyDashboard", "Unexpected regional total."
    End If
    If reviewForm Is Nothing Then Set reviewForm = New KitSampleForm
    reviewForm.Caption = "Dashboard Review"
    reviewForm.lblStatus.Caption = "Filtered total: 30"
    reviewForm.Show vbModeless
    VerifyDashboard = "PASS"
    Exit Function
Failed:
    VerifyDashboard = "FAIL | " & Err.Number & " | " & Err.Description
End Function

Public Sub Kit_ShowDashboard(ByVal control As Office.IRibbonControl)
    Application.StatusBar = VerifyDashboard()
End Sub
