# Starting an Office task

> Read this page, handle the request below, and save a checkpoint yourself before the first Office operation. Hand over the file, the checks and the task ID.

1. **Open the task.** If there is an existing ID, read `task resume` or the Markdown checkpoint file before running anything again. If the task is new, record the verbatim request, the source file and the first step. Record the latest request as soon as the user changes the scope. [Checkpoints and compacting](resume-after-stop.md)
2. **Choose the route.** Identify the file name, the target object and how the result will be checked. Use a copy and a separate Office session. When you may use the Python runner, run `doctor` if the environment has not been confirmed. When only Markdown is available, follow the same steps with the Office tools you have been given. [Workflow on a company machine](company-machine.md)

   | Request | First step | Evidence to hand over |
   | --- | --- | --- |
   | Change data, formulas, tables, PivotTables, charts or shapes | `inventory` to find the right sheet and object, `read` to fix the values before editing. | The result of `plan → apply` on a new copy and a check after reopening. [Excel operations](object-operations.md) |
   | Macro error, wrong Ribbon button, form that does not export correctly | Reproduce on a copy and record the error text or the wrong value. Trace from the callback to the procedure. | A scoped diff, Compile, a before/after case and the output cell or file. If the user goes through a form or the Ribbon, try that exact path. [VBA patch](vba-patch.md) |
   | Create a tab, Ribbon XML or an Excel add-in | Settle which buttons are needed and which procedure each one calls. | The `.xlam`, the build log and the result of clicking each button. [VBA, UserForm and RibbonX reference](excel-python-reference.md) |
   | PowerPoint macro or Ribbon | Use `ppt doctor` in a suitable test session. | A PPTM or PPAM as requested, Compile, runtime and button results. [PowerPoint VBA](powerpoint-vba.md) |
   | Build a report from a sample | Survey the sample and the inputs you already have. Record the output, the column mapping and the points that conflict. | A report that reopens, a reconciliation of the figures and a variant input when one exists. [Report from a sample](report-from-sample.md) |

3. **Do the work and verify.** Look up the [project lessons](project-lessons.md) by error type or object. Ask only about missing points that could change the data, the KPIs or the output. Save the current step before each change. On a failure, read the `stage`, the message or dialog and the actual result before fixing. Rerun the failing case and read the result from the delivered file.
4. **Finish or hand over the session.** Record the output path, the checks that passed and the steps that still need verification. After the checks pass, update the lessons if you found something reusable. If you are about to switch chats or the context is long, compact the summary and continue by task ID.

Editing an open workbook is a separate option, used when the user asks for it explicitly and the tooling supports it. The runner in this kit uses a separate session. Verify the exact path and object before acting.
