# Aligning a rectangle to a vertical line in an Excel chart

This sample is for a chart embedded on a worksheet. The vertical line is an **XY Scatter with Straight Lines** series with two points that share the same X and have two different Y values, using the linear primary X axis. The sample places the **horizontal center of the rectangle** on the vertical line. The rectangle can be inside the chart or on the worksheet that holds the chart.

## Identifying the right object and coordinates

1. Get `Worksheet.ChartObjects(name)` and then `.Chart`. Find the series by name in `Chart.SeriesCollection` and read `Series.XValues`. If two series have the same name, ask for a clearer identification. [ChartObject](https://learn.microsoft.com/en-us/office/vba/api/excel.chartobject) · [Series.XValues](https://learn.microsoft.com/en-us/office/vba/api/excel.series.xvalues)
2. For a scatter chart, `Chart.Axes(xlCategory, xlPrimary)` returns the X axis. With `xMin` and `xMax` from the axis, compute `fraction = (x - xMin) / (xMax - xMin)`. If `ReversePlotOrder` is on, use `1 - fraction`. [Chart.Axes](https://learn.microsoft.com/en-us/office/vba/api/excel.chart.axes) · [Axis.ReversePlotOrder](https://learn.microsoft.com/en-us/office/vba/api/excel.axis.reverseplotorder)
3. Inside the chart, the target coordinate is `PlotArea.InsideLeft + fraction * PlotArea.InsideWidth`, measured in points from the chart edge. If the rectangle belongs to the worksheet, add `ChartObject.Left`. Set `rectangle.Left = targetX - rectangle.Width / 2`. [PlotArea.InsideLeft](https://learn.microsoft.com/office/vba/api/excel.plotarea.insideleft) · [PlotArea.InsideWidth](https://learn.microsoft.com/office/vba/api/excel.plotarea.insidewidth) · [ChartObject.Left](https://learn.microsoft.com/en-us/office/vba/api/excel.chartobject.left)

## Using the sample VBA

Import [AlignChartShape.bas](../examples/chart-shape/AlignChartShape.bas) into a copy you are allowed to edit. Replace the sheet, chart, series and shape names with the real ones. Use `True` if the rectangle belongs to `Chart.Shapes`, or `False` if it belongs to `Worksheet.Shapes`.

```vb
Dim chartBox As ChartObject
Set chartBox = ThisWorkbook.Worksheets("Report").ChartObjects("Plot1")
CenterRectangleOnSeries chartBox, "Reference Line", "Rectangle 1", True
```

Call the procedure again after you update the series, change the axis limits or resize the chart. Put the call at the end of the macro that updates the chart if you want the rectangle to follow automatically. For a shape on the worksheet, also call it again when the chart is moved. For a category chart, a log axis or a series on the secondary axis, you need a mapping and test cases that fit the real chart.

## Testing in Excel

```text
python ExcelKit.py test --source examples/chart-shape --tests examples/chart-shape/tests --entry ChartShapeTest.Smoke
```

The test builds a chart on a blank workbook. It compares the center of the rectangle with the center of the marker Excel draws, tries both places the rectangle can live, changes the axis and the chart size, and then checks that a slanted series is rejected. [Point.Left](https://learn.microsoft.com/en-us/office/vba/api/excel.point.left)
