# Scoped VBA patch on an XLSM

1. Use `export` to view the code of the right project and reproduce the defect on a trusted copy.
2. Create a JSON file with `version: 1` and a list of `edits`. Each edit gives the `module` name, the `procedure`, the exact `before` block and the replacement `after` block. See `examples/vba-report/patch.json`.
3. Run `vba-diff`, check the unified diff and take the preview path.
4. Run `vba-patch` with the existing report-export function, the cells to compare and the reference CSV if the task exports a report.

```text
python ExcelKit.py vba-diff "Source.xlsm" --patch patch.json
python ExcelKit.py --task-id excel-027 --step patch-01 --intent "Fix the report total and check the CSV" vba-patch --preview "<vba-preview.json>" --output "Patched.xlsm" --entry ReportModule.ExportReport --expect expect.json --expect-csv expected.csv --trusted-test
```

The runner updates the body of the code directly on a copy, compares all module code and references, compiles, saves and reopens. The runtime runs on a second copy so that test data and `Report.csv` do not go into the delivered file. The supervisor publishes the new file after the checks succeed. If you press Stop, read `task resume excel-027` and then compare against the receipt. Use a new path for the output.

Each module accepts one contiguous block inside the body of an existing procedure. The module name must match the export. The v1 sample needs a single-line procedure declaration and an end statement on its own line. Conditional compilation, signature changes, new procedures, UserForm design changes or signed VBA need a different workflow. Run only approved, trusted business macros on a copy, because a macro can write files outside the workbook. `--expect-csv` compares the `Report.csv` file that the macro writes next to the test workbook.

Also check the real Ribbon button and the UserForm if that is the user's path. The runner's runtime calls the exact procedure by workbook name and module name. That lets you reconcile the business result even when the company's Office session requires the user to check the UI separately.
