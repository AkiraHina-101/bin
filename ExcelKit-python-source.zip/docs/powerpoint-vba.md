# PowerPoint VBA and add-ins

Run on desktop PowerPoint for Windows with Python 3.8.10 and pywin32. Use a desktop that is approved for testing and has no PowerPoint open. The runner detects a running PowerPoint and returns an error before trying anything. It starts a process under a Windows Job Object, and checks the window's PID and the exact path of the randomly named bootstrap deck before it edits anything. On a timeout, the supervisor stops only the process it created. [Office command-line switches](https://support.microsoft.com/en-us/office/lifecycle/command-line-switches-for-microsoft-office-products) · [Windows Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects)

```text
python ExcelKit.py ppt doctor
python ExcelKit.py ppt test --source examples/powerpoint/vba --output "Verified.pptm" --trusted-test
python ExcelKit.py ppt export "Verified.pptm"
python ExcelKit.py ppt build --source examples/powerpoint/vba --ribbon examples/powerpoint/customUI.xml --output "PowerPointKit.ppam" --trusted-test
python ExcelKit.py ppt inspect "PowerPointKit.ppam"
```

- `inspect` reads the PPTX/PPTM/PPAM structure and the RibbonX from the Office package. `export` opens a PPTM read-only, turns macros off before opening, and exports the modules, classes, forms and the binary part if there is one.
- `test` uses a blank deck, imports the VBA, compiles, saves a PPTM and runs a test function that returns exactly `PASS`. The sample creates a slide and reads the shape text back. `--output` saves the test deck. [PowerPoint Application.Run](https://learn.microsoft.com/en-us/office/vba/api/powerpoint.application.run) · [PpSaveAsFileType](https://learn.microsoft.com/en-us/office/vba/api/powerpoint.ppsaveasfiletype)
- `build` checks the callback names, the Ribbon structure and the VBA in the PPAM. The runner loads it under a unique test name and confirms the path, runs the self-test under the current macro policy, removes the test add-in and then publishes the new file. The macros must be trusted code. Before release, click each button in PowerPoint on the target machine and check the real change. [AddIns.Add](https://learn.microsoft.com/en-us/office/vba/api/powerpoint.addins.add) · [AddIn.FullName](https://learn.microsoft.com/en-us/office/vba/api/powerpoint.addin.fullname) · [RibbonX](https://learn.microsoft.com/en-us/openspecs/office_standards/ms-customui2/452a58ae-cb0a-4926-83f8-fb1cbaa6114c)

On a failure, read `result.json` and `worker.log`. `ppt-connect` relates to the owned window or to COM. `ppt-vbproject` relates to permission to read the project. `vbe-compile` may need you to choose Compile in the VBE on another build. `--skip-compile` is only for a separate runtime run. An add-in blocked by policy needs the IT process.

Run the local regression with `OFFICE_KIT_POWERPOINT_TEST=1` and `python -m unittest discover -s tests -p test_powerpoint_kit.py -v`. By default this group of tests is skipped to avoid touching the user's desktop PowerPoint.
