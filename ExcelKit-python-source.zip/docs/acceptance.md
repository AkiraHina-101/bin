# Excel AI Kit acceptance

The local test environment uses **Windows Excel 16.0 build 20527, Python 3.8.10 x64 and pywin32 311**. Recheck on the company's Office build and policy before bringing it into the official workflow.

## Running the test suite

```text
python -m unittest discover -s tests -p "test_*.py" -v
python ExcelKit.py test --source examples/chart-shape --tests examples/chart-shape/tests --entry ChartShapeTest.Smoke
```

- **Session safety.** Two kit runs go at the same time, and one hangs on a `MsgBox`. The test Excel session outside the kit stays open and keeps its unsaved value. The VBA cases separately check a compile error, a runtime error, error codes, a modal timeout and the rejection of a macro that reports PASS while the data is wrong.
- **Synthetic dashboard.** A local CSV is loaded through Power Query into a table with numeric columns. A PivotTable reads this table. A slicer filters East and the total comes to 30. After the input data is changed, the refresh case expects a total of 70. The XY chart and the rectangle are reconciled after saving and reopening. A separate VBA case compares the rectangle position with the marker Excel draws when the axis and the size change.
- **VBA, UserForm and Ribbon.** Tests `Worksheet_Change` on a copy, exports the `.frm/.frx` pair, builds and reopens the `.xlam`. The **Review Dashboard** button on the Ribbon was clicked, the UserForm showed `Filtered total: 30` and it closed with the X button. The sample form is a result viewer window. The data entry, Esc and Cancel flows of a business form need a separate UI case.
- **Workbook preservation.** There are cases that check the source SHA-256, a failure in the middle of a batch, an output that already exists, a source that changed after the preview, a protected sheet, a duplicate series name and a range outside the scope. `inventory_diff` checks the objects that can be read. Use `assert.range` for specific ranges or business relationships that must be preserved.

## Public samples

Download from the official sources into an approved development folder. The kit's delivery packages contain only the kit's code and documents and the fixtures it creates itself.

| File placed in the sample folder | SHA-256 | Check |
| --- | --- | --- |
| `Financial Sample.xlsx` | `c3f17156ab7c192571ecfc742e88c16a4b7243a4d4b4a420fcb68dec44e10196` | Table inventory on a financial data workbook. [Microsoft Financial Sample](https://learn.microsoft.com/en-us/power-bi/create-reports/sample-financial-download) |
| `Dashboard Tutorial.xlsx` | `1855bc6f420c85aeb663cc6bf8d13a443a8e5f8c5375b3a75a4c0ad1c000a567` | Inventory of PivotTables, PivotCharts, slicers and related objects. [Microsoft Excel Dashboard Tutorial](https://support.microsoft.com/en-us/excel/create-and-share-a-dashboard-with-excel-and-microsoft-groups) |
| `Student Data Model.xlsx` | `8734161c5cd91c82100343b2c9db82174690d5f9000ee7b825c8da4023ae1e7a` | Use the **Complete** version. Recreate the relationship on the test copy, add a DAX measure and verify that the PivotTable returns 180. [Microsoft Student Data Model](https://support.microsoft.com/en-gb/excel/create-a-data-model-in-excel) |

Set the `EXCELKIT_PUBLIC_FIXTURES` environment variable to a folder containing the three file names above before you run unittest. By default the test suite skips this group of samples if the variable is not set. Run it in a development environment that does not use accounts for internal data sources.

**SpreadsheetBench.** Use `sample_data_200.tar.gz` from the project's public repository, SHA-256 `d5f97936a348aa84bbd4db818fc261adee1aa0429e21080b3157f98737da50d4`. The repository is published under CC BY-SA 4.0. The sample stays on the test machine and its source is cited here. [SpreadsheetBench and license](https://github.com/RUCKBReasoning/SpreadsheetBench)

```text
python -m tests.bench_public "<path>/sample_data_200.tar.gz"
```

**12/12 cases** were reconciled against the answer workbooks in Excel. The cases include lookups, spilled array formulas, SUMIFS with structured references, date-time handling, data normalization and multi-column sort. The median time was about **9.6 seconds per preview/apply pair** on the measured run. Each pair starts two Excel sessions in sequence, in addition to the reads of the oracle workbook. This is the result of 12 prepared solutions, and does not measure an AI solving the tasks or the time of manual work.

**Block-write comparison.** On the same Excel session, three runs writing 400 cells gave the same result. The median for writing cell by cell is **1.046 seconds** with 400 value assignments. The median for a single write through `Value2` is **0.0026 seconds**. The measurement covers only the write step, not starting Excel, opening the file or checking the result.

## Support status

- Use the `operations` command to see the schema of the installed version. Use the [command matrix, examples and checks](object-operations.md) when you delegate work.
- **Run on local samples:** workbook/sheet/range, tables, embedded charts, shapes, local PivotTables, local slicers, Power Query CSV, measures/relationships on an existing model, VBA events, UserForms and Ribbon callbacks.
- **Needs acceptance case by case:** OLAP slicer options, connectors that need authentication, editing a chart sheet, Power Query M outside the local samples, a model created from scratch, business UserForms and the first-time-correct speed of an AI fix. Directly editing an open workbook is left for a separate round.

## Simulating an AI that loses all context

To grade the agent's behavior with the same guidance and data, use the [control cases and the grading sheet](agent-testing.md).

Each continued read uses a new Python process and receives only the task ID, with no variables or chat content from the earlier run. The acceptance case keeps the latest request, compacts three times, blocks a summary that uses an old revision and keeps the unfinished step. The real Excel case runs preview/apply, simulates the loss of the final log after the file has been exported, and then verifies the file by SHA-256 and reads the result cell back. The hard-stop case interrupts a runner that is calling a macro and checks that a test Excel session outside the kit keeps its unsaved value.

```text
python -m unittest discover -s tests -p test_task.py -v
```

Set the `EXCELKIT_STOP_TEST=1` environment variable to run the two integration cases that use Excel. This is a simulation of the context-loss behavior shared by models. The time, the number of fix rounds and the first-time-correct rate of Claude Sonnet, GPT-6.1 or GPT-5.6 in the company application have not been measured. [How to load a checkpoint when you change chats](resume-after-stop.md)

To compare models in the company application, create a copy with the same data and use the same business command, for example **filter East, verify that the total is 30, keep the VBA and save a new copy**. For each model, run one run the current way and one run with a checkpoint in its own new chat. Stop after sending the apply command, and then open a new chat. Give both runs the same time and tool permissions. In the checkpoint run give only the task ID, and in the control run use only the information the company's workflow already has. Grade by reading the workbook and the log back.

| Metric | How to record it |
| --- | --- |
| Correct the first time | The first exported workbook passes all the output comparisons |
| Fix rounds | The number of times the AI needs to produce a fix after a check fails |
| Time | From the request to the first pass, with the recovery time after a Stop recorded separately |
| Repeated actions | The number of steps rerun after there was already evidence that the previous step succeeded |
| Safety | The outside session is still open, and the unsaved value and the source checksum are unchanged |

Repeat the case with the Stop point before the change and after the file export. Record the model, the application version, the tool permissions, the case ID, the Stop point and the result of each run. Compare only runs that have the same permissions and conditions.
