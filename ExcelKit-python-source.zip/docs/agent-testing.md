# Grading an agent working with Office

This document is for the coordinator. Give the agent the request and the files for the chosen case. Keep the grading sheet and the answers outside the agent's trial folder.

## Preparing a trial pair

1. Choose one model, one app version, the same Excel/Python/UI permissions and the same time limit. Open a new chat and use a separate folder for each run. Alternate which run goes first, the kit run or the control run, to reduce the effect of order.
2. The control run gets the existing workflow. The kit run starts from [Starting an Office task](getting-started.md) and the chosen business documents. Keep the request and the data identical. If you want to measure the effect of the documents on their own, give both runs the same runner.
3. If you may use Python and desktop Office, run the following for each new trial folder from the full kit. The files use synthetic data and are built with Excel. The `fixture-hashes.json` file is for the grader.

   ```text
   python -m tests.agent_trials runs/agent-baseline
   python -m tests.agent_trials runs/agent-kit
   ```

4. Hand over only one case folder and the documents that are granted. For the recovery case, build the fixture right at the working location, because the checkpoint holds full paths. Set the Stop point or the extra data according to the same script. Record the reason if a tool permission is missing or a model cannot be reached.

When you can only transfer Markdown, choose an equivalent internal workbook that you are allowed to use. The grader verifies the answer and keeps the evidence inside the company environment. Keep the same task wording, files and checks between the two runs.

## Priority cases

### VBA through a UserForm

- **Task:** "The Export Report button in `ReportTool.xlsm` computes the wrong total when East is selected. Fix it and hand over a new version, keeping the functions that are out of scope." Provide the file in the `vba` folder in a place where the sample macro is allowed to run.
- **Grading:** Reproduce East = 80 from the total of the whole region; after the fix, East = 30 and West = 50. Check Compile, a diff on exactly the right procedure, the modules and Ribbon outside the scope, the source hash and the CSV file. If there is a UI, try clicking the Ribbon, entering North, Cancel and then exporting through the form. Record separately if you only ran the procedure through COM.

### Report from two layouts and two CSVs

- **Task:** "Build the April 2026 report in both templates. Use the input files that come with it." Provide the four files in `report`. When the agent asks about the rule, answer "Net equals Gross minus Returns for both templates".
- **Grading:** Management has Net at Detail!G2 = E2 − F2, and Board has Net at Regional Detail!G9 = E9. The agent needs to point out the conflict and ask before exporting. The two outputs follow the exact sheets and header rows of the templates. Reconcile JPY = 1,100 and USD = 28.00, the totals per currency and the lines by region. The template has five March rows. With three new rows, check that the two old rows at the end were cleared in the output area before delivery.

### Stop and compact

- **Real run:** Use the same test data in two chats. Stop before applying a change, and then try one more pair right after the file has been exported. In the new chat, use the task ID or the note document that the run's workflow can store. When you try compacting, compare the verbatim request, the unfinished item and the evidence after each compaction.
- **Prepared simulation:** Use `recovery` to start from the point where the file is on disk, the final receipt is missing and the request has changed. The kit run gets "Continue task `trial-resume`". If the company only uses Markdown or the control run has its own mechanism, prepare an equivalent checkpoint according to that workflow. Record the difference when grading.
- **Grading:** Restore the latest request, reconcile the receipt and the SHA-256, open the right `Result.xlsx` and read Report!B2 = 42. Finish the unfinished step after verifying. Compare the hashes and check whether a new output file was created.

## Extended cases

- **Dashboard.** Build the changed data for the dashboard in [Excel acceptance](acceptance.md). Ask for a Pivot filter and for the rectangle to be aligned after the chart is resized. Compare the total with the source data, the shape position after reopening, and the unsaved value in a test session outside the kit.
- **Learning across two tasks.** Use the [chart and shape sample](chart-shape.md). The first case has an XY Scatter and a linear primary X axis. The next case changes the axis system or the chart type. Grade whether the agent finds the lesson that was checked, recognizes that the conditions changed and rechecks before applying it.

## Grading sheet

| Field | How to record it |
| --- | --- |
| Conditions | The actual model, app, tools, case, run, Stop point, and whether it was a plan trial or an Office run |
| Correct the first time | The first delivered file passes all the checks of the case. For a plan-only run, grade each criterion on the answer and record it as a plan |
| Intervention | The number of times the user had to remind the agent of the workflow or correct its direction. Record the number of necessary business questions separately |
| Fix rounds and time | The number of delivered files that had to be fixed, the time from the task to the first pass, and the recovery time if any |
| Evidence | The file, the content read back, the hash or receipt, and the errors that remain |

## Local reference run

The three priority cases passed the reference checks with desktop Excel and Python 3.8.10. The VBA compiled and exported East = 30. The two reports exported the right total for each currency and the two old rows were cleared. The recovery case read B2 = 42, compacted three times and then completed with the hash of the original export. The evidence is at `runs/agent-trials-reference.log` in the development workspace. Measure each model's first-time-correct rate and level of intervention with control runs in the target app.
