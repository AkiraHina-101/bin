# Excel VBA workflow on a company machine

This document is for workbooks that already exist in the company environment, with desktop Excel and Python 3.8.10. Bring the guides and the [Excel COM reference](excel-python-reference.md) through an approved channel. Use the Python runner when the source files are allowed to be used. The basic Python commands below use the standard library that is already installed.

When you delegate a new task or continue after a Stop, give the AI the [starting page](getting-started.md) together with the request or the task ID.

By default, work on a copy or in a separate Excel session. Use the mode that edits an open workbook only if the user asks for it explicitly and the tooling is allowed to support it. Identify the workbook path, the sheet and the range or object, show a preview of the change and let the user save. The existing Python runner uses a separate session.

Before the first action, save the task ID, the verbatim request and the current step outside the chat. If the AI forgets after you press Stop, open a new chat and tell the AI to read the checkpoint for that exact ID. [Guide to saving, continuing and compacting context](resume-after-stop.md)

## If the Python runner is allowed

```text
python ExcelKit.py doctor
python ExcelKit.py inspect "SPL_Tool_v3_test.xlsm" --verify-crc
python ExcelKit.py test
```

Read `runs/python-<id>/result.json` after each command. Use `read` for one range of cells, `export` to get the VBA that is allowed to be read, `test` to check on a blank workbook, `run` to run an existing function on an approved copy, and `build` to create an add-in in an approved environment.

**Bringing the kit to a company machine.** `dist/` contains only the kit (`ExcelKit-python-source.zip`, `ExcelKit-guides.zip`, created with `python tools/package_kit.py`). Add-ins built by the kit go separately in `output/`, not in `dist/`. Copy only these files, and the add-ins if you need them right away. Do not copy the whole working folder: `runs/`, `tasks/` and `__pycache__/` record absolute paths and the account name of the machine that ran them. The `build` command removes the author name, the company and the save folder (`absPath`) from the add-in, and then reports `FAIL` with `local_traces` if the package still contains a user profile path or a Windows account name.

**Checking a package before opening it.** Every command that reads a package rejects XML that contains a DTD. `inspect` lists `dde_ole_link_parts`, `external_link_parts` and `embedded_parts` (OLE, ActiveX) for review. `inventory`, `read`, `export`, `run`, `plan`, `apply`, `vba-patch` and `test --workbook` refuse to open a file with DDE/OLE links. After `ppt test/build`, the runner removes PowerPoint add-in registrations that point into `runs/` if the worker was stopped midway, and records them in `removed_addin_registrations`.

```text
python ExcelKit.py read "SPL_Tool_v3_test.xlsm" --sheet "Result" --range A1:D20
python ExcelKit.py export "SPL_Tool_v3_test.xlsm"
python ExcelKit.py --timeout 60 run "SPL_Tool_v3_test.xlsm" Module1.Smoke --trusted-test --expect expected.json
python ExcelKit.py build
```

Replace the sheet, the range and the function name with the real values. `run` opens a read-only copy, turns automatic events off and runs a parameterless function that returns the string `PASS`. Test event-dependent operations separately. Drop `--expect` if the VBA function fully confirms the output itself. To have Python additionally confirm that cell A1 on the Result sheet equals 42, use this content in `expected.json`:

```json
[
  {"sheet": "Result", "range": "A1", "values": [[42]]}
]
```

| What the JSON records | How to handle it |
| --- | --- |
| `stage: vbproject` | Check the permission to read the VBA project and whether the project is locked. Record the exact message |
| `stage: vbe-compile` | Read `dialogs`. Open `Smoke.xlsm` in the run folder if you need to see the highlighted line in the VBE |
| `stage: runtime/…` | Record `macro_result`, `com_description` or `dialogs`. If there is no line number yet, reproduce in the VBE and use Debug |
| `stage: assert-range/…` | Compare `mismatch.expected` and `mismatch.actual`. Check the business logic before you change the test |
| `status: TIMEOUT` | Read `stage` and `dialogs`. Check `stopped_test_excel`. The runner stops only the session it launched and keeps the process handle |

## 1. Narrowing down the defect

1. Create a working copy in an approved folder. Record the Excel name and build, the sheet or form, the sample data, the reproduction steps and the expected result.
2. If the defect is in a formula, record the cell address, the formula and the input values. If Excel shows a dialog, copy the title, the content and the buttons shown verbatim before you close it.
3. In the VBE, select the right project of the copy and run **Debug → Compile**. If Compile fails, record the module, the procedure and the highlighted line. For a missing-library message, check **Tools → References** and record the entry labeled **MISSING**.
4. After Compile passes, rerun the exact reproduction steps. For a runtime error, if the dialog offers **Debug**, use it to find the line where it stopped. Use **Run → Reset** in the VBE after you have recorded the information and want to end the trial run. For a dialog that asks to confirm saving or a data change, read it carefully and use the cancel button when you need to stop.

## 2. Using Python to check files

Run it in a terminal you are allowed to use. Replace the sample name with the path of a file you may read.

```text
python --version
python -m zipfile -t "SPL_Tool_v3_test.xlsm"
python -m zipfile -l "SPL_Tool_v3_test.xlsm"
```

The `-t` command checks ZIP integrity. Read the entire output, because Python 3.8.10 can print the name of a corrupt entry and still print `Done testing`. The `-l` command lists the components of the OOXML workbook, including `xl/vbaProject.bin` if there is a VBA project. Both commands read the file package without opening Excel or running macros. A `BadZipFile` error needs a check of the real format and of whether the file is encrypted. [Python zipfile documentation](https://docs.python.org/3/library/zipfile.html#command-line-interface) · [zipfile source in Python 3.8.10](https://github.com/python/cpython/blob/v3.8.10/Lib/zipfile.py#L2204-L2231)

If the company allows the AI to write scripts that read internal data right in the company workspace, give the AI additional checks with `zipfile` and `xml.etree.ElementTree`. Read and check the sheet names, the OOXML structure, the Ribbon relationship in `_rels/.rels`, duplicate IDs and the `onAction` callback names. For the workbook before and after the fix, you can use `hashlib` to confirm that the `vbaProject.bin` part is identical when the change only concerns data. Record the structure check results separately from the Compile, runtime and Ribbon button results. [Python ElementTree documentation](https://docs.python.org/3/library/xml.etree.elementtree.html) · [RibbonX specification](https://learn.microsoft.com/en-us/openspecs/office_standards/ms-customui2/452a58ae-cb0a-4926-83f8-fb1cbaa6114c)

## 3. Accepting VBA, UserForm and Ribbon changes

| Change | Evidence to record |
| --- | --- |
| VBA module | Compile the right project. Run a normal input and exactly the case that failed, on a copy. Record the expected and the actual result |
| UserForm | Open the form in Excel, try valid data, missing data and the **Cancel** action. If you are allowed to export the form, keep the `.frm` with the `.frx` exported by the VBE |
| RibbonX | Check the XML and the callbacks. Load the add-in through the IT process, click the real button and record the result |
| Excel blocks a macro or project access | Record the message verbatim and the step that was blocked. Pass the request to the responsible IT contact |

Excel and the VBE perform Compile and runtime. When you need to build an `.xlam`, use a development environment the company has approved and confirm with IT how the add-in gets onto users' machines. [VBE Debug Menu](https://learn.microsoft.com/en-us/office/vba/language/reference/user-interface-help/debug-menu) · [Excel macro policy](https://learn.microsoft.com/en-us/microsoft-365-apps/security/internet-macros-blocked)

## Delegation prompt for an AI

> Read this guide and the accompanying Excel COM reference. Work on a copy of a workbook you have been allowed to use. Determine whether the defect belongs to a formula, VBA compile, runtime, UserForm or Ribbon. Record the reproduction steps, the dialog text verbatim, the object or the line with the error and the expected output. If the Python runner is allowed, run doctor and then choose the command from the table. For a business logic defect, record at least one input and the reference result, and use --expect when it can be checked through a range of cells. Make the smallest change and rerun the reproduction case. Record the Compile, runtime, business result and UI evidence according to the steps you tried. If you hit a block from access rights or policy, record the exact step and message for the person with authority to handle it.

When you work with charts, shapes, tables or PivotTables, record the object name, the Excel object that contains it and the property to change. Check the actual property after the run. For charts and shapes, determine the coordinate system before you compute positions. [Example of aligning a rectangle to a vertical series](chart-shape.md)

When you are allowed to use the runner, use the chain `inventory → plan → apply`, get the catalog of fields from `python ExcelKit.py operations`, and use `assert.range` with the reference output. The result is written to a new path after verification with Excel. [Commands, JSON examples and handling object errors](object-operations.md)
