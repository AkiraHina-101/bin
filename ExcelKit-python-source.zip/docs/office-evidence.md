# Office kit acceptance

The local scope is Windows desktop, Excel and PowerPoint 16.0, Python 3.8.10 and pywin32. Excel reports build 20527. The edits and runs use synthetic fixtures in a test session. The SHA-256 of `SPL_Tool_v3.xlsm` was compared with its original value, `1A4C7F79E537E6738E403A7CCB10E954C6F9AEB0FB00EE4D534CA5D912D143C3`.

The acceptance run on 2026-11-15 passed 27/27 automated tests, including the optional cases for stopping the runner, PowerPoint, reports and Microsoft samples. The local log is at `runs/office-kit-final-tests.log`. The Ribbon-click cases below were additionally checked on the UI.

| Area | Evidence |
| --- | --- |
| Excel VBA | Reproduced the wrong total `East,80`. Patched a one-line `Sum` into `SumIf`. Compiled in the VBE, ran on a second test copy, read B5 back as 30 and compared the CSV with the expected answer. Code in out-of-scope modules, references, Ribbon XML and the source hash all matched. Rerun with `tests/test_vba_patch.py`. |
| Excel Ribbon and UserForm | Clicked **Report Kit → Export Report**. The form showed East by default. Entered North and clicked Export. The form reported "Enter East or West." and no CSV was written. Cancel closed the form. Reopened, exported East and read a CSV with `Region,Total` and `East,30`. Local evidence at `runs/office-ui-form/Report.csv`. |
| Resuming after a stop | Hard-stopped the shared runner and checked that the session created by the kit was cleaned up. Simulated the three patch boundaries and tried the case where the export finished but the receipt was lost. The checkpoint stores the verbatim request, the artifact, the SHA-256 and the pending step. See `tests/test_task.py` and `tests/test_vba_patch.py`. |
| PowerPoint VBA and PPAM | Compiled through the VBE and ran a PPTM. Exported the modules, built a PPAM with RibbonX, loaded it and ran the self-test. Clicked **PowerPoint Kit → Add verification slide** on a blank deck. Read back through COM exactly one slide and a `KitResult` shape containing "PowerPoint VBA verified". Cases for a wrong callback, an open deck with unsaved changes and a modal timeout are in `tests/test_powerpoint_kit.py`. |
| Report from a sample | Read the OOXML structure of the sample files, confirmed the KPIs and then generated the writes. Two real Excel layouts had different sheet names and header rows. Tried a CSV with renamed and reordered columns, several months, regions and currencies. Compared the Excel formulas with Decimal, reopened and reconciled the output. Cases for a missing column, conflicting KPIs and duplicate keys are in `tests/test_report_profile.py`. |

## Rerunning in the test environment

```powershell
$env:EXCELKIT_STOP_TEST='1'
$env:OFFICE_KIT_POWERPOINT_TEST='1'
$env:OFFICE_KIT_REPORT_TEST='1'
python -m unittest discover -s tests -p "test_*.py" -v
```

`EXCELKIT_PUBLIC_FIXTURES` can point to a folder of Microsoft samples to run the additional dashboard and Data Model cases. [Source and scope of the public samples](research.md)

1. For the Excel UI, set `OFFICE_KIT_EXCEL_UI_FIXTURE` to an empty test folder before running `test_vba_patch.py`. Open the generated `Verified-Report.xlsm` through an approved macro workflow. Rerun the North, Cancel and East flow. See [how to patch and check](vba-patch.md).
2. For the PowerPoint UI, use a test machine, load the PPAM that the kit built and open a blank deck before clicking the sample buttons. Check the slide and removing the add-in. See the [PowerPoint commands](powerpoint-vba.md).
3. For reports, see the [prompt and sample cases](report-from-sample.md). Rerun with a report you are allowed to use on the company machine and grade Claude Sonnet, GPT-6.1 or GPT-5.6 if the company app provides that model. The results in the table are checks on local fixtures. Model comparison figures and Office access rights need to be verified in the company app.

## Handover

The Markdown package contains guides and prompts that can be used right away when the company channel allows documents. The source package is for environments where code is allowed, and it includes the sample UserForm resource pair `.frm/.frx`. Run `doctor` on the target machine's Office, confirm the project access permission and the macro policy, and only then do the first acceptance on a copy. Editing an open workbook is only an optional flow, used when the user asks for it explicitly and the tooling supports it.
