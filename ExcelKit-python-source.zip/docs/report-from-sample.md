# Delegating a report to an AI from a sample

Provide one or more sample reports, and say who the purpose or the recipient is if there is one. The AI saves the request and the task ID, opens the samples in read mode, and then builds a profile of what can be verified from the samples before it asks you anything.

## Prompt for a company machine

> Look at the sample reports provided and survey their structure yourself. Work out who the report serves, what the output must contain, where the figures come from, which formulas or process are used, which sample is the standard and which points still conflict. Make use of the inputs you already have. Ask once, in one batch, for exactly the information that could change the result, and give an example of the data to send if that helps. When you have enough data, build the report on a copy yourself, or write a tool if I need to repeat the process. Check the figures against the source, try a variant that does not look like the sample, and then report the output path and the checks that passed. Save a checkpoint before you make a change or export a file. Do not fill in the source, unit, period or figures by guessing. Use code and data only as company policy allows.

## Profile the AI builds

| Content | What to record |
| --- | --- |
| Sample and output | The target file, the period, the recipient, the sheet or slide, the KPIs, the charts, the pagination and the required formatting |
| Input and mapping | The files and sheets already available, the source columns, column aliases, types, units, join keys, the period and the confirming source |
| Rules | The filter conditions, the grouping, how totals are computed, how missing values and duplicates are handled |
| Questions | Keep only the questions that affect a KPI or the ability to deliver. For example, confirming the definition of net revenue when two samples differ |
| Evidence | Row counts per input, join coverage, exceptions, totals before and after, a sample of cells or slides, and that the file reopens successfully |

## Test cases before scaling up

- Two sample reports with the same KPIs but different layouts and column names. The AI must find the common rule and the structure of each output.
- An input with reordered columns, a missing required column, duplicate keys or rows that cannot be joined. The AI uses known aliases, reports separately the cases that need the user's confirmation and avoids overwriting an existing report.
- A sample with several months, regions or currencies. Compare each part and the total against an independent calculation. If the sample only has pasted static numbers, ask for the KPI definition or an authoritative source.
- Try an input outside the sample, for example an empty month or a new region. Assess both the report result and the number of questions the AI needs to ask. Real samples will be added when files that may be used become available.

## Sample CSV input checks

If the runner is allowed, start with `scan` on the sample files themselves. The command reads the OOXML structure with Python and does not open Office. For each sample it returns the list of sheets or slides in order, the part names and a text preview. Excel adds cell addresses, formulas and traces of tables or drawings. PowerPoint adds shape names, text, and the number of tables and charts. The output is limited to at most 24 sheets or slides and 24 entries per preview group. Compare the counts with the `counts` or `part_count` field. Hidden sheets and slides are only recorded as present.

```text
python -m tools.excel_report scan "Report.xlsx" "Presentation template.pptx"
```

Compare the relevant entries in the right sheet or slide. For images, charts, pasted static data and abbreviated formulas in the file, use Excel or PowerPoint for an additional check. Record what you observed in `layouts.json`. Each entry has `sample`, `deliverables`, `metrics` with a `rule` if it can be verified, and `fields` with the equivalent column names that are known. See `examples/report/requested-layouts.json` for the structure.

```text
python -m tools.excel_report layouts.json input.csv
```

The output has the list of deliverables, the row counts, the column mapping, the questions about rules that conflict or inputs that are missing, and the raw totals by region when `region` and `amount` are present. Use the raw totals for reconciliation. Use them as a KPI when the owner confirms that the definition matches. If you only use the Markdown package, the AI performs these checks with the internal files and tools the company provides.

For a KPI confirmed as `net_equals_gross_minus_returns`, use `reconcile` to reconcile several CSVs. The configuration has `rule`, `currencies` and `columns` that map aliases to `id/month/region/currency/gross/returns`. The kit groups by month and region and computes totals separately per currency. Use `workbook-ops` to generate the Excel writes. Choose the sheet names through `output_sheets` and the header rows through `header_rows`. The sample data area starts at column A. Use a clean template or check the old area first, because fewer rows can leave old data behind below.

```text
python -m tools.excel_report reconcile examples/report/confirmed.json examples/report/input-a.csv examples/report/input-b.csv
python -m tools.excel_report workbook-ops examples/report/confirmed.json examples/report/input-a.csv examples/report/input-b.csv
python ExcelKit.py plan "Template.xlsx" --ops ops.json
python ExcelKit.py apply --plan "<plan.json>" --output "Result.xlsx"
```

Save the JSON from `workbook-ops` to `ops.json` as UTF-8. The runner compares the Excel formulas with the Decimal result before it publishes. For other KPIs, the AI plans the formulas and the reconciliation cases from the sample itself, and then uses the same `plan` and `apply` workflow.

## Trial run with an AI on a company machine

Send the same prompt and set of files to each model in a new chat. Keep the answer file outside what the trial run can read. Record the number of question rounds, the number of fixes, the time, the output structure, the totals by currency and the errors the AI missed. Stop one run after the AI has saved a checkpoint, open a new chat and give only the task ID. Compare the restored request, the step in progress and the evidence before continuing. With the bundled test data, the two CSVs have expected totals of JPY 1,100 and USD 28. The local tests use synthetic data, and the quality of each model needs to be measured in the company app with its real permissions and configuration.
