# Object operations in Excel AI Kit

The kit runs desktop Excel for Windows through Python 3.8.10 and pywin32. Each command opens its own Excel session. Editing an open workbook belongs to an option for later, and is used only when the user asks for it explicitly.

## Workflow for an AI

```text
python ExcelKit.py doctor
python ExcelKit.py inventory "Source.xlsx" --kind table --kind pivot --kind chart
python ExcelKit.py operations
python ExcelKit.py plan "Source.xlsx" --ops ops.json
python ExcelKit.py apply --plan "<path to plan.json from the previous result>" --output "Result.xlsx"
```

`inventory` returns the name, the container and the relationships of each object, along with a warning when Excel cannot read a group. `--sheet` limits it to the objects that belong to the specified worksheet. Workbook-level objects such as connections, slicer caches and the Data Model need a run without `--sheet`. `operations` is the catalog of fields that the current version of the kit understands.

`plan` does a real trial run on a copy and records the before/after of each operation. Check `changes` and `inventory_diff` before you use `apply`. `apply` verifies the SHA-256 and the target state, repeats the work on a copy, saves and then reopens to confirm. The output must be a new path with the same `.xlsx` or `.xlsm` extension as the source. Dependent changes such as PivotTable totals or chart positions can show up in `inventory_diff`. Also add `assert.range` for important ranges or for ranges outside the scope that must stay unchanged.

An example `ops.json` for a workbook that already has a `Report` sheet:

```json
{
  "version": 1,
  "operations": [
    {"id": "inputs", "op": "range.values", "sheet": "Report", "range": "A2:B2", "values": [["0007", 120]]},
    {"id": "calc", "op": "range.formulas", "sheet": "Report", "range": "C2", "formulas": [["=B2*2"]]},
    {"id": "verify", "op": "assert.range", "sheet": "Report", "range": "C2", "values": [[240]]}
  ]
}
```

The batch runs in the order declared. Give objects clear names, use A1 addresses and English Excel function names. Enter ranges as two-dimensional arrays. Text values such as codes with a leading zero, or strings that start with `=`, use `range.values`. Formulas use `range.formulas`. For a spilled formula use `dynamic: true`, write the formula into one cell and verify the whole range where it is expected to spill. Use real Excel values for numbers. A date read through `Value2` is a day number in the workbook's date system. `range.formulas` and `name.set` reject, already at the plan step, formulas that call outside the workbook: `WEBSERVICE`, `IMAGE`, `RTD`, `CALL`, `REGISTER`, `EXEC`, `STOCKHISTORY`, references to other workbooks (`[Book.xlsx]`, `C:\…`, `\\server\…`), URLs and DDE links (`app|topic`). Text inside double quotes is not checked. Addresses must be within `A1:XFD1048576`. [Range.Value2](https://learn.microsoft.com/en-us/office/vba/api/excel.range.value2) · [Formula and Formula2](https://learn.microsoft.com/en-us/office/vba/excel/concepts/cells-and-ranges/range-formula-vs-formula2)

## Objects, operations and checks

| Object | Commands | Verification |
| --- | --- | --- |
| Worksheet, cell, name | `sheet.create`, `range.values`, `range.formulas`, `range.sort`, `range.format`, `range.validation`, `name.set` | Compare values, formulas, format, the whole-number limits and the name address. Sort takes relative column indexes from 1, ascending, with the first row as the header |
| Excel Table | `table.create`, `table.resize`, `table.filter` | Compare the range, the header and the filter condition. Try the expected set of rows with representative data |
| Chart, series, axis | `chart.create/update`, `series.create/update`, `axis.set` | Embedded charts. Check the series source, the axis limits and the position after reopening. X/Y are two one-dimensional ranges of equal length on the chart's sheet |
| Chart shape, sheet shape | `shape.create/update`, `shape.align_series` | A newly created shape is a rectangle. Geometry uses points with `left/top/width/height`. The align operation requires a two-point XY Scatter on a linear primary X axis. Use `on_worksheet: true` for a rectangle that belongs to the sheet. When the data or the chart size changes later, call the align operation again |
| PivotTable and slicer | `pivot.create`, `pivot.layout`, `pivot.refresh`, `slicer.create`, `slicer.filter` | Use a local table, one SUM aggregation field and a list of rows/columns. `slicer.filter` takes the item names in the cache. Reconcile the total after filtering with `assert.range` |
| Power Query | `query.set`, `query.csv`, `query.load`, `query.refresh` | `query.set` supports the expression `Excel.CurrentWorkbook(){[Name="TableName"]}[Content]`. `query.csv` uses an absolute path on a fixed local drive (no mapped network drives, UNC or USB; copy the CSV to a local drive first), UTF-8 CSV with a header and commas. Use `number_columns` to set number types by the `en-US` locale. Recreate the preview if the CSV changes. When a PivotTable reads the output table, call `pivot.refresh` after `query.refresh` |
| Data Model | `model.relationship`, `model.measure`, `model.pivot` | Use a model that already has tables. Verify the columns on both sides, the DAX measure and the total figures through a PivotTable on a copy |
| VBA, UserForm, RibbonX | `export`, `test`, `run`, `build` | Compile and test in Excel. Click the callback from the Ribbon and open/cancel the UserForm on a sample workbook. Record the UI check result separately |

`operations` lists both the required and the optional fields. For charts, `chart_type` accepts `column`, `bar`, `line`, `scatter`, `scatter_lines`, `scatter_lines_markers`. For `axis.set`, use `x` or `y` for the primary axis. A category axis may not support numeric limits. An OLAP slicer uses MDX member names through COM and needs to be checked on the exact model. [Chart.Axes](https://learn.microsoft.com/en-us/office/vba/api/excel.chart.axes) · [PivotTables](https://learn.microsoft.com/en-us/office/vba/api/excel.pivottables) · [SlicerCache](https://learn.microsoft.com/en-us/office/vba/api/excel.slicercache)

## VBA on a real workbook

`test --workbook <copy.xlsm> --documents <folder> --events` loads the test file, replaces the body of the document module with the same **CodeName** and compiles. For example, `Sheet3.document.cls` must point at the module that currently has the code name `Sheet3`. Also use `--tests <folder> --entry Module.Smoke`. The imported code is tried on a copy. The VBA code or the test function should catch errors inside and return exactly the string `PASS` after it has checked the result.

In `test`, `--events` turns events on while the smoke function runs, which suits trying `Worksheet_Change`. To try a `Workbook_Open` that is already saved in an approved sample workbook, use `run <file.xlsm> Module.Smoke --trusted-test --events` and compare the sign the event produces. `build` checks the package and calls the self-test through COM. Also verify the callback from the real Ribbon button when you accept an add-in.

## Scope and diagnosis

- Use an Excel test environment the company has approved, and do not sign in to external data sources when you open a downloaded workbook. The kit opens with macros off, does not update workbook links and rejects some refresh-on-open configurations. Test trusted macros through the dedicated command. [AutomationSecurity](https://learn.microsoft.com/en-us/office/vba/api/excel.application.automationsecurity)
- If the JSON records `operation/<id>`, fix the operation with that ID. `verify/<id>` points to a result that differs after Excel processed it or reopened it. `excel-start` usually relates to Office registration or a startup dialog. Read `dialogs`, `worker.log` and `com_description` if present.
- For objects outside the catalog, such as a chart sheet that needs editing, a shape on a secondary axis, a connector that needs sign-in or a UserForm layout, use VBA or separate Excel actions on a copy. Record the target object, the steps taken and the actual check. [Excel COM and VBA reference](excel-python-reference.md)
