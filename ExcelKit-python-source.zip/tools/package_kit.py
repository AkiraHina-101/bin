"""Build the two distributable ZIPs from an explicit source manifest."""

from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]
DOCS = [
    "company-machine.md", "excel-python-reference.md", "object-operations.md",
    "chart-shape.md", "acceptance.md", "research.md", "resume-after-stop.md",
    "vba-patch.md", "office-evidence.md", "report-from-sample.md",
    "powerpoint-vba.md", "getting-started.md", "project-lessons.md", "agent-testing.md",
]


def archive(name, files):
    dest = ROOT / "dist" / name
    dest.parent.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=dest.parent) as folder:
        staged = Path(folder) / name
        with ZipFile(staged, "x", ZIP_DEFLATED) as output:
            for file in files:
                output.write(file, file.relative_to(ROOT).as_posix())
        with ZipFile(staged) as output:
            if output.testzip() is not None or len(output.namelist()) != len(files):
                raise RuntimeError("Failed to verify " + str(staged))
        staged.replace(dest)
    print(dest)


def main():
    docs = [ROOT / "docs" / name for name in DOCS]
    source = [
        ROOT / "README.md", ROOT / "ExcelKit.py", *docs,
        *sorted((ROOT / "tools").glob("excel_*.py")), Path(__file__).resolve(),
        *sorted((ROOT / "ribbon").glob("*.xml")),
        *sorted((ROOT / "vba").glob("*.bas")),
        *sorted((ROOT / "tests").glob("*.py")),
        *sorted((ROOT / "tests" / "cases").glob("*.bas")),
        *sorted((ROOT / "tests" / "vba").glob("Kit*")),
        *sorted((ROOT / "examples").rglob("*.bas")),
        *sorted((ROOT / "examples").rglob("*.xml")),
        *sorted((ROOT / "examples").rglob("*.json")),
        *sorted((ROOT / "examples").rglob("*.csv")),
        *sorted((ROOT / "examples").rglob("*.code")),
    ]
    archive("ExcelKit-guides.zip", docs)
    archive("ExcelKit-python-source.zip", source)


if __name__ == "__main__":
    main()
