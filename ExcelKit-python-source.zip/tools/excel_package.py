"""Inspect Excel OPC packages and add a RibbonX part to a staged add-in."""

from collections import Counter
from pathlib import PurePosixPath
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile
import posixpath
import os
import re
import shutil
import tempfile


REL = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
RIBBONS = {
    "http://schemas.microsoft.com/office/2006/relationships/ui/extensibility":
        "http://schemas.microsoft.com/office/2006/01/customui",
    "http://schemas.microsoft.com/office/2007/relationships/ui/extensibility":
        "http://schemas.microsoft.com/office/2009/07/customui",
}
MODERN = "http://schemas.microsoft.com/office/2007/relationships/ui/extensibility"
ADDIN = "application/vnd.ms-excel.addin.macroEnabled.main+xml"


# Office parts never need a DTD. Rejecting one blocks entity-expansion payloads before expat runs.
DTD = re.compile(rb"<!(?:DOCTYPE|ENTITY)|<\x00!\x00", re.I)
CORE = "docProps/core.xml"
APP = "docProps/app.xml"
ABS_PATH = re.compile(rb"<(?:[A-Za-z0-9_]+:)?absPath\b[^>]*?/>")
PERSONAL = {
    CORE: re.compile(rb"(<(dc:creator|cp:lastModifiedBy)\b[^>]*>)[^<]*(</\2>)"),
    APP: re.compile(rb"(<(Company|Manager)\b[^>]*>)[^<]*(</\2>)"),
}


def parse_xml(data):
    if DTD.search(data):
        raise ValueError("XML with a DTD or entity declaration is not accepted.")
    return ET.fromstring(data)


def scrub_part(name, payload):
    """Remove build-machine identity: author names and the folder Excel saved from."""
    if name.lower().endswith("/workbook.xml"):
        payload = ABS_PATH.sub(b"", payload)
    pattern = PERSONAL.get(name)
    if pattern:
        payload = pattern.sub(lambda m: m.group(1) + m.group(3), payload)
    return payload


def local_traces(path):
    """Return package parts that still mention a Windows user profile or this account."""
    markers = [b"\\users\\", b"/users/"]
    for variable in ("USERNAME", "USERPROFILE", "COMPUTERNAME"):
        value = os.environ.get(variable, "").strip()
        if len(value) >= 3:
            markers += [value.lower().encode("utf-8"), value.lower().encode("utf-16-le")]
    found = []
    with ZipFile(path) as archive:
        for name in archive.namelist():
            data = archive.read(name).lower()
            if any(marker in data for marker in markers):
                found.append(name)
    return found


def scrub_package(source, output):
    with ZipFile(source) as original, ZipFile(output, "x", ZIP_DEFLATED) as archive:
        read_package(original)
        for name in original.namelist():
            archive.writestr(name, scrub_part(name, original.read(name)))


def publish_new(source, output):
    publish(source, output, os.rename)


def publish_replace(source, output):
    publish(source, output, os.replace)


def publish(source, output, move):
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(dir=str(output.parent), prefix=".excel-kit-", suffix=".tmp")
    os.close(fd)
    try:
        shutil.copyfile(source, temp_name)
        move(temp_name, output)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def read_package(zip_file):
    counts = Counter(zip_file.namelist())
    duplicates = [name for name, count in counts.items() if count > 1]
    if duplicates:
        raise ValueError("Duplicate ZIP entries: " + ", ".join(duplicates))
    rels = parse_xml(zip_file.read("_rels/.rels"))
    types = parse_xml(zip_file.read("[Content_Types].xml"))
    if rels.tag != "{%s}Relationships" % REL or types.tag != "{%s}Types" % CT:
        raise ValueError("Invalid root relationship or content types XML.")
    return counts, rels, types


def internal_target(relationship):
    uri = urlsplit(relationship.attrib["Target"])
    if relationship.get("TargetMode", "Internal") != "Internal" or any(
        (uri.scheme, uri.netloc, uri.query, uri.fragment)
    ):
        raise ValueError("Expected an internal package part.")
    name = posixpath.normpath(unquote(uri.path).lstrip("/"))
    if name in (".", "..") or name.startswith("../") or "\\" in name:
        raise ValueError("Invalid package part path: " + name)
    return name


def ribbon_actions(root, namespace):
    if root.tag != "{%s}customUI" % namespace:
        raise ValueError("Wrong RibbonX root or namespace.")
    ids = [node.attrib["id"] for node in root.iter() if "id" in node.attrib]
    if any(not value.strip() for value in ids) or len(set(ids)) != len(ids):
        raise ValueError("RibbonX contains blank or duplicate IDs.")
    actions = [node.attrib["onAction"] for node in root.iter() if "onAction" in node.attrib]
    if any(not action.strip() for action in actions):
        raise ValueError("RibbonX contains an empty onAction.")
    return actions


def inspect_package(path, verify_crc=False, root_directory="xl"):
    with ZipFile(path) as archive:
        names, rels, types = read_package(archive)
        if verify_crc:
            bad = archive.testzip()
            if bad:
                raise ValueError("ZIP integrity failed: " + bad)
        overrides = {node.get("PartName"): node.get("ContentType") for node in types
                     if node.tag == "{%s}Override" % CT}
        defaults = {node.get("Extension"): node.get("ContentType") for node in types
                    if node.tag == "{%s}Default" % CT}
        workbook_rels = [node for node in rels if node.get("Type", "").endswith("/officeDocument")]
        if len(workbook_rels) != 1:
            raise ValueError("Expected one workbook relationship.")
        workbook = internal_target(workbook_rels[0])
        if workbook not in names or not workbook.startswith(root_directory + "/"):
            raise ValueError("Missing expected Office document part: " + workbook)
        vba = sorted(name for name in names if name.lower().endswith("/vbaproject.bin"))
        xlm = sorted(name for name in names if name.lower().startswith("xl/macrosheets/"))
        xlm.extend(part for part, kind in overrides.items()
                   if "macrosheet" in (kind or "").lower() and part.lstrip("/") not in xlm)
        ribbons = []
        for kind, namespace in RIBBONS.items():
            matches = [node for node in rels if node.get("Type") == kind]
            if len(matches) > 1:
                raise ValueError("Duplicate RibbonX relationships for: " + kind)
            if not matches:
                continue
            part = internal_target(matches[0])
            extension = PurePosixPath(part).suffix.lstrip(".")
            if overrides.get("/" + part, defaults.get(extension)) != "application/xml":
                raise ValueError("Unexpected RibbonX content type: " + part)
            actions = ribbon_actions(parse_xml(archive.read(part)), namespace)
            ribbons.append({"part": part, "onAction": actions})
        connections = []
        for name in names:
            if (name == "xl/connections.xml" or
                    (name.startswith(("xl/queryTables/", "xl/pivotCache/pivotCacheDefinition"))
                     and name.endswith(".xml") and "/_rels/" not in name)):
                root = parse_xml(archive.read(name))
                for node in root.iter():
                    if any(key.rsplit("}", 1)[-1].lower() == "refreshonload" and value in ("1", "true")
                           for key, value in node.attrib.items()):
                        connections.append(name)
                        break
        prefix = root_directory + "/"
        external = sorted(name for name in names if name.startswith(prefix + "externalLinks/")
                          and name.endswith(".xml") and "/_rels/" not in name)
        live_links = [name for name in external
                      if re.search(rb"<(?:[A-Za-z0-9_]+:)?(?:ddeLink|oleLink)\b", archive.read(name))]
        embedded = sorted(name for name in names
                          if name.startswith((prefix + "embeddings/", prefix + "activeX/")))
        return {"workbook_part": workbook, "workbook_content_type": overrides.get("/" + workbook),
                "vba_parts": vba, "xlm_parts": xlm, "ribbon_parts": ribbons,
                "refresh_on_open_parts": connections,
                "external_link_parts": external, "dde_ole_link_parts": live_links,
                "embedded_parts": embedded,
                "vba_signatures": [name for name in names if "/vbaprojectsignature" in name.lower()],
                "package_signatures": any(p.lower().startswith("_xmlsignatures/") for p in names)}


def add_ribbon(source, output, markup):
    part = "customUI/customUI.xml"
    with ZipFile(source) as original, ZipFile(output, "x", ZIP_DEFLATED) as archive:
        names, rels, types = read_package(original)
        rid = "rIdExcelAIKitRibbon"
        if part in names or any(r.get("Type") == MODERN or r.get("Id") == rid for r in rels):
            raise ValueError("Staged add-in already contains the RibbonX part or relationship ID.")
        if any(p.lower().startswith("_xmlsignatures/") for p in names):
            raise ValueError("Expected an unsigned add-in package.")
        ET.SubElement(rels, "{%s}Relationship" % REL, Id=rid, Type=MODERN, Target=part)
        ET.SubElement(types, "{%s}Override" % CT, PartName="/" + part, ContentType="application/xml")
        replacements = {"_rels/.rels": rels, "[Content_Types].xml": types}
        for name in names:
            if name in replacements:
                payload = ET.tostring(replacements[name], encoding="utf-8", xml_declaration=True)
            else:
                payload = scrub_part(name, original.read(name))
            archive.writestr(name, payload)
        archive.writestr(part, markup)
