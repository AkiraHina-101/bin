"""Validate exact VBA source edits and preview them as unified diffs."""

from difflib import unified_diff
import re


START = re.compile(r"^\s*(?:(?:Public|Private|Friend|Static)\s+)*(?:Sub|Function|Property\s+(?:Get|Let|Set))\s+([A-Za-z][A-Za-z0-9_]*)\b", re.I)
END = re.compile(r"^\s*End\s+(?:Sub|Function|Property)\s*(?:'.*)?$", re.I)


def snapshot(project):
    components = {}
    for component in project.VBComponents:
        module = component.CodeModule
        count = module.CountOfLines
        code = module.Lines(1, count).splitlines() if count else []
        components[component.Name] = {"type": component.Type, "lines": code}
    return {"components": components,
            "references": sorted((ref.Guid, ref.Major, ref.Minor) for ref in project.References)}


def edits(state, document):
    if not isinstance(document, dict) or set(document) != {"version", "edits"} or document["version"] != 1:
        raise ValueError('Expected {"version": 1, "edits": [...]}.')
    requested = document["edits"]
    if not isinstance(requested, list) or not 1 <= len(requested) <= 20:
        raise ValueError("Expected 1–20 edits.")
    result, seen = [], set()
    for item in requested:
        required = {"module", "procedure", "before", "after"}
        if (not isinstance(item, dict) or set(item) != required or
                any(not isinstance(item[k], str) or not item[k].strip() for k in required)):
            raise ValueError("Each edit needs module, procedure, before and after text.")
        name = item["module"]
        if name in seen:
            raise ValueError("Use one contiguous edit per module: " + name)
        seen.add(name)
        source = state["components"].get(name)
        if not source or source["type"] not in (1, 2, 3, 100):
            raise ValueError("Unknown or unsupported module: " + name)
        code = source["lines"]
        procedures = [i for i, line in enumerate(code)
                      if START.match(line) and START.match(line)[1].casefold() == item["procedure"].casefold()]
        if len(procedures) != 1:
            raise ValueError("Procedure name must identify one declaration in " + name)
        start = procedures[0]
        if code[start].rstrip().endswith("_"):
            raise ValueError("This patch command requires a single-line procedure declaration.")
        end = next((i for i in range(start + 1, len(code)) if END.match(code[i])), None)
        if end is None:
            raise ValueError("Procedure has no supported standalone End statement.")
        old, new = item["before"].splitlines(), item["after"].splitlines()
        if old == new or any(START.match(line) or END.match(line) or
                             re.match(r"^\s*(?:#|Attribute\b)", line, re.I) for line in old + new):
            raise ValueError("Patch a changed body block without declarations or directives.")
        matches = [i for i in range(start + 1, end - len(old) + 1) if code[i:i + len(old)] == old]
        if len(matches) != 1:
            raise ValueError("Before text must match exactly once inside %s.%s." % (name, item["procedure"]))
        index = matches[0]
        if "#if" in "\n".join(code[start:end]).lower() or code[index - 1].rstrip().endswith("_") or (
            old[-1].rstrip().endswith("_") or new[-1].rstrip().endswith("_")
        ):
            raise ValueError("Patch must avoid conditional-compilation and partial continuation blocks.")
        changed = code[:index] + new + code[index + len(old):]
        result.append({"module": name, "line": index + 1, "remove": len(old),
                       "insert": new, "expected_code": changed,
                       "diff": "\n".join(unified_diff(code, changed, "before/" + name, "after/" + name,
                                                     lineterm=""))})
    return result
