"""Declarative, scoped operations for a disposable workbook."""

import math
from pathlib import Path
import re
from time import perf_counter

import pythoncom

from .excel_schema import KINDS, NAMES, SCHEMA


A1 = re.compile(r"\$?([A-Za-z]{1,3})\$?([1-9][0-9]{0,6})(?::\$?([A-Za-z]{1,3})\$?([1-9][0-9]{0,6}))?")
MAX_CELLS = 100000
MAX_COLUMN, MAX_ROW = 16384, 1048576  # XFD, Excel 2007+ grid
# Functions that reach the network, another process or native code when Excel calculates.
OUTBOUND_FUNCTIONS = re.compile(
    r"(?<![A-Za-z0-9_.])(?:_xlfn\.)?(?:WEBSERVICE|IMAGE|RTD|CALL|REGISTER(?:\.ID)?|EXEC|"
    r"STOCKHISTORY|SQL\.REQUEST)\s*\(", re.I)
EXTERNAL_REFERENCE = re.compile(
    r"\[[^\]\[]*\.(?:xl[a-z]{0,2}|csv|ods)\]|\[\d+\][^!\[\]]*!|[A-Za-z]:\\|\\\\|[a-z][a-z0-9+.-]*://|\|",
    re.I)


def column_number(letters):
    value = 0
    for letter in letters.upper():
        value = value * 26 + ord(letter) - 64
    return value


def valid_a1(address):
    match = isinstance(address, str) and A1.fullmatch(address)
    if not match:
        return False
    columns, rows = match.group(1, 3), match.group(2, 4)
    return (all(column_number(c) <= MAX_COLUMN for c in columns if c) and
            all(int(r) <= MAX_ROW for r in rows if r))


def without_strings(formula):
    # Text inside "..." (with "" escapes) cannot reference anything by itself.
    return re.sub(r'"(?:[^"]|"")*"', '""', formula)


def check_formula(formula):
    """Reject formulas that call out of the workbook: network, DDE, other files or native code."""
    if not isinstance(formula, str) or not formula.startswith("="):
        raise ValueError("Expected an invariant Excel formula starting with '='.")
    code = without_strings(formula)
    if OUTBOUND_FUNCTIONS.search(code):
        raise ValueError("Formula calls a network, RTD or native-code function: " + formula[:200])
    if EXTERNAL_REFERENCE.search(code):
        raise ValueError("Formula refers to another file, a URL or a DDE link: " + formula[:200])
    return formula


def fixed_local_drive(path):
    """True only for a drive letter on a fixed local disk (not mapped, removable or UNC)."""
    import ctypes

    drive = Path(path).drive
    if len(drive) != 2 or drive[1] != ":":
        return False
    return ctypes.windll.kernel32.GetDriveTypeW(drive + "\\") == 3  # DRIVE_FIXED


def list_items(items):
    return [items.Item(index) for index in range(1, items.Count + 1)]


def inventory(book, sheet_name, kinds):
    selected = set(kinds or KINDS)
    if selected - KINDS:
        raise ValueError("Unknown inventory kind: " + ", ".join(sorted(selected - KINDS)))
    data, warnings = [], []

    def group(kind, owner, build):
        if kind in selected:
            try:
                data.extend(dict(kind=kind, owner=owner, **item) for item in build())
            except (pythoncom.com_error, AttributeError) as error:
                warnings.append({"kind": kind, "owner": owner, "message": str(error)})

    def chart_items(graph, owner, props):
        group("chart", owner, lambda: [dict(props, chart_type=graph.ChartType)])
        group("series", owner + "/" + props["name"], lambda: [
            {"name": item.Name, "index": index, "axis_group": item.AxisGroup, "formula": item.Formula}
            for index, item in enumerate(list_items(graph.SeriesCollection()), 1)])
        group("shape", owner + "/" + props["name"], lambda: describe_shapes(graph.Shapes, "chart"))

    for sheet in ([book.Worksheets.Item(sheet_name)] if sheet_name else book.Worksheets):
        owner = sheet.Name
        group("sheet", owner, lambda: [{"name": owner, "code_name": sheet.CodeName,
                                        "protected": sheet.ProtectContents, "visible": sheet.Visible}])
        group("table", owner, lambda: [{"name": t.Name, "range": t.Range.Address,
                                       "columns": [c.Name for c in t.ListColumns]} for t in sheet.ListObjects])
        group("shape", owner, lambda: describe_shapes(sheet.Shapes, "worksheet"))
        group("pivot", owner, lambda: [{"name": p.Name, "range": p.TableRange2.Address,
                                       "cache_index": p.CacheIndex, "olap": p.PivotCache().OLAP,
                                       "source_type": p.PivotCache().SourceType}
                                      for p in list_items(sheet.PivotTables())])
        if selected & {"chart", "series", "shape"}:
            try:
                for obj in list_items(sheet.ChartObjects()):
                    chart_items(obj.Chart, owner, {"name": obj.Name, "container": "worksheet"})
            except (pythoncom.com_error, AttributeError) as error:
                warnings.append({"kind": "chart", "owner": owner, "message": str(error)})
    if not sheet_name:
        for graph in book.Charts:
            chart_items(graph, book.Name, {"name": graph.Name, "container": "chart_sheet"})
        group("name", book.Name, lambda: [{"name": n.Name, "refers_to": n.RefersTo} for n in book.Names])
        group("slicer", book.Name, lambda: [{"name": c.Name, "olap": c.OLAP, "source": c.SourceName,
                                            "pivots": [p.Name for p in list_items(c.PivotTables)],
                                            "slicers": [s.Name for s in c.Slicers]}
                                           for c in book.SlicerCaches])
        group("query", book.Name, lambda: [{"name": q.Name} for q in book.Queries])
        group("connection", book.Name, lambda: [{"name": c.Name, "type": c.Type} for c in book.Connections])
        group("model", book.Name, lambda: model_inventory(book))
        if book.HasVBProject:
            group("vba", book.Name, lambda: [{"name": c.Name, "type": c.Type}
                                             for c in book.VBProject.VBComponents])
    return {"workbook": book.Name, "objects": data, "warnings": warnings}


def model_inventory(book):
    if not any(c.Type == 7 for c in book.Connections):  # xlConnectionTypeMODEL
        return []
    model = book.Model
    tables = [{"name": table.Name, "type": "table",
               "columns": [c.Name for c in table.ModelTableColumns]} for table in model.ModelTables]
    measures = [{"name": item.Name, "type": "measure", "table": item.AssociatedTable.Name}
                for item in model.ModelMeasures]
    relationships = [{"name": item.ForeignKeyTable.Name + "." + item.ForeignKeyColumn.Name,
                      "type": "relationship", "primary_table": item.PrimaryKeyTable.Name,
                      "primary_column": item.PrimaryKeyColumn.Name, "active": item.Active}
                     for item in model.ModelRelationships]
    return tables + measures + relationships


def describe_shapes(shapes, container):
    return [{"name": item.Name, "type": item.Type, "container": container, **geometry(item)}
            for item in shapes]


def geometry(obj):
    return {key.lower(): round(float(getattr(obj, key)), 2)
            for key in ("Left", "Top", "Width", "Height")}


def valid_string(value):
    return isinstance(value, str) and bool(value.strip())


def number(value):
    return (type(value) is int and abs(value) < 10 ** 308) or (
        type(value) is float and math.isfinite(value))


def equal(actual, expected, tolerance=0):
    if number(actual) and number(expected):
        return abs(actual - expected) <= tolerance
    if isinstance(actual, (list, tuple)) and isinstance(expected, (list, tuple)):
        return len(actual) == len(expected) and all(equal(a, b, tolerance) for a, b in zip(actual, expected))
    if isinstance(actual, dict) and isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(equal(actual[k], v, tolerance) for k, v in expected.items())
    return type(actual) is type(expected) and actual == expected


def sheet_range(sheet, address):
    if not valid_a1(address):
        raise ValueError("Expected a single rectangular A1 address within A1:XFD1048576.")
    area = sheet.Range(address)
    if area.Rows.Count * area.Columns.Count > MAX_CELLS:
        raise ValueError("Range exceeds the operation limit (%s cells)." % MAX_CELLS)
    return area


def matrix(area, value):
    return [[value]] if area.Rows.Count == area.Columns.Count == 1 else [list(row) for row in value]


def check_matrix(area, data, formulas=False):
    rows, cols = area.Rows.Count, area.Columns.Count
    if not isinstance(data, list) or len(data) != rows or any(
        not isinstance(row, list) or len(row) != cols for row in data
    ):
        raise ValueError("Expected a two-dimensional array matching the target range.")
    for row in data:
        for value in row:
            if formulas:
                check_formula(value)
            elif value is not None and type(value) is not bool and not number(value) and not isinstance(value, str):
                raise ValueError("Expected text, finite number, boolean or null.")


def exact(items, name):
    matches = [item for item in items if item.Name.casefold() == name.casefold()]
    if len(matches) != 1:
        raise ValueError("Expected exactly one object named %r, found %s." % (name, len(matches)))
    return matches[0]


def create_or_find(items, name, create):
    matches = [item for item in items if item.Name.casefold() == name.casefold()]
    if len(matches) > 1:
        raise ValueError("Duplicate object name: " + name)
    if create and matches:
        raise ValueError("Object already exists: " + name)
    if not create and not matches:
        raise ValueError("Object does not exist: " + name)
    return matches[0] if matches else None


CHART_TYPES = {"column": 51, "bar": 57, "line": 4, "scatter": -4169,
               "scatter_lines": 75, "scatter_lines_markers": 74}


def parse_ops(document):
    if not isinstance(document, dict) or set(document) != {"version", "operations"} or document["version"] != 1:
        raise ValueError('Expected {"version": 1, "operations": [...]}.')
    ops = document["operations"]
    if not isinstance(ops, list) or not 1 <= len(ops) <= 200:
        raise ValueError("Expected 1–200 operations.")
    ids = set()
    for op in ops:
        if not isinstance(op, dict) or not valid_string(op.get("id")) or op["id"] in ids:
            raise ValueError("Every operation must have a unique nonempty id.")
        ids.add(op["id"])
        kind = op.get("op")
        if not isinstance(kind, str) or kind not in SCHEMA:
            raise ValueError("Unsupported operation: " + str(kind))
        required, optional = (set(part.split()) for part in SCHEMA[kind])
        keys = op.keys() - {"id", "op"}
        if required - keys or keys - required - optional:
            raise ValueError("Invalid fields for %s: missing %s, unexpected %s."
                             % (op["id"], sorted(required - keys), sorted(keys - required - optional)))
        if any(not valid_string(op[k]) for k in keys & NAMES):
            raise ValueError("Object names and addresses must be nonempty strings: " + op["id"])
        # Static safety check at plan time, before Excel sees the formula.
        if kind == "range.formulas" and isinstance(op["formulas"], list):
            for row in op["formulas"]:
                for value in row if isinstance(row, list) else []:
                    check_formula(value)
        if kind == "name.set":
            check_formula(op["refers_to"])
    return ops


def targets(op):
    """Fields used to compare a target's baseline across preview and apply."""
    return {key: op[key] for key in ("sheet", "range", "name", "chart", "axis", "table", "cell")
            if key in op}


def chart_for(book, op, key="chart"):
    return book.Worksheets.Item(op["sheet"]).ChartObjects(op[key]).Chart


def put_geometry(item, dimensions):
    keys = {"left", "top", "width", "height"}
    if not isinstance(dimensions, dict) or set(dimensions) != keys or any(
        not number(v) or v < 0 or (k in {"width", "height"} and v == 0)
        for k, v in dimensions.items()
    ):
        raise ValueError("Geometry requires finite left/top and positive width/height in points.")
    for key in ("width", "height", "left", "top"):
        setattr(item, key.capitalize(), dimensions[key])
    if not equal(geometry(item), dimensions, 0.03):
        raise ValueError("Excel returned unexpected object geometry.")


def enable_local_queries(book):
    # Declarative query mutations/refresh use a small, auditable local-source recipe.
    for item in book.Queries:
        validate_local_m(item.Formula)


def csv_dependencies(book, operations):
    if not any(op["op"].startswith("query.") for op in operations):
        return set()
    paths = {Path(op["path"]).resolve() for op in operations if op["op"] == "query.csv"}
    for query in book.Queries:
        match = re.search(r'File\.Contents\("([^"]+)"\)', query.Formula)
        if match:
            validate_local_m(query.Formula)
            paths.add(Path(match.group(1)).resolve())
    return paths


def validate_local_m(formula):
    if isinstance(formula, str) and re.fullmatch(
        r'\s*Excel\.CurrentWorkbook\(\)\{\[Name="[A-Za-z_][A-Za-z0-9_]*"\]\}\[Content\]\s*', formula
    ):
        return formula.strip()
    if isinstance(formula, str):
        source = formula.strip()
        convert = re.fullmatch(
            r'Table\.TransformColumnTypes\((.*),\{(\{"[A-Za-z_][A-Za-z0-9_ ]*",type number\}'
            r'(?:,\{"[A-Za-z_][A-Za-z0-9_ ]*",type number\})*)\},"en-US"\)', source)
        if convert:
            source = convert.group(1)
        match = re.fullmatch(
            r'Table\.PromoteHeaders\(Csv\.Document\(File\.Contents\("([^"\r\n]+)"\),'
            r'\[Delimiter=",",Columns=([0-9]+),Encoding=65001\]\)\)', source)
        if match:
            path = Path(match.group(1))
            if fixed_local_drive(path) and path.is_file() and path.suffix.lower() == ".csv":
                return formula.strip()
    raise ValueError("Use a current-workbook table or the local CSV recipe (query.csv).")


def handle(book, op):
    kind = op["op"]
    if kind == "sheet.create":
        create_or_find(book.Sheets, op["sheet"], True)
        item = book.Worksheets.Add()
        item.Name = op["sheet"]
        return {"name": item.Name}
    sheet = book.Worksheets.Item(op["sheet"]) if "sheet" in op else None
    if kind.startswith("range.") or kind == "assert.range":
        return range_operation(sheet, op)
    if kind == "name.set":
        check_formula(op["refers_to"])
        item = book.Names.Add(op["name"], op["refers_to"])
        return {"name": item.Name, "refers_to": item.RefersTo}
    if kind.startswith("table."):
        return table_operation(sheet, op)
    if kind.startswith(("chart.", "series.", "axis.", "shape.")):
        return visual_operation(book, sheet, op)
    if kind.startswith(("pivot.", "slicer.")):
        return pivot_operation(book, sheet, op)
    return data_operation(book, sheet, op)


def range_operation(sheet, op):
    area = sheet_range(sheet, op["range"])
    kind = op["op"]
    if kind == "assert.range":
        values = op["values"]
        check_matrix(area, values)
        tolerance = op.get("tolerance", 0)
        actual = matrix(area, area.Value2)
        if not number(tolerance) or tolerance < 0:
            raise ValueError("Tolerance must be a nonnegative finite number.")
        for row, (got, wanted) in enumerate(zip(actual, values), 1):
            for column, (left, right) in enumerate(zip(got, wanted), 1):
                if not equal(left, right, tolerance):
                    raise ValueError("Unexpected output in %s!%s at relative row %s, column %s. "
                                     "Expected %r, got %r." % (sheet.Name, op["range"], row, column, right, left))
        return {"values": actual}
    if area.MergeCells is None or area.MergeCells:
        raise ValueError("Range intersects merged cells. Address the merge explicitly in Excel.")
    if kind == "range.values":
        check_matrix(area, op["values"])
        # Excel parses leading '=' in Value2. Prefix each input string with an apostrophe.
        wire = tuple(tuple("'" + v if isinstance(v, str) else v for v in row) for row in op["values"])
        area.Value2 = wire[0][0] if area.Rows.Count == area.Columns.Count == 1 else wire
        actual = matrix(area, area.Value2)
        if not equal(actual, op["values"]):
            raise ValueError("Excel normalized one or more values. Check empty strings or numeric precision.")
        return {"values": actual}
    if kind == "range.formulas":
        check_matrix(area, op["formulas"], True)
        dynamic = op.get("dynamic", False)
        if type(dynamic) is not bool:
            raise ValueError("dynamic must be boolean.")
        prop = "Formula2" if dynamic else "Formula"
        data = tuple(tuple(row) for row in op["formulas"])
        setattr(area, prop, data[0][0] if area.Rows.Count == area.Columns.Count == 1 else data)
        return {"formulas": matrix(area, getattr(area, prop)), "values": matrix(area, area.Value2)}
    if kind == "range.format":
        area.NumberFormat = op["number_format"]
        return {"number_format": area.NumberFormat}
    if kind == "range.sort":
        keys = op["keys"]
        if not isinstance(keys, list) or not keys or any(
            type(key) is not int or not 1 <= key <= area.Columns.Count for key in keys
        ) or len(set(keys)) != len(keys):
            raise ValueError("Sort keys must be distinct 1-based column indices within the range.")
        sorter = sheet.Sort
        sorter.SortFields.Clear()
        for key in keys:
            sorter.SortFields.Add(area.Columns.Item(key), 0, 1)
        sorter.SetRange(area)
        sorter.Header = 1
        sorter.Apply()
        return {"values": matrix(area, area.Value2)}
    minimum, maximum = op["minimum"], op["maximum"]
    if not number(minimum) or not number(maximum) or maximum < minimum:
        raise ValueError("Expected a valid numeric validation interval.")
    validation = area.Validation
    validation.Delete()
    validation.Add(2, 1, 1, minimum, maximum)  # xlValidateWholeNumber / Stop / Between
    return {"type": validation.Type, "minimum": validation.Formula1, "maximum": validation.Formula2}


def table_operation(sheet, op):
    kind = op["op"]
    if kind == "table.create":
        area = sheet_range(sheet, op["range"])
        create_or_find(sheet.ListObjects, op["name"], True)
        header = area.Rows.Item(1)
        headers = matrix(header, header.Value2)[0]
        if any(not valid_string(h) for h in headers) or len({h.casefold() for h in headers}) != len(headers):
            raise ValueError("Excel table headers must be distinct, nonempty text.")
        item = sheet.ListObjects.Add(1, area, pythoncom.Missing, 1)
        item.Name = op["name"]
        if "style" in op:
            item.TableStyle = op["style"]
    else:
        item = sheet.ListObjects.Item(op["name"])
        if kind == "table.resize":
            item.Resize(sheet_range(sheet, op["range"]))
        else:
            field = item.ListColumns.Item(op["column"]).Index
            criterion = str(op["equals"]).replace("~", "~~").replace("*", "~*").replace("?", "~?")
            item.Range.AutoFilter(field, "=" + criterion)
            applied = item.AutoFilter.Filters.Item(field)
            if not applied.On:
                raise ValueError("Excel did not apply the table filter.")
            return {"range": item.Range.Address, "criterion": applied.Criteria1}
    return {"name": item.Name, "range": item.Range.Address,
            "columns": [column.Name for column in item.ListColumns]}


def visual_operation(book, sheet, op):
    kind = op["op"]
    if kind.startswith("chart."):
        items = list_items(sheet.ChartObjects())
        obj = create_or_find(items, op["name"], kind == "chart.create")
        if obj is None:
            obj = sheet.ChartObjects().Add(1, 1, 100, 100)
            obj.Name = op["name"]
        graph = obj.Chart
        if "chart_type" in op:
            graph.ChartType = CHART_TYPES[op["chart_type"]]
        if "title" in op:
            graph.HasTitle = True
            graph.ChartTitle.Text = op["title"]
        if "geometry" in op:
            put_geometry(obj, op["geometry"])
        return chart_state(obj)
    graph = chart_for(book, op) if "chart" in op else None
    if kind.startswith("series."):
        items = graph.SeriesCollection()
        xs, ys = sheet_range(sheet, op["x"]), sheet_range(sheet, op["y"])
        if (xs.Rows.Count > 1 and xs.Columns.Count > 1) or (ys.Rows.Count > 1 and ys.Columns.Count > 1) or xs.Count != ys.Count:
            raise ValueError("Series X and Y must be one-dimensional ranges with equal lengths.")
        series = create_or_find(list_items(items), op["name"], kind == "series.create")
        if series is None:
            series = items.NewSeries()
            series.Name = op["name"]
        if "chart_type" in op:
            series.ChartType = CHART_TYPES[op["chart_type"]]
        series.XValues = xs
        series.Values = ys
        return series_state(series)
    if kind == "axis.set":
        axis = axis_for(graph, op)
        minimum, maximum = op["minimum"], op["maximum"]
        if not number(minimum) or not number(maximum) or maximum <= minimum:
            raise ValueError("Axis bounds need minimum < maximum.")
        if minimum >= axis.MaximumScale:
            axis.MaximumScale = maximum
            axis.MinimumScale = minimum
        else:
            axis.MinimumScale = minimum
            axis.MaximumScale = maximum
        if "reversed" in op:
            if type(op["reversed"]) is not bool:
                raise ValueError("reversed must be boolean.")
            axis.ReversePlotOrder = op["reversed"]
        return axis_state(axis)
    host = sheet if graph is None or op.get("on_worksheet", False) else graph
    if kind == "shape.create":
        create_or_find(host.Shapes, op["name"], True)
        item = host.Shapes.AddShape(1, 1, 1, 20, 20)  # msoShapeRectangle
        item.Name = op["name"]
    else:
        item = exact(host.Shapes, op["name"])
    if kind == "shape.align_series":
        item.Left = aligned_left(sheet, graph, item, op)
    if "geometry" in op:
        put_geometry(item, op["geometry"])
    if "text" in op:
        item.TextFrame2.TextRange.Text = op["text"]
    return shape_state(item, op)


def aligned_left(sheet, graph, shape, op):
    series = exact(list_items(graph.SeriesCollection()), op["series"])
    if series.ChartType not in (74, 75) or series.AxisGroup != 1 or shape.Type != 1 or shape.AutoShapeType != 1:
        raise ValueError("Align shape requires a rectangle and a primary straight-line XY series.")
    xs, ys = list(series.XValues), list(series.Values)
    if len(xs) != 2 or len(ys) != 2 or not all(number(v) for v in xs + ys) or xs[0] != xs[1] or ys[0] == ys[1]:
        raise ValueError("A vertical series needs two numeric points with equal X and different Y.")
    graph.Refresh()
    axis = graph.Axes(1, 1)
    minimum, maximum = axis.MinimumScale, axis.MaximumScale
    if axis.ScaleType != -4132 or not minimum <= xs[0] <= maximum or maximum <= minimum:
        raise ValueError("X must be visible on a linear axis.")
    fraction = (xs[0] - minimum) / (maximum - minimum)
    if axis.ReversePlotOrder:
        fraction = 1 - fraction
    plot = graph.PlotArea
    if plot.InsideWidth <= 0:
        raise ValueError("Excel has not laid out the plot area.")
    offset = sheet.ChartObjects(op["chart"]).Left if op.get("on_worksheet", False) else 0
    return offset + plot.InsideLeft + fraction * plot.InsideWidth - shape.Width / 2


def chart_state(obj):
    graph = obj.Chart
    return {"name": obj.Name, "chart_type": graph.ChartType, "geometry": geometry(obj),
            "title": graph.ChartTitle.Text if graph.HasTitle else None}


def series_state(series):
    return {"name": series.Name, "formula": series.Formula, "chart_type": series.ChartType}


def axis_for(graph, op):
    if op["axis"] not in ("x", "y"):
        raise ValueError("Expected axis x or y.")
    return graph.Axes(1 if op["axis"] == "x" else 2, 1)


def axis_state(axis):
    return {"minimum": axis.MinimumScale, "maximum": axis.MaximumScale, "reversed": bool(axis.ReversePlotOrder)}


def shape_state(item, op):
    state = {"name": item.Name, "geometry": geometry(item)}
    if "text" in op:
        state["text"] = item.TextFrame2.TextRange.Text
    return state


def pivot_operation(book, sheet, op):
    kind = op["op"]
    if kind == "slicer.filter":
        return filter_slicer(book.SlicerCaches, op)
    if kind == "slicer.create":
        pivot = book.Worksheets.Item(op["pivot_sheet"]).PivotTables(op["pivot"])
        if pivot.PivotCache().OLAP:
            raise ValueError("Creating a slicer requires a classic PivotTable.")
        cache = book.SlicerCaches.Add2(pivot, op["field"], op["name"])
        dims = op["geometry"]
        slicer = cache.Slicers.Add(sheet)
        slicer.Name = op["name"]
        slicer.Caption = op["field"]
        put_geometry(slicer, dims)
        return {"name": cache.Name, "slicer": slicer.Name, "geometry": geometry(slicer)}
    if kind == "pivot.create":
        table = book.Worksheets.Item(op["source_sheet"]).ListObjects.Item(op["table"])
        destination = sheet_range(sheet, op["cell"])
        if destination.Count != 1:
            raise ValueError("Pivot destination must be one cell.")
        cache = book.PivotCaches().Create(1, table.Name)
        pivot = cache.CreatePivotTable(destination, op["name"])
        pivot.AddDataField(pivot.PivotFields(op["value"]), op["caption"], -4157)  # xlSum
    else:
        pivot = sheet.PivotTables(op["name"])
    if pivot.PivotCache().OLAP:
        raise ValueError("Pivot layout mutations require a classic PivotTable.")
    if kind == "pivot.refresh":
        if pivot.PivotCache().SourceType != 1:
            raise ValueError("Pivot refresh requires a local worksheet source.")
        if not pivot.RefreshTable():
            raise ValueError("Excel could not refresh the PivotTable.")
        return pivot_state(pivot)
    rows, columns = op["rows"], op["columns"]
    if any(not isinstance(fields, list) or any(not valid_string(f) for f in fields)
           for fields in (rows, columns)) or len(set(f.casefold() for f in rows + columns)) != len(rows + columns):
        raise ValueError("Pivot rows and columns require distinct field names.")
    pivot.ManualUpdate = True
    try:
        for field in list_items(pivot.RowFields) + list_items(pivot.ColumnFields):
            field.Orientation = 0
        for layout, orientation in ((rows, 1), (columns, 2)):
            for index, name in enumerate(layout, 1):
                field = pivot.PivotFields(name)
                field.Orientation = orientation
                field.Position = index
    finally:
        pivot.ManualUpdate = False
    pivot.Update()
    return pivot_state(pivot)


def pivot_state(pivot):
    return {"name": pivot.Name, "rows": [f.Name for f in list_items(pivot.RowFields)],
            "columns": [f.Name for f in list_items(pivot.ColumnFields)],
            "values": [f.Name for f in list_items(pivot.DataFields)],
            "range": pivot.TableRange2.Address}


def filter_slicer(caches, op):
    cache = caches.Item(op["name"])
    selected = op["selected"]
    if not isinstance(selected, list) or not selected or any(not valid_string(v) for v in selected):
        raise ValueError("Slicer selection must be a nonempty list of item names.")
    if cache.OLAP:
        cache.VisibleSlicerItemsList = tuple(selected)
    else:
        items = list_items(cache.SlicerItems)
        available = {item.Name for item in items}
        if set(selected) - available:
            raise ValueError("Unknown slicer items: " + ", ".join(sorted(set(selected) - available)))
        cache.ClearManualFilter()
        for item in items:
            if item.Name not in selected:
                item.Selected = False
    result = slicer_selection(cache)
    if sorted(set(selected)) != result["selected"]:
        raise ValueError("Unexpected slicer selection.")
    return result


def slicer_selection(cache):
    names = cache.VisibleSlicerItemsList if cache.OLAP else [i.Name for i in cache.SlicerItems if i.Selected]
    return {"name": cache.Name, "selected": sorted(names or [])}


def data_operation(book, sheet, op):
    kind = op["op"]
    if kind in {"query.set", "query.csv"}:
        if kind == "query.csv":
            path = Path(op["path"])
            if not fixed_local_drive(path):
                raise ValueError("query.csv reads only from a fixed local disk. "
                                 "Copy the CSV from a network, mapped or removable drive first.")
            if not path.is_absolute() or any(c in str(path) for c in '"#\r\n') or (
                type(op["columns"]) is not int or not 1 <= op["columns"] <= 200
            ):
                raise ValueError("Use an absolute local CSV path and a column count from 1 to 200.")
            formula = ('Table.PromoteHeaders(Csv.Document(File.Contents("%s"),'
                       '[Delimiter=",",Columns=%d,Encoding=65001]))') % (path, op["columns"])
            numeric = op.get("number_columns", [])
            if not isinstance(numeric, list) or any(
                not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_ ]*", value)
                for value in numeric
            ) or len(set(numeric)) != len(numeric):
                raise ValueError("number_columns requires distinct simple CSV header names.")
            if numeric:
                types = ",".join('{"%s",type number}' % value for value in numeric)
                formula = 'Table.TransformColumnTypes(%s,{%s},"en-US")' % (formula, types)
        else:
            formula = op["formula"]
        formula = validate_local_m(formula)
        existing = [item for item in book.Queries if item.Name.casefold() == op["name"].casefold()]
        if existing:
            query = existing[0]
            query.Formula = formula
        else:
            query = book.Queries.Add(op["name"], formula)
        return {"name": query.Name, "formula": query.Formula}
    if kind.startswith("query."):
        enable_local_queries(book)
        query = book.Queries.Item(op["name"])
        if kind == "query.load":
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", query.Name):
                raise ValueError("Query load requires a simple query name.")
            destination = sheet_range(sheet, op["cell"])
            if destination.Count != 1:
                raise ValueError("Query load destination must be one cell.")
            connection = ('OLEDB;Provider=Microsoft.Mashup.OleDb.1;Data Source=$Workbook$;Location='
                          + query.Name + ';Extended Properties=""')
            table = sheet.ListObjects.Add(0, connection, False, 1, destination)
            table.Name = op["table"]
            table.QueryTable.CommandType = 2
            table.QueryTable.CommandText = "SELECT * FROM [" + query.Name + "]"
            table.QueryTable.Refresh(False)
            return {"table": table.Name, "range": table.Range.Address}
        query.Refresh()
        book.Application.CalculateUntilAsyncQueriesDone()
        return {"name": query.Name, "formula": query.Formula}
    model = book.Model
    if kind == "model.pivot":
        destination = sheet_range(sheet, op["cell"])
        if destination.Count != 1:
            raise ValueError("Model Pivot destination must be one cell.")
        cache = book.PivotCaches().Create(2, model.DataModelConnection, 6)
        pivot = cache.CreatePivotTable(destination, op["name"])
        field = pivot.CubeFields.Item("[Measures].[" + op["measure"] + "]")
        field.Orientation = 4
        return model_pivot_state(pivot, op)
    if kind == "model.relationship":
        foreign = model.ModelTables.Item(op["foreign_table"]).ModelTableColumns.Item(op["foreign_column"])
        primary = model.ModelTables.Item(op["primary_table"]).ModelTableColumns.Item(op["primary_column"])
        item = model.ModelRelationships.Add(foreign, primary)
        return relationship_state(item)
    table = model.ModelTables.Item(op["table"])
    formula = op["formula"].strip()
    if formula.startswith("="):
        formula = formula[1:]
    item = model.ModelMeasures.Add(op["name"], table, formula, model.ModelFormatGeneral,
                                   op.get("description", ""))
    return measure_state(item)


def relationship_state(item):
    return {"foreign_table": item.ForeignKeyTable.Name, "foreign_column": item.ForeignKeyColumn.Name,
            "primary_table": item.PrimaryKeyTable.Name, "primary_column": item.PrimaryKeyColumn.Name,
            "active": bool(item.Active)}


def measure_state(item):
    return {"name": item.Name, "table": item.AssociatedTable.Name, "formula": item.Formula}


def model_pivot_state(pivot, op):
    if not pivot.PivotCache().OLAP:
        raise ValueError("Expected a Data Model PivotTable.")
    field = pivot.CubeFields.Item("[Measures].[" + op["measure"] + "]")
    if field.Orientation != 4:
        raise ValueError("Data Model measure is missing from the PivotTable.")
    return {"name": pivot.Name, "measure": field.Name, "range": pivot.TableRange2.Address}


def state_for(book, op):
    kind = op["op"]
    if kind == "assert.range":
        return handle(book, op)
    sheet = book.Worksheets.Item(op["sheet"]) if "sheet" in op else None
    if kind == "sheet.create":
        return {"name": sheet.Name}
    if kind.startswith("range."):
        area = sheet_range(sheet, op["range"])
        if kind in {"range.values", "range.sort"}:
            return {"values": matrix(area, area.Value2)}
        if kind == "range.formulas":
            prop = "Formula2" if op.get("dynamic", False) else "Formula"
            return {"formulas": matrix(area, getattr(area, prop)), "values": matrix(area, area.Value2)}
        if kind == "range.format":
            return {"number_format": area.NumberFormat}
        return {"type": area.Validation.Type, "minimum": area.Validation.Formula1,
                "maximum": area.Validation.Formula2}
    if kind == "name.set":
        item = book.Names.Item(op["name"])
        return {"name": item.Name, "refers_to": item.RefersTo}
    if kind.startswith("table.") or kind == "query.load":
        item = sheet.ListObjects.Item(op["name"] if kind.startswith("table.") else op["table"])
        result = {"name": item.Name, "range": item.Range.Address,
                  "columns": [column.Name for column in item.ListColumns]}
        if kind == "table.filter":
            applied = item.AutoFilter.Filters.Item(item.ListColumns.Item(op["column"]).Index)
            result["criterion"] = applied.Criteria1 if applied.On else None
        return result
    if kind.startswith("chart."):
        return chart_state(sheet.ChartObjects(op["name"]))
    if kind.startswith("series."):
        return series_state(exact(list_items(chart_for(book, op).SeriesCollection()), op["name"]))
    if kind == "axis.set":
        return axis_state(axis_for(chart_for(book, op), op))
    if kind.startswith("shape."):
        host = chart_for(book, op) if "chart" in op and not op.get("on_worksheet", False) else sheet
        item = exact(host.Shapes, op["name"])
        if kind == "shape.align_series" and abs(item.Left - aligned_left(sheet, chart_for(book, op), item, op)) > 1:
            raise ValueError("Shape did not align with the chart series.")
        return shape_state(item, op)
    if kind.startswith("pivot."):
        return pivot_state(sheet.PivotTables(op["name"]))
    if kind == "slicer.create":
        cache = book.SlicerCaches.Item(op["name"])
        item = cache.Slicers.Item(op["name"])
        return {"name": cache.Name, "slicer": item.Name, "geometry": geometry(item)}
    if kind == "slicer.filter":
        return slicer_selection(book.SlicerCaches.Item(op["name"]))
    if kind.startswith("query."):
        item = book.Queries.Item(op["name"])
        return {"name": item.Name, "formula": item.Formula}
    if kind == "model.measure":
        return measure_state(book.Model.ModelMeasures.Item(op["name"]))
    if kind == "model.pivot":
        return model_pivot_state(sheet.PivotTables(op["name"]), op)
    for item in book.Model.ModelRelationships:
        state = relationship_state(item)
        if all(state[k] == op[k] for k in ("foreign_table", "foreign_column", "primary_table", "primary_column")):
            return state
    raise ValueError("Model relationship not found.")


def changes(book, operations, stage, report, baseline=None):
    report["changes"] = []
    for op in operations:
        stage("operation/" + op["id"])
        started = perf_counter()
        try:
            before = state_for(book, op) if op["op"] not in {"assert.range", "shape.align_series"} else None
        except (pythoncom.com_error, ValueError, AttributeError):
            before = None  # creation, or Excel has not populated the property yet
        if baseline is not None and not equal(before, baseline[len(report["changes"])], 1e-6):
            report["verification"] = {"expected": baseline[len(report["changes"])], "actual": before}
            raise ValueError("Target state differs from the preview.")
        if op["op"] == "assert.range":
            book.Application.Calculate()
        actual = handle(book, op)
        report["changes"].append({"id": op["id"], "op": op["op"], "before": before,
                                  "target": targets(op), "after": actual,
                                  "elapsed_ms": round((perf_counter() - started) * 1000)})
    book.Application.Calculate()
    return snapshots(book, operations, stage)


def snapshots(book, operations, stage):
    values = []
    for op in operations:
        stage("verify/" + op["id"])
        values.append(state_for(book, op))
    return values
