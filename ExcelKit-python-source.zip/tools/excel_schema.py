"""Supported Excel inventory groups and declarative operations."""

KINDS = {"sheet", "name", "table", "chart", "series", "shape", "pivot", "slicer",
         "query", "connection", "model", "vba"}

# Required and optional fields also define the public CLI schema.
SCHEMA = {
    "sheet.create": ("sheet", ""),
    "range.values": ("sheet range values", ""),
    "range.formulas": ("sheet range formulas", "dynamic"),
    "range.format": ("sheet range number_format", ""),
    "range.validation": ("sheet range minimum maximum", ""),
    "range.sort": ("sheet range keys", ""),
    "name.set": ("name refers_to", ""),
    "table.create": ("sheet name range", "style"),
    "table.resize": ("sheet name range", ""),
    "table.filter": ("sheet name column equals", ""),
    "chart.create": ("sheet name geometry chart_type", "title"),
    "chart.update": ("sheet name", "chart_type title geometry"),
    "series.create": ("sheet chart name x y", "chart_type"),
    "series.update": ("sheet chart name x y", "chart_type"),
    "axis.set": ("sheet chart axis minimum maximum", "reversed"),
    "shape.create": ("sheet name geometry", "chart text"),
    "shape.update": ("sheet name", "chart geometry text"),
    "shape.align_series": ("sheet chart name series", "on_worksheet"),
    "pivot.create": ("sheet name cell source_sheet table rows columns value caption", ""),
    "pivot.layout": ("sheet name rows columns", ""),
    "pivot.refresh": ("sheet name", ""),
    "slicer.create": ("sheet name pivot_sheet pivot field geometry", ""),
    "slicer.filter": ("name selected", ""),
    "query.set": ("name formula", ""),
    "query.refresh": ("name", ""),
    "query.load": ("name sheet cell table", ""),
    "query.csv": ("name path columns", "number_columns"),
    "model.relationship": ("foreign_table foreign_column primary_table primary_column", ""),
    "model.measure": ("name table formula", "description"),
    "model.pivot": ("sheet name cell measure", ""),
    "assert.range": ("sheet range values", "tolerance"),
}
NAMES = set(("sheet name range chart series cell source_sheet table pivot_sheet pivot field "
             "foreign_table foreign_column primary_table primary_column measure path x y").split())
