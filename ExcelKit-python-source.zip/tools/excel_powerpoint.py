"""PowerPoint automation on a verified runner-owned Windows process."""

import gc
from pathlib import Path
from time import monotonic, sleep
import traceback
from uuid import uuid4

import pythoncom
import pywintypes
import win32api
import win32gui
from zipfile import ZipFile
import win32process
from win32com.client import Dispatch

from .excel_package import MODERN, RIBBONS, add_ribbon, inspect_package, local_traces, parse_xml, ribbon_actions
from .excel_task import read_json
from .excel_windows import OwnedOffice, native_office_windows, office_executable
from .excel_worker import MACRO, com_error, compile_project, export_components, import_modules, project_of, verify_actions
import winreg


PPAM = "application/vnd.ms-powerpoint.addin.macroEnabled.main+xml"
PPTM = "application/vnd.ms-powerpoint.presentation.macroEnabled.main+xml"


def running_powerpoint():
    for pid in win32process.EnumProcesses():
        try:
            handle = win32api.OpenProcess(0x1000, False, pid)
            try:
                if Path(win32process.GetModuleFileNameEx(handle, 0)).name.casefold() == "powerpnt.exe":
                    return True
            finally:
                handle.Close()
        except pywintypes.error:
            continue
    return False


def load_addin(app, path):
    if any(Path(item.FullName).name.casefold() == path.name.casefold() for item in app.AddIns):
        raise ValueError("PowerPoint already has an add-in with the name " + path.name)
    previous = app.AutomationSecurity
    try:
        app.AutomationSecurity = 2
        item = app.AddIns.Add(str(path))
        try:
            if Path(item.FullName).resolve() != path.resolve():
                raise ValueError("PowerPoint registered a different add-in path.")
            item.Loaded = -1
            if item.Loaded != -1:
                raise ValueError("PowerPoint refused to load the add-in under its current policy.")
            return item
        except Exception:
            unload_addin(app, path)
            raise
    finally:
        app.AutomationSecurity = previous


def remove_addin_registrations(folder):
    """Delete PowerPoint add-in registrations that point inside a kit run folder.

    AddIns.Add records the add-in under HKCU so PowerPoint loads it at every start. A killed
    worker cannot unregister it, so the supervisor removes leftovers once PowerPoint has exited.
    """
    folder = Path(folder).resolve()
    removed = []
    office = r"Software\Microsoft\Office"
    try:
        root = winreg.OpenKey(winreg.HKEY_CURRENT_USER, office)
    except OSError:
        return removed
    with root:
        versions = []
        index = 0
        while True:
            try:
                versions.append(winreg.EnumKey(root, index))
            except OSError:
                break
            index += 1
    for version in versions:
        key_path = office + "\\" + version + r"\PowerPoint\AddIns"
        try:
            addins = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0,
                                    winreg.KEY_READ | winreg.KEY_WRITE)
        except OSError:
            continue
        with addins:
            names, index = [], 0
            while True:
                try:
                    names.append(winreg.EnumKey(addins, index))
                except OSError:
                    break
                index += 1
            for name in names:
                try:
                    with winreg.OpenKey(addins, name) as entry:
                        target = Path(winreg.QueryValueEx(entry, "Path")[0]).resolve()
                except OSError:
                    continue
                if target == folder or folder in target.parents:
                    winreg.DeleteKey(addins, name)
                    removed.append(key_path + "\\" + name)
    return removed


def unload_addin(app, path):
    for index in range(1, app.AddIns.Count + 1):
        item = app.AddIns.Item(index)
        if Path(item.FullName).resolve() == path.resolve():
            item.Loaded = 0
            app.AddIns.Remove(index)
            return


def starter(path):
    office = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    main = "http://schemas.openxmlformats.org/presentationml/2006/main"
    with ZipFile(path, "x") as archive:
        archive.writestr("[Content_Types].xml",
                         '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                         '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                         '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
                         '</Types>')
        archive.writestr("_rels/.rels",
                         '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                         '<Relationship Id="rId1" Type="%s/officeDocument" Target="ppt/presentation.xml"/>'
                         '</Relationships>' % office)
        archive.writestr("ppt/presentation.xml", '<p:presentation xmlns:p="%s">'
                         '<p:sldSz cx="9144000" cy="5143500"/><p:notesSz cx="6858000" cy="9144000"/>'
                         '</p:presentation>' % main)


def launch_powerpoint(path):
    if running_powerpoint():
        raise RuntimeError("PowerPoint is already running. Use a separate authorized desktop for tests.")
    starter(path)
    return OwnedOffice(office_executable("powerpnt.exe"), ["/O", path], visible=True)


def owned_frames(pid, label):
    matches = []

    def visit(handle, _):
        if (win32process.GetWindowThreadProcessId(handle)[1] == pid and
                win32gui.GetClassName(handle) == "PPTFrameClass" and label in win32gui.GetWindowText(handle)):
            matches.append(handle)
        return True

    win32gui.EnumWindows(visit, None)
    return matches


def connect(pid, bootstrap):
    deadline = monotonic() + 12
    while monotonic() < deadline:
        frames = owned_frames(pid, bootstrap.stem)
        if not frames:
            sleep(0.2)
            continue
        candidates = []
        for window in native_office_windows(pid, "paneClassDC"):
            try:
                candidates.append(window.Application)
            except (pythoncom.com_error, AttributeError):
                continue
        try:
            association = pythoncom.GetActiveObject("PowerPoint.Application")
            candidates.append(Dispatch(association.QueryInterface(pythoncom.IID_IDispatch)))
        except pythoncom.com_error:
            pass
        for app in candidates:
            try:
                for index in range(1, app.Presentations.Count + 1):
                    deck = app.Presentations.Item(index)
                    if Path(deck.FullName).resolve() == bootstrap and owned_frames(pid, bootstrap.stem) == frames:
                        return app, deck, frames[0]
            except (pythoncom.com_error, AttributeError):
                continue
        sleep(0.2)
    raise RuntimeError("PowerPoint did not expose COM from the owned process.")


def open_deck(app, path, security):
    previous = app.AutomationSecurity
    try:
        app.AutomationSecurity = security
        return app.Presentations.Open(str(path), -1, 0, -1)
    finally:
        app.AutomationSecurity = previous


def require_macro(app, name, entry):
    if not MACRO.fullmatch(entry):
        raise ValueError("Use a qualified PowerPoint VBA procedure name.")
    value = app.Run("%s!%s" % (name, entry))
    if value != "PASS":
        raise ValueError("PowerPoint VBA returned %r." % value)
    return value


def execute(directory, write_json):
    request = read_json(directory / "request.json")
    action = request["ppt_action"]
    pid = request["excel_pid"]
    state = {"excel_pid": pid}
    report = {"ppt_action": action}
    app = deck = project = addin = bootstrap = None

    def stage(name):
        state["stage"] = name
        write_json(directory / "state.json", state)

    pythoncom.CoInitialize()
    try:
        stage("ppt-connect")
        app, bootstrap, state["excel_window"] = connect(pid, Path(request["bootstrap"]))
        report["powerpoint"] = {"version": str(app.Version), "pid": pid}
        if action == "export":
            source = Path(request["presentation"])
            package = inspect_package(source, True, "ppt")
            if source.suffix.lower() != ".pptm" or not package["vba_parts"]:
                raise ValueError("Export expects a local PPTM with a VBA project.")
            stage("ppt-export")
            deck = open_deck(app, source, 3)
            export_components(deck, directory / "vba")
            report["export"] = str(directory / "vba")
        else:
            stage("ppt-vbproject")
            deck = bootstrap
            project = project_of(deck)
            if action != "doctor":
                import_modules(project, request["source"], stage)
                scratch = directory / "work"
                scratch.mkdir()
                presentation = scratch / "VbaSmoke.pptm"
                deck.SaveAs(str(presentation), 25)
                compile_project(app, project, report, stage, state, request["skip_compile"])
                if action == "test":
                    stage("ppt-runtime")
                    report["macro_result"] = require_macro(app, deck.Name, request["entry"])
                    report["slide_count"] = deck.Slides.Count
                    report["shape_count"] = sum(slide.Shapes.Count for slide in deck.Slides)
                    if request["output"]:
                        output = Path(request["output"])
                        if output.suffix.lower() != ".pptm" or output.exists():
                            raise ValueError("Test output requires a new .pptm path.")
                        deck.Save()
                        package = inspect_package(presentation, True, "ppt")
                        if package["workbook_content_type"] != PPTM or not package["vba_parts"]:
                            raise ValueError("Test did not produce a macro-enabled PowerPoint presentation.")
                        report["staged_output"] = str(presentation)
                else:
                    stage("ppt-build")
                    output = Path(request["output"])
                    if output.suffix.lower() != ".ppam" or output.exists():
                        raise ValueError("Build expects a new .ppam path.")
                    markup = Path(request["ribbon"]).read_bytes()
                    ribbon_actions(parse_xml(markup), RIBBONS[MODERN])
                    verify_actions(markup, project)
                    raw = scratch / "raw.ppam"
                    deck.SaveAs(str(raw), 30)
                    if deck.FullName.casefold() == str(raw).casefold():
                        deck.Saved = -1
                        deck.Close()
                        bootstrap = None
                        deck = None
                    project = None
                    folder = scratch / "ribbon"
                    folder.mkdir()
                    staged = folder / ("KitSmoke_" + uuid4().hex + ".ppam")
                    add_ribbon(raw, staged, markup)
                    package = inspect_package(staged, True, "ppt")
                    if package["workbook_content_type"] != PPAM or not package["vba_parts"]:
                        raise ValueError("Build did not produce a macro-enabled PowerPoint add-in.")
                    traces = local_traces(staged)
                    if traces:
                        report["local_traces"] = traces
                        raise ValueError("Add-in still contains a user profile path or account name.")
                    stage("ppt-addin-load")
                    addin = load_addin(app, staged)
                    stage("ppt-addin-runtime")
                    report["macro_result"] = require_macro(app, staged.name, request["entry"])
                    report["staged_output"] = str(staged)
        report.update(status="PASS", stage="complete")
    except Exception as error:
        traceback.print_exc()
        report.update(status="FAIL", stage=state.get("stage"), **com_error(error))
    finally:
        try:
            stage("cleanup")
            project = None
            if addin is not None:
                unload_addin(app, staged)
                addin = None
            if deck is not None:
                deck.Saved = -1
                deck.Close()
                if deck is bootstrap:
                    bootstrap = None
                deck = None
        except Exception as error:
            report.update(status="FAIL", cleanup_error=str(error))
        finally:
            try:
                if app is not None:
                    if bootstrap is not None:
                        bootstrap.Saved = -1
                        bootstrap.Close()
                    app.Quit()
            finally:
                app = None
                gc.collect()
                pythoncom.CoUninitialize()
    return report
