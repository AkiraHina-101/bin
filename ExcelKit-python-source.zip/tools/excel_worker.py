"""COM work for an isolated Excel session. Called only by ExcelKit.py."""

import copy
import gc
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import traceback
from time import monotonic, sleep

import pythoncom

from .excel_package import (ADDIN, MODERN, RIBBONS, add_ribbon, inspect_package, local_traces, parse_xml,
                            ribbon_actions)
from .excel_windows import connect_owned_excel, dialogs
from .excel_objects import changes, csv_dependencies, equal, inventory, parse_ops, snapshots, valid_a1
from .excel_vba_patch import edits as vba_edits, snapshot as vba_snapshot


VBA_NAME = re.compile(r'^Attribute VB_Name\s*=\s*"([A-Za-z][A-Za-z0-9_]*)"', re.I | re.M)
FORM_BLOB = re.compile(r'^\s*OleObjectBlob\s*=\s*"([^"]+)"', re.I | re.M)
MACRO = re.compile(r"[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)?")
EXTENSIONS = {1: ".bas", 2: ".cls", 3: ".frm", 100: ".document.cls"}


def com_error(error):
    result = {"message": str(error)}
    if isinstance(error, pythoncom.com_error):
        result["hresult"] = "0x%08X" % (error.hresult & 0xFFFFFFFF)
        if error.excepinfo:
            result["com_source"] = error.excepinfo[1]
            result["com_description"] = error.excepinfo[2]
            if isinstance(error.excepinfo[5], int):
                result["com_scode"] = "0x%08X" % (error.excepinfo[5] & 0xFFFFFFFF)
    return result


def project_of(book):
    try:
        project = book.VBProject
        if project.Protection != 0:
            raise ValueError("VBA project is locked.")
        _ = project.VBComponents.Count
        return project
    except pythoncom.com_error as error:
        raise ValueError("VBProject unavailable. Check Trust access to the VBA project object model "
                         "and organization policy. " + str(error))


def import_modules(project, directory, set_stage):
    components = project.VBComponents
    names = {component.Name.casefold() for component in components}
    files = sorted(p for p in Path(directory).iterdir() if p.is_file()
                   and p.suffix.lower() in {".bas", ".cls", ".frm"}
                   and not p.name.lower().endswith(".document.cls"))
    if not files:
        raise ValueError("No importable VBA modules in " + directory)
    for path in files:
        set_stage("import/" + path.name)
        data = path.read_bytes()
        # Scan ASCII metadata without transcoding the actual file VBE reads.
        text = data.decode("utf-8-sig", errors="replace")
        match = VBA_NAME.search(text)
        if not match:
            raise ValueError("Missing or unsupported Attribute VB_Name: " + path.name)
        name = match.group(1)
        if name.casefold() in names:
            raise ValueError("Duplicate VBA component: " + name)
        if path.suffix.lower() == ".frm":
            for sidecar in FORM_BLOB.findall(text):
                if (Path(sidecar).name != sidecar or ":" in sidecar or
                        not path.with_name(sidecar).is_file()):
                    raise ValueError("Missing or invalid UserForm sidecar: " + sidecar)
        component = components.Import(str(path))
        if component.Name.casefold() != name.casefold():
            raise ValueError("Unexpected imported component name: " + component.Name)
        names.add(name.casefold())


def compile_project(excel, project, report, set_stage, state, skip):
    set_stage("references")
    for reference in project.References:
        if reference.IsBroken:
            raise ValueError("A VBA reference is missing. Check VBE Tools > References.")
    if skip:
        report["compile"] = "skipped"
        return
    set_stage("vbe-compile")
    vbe = excel.VBE
    components = project.VBComponents
    components.Item(components.Count).CodeModule.CodePane.Show()
    report["vba_project"] = str(project.Name)
    if vbe.ActiveVBProject.FileName != project.FileName:
        raise ValueError("Unable to select the intended project for Compile.")
    control = vbe.CommandBars.FindControl(1, 578)
    if control is None or not control.Enabled:
        report["compile"] = "manual-required"
        raise ValueError("VBE Compile command unavailable. Use Debug > Compile and "
                         "--skip-compile for a runtime-only check.")
    control.Execute()
    # Compile errors can take a few seconds to raise their dialog on large projects.
    deadline = monotonic() + 5
    while control.Enabled and monotonic() < deadline:
        pythoncom.PumpWaitingMessages()
        sleep(0.1)
    if control.Enabled and vbe.ActiveVBProject.FileName == project.FileName:
        observed = dialogs(state["excel_pid"], state["excel_window"])
        if not observed:
            control.Execute()
    if control.Enabled:
        try:
            report["dialogs"] = dialogs(state["excel_pid"], state["excel_window"])
        except Exception as error:
            report["dialog_capture_error"] = str(error)
        report["compile"] = "failed-or-unconfirmed"
        raise ValueError("VBE Compile did not complete. Inspect dialogs or open the staged workbook in VBE.")
    report["compile"] = "vbe-command"


def smoke(excel, book, entry, report, set_stage):
    if not MACRO.fullmatch(entry):
        raise ValueError("Expected a macro name such as Module1.Smoke.")
    set_stage("runtime/" + entry)
    qualified = "'%s'!%s" % (book.Name.replace("'", "''"), entry)
    value = excel.Run(qualified)
    report["macro_result"] = value if isinstance(value, (str, int, float, bool, type(None))) else str(value)
    if value != "PASS":
        raise ValueError("Expected PASS from the macro. See macro_result.")


def open_workbook(excel, path, security, read_only=True):
    previous = excel.AutomationSecurity
    try:
        excel.AutomationSecurity = security
        missing = pythoncom.Missing
        book = excel.Workbooks.Open(str(path), 0, read_only, missing, missing, missing, True,
                                    missing, missing, missing, False, missing, False)
        if bool(book.ReadOnly) != read_only:
            book.Close(False)
            raise ValueError("Excel could not open the file in the requested read mode.")
        return book
    finally:
        excel.AutomationSecurity = previous


def read_range(book, sheet, address):
    if not valid_a1(address):
        raise ValueError("Use one rectangular A1 range, for example A1:D20.")
    cells = book.Worksheets.Item(sheet).Range(address)
    rows, columns = cells.Rows.Count, cells.Columns.Count
    if rows * columns > 10000:
        raise ValueError("Select at most 10,000 cells per read.")
    values = cells.Value2
    has_formula = cells.HasFormula
    if rows == columns == 1:
        values = ((values,),)
    formulas = [[None] * columns for _ in range(rows)]
    if has_formula:
        formulas = [[cells.Formula]] if rows == columns == 1 else cells.Formula
    elif has_formula is None:
        top, left = cells.Row, cells.Column
        for area in cells.SpecialCells(-4123).Areas:  # xlCellTypeFormulas
            height, width = area.Rows.Count, area.Columns.Count
            r, c = area.Row - top, area.Column - left
            data = ((area.Formula,),) if height == width == 1 else area.Formula
            for offset, row in enumerate(data):
                formulas[r + offset][c:c + width] = row
    return {"sheet": sheet, "address": address, "values": values, "formulas": formulas}


def read_expectations(path):
    if not path:
        return []
    expectations = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(expectations, list) or not expectations:
        raise ValueError("Expected a nonempty JSON list of range checks.")
    for item in expectations:
        if (not isinstance(item, dict) or set(item) != {"sheet", "range", "values"} or
                not isinstance(item["sheet"], str) or not item["sheet"] or
                not valid_a1(item["range"])):
            raise ValueError("Each range check needs sheet, range and values.")
        values = item["values"]
        if (not isinstance(values, list) or not values or not isinstance(values[0], list) or not values[0]
                or any(not isinstance(row, list) or len(row) != len(values[0]) for row in values)
                or any(type(value) not in (int, float, str, bool, type(None))
                       for row in values for value in row)):
            raise ValueError("Expected values must be a rectangular two-dimensional array of cell values.")
    return expectations


def verify_ranges(book, checks, report, set_stage):
    report["verified_ranges"] = 0
    for check in checks:
        sheet, address = check["sheet"], check["range"]
        set_stage("assert-range/" + sheet + "!" + address)
        expected = check["values"]
        actual = [list(row) for row in read_range(book, sheet, address)["values"]]
        equal = actual == expected and all(
            isinstance(a, bool) == isinstance(b, bool)
            for actual_row, expected_row in zip(actual, expected)
            for a, b in zip(actual_row, expected_row)
        )
        if not equal:
            report["mismatch"] = {"expected": expected, "actual": actual}
            raise ValueError("Macro returned PASS, but the workbook output differs.")
        report["verified_ranges"] += 1


def export_components(book, destination):
    project = project_of(book)
    destination.mkdir()
    for component in project.VBComponents:
        extension = EXTENSIONS.get(component.Type)
        if not extension:
            raise ValueError("Unsupported VBA component type: %r" % component.Type)
        component.Export(str(destination / (component.Name + extension)))


def apply_document_modules(project, directory, stage):
    paths = sorted(Path(directory).glob("*.document.cls"))
    if not paths:
        raise ValueError("No CodeName.document.cls files in " + directory)
    for path in paths:
        stage("document/" + path.name)
        code_name = path.name[:-len(".document.cls")]
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", code_name):
            raise ValueError("Expected a valid worksheet CodeName or ThisWorkbook: " + path.name)
        component = project.VBComponents.Item(code_name)
        if component.Type != 100:
            raise ValueError("Not a document module: " + code_name)
        raw = path.read_bytes()
        text = raw.decode("utf-8-sig") if raw.startswith(b"\xef\xbb\xbf") else raw.decode("mbcs")
        declared = VBA_NAME.search(text)
        if declared and declared.group(1).casefold() != code_name.casefold():
            raise ValueError("Document module code name does not match file name: " + code_name)
        lines = text.splitlines()
        start = next((i for i, line in enumerate(lines) if line.lower().startswith("attribute vb_name")),
                     None)
        if start is not None:
            while start < len(lines) and lines[start].lower().startswith("attribute "):
                start += 1
        body = lines[start:] if start is not None else lines
        if any(line.lstrip().lower().startswith("attribute ") for line in body):
            raise ValueError("Procedure attributes require manual transfer in VBE: " + code_name)
        module = component.CodeModule
        if module.CountOfLines:
            module.DeleteLines(1, module.CountOfLines)
        if body:
            module.AddFromString("\r\n".join(body))


def verify_actions(markup, project):
    actions = ribbon_actions(parse_xml(markup), RIBBONS[MODERN])
    modules = []
    for component in project.VBComponents:
        if component.Type == 1:
            module = component.CodeModule
            if module.CountOfLines:
                modules.append(module.Lines(1, module.CountOfLines))
    for action in actions:
        pattern = r"^\s*Public\s+Sub\s+" + re.escape(action) + r"\s*\("
        if not any(re.search(pattern, module, re.I | re.M) for module in modules):
            raise ValueError("No public Ribbon onAction Sub: " + action)


def fingerprint(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def csv_rows(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.reader(stream))


def ribbon_parts_bytes(path, package):
    from zipfile import ZipFile

    with ZipFile(path) as archive:
        return {item["part"]: archive.read(item["part"]) for item in package["ribbon_parts"]}


class Session:
    def __init__(self, directory, request, write_json):
        self.directory = directory
        self.request = request
        self.write_json = write_json
        self.state = {}
        self.report = {}
        self.excel = None
        self.book = None
        self.owns_excel = False
        self.expectations = []

    def stage(self, name):
        self.state["stage"] = name
        self.write_json(self.directory / "state.json", self.state)

    def start(self):
        self.stage("excel-start")
        pid = self.request["excel_pid"]
        self.excel, starter = connect_owned_excel(pid, Path(self.request["bootstrap"]))
        self.owns_excel = True
        self.state.update(excel_pid=pid, excel_window=self.excel.Hwnd)
        self.stage("excel-init")
        self.report["excel"] = {"version": self.excel.Version, "build": self.excel.Build}
        self.report["excel_pid"] = pid
        self.excel.EnableEvents = False
        self.excel.AskToUpdateLinks = False
        starter.Close(False)

    def check_existing(self, action):
        request = self.request
        self.stage("inspect-input")
        path = Path(request["workbook"])
        if path.suffix.lower() not in {".xlsx", ".xlsm", ".xlam"}:
            raise ValueError("Expected an .xlsx, .xlsm or .xlam OOXML file.")
        package = inspect_package(path)
        if package["xlm_parts"]:
            raise ValueError("Excel 4.0 macro sheets detected. Inspect without opening the file.")
        if package["refresh_on_open_parts"]:
            raise ValueError("Workbook requests automatic refresh on open. Inspect the package first.")
        if package["dde_ole_link_parts"]:
            raise ValueError("Workbook contains DDE or OLE links. Inspect the package first.")
        if action in {"export", "run"} and not package["vba_parts"]:
            raise ValueError("No VBA project in this workbook.")
        self.stage("open/" + action)
        if action == "run":
            staged = self.directory / "work" / path.name
            staged.parent.mkdir()
            shutil.copyfile(path, staged)
            self.excel.EnableEvents = bool(request["events"])
            path = staged
        self.book = open_workbook(self.excel, path, 2 if action == "run" else 3)
        if action == "inventory":
            self.stage("inventory")
            self.report["inventory"] = inventory(self.book, request["sheet"], request["kind"])
        elif action == "read":
            self.stage("read-range")
            self.report["range"] = read_range(self.book, request["sheet"], request["address"])
        elif action == "export":
            self.stage("export")
            destination = self.directory / "export"
            export_components(self.book, destination)
            self.report["export"] = str(destination)
        else:
            smoke(self.excel, self.book, request["entry"], self.report, self.stage)
            verify_ranges(self.book, self.expectations, self.report, self.stage)

    def edit_copy(self, action):
        request = self.request
        self.stage("validate-plan")
        if action == "plan":
            source = Path(request["workbook"])
            document = json.loads(Path(request["ops"]).read_text(encoding="utf-8-sig"))
            expected = None
            baseline = None
            source_hash = fingerprint(source)
        else:
            plan = json.loads(Path(request["plan"]).read_text(encoding="utf-8-sig"))
            if plan.get("version") != 1 or not isinstance(plan.get("verified"), list):
                raise ValueError("Expected a version 1 plan produced by the plan command.")
            source = Path(plan["source"]).resolve()
            document = {"version": 1, "operations": plan["operations"]}
            expected = plan["verified"]
            baseline = plan.get("baseline")
            source_hash = plan["source_sha256"]
            if fingerprint(source) != source_hash:
                raise ValueError("Source changed after preview. Generate a new plan.")
            output = Path(request["output"])
            if output == source or output.exists() or output.suffix.lower() != source.suffix.lower():
                raise ValueError("Use a new output path with the same workbook extension.")
        ops = parse_ops(document)
        if expected is not None and (not isinstance(baseline, list) or len(baseline) != len(ops)
                                     or len(expected) != len(ops)):
            raise ValueError("Plan snapshots do not match the operation list.")
        if source.suffix.lower() not in {".xlsx", ".xlsm"}:
            raise ValueError("Declarative edits support saved .xlsx and .xlsm workbooks.")
        self.stage("copy")
        package = inspect_package(source)
        if (package["xlm_parts"] or package["package_signatures"] or package["vba_signatures"]
                or package["refresh_on_open_parts"] or package["dde_ole_link_parts"]):
            raise ValueError("Inspect legacy macro, package signature or automatic refresh before editing.")
        staged = self.directory / "work" / source.name
        staged.parent.mkdir()
        shutil.copyfile(source, staged)
        if fingerprint(staged) != source_hash or fingerprint(source) != source_hash:
            raise ValueError("Source changed during staging.")

        self.stage("open-copy")
        self.book = open_workbook(self.excel, staged, 3, read_only=False)
        if self.book.ProtectStructure and any(op["op"] == "sheet.create" for op in ops):
            raise ValueError("Workbook structure is protected.")
        self.stage("capture-inventory")
        original_inventory = inventory(self.book, None, None)
        dependencies = {str(path): fingerprint(path)
                        for path in sorted(csv_dependencies(self.book, ops))}
        if expected is not None and dependencies != plan.get("dependencies", {}):
            raise ValueError("A local CSV source changed after preview. Generate a new plan.")
        verified = changes(self.book, ops, self.stage, self.report, baseline)
        if expected is not None and not equal(expected, verified, 1e-6):
            self.report["verification"] = {"expected": expected, "actual": verified}
            raise ValueError("Workbook output differed from the preview. Generate a new plan.")
        self.stage("save-copy")
        self.book.Save()
        self.book.Close(False)
        self.book = None
        saved_package = inspect_package(staged)
        if (saved_package["workbook_content_type"] != package["workbook_content_type"] or
                saved_package["ribbon_parts"] != package["ribbon_parts"] or
                bool(saved_package["vba_parts"]) != bool(package["vba_parts"])):
            raise ValueError("Workbook format, VBA presence or RibbonX metadata changed unexpectedly.")
        if saved_package["refresh_on_open_parts"]:
            raise ValueError("The staged workbook requests automatic refresh on open.")
        self.stage("reopen-copy")
        self.book = open_workbook(self.excel, staged, 3)
        reopened = snapshots(self.book, ops, self.stage)
        if not equal(verified, reopened, 1e-6):
            self.report["verification"] = {"expected": verified, "actual": reopened}
            raise ValueError("Workbook output differed after reopening.")
        self.stage("compare-inventory")
        final_inventory = inventory(self.book, None, None)
        before_objects = {(obj["kind"], obj["owner"], obj["name"], obj.get("index")): obj
                          for obj in original_inventory["objects"]}
        after_objects = {(obj["kind"], obj["owner"], obj["name"], obj.get("index")): obj
                         for obj in final_inventory["objects"]}
        self.report["inventory_diff"] = {
            "added": [value for key, value in after_objects.items() if key not in before_objects],
            "removed": [value for key, value in before_objects.items() if key not in after_objects],
            "changed": [{"before": value, "after": after_objects[key]}
                        for key, value in before_objects.items()
                        if key in after_objects and not equal(value, after_objects[key], 0.03)],
            "warnings": original_inventory["warnings"] + final_inventory["warnings"],
        }
        removed = self.report["inventory_diff"]["removed"]
        if any(item["kind"] in {"sheet", "table", "chart", "pivot", "slicer", "query", "model", "vba"}
               for item in removed):
            raise ValueError("Excel removed an existing object. Inspect inventory_diff.")
        self.book.Close(False)
        self.book = None
        if fingerprint(source) != source_hash:
            raise ValueError("Source changed during the run.")
        if any(fingerprint(Path(path)) != digest for path, digest in dependencies.items()):
            raise ValueError("A local CSV source changed during the run.")
        if action == "apply":
            self.report["staged_output"] = str(staged)
        else:
            path = self.directory / "plan.json"
            self.write_json(path, {"version": 1, "source": str(source), "source_sha256": source_hash,
                                  "operations": ops, "verified": reopened,
                                  "dependencies": dependencies,
                                  "baseline": [item["before"] for item in self.report["changes"]]})
            self.report["plan"] = str(path)
            staged.unlink()

    def patch_vba(self, action):
        request = self.request
        self.stage("vba-input")
        if action == "vba-diff":
            source = Path(request["workbook"])
            document = json.loads(Path(request["patch"]).read_text(encoding="utf-8-sig"))
            preview = None
        else:
            preview = json.loads(Path(request["preview"]).read_text(encoding="utf-8-sig"))
            source = Path(preview["source"]).resolve()
            document = preview["patch"]
            output = Path(request["output"])
            if output == source or output.exists() or output.suffix.lower() != ".xlsm":
                raise ValueError("VBA patch needs a new .xlsm output path.")
            if not MACRO.fullmatch(request["entry"]):
                raise ValueError("Use an existing public Sub, for example ReportModule.ExportReport.")
            if not self.expectations:
                raise ValueError("Provide expected result cells for the VBA patch.")

        initial_hash = fingerprint(source)
        package = inspect_package(source)
        if (source.suffix.lower() != ".xlsm" or not package["vba_parts"] or package["xlm_parts"]
                or package["package_signatures"] or package["vba_signatures"] or package["refresh_on_open_parts"]
                or package["dde_ole_link_parts"]):
            raise ValueError("Use an authorized local .xlsm with unsigned VBA and no XLM or refresh on open.")
        if preview is not None and initial_hash != preview["source_sha256"]:
            raise ValueError("Source changed after vba-diff. Create a new preview.")
        original_ribbon = ribbon_parts_bytes(source, package)
        if preview is None:
            self.book = open_workbook(self.excel, source, 3)
        else:
            working = self.directory / "work"
            working.mkdir()
            staged = working / source.name
            shutil.copyfile(source, staged)
            if fingerprint(staged) != initial_hash:
                raise ValueError("Source changed while copying.")
            self.book = open_workbook(self.excel, staged, 3, read_only=False)
        self.stage("vba-snapshot")
        project = project_of(self.book)
        before = vba_snapshot(project)
        operations = vba_edits(before, document)
        unified = [item["diff"] for item in operations]
        self.report["diff"] = unified
        if preview is None:
            path = self.directory / "vba-preview.json"
            self.write_json(path, {"source": str(source), "source_sha256": initial_hash,
                                   "patch": document, "diff": unified})
            self.report["preview"] = str(path)
            return
        if unified != preview["diff"]:
            raise ValueError("Patch differs from the VBA preview.")

        expected = copy.deepcopy(before)
        for item in operations:
            self.stage("vba-edit/" + item["module"])
            module = project.VBComponents.Item(item["module"]).CodeModule
            module.DeleteLines(item["line"], item["remove"])
            module.InsertLines(item["line"], "\r\n".join(item["insert"]))
            expected["components"][item["module"]]["lines"] = item["expected_code"]
        if vba_snapshot(project) != expected:
            raise ValueError("VBA code or references changed outside the preview.")
        compile_project(self.excel, project, self.report, self.stage, self.state, False)
        project = module = None
        self.book.Save()
        self.book.Close(False)
        self.book = None
        saved = inspect_package(staged, verify_crc=True)
        if (saved["ribbon_parts"] != package["ribbon_parts"] or not saved["vba_parts"]
                or ribbon_parts_bytes(staged, saved) != original_ribbon):
            raise ValueError("Saved workbook did not preserve VBA or Ribbon metadata.")

        # Execute on a second copy to keep test side effects out of the deliverable.
        trial = working / "verification"
        trial.mkdir()
        testfile = trial / source.name
        shutil.copyfile(staged, testfile)
        self.stage("vba-reopen")
        self.book = open_workbook(self.excel, testfile, 2)
        if vba_snapshot(project_of(self.book)) != expected:
            raise ValueError("Reopened workbook VBA differs from the expected code.")
        entry = request["entry"]
        self.stage("runtime/" + entry)
        self.excel.Run("'%s'!%s" % (self.book.Name.replace("'", "''"), entry))
        verify_ranges(self.book, self.expectations, self.report, self.stage)
        if request["expect_csv"]:
            self.stage("vba-report")
            produced = trial / "Report.csv"
            if not produced.is_file() or csv_rows(produced) != csv_rows(Path(request["expect_csv"])):
                raise ValueError("Report.csv is missing or differs from expected rows.")
            self.report["report_csv"] = str(self.directory / "verified-report.csv")
            shutil.copyfile(produced, self.report["report_csv"])
        if fingerprint(source) != initial_hash:
            raise ValueError("Source file changed during test.")
        self.report["staged_output"] = str(staged)

    def build_or_test(self, action, project):
        request = self.request
        import_modules(project, request["source"], self.stage)
        if action == "test":
            import_modules(project, request["tests"], self.stage)
            if request["documents"]:
                apply_document_modules(project, request["documents"], self.stage)
        self.stage("save-test-workbook")
        self.book.SaveAs(str(self.directory / "Smoke.xlsm"), 52)
        compile_project(self.excel, project, self.report, self.stage, self.state, request["skip_compile"])
        if action == "test":
            self.excel.EnableEvents = bool(request["events"])
            smoke(self.excel, self.book, request["entry"], self.report, self.stage)
            verify_ranges(self.book, self.expectations, self.report, self.stage)
            return

        self.stage("ribbon-xml")
        output = Path(request["output"])
        if output.suffix.lower() != ".xlam":
            raise ValueError("Build output must have the .xlam extension.")
        markup = Path(request["ribbon"]).read_bytes()
        verify_actions(markup, project)
        self.stage("save-xlam")
        original = self.directory / "raw.xlam"
        self.book.IsAddin = True
        self.book.SaveAs(str(original), 55)
        self.book.Close(False)
        self.book = None
        self.stage("package-ribbon")
        staged = self.directory / output.name
        if staged == original:
            raise ValueError("Choose an output name other than raw.xlam.")
        add_ribbon(original, staged, markup)
        package = inspect_package(staged, verify_crc=True)
        if package["workbook_content_type"] != ADDIN or not package["vba_parts"]:
            raise ValueError("Staged package is missing the add-in content type or VBA part.")
        traces = local_traces(staged)
        if traces:
            self.report["local_traces"] = traces
            raise ValueError("Add-in still contains a user profile path or account name. See local_traces.")
        self.stage("reopen-xlam")
        self.book = open_workbook(self.excel, staged, 2)
        if self.book.FileFormat != 55 or not self.book.IsAddin:
            raise ValueError("Excel did not reopen the file as an add-in.")
        smoke(self.excel, self.book, request["entry"], self.report, self.stage)
        self.book.Close(False)
        self.book = None
        self.report["staged_output"] = str(staged)

    def perform(self):
        action = self.request["action"]
        if action in {"read", "export", "run", "inventory"}:
            self.check_existing(action)
        elif action in {"plan", "apply"}:
            self.edit_copy(action)
        elif action in {"vba-diff", "vba-patch"}:
            self.patch_vba(action)
        else:
            self.stage("blank-workbook")
            if action == "test" and self.request["workbook"]:
                original = Path(self.request["workbook"])
                package = inspect_package(original)
                if (original.suffix.lower() != ".xlsm" or package["xlm_parts"] or
                        package["refresh_on_open_parts"] or package["package_signatures"] or package["vba_signatures"]
                        or package["dde_ole_link_parts"]):
                    raise ValueError("Test requires a local .xlsm without XLM, signatures or refresh on open.")
                staged = self.directory / "work" / original.name
                staged.parent.mkdir()
                shutil.copyfile(original, staged)
                self.book = open_workbook(self.excel, staged, 2, read_only=False)
            else:
                if action == "test" and self.request["documents"]:
                    raise ValueError("--documents requires --workbook with the intended document code names.")
                self.book = self.excel.Workbooks.Add(-4167)
            self.stage("vbproject")
            project = project_of(self.book)
            if action != "doctor":
                self.build_or_test(action, project)
        self.report.update(status="PASS", stage="complete")

    def close(self):
        try:
            if self.book is not None:
                self.excel.EnableEvents = False
                self.book.Close(False)
        finally:
            self.book = None
            try:
                if self.owns_excel:
                    try:
                        self.excel.DisplayAlerts = False
                    finally:
                        self.excel.Quit()
            finally:
                self.excel = None


def execute(directory, write_json):
    request = json.loads((directory / "request.json").read_text(encoding="utf-8"))
    session = Session(directory, request, write_json)
    pythoncom.CoInitialize()
    try:
        try:
            session.stage("test-input")
            session.expectations = read_expectations(request.get("expect"))
            session.start()
            session.perform()
        except Exception as error:
            traceback.print_exc()
            session.report.update(status="FAIL", stage=session.state.get("stage", "startup"), **com_error(error))
        finally:
            try:
                session.stage("cleanup")
            finally:
                try:
                    session.close()
                except Exception as error:
                    if session.report["status"] == "PASS":
                        session.report.update(status="FAIL", stage="cleanup")
                    session.report["cleanup_error"] = com_error(error)
    finally:
        gc.collect()
        pythoncom.CoUninitialize()
    return session.report
