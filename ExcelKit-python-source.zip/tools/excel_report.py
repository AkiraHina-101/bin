"""Infer report requirements from confirmed layouts and profile CSV inputs."""

import csv
import hashlib
from decimal import Decimal, InvalidOperation
from io import StringIO
import json
from pathlib import Path
import posixpath
import re
import sys
import unicodedata
from urllib.parse import urlsplit
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile

from .excel_package import internal_target


PREVIEW_LIMIT = 24
XML_LIMIT = 16 * 1024 * 1024


def scan_sample(path):
    """Read bounded, source-located layout evidence without starting Office."""
    extension = path.suffix.casefold()
    if extension not in {".xlsx", ".xlsm", ".pptx", ".pptm"}:
        raise ValueError("Sample scan supports XLSX, XLSM, PPTX and PPTM.")

    with ZipFile(path) as archive:
        if len(set(archive.namelist())) != len(archive.namelist()):
            raise ValueError("Duplicate ZIP entries in " + path.name)

        def xml(part):
            if archive.getinfo(part).file_size > XML_LIMIT:
                raise ValueError("XML part exceeds scan limit: " + part)
            raw = archive.read(part)
            if re.search(br"<!DOCTYPE|<!ENTITY", raw.replace(b"\x00", b""), re.I):
                raise ValueError("Unexpected XML declaration in " + part)
            return ET.fromstring(raw)

        def related(node, parent=""):
            target = node.attrib["Target"]
            uri = urlsplit(target)
            if uri.scheme or uri.netloc:
                raise ValueError("Expected a local Office package relationship.")
            normalized = target if target.startswith("/") else posixpath.join(posixpath.dirname(parent), target)
            return internal_target(ET.Element("Relationship", dict(node.attrib, Target=normalized)))

        root_rel = [node for node in xml("_rels/.rels") if node.get("Type", "").endswith("/officeDocument")]
        if len(root_rel) != 1:
            raise ValueError("Expected one Office document relationship.")
        main_part = related(root_rel[0])
        root = xml(main_part)
        namespace = root.tag.partition("}")[0] + "}"
        excel = extension in {".xlsx", ".xlsm"}
        expected_root = "workbook" if excel else "presentation"
        if root.tag != namespace + expected_root:
            raise ValueError("Office document type differs from the extension.")
        folder, name = posixpath.split(main_part)
        ref_part = posixpath.join(folder, "_rels", name + ".rels")
        refs = {node.attrib["Id"]: node for node in xml(ref_part)} if ref_part in archive.namelist() else {}
        kind, item_tag = ("sheets", "sheet") if excel else ("sldIdLst", "sldId")
        all_items = root.findall(namespace + kind + "/" + namespace + item_tag)
        items = []
        shared = []
        if excel:
            for node in refs.values():
                if node.get("Type", "").endswith("/sharedStrings"):
                    shared = [xml_text(value, "t") for value in xml(related(node, main_part))]
                    break
        for index, item in enumerate(all_items[:PREVIEW_LIMIT], 1):
            rid = next((value for key, value in item.attrib.items() if key.endswith("}id")), None)
            rel = refs[rid]
            record = {"position": index}
            if excel:
                record.update(name=item.attrib["name"], visibility=item.get("state", "visible"),
                              kind=rel.attrib["Type"].rsplit("/", 1)[-1])
                if record["visibility"] != "visible" or record["kind"] != "worksheet":
                    items.append(record)
                    continue
            part = related(rel, main_part)
            markup = xml(part)
            record["part"] = part
            if excel:
                record.update(sheet_evidence(markup, shared))
            elif markup.get("show") in {"0", "false"}:
                record["visibility"] = "hidden"
            else:
                record.update(slide_evidence(markup))
            items.append(record)
    return {"sample": str(path), "type": "excel" if excel else "powerpoint", "parts": items,
            "part_count": len(all_items), "truncated": len(all_items) > len(items)}


def xml_text(node, tag):
    return " ".join(value.text for value in node.findall(".//{*}" + tag) if value.text)


def sheet_evidence(sheet, shared):
    dimension = sheet.find("{*}dimension")
    record = {"used_range": dimension.get("ref") if dimension is not None else None,
              "objects": {tag: len(sheet.findall(".//{*}" + tag)) for tag in ("drawing", "tablePart", "pivotTable")},
              "text_cells": [], "formulas": []}
    counts = {"text_cells": 0, "formulas": 0}
    for cell in sheet.iterfind("./{*}sheetData/{*}row/{*}c"):
        formula = cell.find("{*}f")
        address = cell.get("r")
        if formula is not None:
            counts["formulas"] += 1
            if len(record["formulas"]) < PREVIEW_LIMIT:
                record["formulas"].append({"cell": address, "expression": (formula.text or "")[:500],
                                           "attributes": formula.attrib})
            continue
        kind = cell.get("t")
        value = cell.findtext("{*}v")
        label = None
        if kind == "s" and value is not None:
            label = shared[int(value)]
        elif kind == "inlineStr":
            label = xml_text(cell, "t")
        elif kind == "str":
            label = value
        if label:
            counts["text_cells"] += 1
            if len(record["text_cells"]) < PREVIEW_LIMIT:
                record["text_cells"].append({"cell": address, "text": label[:240]})
    record["counts"] = counts
    return record


def slide_evidence(slide):
    shape_names = [node.get("name")[:240] for node in slide.iterfind(".//{*}cNvPr") if node.get("name")]
    paragraphs = [xml_text(node, "t") for node in slide.iterfind(".//{*}p")]
    paragraphs = [text[:240] for text in paragraphs if text]
    return {"shape_names": shape_names[:PREVIEW_LIMIT], "shape_count": len(shape_names),
            "text": paragraphs[:PREVIEW_LIMIT], "text_count": len(paragraphs),
            "tables": len(slide.findall(".//{*}tbl")), "charts": len(slide.findall(".//{*}chart"))}


def normalize(value):
    text = unicodedata.normalize("NFKC", value).casefold().strip()
    return re.sub(r"[\s_\-]+", " ", text)


def profile(layouts, files):
    """Layouts are extracted notes the agent must ground in the supplied samples."""
    if len(layouts) < 1:
        raise ValueError("Supply at least one report layout.")
    rules = {}
    missing_definitions = set()
    outputs = []
    for layout in layouts:
        outputs.append({"sample": layout["sample"], "deliverables": layout["deliverables"]})
        for metric, spec in layout["metrics"].items():
            if not spec.get("rule"):
                missing_definitions.add(metric)
            rules.setdefault(metric, set()).update([spec["rule"]] if spec.get("rule") else [])
    questions = []
    for metric, options in sorted(rules.items()):
        if len(options) > 1:
            questions.append({"kind": "conflicting_definition", "metric": metric, "choices": sorted(options)})
        elif not options and metric in missing_definitions:
            questions.append({"kind": "missing_definition", "metric": metric})

    required = {}
    for layout in layouts:
        for column, aliases in layout["fields"].items():
            required.setdefault(column, {normalize(column)}).update(normalize(alias) for alias in aliases)

    inputs = []
    for path in files:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream)
            headers = next(reader, None)
            if not headers:
                raise ValueError("No CSV header: " + str(path))
            keys = [normalize(value) for value in headers]
            if len(set(keys)) != len(keys):
                raise ValueError("Ambiguous CSV headers: " + str(path))
            mapping = {}
            for field, aliases in required.items():
                matches = [i for i, key in enumerate(keys) if key in aliases]
                if len(matches) == 1:
                    mapping[field] = matches[0]
                elif len(matches) > 1:
                    questions.append({"kind": "ambiguous_column", "field": field, "file": str(path),
                                      "choices": [headers[i] for i in matches]})
            for field in sorted(required):
                if not any(key in required[field] for key in keys):
                    questions.append({"kind": "missing_column", "field": field, "file": str(path)})
            for index in sorted(set(mapping.values())):
                fields = sorted(field for field, column in mapping.items() if column == index)
                if len(fields) > 1:
                    questions.append({"kind": "shared_column", "file": str(path),
                                      "column": headers[index], "fields": fields})
            count = 0
            missing = dict.fromkeys(mapping, 0)
            regional = {}
            if {"amount", "region"} <= mapping.keys():
                data_fields = (mapping["region"], mapping["amount"])
            else:
                data_fields = None
            for row in reader:
                if len(row) != len(headers):
                    raise ValueError("CSV row width differs from header at row %d." % (count + 2))
                count += 1
                for field, index in mapping.items():
                    if not row[index].strip():
                        missing[field] += 1
                if data_fields:
                    region, amount = (row[index].strip() for index in data_fields)
                    try:
                        value = Decimal(amount)
                        if not value.is_finite() or not region:
                            raise InvalidOperation
                    except InvalidOperation:
                        questions.append({"kind": "invalid_value", "file": str(path), "row": count + 1,
                                          "field": "amount" if region else "region"})
                    else:
                        regional[region] = regional.get(region, Decimal(0)) + value
            for field, count_missing in sorted(missing.items()):
                if count_missing:
                    questions.append({"kind": "missing_values", "field": field,
                                      "file": str(path), "rows": count_missing})
            inputs.append({"file": str(path), "rows": count, "missing_values": missing,
                           "mapping": {field: headers[index] for field, index in mapping.items()},
                           "raw_amount_by_region": {name: str(value) for name, value in sorted(regional.items())}})
    if not files:
        questions.append({"kind": "missing_input_files", "fields": sorted(required)})
    return {"status": "needs-input" if questions else "ready-for-mapping",
            "expected_outputs": outputs, "inputs": inputs, "questions": questions}


def reconcile(spec, files):
    """Independent regional and monthly totals for an explicitly confirmed report."""
    if spec.get("rule") != "net_equals_gross_minus_returns":
        raise ValueError("Confirm the KPI rule before generating the report.")
    if not files:
        raise ValueError("Provide at least one input CSV.")
    fields = {"id", "month", "region", "currency", "gross", "returns"}
    if fields != set(spec["columns"]):
        raise ValueError("Provide aliases for id, month, region, currency, gross and returns.")
    aliases = {field: {normalize(field), *map(normalize, spec["columns"][field])} for field in fields}
    seen = set()
    groups = {}
    sources = []
    for path in files:
        raw = path.read_bytes()
        source = {"name": path.name, "sha256": hashlib.sha256(raw).hexdigest(), "rows": 0}
        reader = csv.reader(StringIO(raw.decode("utf-8-sig"), newline=""))
        header = [normalize(value) for value in next(reader, [])]
        mapping = {}
        for field in sorted(fields):
            indices = [i for i, name in enumerate(header) if name in aliases[field]]
            if len(indices) != 1:
                raise ValueError("%s: identify exactly one column for %s." % (path.name, field))
            mapping[field] = indices[0]
        if len(set(mapping.values())) != len(mapping):
            raise ValueError("A column maps to multiple required fields.")
        for row in reader:
            source["rows"] += 1
            location = "%s row %s" % (path.name, source["rows"] + 1)
            if len(row) != len(header):
                raise ValueError(location + ": wrong column count.")
            values = {name: row[i].strip() for name, i in mapping.items()}
            if not all(values.values()):
                raise ValueError(location + ": required input is empty.")
            if values["id"] in seen:
                raise ValueError(location + ": duplicate input ID " + values["id"])
            seen.add(values["id"])
            if not re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", values["month"]):
                raise ValueError(location + ": month must use YYYY-MM.")
            currency = values["currency"].upper()
            if currency not in spec["currencies"]:
                raise ValueError(location + ": unconfirmed currency " + currency)
            try:
                gross, returns = (Decimal(values[name]) for name in ("gross", "returns"))
            except InvalidOperation as error:
                raise ValueError(location + ": invalid decimal.") from error
            if not gross.is_finite() or not returns.is_finite() or gross < 0 or returns < 0:
                raise ValueError(location + ": expected finite nonnegative amounts.")
            key = (values["month"], values["region"], currency)
            group = groups.setdefault(key, [0, Decimal(0), Decimal(0)])
            group[0] += 1
            group[1] += gross
            group[2] += returns
        sources.append(source)
    output = []
    totals = {}
    for (month, region, currency), (count, gross, returns) in sorted(groups.items()):
        output.append({"month": month, "region": region, "currency": currency, "rows": count,
                       "gross": str(gross), "returns": str(returns), "net": str(gross - returns)})
        totals[currency] = totals.get(currency, Decimal(0)) + gross - returns
    return {"sources": sources, "groups": output, "net_by_currency": {k: str(v) for k, v in sorted(totals.items())}}


def workbook_ops(spec, files):
    result = reconcile(spec, files)
    if not result["groups"]:
        raise ValueError("No source rows to report.")
    sheets = spec.get("output_sheets", {"summary": "Summary", "detail": "Detail"})
    summary, detail = sheets["summary"], sheets["detail"]
    if summary.casefold() == detail.casefold():
        raise ValueError("Summary and detail require distinct output sheets.")
    rows = spec.get("header_rows", {"summary": 1, "detail": 1})
    totals = list(result["net_by_currency"].items())
    summary_header, detail_header = rows["summary"], rows["detail"]
    for header, count in ((summary_header, len(totals)), (detail_header, len(result["groups"]))):
        if type(header) is not int or not 1 <= header <= 1048576 - count:
            raise ValueError("Output rows exceed Excel's worksheet limits.")
    first, end = detail_header + 1, detail_header + len(result["groups"])
    total_first, total_end = summary_header + 1, summary_header + len(totals)
    headers = ["Month", "Region", "Currency", "Rows", "Gross", "Returns", "Net"]
    raw = [[g["month"], g["region"], g["currency"], g["rows"],
            float(g["gross"]), float(g["returns"])] for g in result["groups"]]
    net = [[float(g["net"])] for g in result["groups"]]
    detail_ref = "'" + detail.replace("'", "''") + "'"
    operations = [
        {"id": "detail", "op": "range.values", "sheet": detail, "range": f"A{detail_header}:G{detail_header}",
         "values": [headers]},
        {"id": "groups", "op": "range.values", "sheet": detail, "range": f"A{first}:F{end}", "values": raw},
        {"id": "net", "op": "range.formulas", "sheet": detail, "range": f"G{first}:G{end}",
         "formulas": [[f"=E{row}-F{row}"] for row in range(first, end + 1)]},
        {"id": "summary", "op": "range.values", "sheet": summary, "range": f"A{summary_header}:B{summary_header}",
         "values": [["Currency", "Net"]]},
        {"id": "currencies", "op": "range.values", "sheet": summary, "range": f"A{total_first}:A{total_end}",
         "values": [[currency] for currency, _ in totals]},
        {"id": "total", "op": "range.formulas", "sheet": summary, "range": f"B{total_first}:B{total_end}",
         "formulas": [[f"=SUMIF({detail_ref}!$C${first}:$C${end},A{row},{detail_ref}!$G${first}:$G${end})"]
                      for row in range(total_first, total_end + 1)]},
        {"id": "verify-detail", "op": "assert.range", "sheet": detail, "range": f"G{first}:G{end}",
         "values": net, "tolerance": 0.0000001},
        {"id": "verify-total", "op": "assert.range", "sheet": summary, "range": f"B{total_first}:B{total_end}",
         "values": [[float(amount)] for _, amount in totals], "tolerance": 0.0000001},
    ]
    return {"version": 1, "operations": operations}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("Usage: python -m tools.excel_report scan sample.xlsx [sample.pptx ...] | layouts.json [input.csv ...]")
    modes = {"reconcile": reconcile, "workbook-ops": workbook_ops}
    function = modes.get(sys.argv[1], profile)
    offset = 1 if function is profile else 2
    try:
        if sys.argv[1] == "scan":
            if len(sys.argv) < 3:
                raise ValueError("Provide at least one sample report.")
            result = {"samples": [scan_sample(Path(path)) for path in sys.argv[2:]]}
        else:
            spec = json.loads(Path(sys.argv[offset]).read_text(encoding="utf-8-sig"))
            files = [Path(path) for path in sys.argv[offset + 1:]]
            result = function(spec, files)
    except (ValueError, KeyError, OSError, IndexError, ET.ParseError, BadZipFile) as error:
        print(json.dumps({"status": "needs-input", "message": str(error)}, ensure_ascii=True))
        sys.exit(1)
    print(json.dumps(result, ensure_ascii=True, indent=2))
