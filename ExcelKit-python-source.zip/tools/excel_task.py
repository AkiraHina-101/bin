"""Durable ExcelKit task checkpoints. Uses the Python standard library."""

from contextlib import contextmanager
from hashlib import sha256
import json
import msvcrt
import os
from pathlib import Path
import re
from time import sleep
from uuid import uuid4


IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}")
MAX_BRIEF = 1600


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path, value, *, durable=True):
    temporary = path.with_name(path.name + "." + uuid4().hex + ".tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=True, indent=2)
            if durable:
                stream.flush()
                os.fsync(stream.fileno())
        # A Windows reader without FILE_SHARE_DELETE can briefly block replacement.
        for delay in (0.01, 0.02, 0.04, 0.08, 0.16, 0):
            try:
                os.replace(temporary, path)
                break
            except PermissionError as error:
                if not delay or error.winerror not in (5, 32, 33):
                    raise
                sleep(delay)
    finally:
        temporary.unlink(missing_ok=True)


def digest(path):
    hashed = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hashed.update(chunk)
    return hashed.hexdigest()


def require_id(value):
    if not isinstance(value, str) or not IDENTIFIER.fullmatch(value):
        raise ValueError("Use a task/step ID of up to 64 letters, digits, underscores or hyphens.")
    return value.lower()


def brief(value, label, optional=False):
    if not isinstance(value, str) or (not value.strip() and not optional) or len(value) > MAX_BRIEF:
        raise ValueError("Use up to %s characters for %s." % (MAX_BRIEF, label))
    return value.strip()


class Task:
    def __init__(self, root, task_id):
        self.directory = root / "tasks" / require_id(task_id)
        self.path = self.directory / "checkpoint.json"

    @contextmanager
    def lock(self):
        if not self.directory.is_dir():
            raise ValueError("Task not found. Initialize it with task start.")
        with (self.directory / ".lock").open("a+b") as stream:
            stream.seek(0)
            try:
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise ValueError("This task is being updated or a tracked command is still running.")
            try:
                yield
            finally:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)

    def start(self, request, next_step):
        next_step = brief(next_step, "next step")
        if not request.strip():
            raise ValueError("The latest user request is empty.")
        self.directory.mkdir(parents=True, exist_ok=True)
        with self.lock():
            if self.path.exists():
                raise ValueError("Task already exists. Read its checkpoint with task resume.")
            write_json(self.path, {"version": 1, "request": request, "objective": "", "constraints": "",
                                   "completed": "", "next": next_step, "pending": None, "last": None,
                                   "status": "active", "revision": 1, "used_steps": []})
        return self.resume()

    def update(self, request):
        if not request.strip():
            raise ValueError("The latest user request is empty.")
        with self.lock():
            state = read_json(self.path)
            if state["status"] == "done":
                raise ValueError("Start a new task ID for a completed task.")
            if state["request"] != request:
                write_json(self.directory / ("request-%s.json" % state["revision"]), state["request"])
                state["request"] = request
                state["summary_outdated"] = True
                self.save(state)
        return self.resume()

    def inspect_outcome(self, pending):
        if not pending:
            return None
        run = Path(pending["run"]) if pending["run"] else None
        if run is None:
            return {"state": "unconfirmed", "reason": "External action needs observed evidence."}
        receipt = run / "result.json"
        publication = run / "publication.json"
        if publication.is_file():
            evidence = read_json(publication)
            output = Path(evidence["path"])
            if output.is_file() and digest(output) == evidence["sha256"]:
                if not receipt.is_file():
                    return {"state": "published_unlogged", "output": str(output),
                            "evidence": str(publication)}
            elif output.exists() or receipt.is_file() and read_json(receipt).get("status") == "PASS":
                return {"state": "output_mismatch", "output": str(output),
                        "evidence": str(publication)}
        if receipt.is_file():
            report = read_json(receipt)
            summary = {key: report[key] for key in ("status", "stage", "output", "plan", "preview",
                                                   "export", "report_csv", "message")
                       if key in report}
            if "message" in summary:
                summary["message"] = summary["message"][:500]
            return {"state": "receipt", "evidence": str(receipt), **summary}
        return {"state": "unconfirmed", "reason": "No final receipt. Inspect this run before retrying.",
                "state_file": str(run / "state.json")}

    def resume(self):
        # Read-only: write_json replaces the checkpoint atomically, so no lock is needed and
        # a long tracked command does not block reading its progress.
        if not self.path.is_file():
            raise ValueError("Task not found. Initialize it with task start.")
        state = read_json(self.path)
        pending = state["pending"]
        return {"task": self.directory.name, "checkpoint": str(self.path),
                "request": state["request"] if len(state["request"]) <= MAX_BRIEF else None,
                "request_in_checkpoint": len(state["request"]) > MAX_BRIEF,
                **{key: state[key] for key in
                   ("status", "objective", "constraints", "completed", "next", "last", "revision")},
                "request_archive": str(self.directory / "request-*.json"),
                "summary_outdated": state.get("summary_outdated", False),
                "pending": pending, "outcome": self.inspect_outcome(pending)}

    def save(self, state):
        state["revision"] += 1
        write_json(self.path, state)

    def begin(self, step, intent, run):
        state = read_json(self.path)
        step = require_id(step)
        if state["pending"]:
            raise ValueError("Resolve the pending step before recording or running another.")
        if state["status"] == "done" or step in state["used_steps"]:
            raise ValueError("Task is complete or this step ID was already used. Read task resume.")
        state["pending"] = {"step": step, "intent": brief(intent, "step intent"),
                            "run": str(run) if run else None}
        if state.get("summary_outdated"):
            raise ValueError("Review the latest request and refresh the checkpoint summary before starting.")
        self.save(state)

    def resolve(self, step, next_step, disposition, evidence, complete):
        with self.lock():
            state = read_json(self.path)
            pending = state["pending"]
            if not pending or pending["step"] != require_id(step):
                raise ValueError("Step does not match the pending action.")
            if complete and state.get("summary_outdated"):
                raise ValueError("Review the latest request and refresh the summary before completing.")
            result = self.inspect_outcome(pending)
            if disposition == "verified":
                automatic = result["state"] == "published_unlogged" or (
                    result["state"] == "receipt" and result["status"] == "PASS")
                if not automatic and not evidence:
                    raise ValueError("Record concrete observed evidence for this action.")
                if result["state"] == "output_mismatch":
                    raise ValueError("Output differs from the publication receipt. Resolve as needs-work.")
            else:
                if complete:
                    raise ValueError("A step needing work cannot complete the task.")
                if result["state"] == "unconfirmed" and not evidence:
                    raise ValueError("Record what was inspected before resuming an unconfirmed action.")
            state["next"] = brief(next_step, "next step", optional=complete)
            state["last"] = {"step": pending["step"], "disposition": disposition,
                             "evidence": brief(evidence or result.get("evidence", ""), "evidence", optional=True),
                             "run": pending["run"], "intent": pending["intent"], "outcome": result}
            history = self.directory / "steps"
            history.mkdir(exist_ok=True)
            write_json(history / (pending["step"] + ".json"), state["last"])
            state["pending"] = None
            state["status"] = "done" if complete else "active"
            state["used_steps"].append(pending["step"])
            self.save(state)
        return self.resume()

    def compact(self, notes, revision):
        keys = {"objective", "constraints", "completed", "next"}
        if not isinstance(notes, dict) or keys != notes.keys():
            raise ValueError("Provide objective, constraints, completed and next in the summary JSON.")
        with self.lock():
            state = read_json(self.path)
            if state["revision"] != revision:
                raise ValueError("Checkpoint changed. Read task resume before replacing the summary.")
            for key in keys:
                state[key] = brief(notes[key], key, optional=key in {"constraints", "completed"} or
                                   (key == "next" and state["status"] == "done"))
            state["summary_outdated"] = False
            self.save(state)
        return self.resume()
