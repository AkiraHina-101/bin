"""Read dialogs and stop only the Excel process owned by a timed-out worker."""

import ctypes
from ctypes import wintypes
from pathlib import Path
import subprocess
import time
import winreg
from zipfile import ZipFile

import pythoncom
import win32api
import win32event
import win32gui
import win32job
import win32process
from win32com.client import Dispatch


class OwnedOffice:
    def __init__(self, executable, arguments, visible=False):
        self.name = executable.name
        self.job = win32job.CreateJobObject(None, "")
        self.handle = None
        try:
            info = win32job.QueryInformationJobObject(self.job, win32job.JobObjectExtendedLimitInformation)
            info["BasicLimitInformation"]["LimitFlags"] |= win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            win32job.SetInformationJobObject(self.job, win32job.JobObjectExtendedLimitInformation, info)
            startup = win32process.STARTUPINFO()
            startup.dwFlags = subprocess.STARTF_USESHOWWINDOW
            startup.wShowWindow = 1 if visible else 0
            command = subprocess.list2cmdline([str(executable), *map(str, arguments)])
            self.handle, thread, self.pid, _ = win32process.CreateProcess(
                str(executable), command, None, None, False, 4, None, None, startup)
            try:
                win32job.AssignProcessToJobObject(self.job, self.handle)
                win32process.ResumeThread(thread)
            finally:
                thread.Close()
        except Exception:
            if self.handle is not None:
                try:
                    win32api.TerminateProcess(self.handle, 1)
                finally:
                    self.handle.Close()
            self.job.Close()
            raise

    def poll(self):
        if win32event.WaitForSingleObject(self.handle, 0) == win32event.WAIT_OBJECT_0:
            return win32process.GetExitCodeProcess(self.handle)
        return None

    def wait(self, timeout):
        if win32event.WaitForSingleObject(self.handle, int(timeout * 1000)) == win32event.WAIT_TIMEOUT:
            raise subprocess.TimeoutExpired(self.name, timeout)
        return win32process.GetExitCodeProcess(self.handle)

    def kill(self):
        win32api.TerminateProcess(self.handle, 124)

    def attach_worker(self, worker):
        # The worker waits for the release marker before invoking Excel COM.
        handle = win32api.OpenProcess(0x0101, False, worker.pid)
        try:
            win32job.AssignProcessToJobObject(self.job, handle)
        finally:
            handle.Close()

    def close(self):
        self.job.Close()
        self.handle.Close()


def office_executable(name):
    key = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths" + "\\" + name
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(hive, key) as entry:
                executable = Path(winreg.QueryValue(entry, None))
            if executable.name.lower() == name and executable.is_file():
                return executable
        except OSError:
            continue
    else:
        raise RuntimeError(name + " was not found in Windows App Paths.")


def launch_excel(bootstrap):
    # The starter contains one empty sheet, no links, connections or executable content.
    main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    office = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    rel = "http://schemas.openxmlformats.org/package/2006/relationships"
    with ZipFile(bootstrap, "x") as package:
        package.writestr("[Content_Types].xml",
                         '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                         '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                         '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                         '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                         '</Types>')
        package.writestr("_rels/.rels", '<Relationships xmlns="%s"><Relationship Id="rId1" Type="%s/officeDocument" Target="xl/workbook.xml"/></Relationships>' % (rel, office))
        package.writestr("xl/workbook.xml", '<workbook xmlns="%s" xmlns:r="%s"><sheets><sheet name="Bootstrap" sheetId="1" r:id="rId1"/></sheets></workbook>' % (main, office))
        package.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="%s"><Relationship Id="rId1" Type="%s/worksheet" Target="worksheets/sheet1.xml"/></Relationships>' % (rel, office))
        package.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="%s"><sheetData/></worksheet>' % main)
    return OwnedOffice(office_executable("excel.exe"), ["/x", bootstrap])


def native_office_windows(pid, child_class):
    windows = []

    def visit(window, _):
        if win32process.GetWindowThreadProcessId(window)[1] == pid:
            win32gui.EnumChildWindows(window, child, None)
        return True

    def child(window, _):
        if (win32process.GetWindowThreadProcessId(window)[1] == pid and
                win32gui.GetClassName(window) == child_class):
            windows.append(window)
        return True

    win32gui.EnumWindows(visit, None)
    for window in windows:
        try:
            result = win32gui.SendMessageTimeout(window, 0x003D, 0, -16, 2, 500)
            if result[1]:
                yield Dispatch(pythoncom.ObjectFromLresult(result[1], pythoncom.IID_IDispatch, 0))
        except (pythoncom.com_error, win32gui.error):
            continue


def connect_owned_excel(pid, bootstrap, timeout=60):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        for native in native_office_windows(pid, "EXCEL7"):
            try:
                app = native.Application
                if win32process.GetWindowThreadProcessId(app.Hwnd)[1] != pid:
                    raise RuntimeError("COM attached to a different Excel process.")
                for book in app.Workbooks:
                    if Path(book.FullName).resolve() == bootstrap:
                        return app, book
            except (pythoncom.com_error, win32gui.error):
                continue
        time.sleep(0.15)
    raise RuntimeError("Excel did not expose COM for the starter workbook within %s seconds. "
                       "Check for a startup dialog, license prompt or blocked add-in." % timeout)


def window_text(window):
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    send = user32.SendMessageTimeoutW
    send.argtypes = (wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM,
                     wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_size_t))
    send.restype = wintypes.LPARAM
    buffer = ctypes.create_unicode_buffer(2048)
    result = ctypes.c_size_t()
    send(window, 0x000D, len(buffer), ctypes.addressof(buffer), 2, 100, ctypes.byref(result))
    return buffer.value


def dialogs(pid, excel_window):
    found = []

    def scan(window, _):
        if len(found) >= 6 or not win32gui.IsWindowVisible(window) or window == excel_window:
            return True
        if win32process.GetWindowThreadProcessId(window)[1] != pid:
            return True
        cls = win32gui.GetClassName(window)
        if cls not in ("#32770", "bosa_sdm_XL9") and not cls.startswith("Thunder"):
            return True
        labels = []
        inspected = [0]

        def child(control, _):
            if inspected[0] < 16 and win32gui.GetClassName(control) in ("Static", "Button"):
                inspected[0] += 1
                label = window_text(control)
                if label:
                    labels.append(label)
            return True

        win32gui.EnumChildWindows(window, child, None)
        found.append({"title": window_text(window), "class": cls, "text": labels})
        return True

    win32gui.EnumWindows(scan, None)
    return found


def stop_owned_excel(process, state):
    details = {"stopped_test_excel": False}
    if process.poll() is not None:
        return details
    try:
        try:
            details["dialogs"] = dialogs(process.pid, state.get("excel_window"))
        except Exception as error:
            details["dialog_capture_error"] = str(error)
        process.kill()
        process.wait(timeout=5)
        details["stopped_test_excel"] = True
    except Exception as error:
        details["excel_cleanup_error"] = str(error)
    return details
