VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} KitSampleForm 
   Caption         =   "Excel AI Kit"
   ClientHeight    =   1140
   ClientLeft      =   108
   ClientTop       =   456
   ClientWidth     =   3480
   OleObjectBlob   =   "KitSampleForm.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "KitSampleForm"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
