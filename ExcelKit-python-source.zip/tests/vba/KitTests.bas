Attribute VB_Name = "KitTests"
Option Explicit

Public Function Smoke() As String
    On Error GoTo Failed
    Dim form As KitSampleForm
10  If KitWorkbookSummary(Nothing) <> "No workbook is active." Then
        Err.Raise vbObjectError + 101, "KitTests.Smoke", "Unexpected empty-workbook summary"
    End If
20  If KitWorkbookSummary(ThisWorkbook) <> ThisWorkbook.Name & " | Worksheets: 1 | Read-only: False" Then
        Err.Raise vbObjectError + 102, "KitTests.Smoke", "Unexpected workbook summary"
    End If
30  If Kit_SelfTest() <> "PASS" Then
        Err.Raise vbObjectError + 103, "KitTests.Smoke", "Add-in self-test failed"
    End If
40  Set form = New KitSampleForm
50  Load form
60  If form.Caption <> "Excel AI Kit" Or form.lblStatus.Caption <> "Excel AI Kit form smoke test" Then
        Err.Raise vbObjectError + 104, "KitTests.Smoke", "Unexpected UserForm controls"
    End If
70  Unload form
    Smoke = "PASS"
    Exit Function
Failed:
    Smoke = "FAIL | " & Err.Number & " | " & Err.Source & " | line " & Erl & " | " & Err.Description
End Function
