"""Native PowerPoint runner, add-in package and ownership regression."""

import os
from pathlib import Path
import tempfile
import unittest

from tests.test_python_runner import invoke, ROOT
from tools.excel_report import scan_sample


FIXTURE = ROOT / "examples" / "powerpoint"


@unittest.skipUnless(os.environ.get("OFFICE_KIT_POWERPOINT_TEST"), "PowerPoint needs an unused desktop session.")
class PowerPointKit(unittest.TestCase):
    def test_deck_and_addin(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            deck = root / "verified.pptm"
            code, report = invoke("ppt", "test", "--source", FIXTURE / "vba", "--output", deck, "--trusted-test")
            self.assertEqual(code, 0, report)
            self.assertEqual((report["slide_count"], report["shape_count"]), (1, 1))
            self.assertEqual(report["compile"], "vbe-command")
            sample = scan_sample(deck)
            self.assertEqual(sample["part_count"], 1)
            self.assertIn("KitResult", sample["parts"][0]["shape_names"])
            self.assertIn("PowerPoint VBA verified", sample["parts"][0]["text"])
            code, exported = invoke("ppt", "export", deck)
            self.assertEqual(code, 0, exported)
            self.assertTrue((Path(exported["export"]) / "PowerPointSmoke.bas").is_file())
            addin = root / "verified.ppam"
            code, report = invoke("ppt", "build", "--source", FIXTURE / "vba", "--ribbon",
                                  FIXTURE / "customUI.xml", "--output", addin, "--trusted-test")
            self.assertEqual(code, 0, report)
            code, contents = invoke("ppt", "inspect", addin)
            self.assertEqual(code, 0, contents)
            self.assertEqual(contents["package"]["ribbon_parts"][0]["onAction"], ["KitRunSmoke"])
            invalid = root / "wrong.xml"
            invalid.write_bytes((FIXTURE / "customUI.xml").read_bytes().replace(b"KitRunSmoke", b"NoSuchCallback"))
            bad = root / "invalid.ppam"
            code, failure = invoke("ppt", "build", "--source", FIXTURE / "vba", "--ribbon",
                                   invalid, "--output", bad, "--trusted-test")
            self.assertEqual(code, 1, failure)
            self.assertIn("NoSuchCallback", failure["message"])
            self.assertFalse(bad.exists())

    def test_existing_process_does_not_get_closed(self):
        from tools.excel_powerpoint import connect, running_powerpoint, starter
        from tools.excel_windows import OwnedOffice, office_executable
        self.assertFalse(running_powerpoint(), "Use a desktop without another PowerPoint session.")
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "Existing-Sentinel.pptx"
            starter(path)
            process = OwnedOffice(office_executable("powerpnt.exe"), ["/O", path], visible=True)
            try:
                app, deck, _ = connect(process.pid, path)
                page = deck.Slides.Add(1, 12)
                page.Shapes.AddTextbox(1, 10, 10, 200, 30).TextFrame.TextRange.Text = "unsaved sentinel"
                code, result = invoke("ppt", "doctor")
                self.assertEqual(code, 1, result)
                self.assertIn("already running", result["message"])
                self.assertIsNone(process.poll())
                self.assertEqual(deck.Saved, 0)
                self.assertEqual(page.Shapes.Item(1).TextFrame.TextRange.Text, "unsaved sentinel")
                deck.Saved = -1
                app.Quit()
            finally:
                if process.poll() is None:
                    process.kill()
                process.wait(timeout=5)
                process.close()

    def test_modal_timeout_only_closes_owned_process(self):
        from tools.excel_powerpoint import running_powerpoint
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "Modal.bas").write_text(
                'Attribute VB_Name = "Modal"\nOption Explicit\nPublic Function Smoke() As String\n'
                'MsgBox "PowerPoint timeout fixture", vbOKOnly, "Kit Modal"\nSmoke = "PASS"\nEnd Function\n',
                encoding="ascii")
            code, report = invoke("--timeout", "15", "ppt", "test", "--source", tmp,
                                  "--trusted-test", "--entry", "Modal.Smoke")
            self.assertEqual(code, 124, report)
            self.assertEqual(report["stage"], "ppt-runtime")
            self.assertTrue(report["stopped_test_excel"])
            self.assertFalse(running_powerpoint())
