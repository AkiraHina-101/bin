"""Run a pinned set of SpreadsheetBench tasks without installing extra libraries."""

from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
from statistics import median
import sys
import tarfile
from time import perf_counter
from uuid import uuid4

from tests.test_excel_objects import step, write_ops
from tests.test_python_runner import invoke, ROOT


TASKS = {
    "59196": ("Sheet1", "H3:H5", 'INDEX($D$2:$G$2,MATCH(MAX(D{r}:G{r}),D{r}:G{r},0))'),
    "52292": ("Sheet1", "K27:P32", "C5:H10*TRANSPOSE(C16:C21)"),
    "58296": ("Sheet1", "G4:G11", 'SUMIFS(Table13[Amount],Table13[Date],">="&E{r},Table13[Date],"<="&F{r})'),
    "472-15": ("Sheet1", "B2", 'MATCH(LEFT(A1,FIND(" ",A1&" ")-1),{"4Ozark","3Tall","1Jasper","2GWood","5Dawson","8CPark"},0)'),
    "57262": ("Sheet1", "T7:T15", "SUMPRODUCT(E{r}:K{r},TRANSPOSE($Y$13:$Y$19))"),
    "44389": ("Sheet1", "P2:P7", 'TEXTJOIN(",",TRUE,IF(B{r}:N{r}=MIN(IF(B{r}:N{r}>0,B{r}:N{r})),$B$1:$N$1,""))'),
    "57716": ("Calendar", "I4:I14", 'IF(N(B{r}),"",SUMPRODUCT(--TEXT(RIGHT(B{r}:H{r},3),"0;;;\\0")))'),
    "32438": ("Sheet1", "J2:J4", "MOD(I{r},1)"),
    "41978": ("Cumulative", "I2:I11", 'COUNTIFS($G$14:$G$200,G{r},$J$14:$J$200,"open")'),
    "55427": ("Compiled and located schools da", "B2:B1461",
              "INDEX('URN lookup'!$D$2:$D$1461,MATCH(TRIM(L{r}),'URN lookup'!$K$2:$K$1461,0))"),
    "81-41": ("Sheet1", "B2:F8", None),
    "262-17": ("Sheet1", "A1:F14", None),
}


def require_pass(*args):
    code, result = invoke(*args)
    if code:
        raise RuntimeError("%s %s (%s)" % (result.get("stage"), result.get("message"), result.get("run")))
    return result


def read(path, sheet, address):
    return require_pass("read", path, "--sheet", sheet, "--range", address)["range"]["values"]


def test_case(case):
    identity, (sheet, address, formula), folder = case
    source, answer = folder / "input.xlsx", folder / "answer.xlsx"
    try:
        oracle = read(answer, sheet, address)
        if identity == "81-41":
            baseline = read(source, sheet, address)
            values = [[0 if item in (".", "[Not Done (.)]") else "Not Done (0)" if item == "Not Done (.)"
                       else item for item in row] for row in baseline]
            ops = [step("clean", "range.values", sheet=sheet, range=address, values=values)]
        elif identity == "262-17":
            ops = [step("sort", "range.sort", sheet=sheet, range=address, keys=[3, 6])]
        elif identity == "52292":
            ops = [step("array", "range.formulas", sheet=sheet, range="K27", formulas=[["=" + formula]], dynamic=True)]
        else:
            rows = [int(n) for n in re.findall(r"\d+", address)]
            last = rows[-1]
            target = address
            if identity == "55427":
                # The task's scoring range includes blank rows beyond the source dataset.
                input_rows = read(source, sheet, "L2:L1461")
                last = max(i for i, row in enumerate(input_rows, 2) if row[0] is not None)
                target = "B2:B" + str(last)
            content = [["=" + formula.replace("{r}", str(row))] for row in range(rows[0], last + 1)]
            dynamic = identity in {"44389", "57262", "57716"}
            ops = [step("formula", "range.formulas", sheet=sheet, range=target, formulas=content, dynamic=dynamic)]
            if identity == "32438":
                ops.append(step("display", "range.format", sheet=sheet, range=address, number_format="hh:mm:ss"))
        ops.append(step("golden", "assert.range", sheet=sheet, range=address, values=oracle, tolerance=1e-6))
        path = folder / "ops.json"
        write_ops(path, ops)
        started = perf_counter()
        preview = require_pass("plan", source, "--ops", path)
        require_pass("apply", "--plan", preview["plan"], "--output", folder / "result.xlsx")
        return {"id": identity, "status": "PASS", "seconds": round(perf_counter() - started, 2)}
    except Exception as error:
        return {"id": identity, "status": "FAIL", "message": str(error)}


def main(archive_path):
    raw = Path(archive_path)
    digest = hashlib.sha256(raw.read_bytes()).hexdigest()
    if digest != "d5f97936a348aa84bbd4db818fc261adee1aa0429e21080b3157f98737da50d4":
        raise ValueError("Unexpected SpreadsheetBench archive SHA-256. Review upstream fixture version.")
    run = ROOT / "runs" / ("spreadsheetbench-" + uuid4().hex[:12])
    run.mkdir(parents=True)
    cases = []
    with tarfile.open(raw, "r:gz") as archive:
        for identity, task in TASKS.items():
            directory = run / identity
            directory.mkdir()
            for variant in ("input", "answer"):
                filename = "sample_data_200/spreadsheet/{0}/1_{0}_{1}.xlsx".format(identity, variant)
                (directory / (variant + ".xlsx")).write_bytes(archive.extractfile(filename).read())
            cases.append((identity, task, directory))
    with ThreadPoolExecutor(2) as workers:
        results = list(workers.map(test_case, cases))
    passed = [item["seconds"] for item in results if item["status"] == "PASS"]
    report = {"cases": results, "passed": len(passed), "total": len(cases),
              "median_seconds": median(passed) if passed else None, "fixture_sha256": digest}
    (run / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(dict(report, report=str(run / "report.json")), indent=2))
    return len(passed) != len(cases)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
