"""Desktop Excel tests for the declarative workflow and process ownership."""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import shutil
import tempfile
import unittest

import win32process
from win32com.client import DispatchEx

from tests.test_python_runner import ROOT, invoke


def step(identifier, operation, **fields):
    return dict(id=identifier, op=operation, **fields)


def write_ops(path, ops):
    path.write_text(json.dumps({"version": 1, "operations": ops}), encoding="utf-8")


def rectangle(left, top, width, height):
    return dict(left=left, top=top, width=width, height=height)


def blank(path):
    excel = DispatchEx("Excel.Application")
    book = excel.Workbooks.Add(-4167)
    try:
        book.Worksheets.Item(1).Name = "Input"
        book.Worksheets.Item(1).Range("Z1").Value2 = "out-of-scope"
        book.SaveAs(str(path), 51)
    finally:
        book.Close(False)
        excel.Quit()


class WorkbookWorkflow(unittest.TestCase):
    def test_update_existing_dashboard_objects(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source, ops, output = [folder / p for p in ("source.xlsx", "ops.json", "dashboard.xlsx")]
            blank(source)
            write_ops(ops, [
                step("rows", "range.values", sheet="Input", range="A1:C4",
                     values=[["Region", "Sales", "Month"], ["East", 10, "Jan"],
                             ["West", 20, "Jan"], ["East", 40, "Feb"]]),
                step("table", "table.create", sheet="Input", name="Orders", range="A1:C3"),
                step("chart", "chart.create", sheet="Input", name="SalesChart", chart_type="column",
                     geometry=rectangle(200, 20, 300, 180)),
                step("series", "series.create", sheet="Input", name="Sales", chart="SalesChart",
                     x="A2:A3", y="B2:B3"),
                step("shape", "shape.create", sheet="Input", name="LegendBox", geometry=rectangle(20, 150, 100, 22)),
                step("report", "sheet.create", sheet="SalesReport"),
                step("pivot", "pivot.create", sheet="SalesReport", name="SalesPivot", cell="A3", source_sheet="Input",
                     table="Orders", rows=["Region"], columns=[], value="Sales", caption="Total"),
            ])
            code, preview = invoke("plan", source, "--ops", ops)
            self.assertEqual(code, 0, preview)
            code, applied = invoke("apply", "--plan", preview["plan"], "--output", output)
            self.assertEqual(code, 0, applied)
            write_ops(ops, [
                step("resize", "table.resize", sheet="Input", name="Orders", range="A1:C4"),
                step("filter", "table.filter", sheet="Input", name="Orders", column="Region", equals="East"),
                step("chart", "chart.update", sheet="Input", name="SalesChart", title="Sales by region"),
                step("series", "series.update", sheet="Input", name="Sales", chart="SalesChart", x="A2:A4", y="B2:B4"),
                step("shape", "shape.update", sheet="Input", name="LegendBox", text="Updated",
                     geometry=rectangle(30, 150, 110, 25)),
                step("layout", "pivot.layout", sheet="SalesReport", name="SalesPivot", rows=["Region"], columns=["Month"]),
                step("refresh", "pivot.refresh", sheet="SalesReport", name="SalesPivot"),
                step("check", "assert.range", sheet="SalesReport", range="D7", values=[[70]]),
            ])
            code, preview = invoke("plan", output, "--ops", ops)
            self.assertEqual(code, 0, preview)

    def test_rejects_ambiguous_series_and_protected_sheet(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source, ops = folder / "guarded.xlsx", folder / "ops.json"
            excel = DispatchEx("Excel.Application")
            book = excel.Workbooks.Add(-4167)
            try:
                sheet = book.Worksheets.Item(1)
                sheet.Name = "Guarded"
                graph = sheet.ChartObjects().Add(20, 20, 200, 100).Chart
                for _ in range(2):
                    series = graph.SeriesCollection().NewSeries()
                    series.Name = "Same"
                    series.XValues = (1, 2)
                    series.Values = (3, 4)
                name = list(sheet.ChartObjects())[0].Name
                sheet.Protect()
                book.SaveAs(str(source), 51)
            finally:
                series = graph = sheet = None
                book.Close(False)
                excel.Quit()
            original = source.read_bytes()
            write_ops(ops, [step("protected", "range.values", sheet="Guarded", range="A1", values=[[5]])])
            status, result = invoke("plan", source, "--ops", ops)
            self.assertEqual(status, 1, result)
            self.assertEqual(result["stage"], "operation/protected")
            write_ops(ops, [step("ambiguous", "series.update", sheet="Guarded", chart=name,
                                 name="Same", x="A1:A2", y="B1:B2")])
            status, result = invoke("plan", source, "--ops", ops)
            self.assertEqual(status, 1, result)
            self.assertIn("Duplicate object", result["message"])
            self.assertEqual(source.read_bytes(), original)

    def test_document_event_on_staged_copy(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            excel = DispatchEx("Excel.Application")
            book = excel.Workbooks.Add(-4167)
            source = folder / "source.xlsm"
            try:
                project = book.VBProject
                project.VBComponents.Add(1).CodeModule.AddFromString("Option Explicit")
                project = None
                book.SaveAs(str(source), 52)
                code_name = book.Worksheets.Item(1).CodeName
            finally:
                book.Close(False)
                excel.Quit()
            original = source.read_bytes()
            (folder / (code_name + ".document.cls")).write_text(
                'Option Explicit\nPrivate Sub Worksheet_Change(ByVal Target As Range)\n'
                'If Target.Address <> "$A$1" Then Exit Sub\n'
                'Me.Range("B1").Value2 = Target.Value2 * 2\nEnd Sub', encoding="ascii")
            (folder / "EventTest.bas").write_text(
                'Attribute VB_Name = "EventTest"\nOption Explicit\nPublic Function Smoke() As String\n'
                'ThisWorkbook.Worksheets.Item(1).Range("A1").Value2 = 21\n'
                'If ThisWorkbook.Worksheets.Item(1).Range("B1").Value2 = 42 Then Smoke = "PASS"\n'
                'End Function', encoding="ascii")
            code, result = invoke("test", "--workbook", source, "--documents", folder,
                                  "--tests", folder, "--entry", "EventTest.Smoke", "--events")
            self.assertEqual(code, 0, result)
            self.assertEqual(source.read_bytes(), original)
            staged = Path(result["run"]) / "Smoke.xlsm"
            code, reopened = invoke("run", staged, "EventTest.Smoke", "--trusted-test", "--events")
            self.assertEqual(code, 0, reopened)

    @unittest.skipUnless(os.environ.get("EXCELKIT_PUBLIC_FIXTURES"), "Optional local Microsoft samples")
    def test_public_workbooks_and_model(self):
        assets = Path(os.environ["EXCELKIT_PUBLIC_FIXTURES"])
        for file, required in (("Financial Sample.xlsx", {"table"}),
                               ("Dashboard Tutorial.xlsx", {"pivot", "chart", "slicer"}),
                               ("Student Data Model.xlsx", {"pivot", "model", "connection"})):
            code, report = invoke("inventory", assets / file)
            self.assertEqual(code, 0, report)
            self.assertTrue(required.issubset({item["kind"] for item in report["inventory"]["objects"]}), report)
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source = folder / "model.xlsx"
            shutil.copyfile(assets / "Student Data Model.xlsx", source)
            excel = DispatchEx("Excel.Application")
            excel.AutomationSecurity = 3
            book = excel.Workbooks.Open(str(source), 0, False)
            try:
                for relation in book.Model.ModelRelationships:
                    if relation.ForeignKeyColumn.Name == "Semester":
                        relation.Delete()
                        break
                book.Save()
            finally:
                relation = None
                book.Close(False)
                excel.Quit()
            original = source.read_bytes()
            ops = folder / "model.json"
            write_ops(ops, [
                step("relationship", "model.relationship", foreign_table="tbl_Grades",
                     foreign_column="Semester", primary_table="tbl_Semesters", primary_column="Semester ID"),
                step("model", "model.measure", name="Kit Grade Rows", table="tbl_Grades",
                     formula="COUNTROWS(tbl_Grades)"),
                step("report", "sheet.create", sheet="KitReport"),
                step("model_pivot", "model.pivot", sheet="KitReport", name="KitPivot", cell="A3",
                     measure="Kit Grade Rows"),
                step("check", "assert.range", sheet="KitReport", range="A4", values=[[180]]),
            ])
            code, preview = invoke("plan", source, "--ops", ops)
            self.assertEqual(code, 0, preview)
            code, result = invoke("apply", "--plan", preview["plan"], "--output", folder / "result.xlsx")
            self.assertEqual(code, 0, result)
            self.assertEqual(source.read_bytes(), original)

    def test_query_load_and_refresh(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source, ops, csv = [folder / p for p in ("source.xlsx", "ops.json", "sales.csv")]
            blank(source)
            csv.write_text("Region,Amount\nEast,30\nWest,60\n", encoding="utf-8")
            write_ops(ops, [
                step("query", "query.csv", name="SalesCsv", path=str(csv), columns=2),
                step("output", "sheet.create", sheet="Loaded"),
                step("load", "query.load", name="SalesCsv", sheet="Loaded", cell="A1", table="ImportedSales"),
                step("check", "assert.range", sheet="Loaded", range="A2:B3",
                     values=[["East", "30"], ["West", "60"]]),
            ])
            code, p = invoke("plan", source, "--ops", ops)
            self.assertEqual(code, 0, p)
            loaded = folder / "loaded.xlsx"
            code, applied = invoke("apply", "--plan", p["plan"], "--output", loaded)
            self.assertEqual(code, 0, applied)
            csv.write_text("Region,Amount\nEast,50\nWest,90\n", encoding="utf-8")
            code, stale = invoke("apply", "--plan", p["plan"], "--output", folder / "stale.xlsx")
            self.assertEqual(code, 1, stale)
            self.assertIn("CSV source changed", stale["message"])
            write_ops(ops, [
                step("refresh", "query.refresh", name="SalesCsv"),
                step("check", "assert.range", sheet="Loaded", range="A2:B3",
                     values=[["East", "50"], ["West", "90"]]),
            ])
            code, refreshed = invoke("plan", loaded, "--ops", ops)
            self.assertEqual(code, 0, refreshed)

    def test_dashboard_plan_apply_and_source_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source, ops, output = [folder / p for p in ("source.xlsx", "ops.json", "result.xlsx")]
            blank(source)
            original = source.read_bytes()
            artifacts = os.environ.get("EXCELKIT_DASHBOARD_ARTIFACTS")
            destination = Path(artifacts).resolve() if artifacts else folder
            destination.mkdir(parents=True, exist_ok=True)
            csv = destination / "sales.csv"
            csv.write_text("Region,Amount\nEast,10\nEast,20\nWest,60\n", encoding="utf-8")
            write_ops(ops, [
                step("data", "range.values", sheet="Input", range="A1:D4",
                     values=[["Region", "Amount", "X", "Y"], ["East", 10, 20, 1],
                             ["East", 20, 20, 8], ["West", 60, None, None]]),
                step("typed", "range.values", sheet="Input", range="F1:G1", values=[["=literal", "0007"]]),
                step("compute", "range.formulas", sheet="Input", range="B6", formulas=[["=SUM(B2:B4)"]]),
                step("format", "range.format", sheet="Input", range="B2:B4", number_format="0.00"),
                step("validate", "range.validation", sheet="Input", range="B2:B4", minimum=0, maximum=100),
                step("total_name", "name.set", name="SalesTotal", refers_to="=Input!$B$6"),
                step("table", "table.create", sheet="Input", name="Sales", range="A1:B4", style="TableStyleMedium2"),
                step("report", "sheet.create", sheet="Report"),
                step("query", "query.csv", name="DashboardCsv", path=str(csv), columns=2, number_columns=["Amount"]),
                step("query_load", "query.load", sheet="Report", name="DashboardCsv", cell="K1", table="ImportedSales"),
                step("plot", "chart.create", sheet="Input", name="Plot1", title="Threshold",
                     chart_type="scatter_lines", geometry=rectangle(140, 25, 400, 220)),
                step("series", "series.create", sheet="Input", chart="Plot1", name="Guide", x="C2:C3", y="D2:D3"),
                step("scale", "axis.set", sheet="Input", chart="Plot1", axis="x", minimum=0, maximum=60),
                step("marker", "shape.create", sheet="Input", chart="Plot1", name="Marker", text="Reference",
                     geometry=rectangle(10, 30, 45, 15)),
                step("align", "shape.align_series", sheet="Input", chart="Plot1", name="Marker", series="Guide"),
                step("pivot", "pivot.create", sheet="Report", name="SalesPivot", cell="A3", source_sheet="Report",
                     table="ImportedSales", rows=["Region"], columns=[], value="Amount", caption="Sales sum"),
                step("slicer", "slicer.create", sheet="Report", name="RegionSlicer", pivot_sheet="Report",
                     pivot="SalesPivot", field="Region", geometry=rectangle(220, 25, 120, 100)),
                step("east", "slicer.filter", name="RegionSlicer", selected=["East"]),
                step("pivot_check", "assert.range", sheet="Report", range="B5", values=[[30]]),
                step("gross_check", "assert.range", sheet="Input", range="B6", values=[[90]]),
                step("query_check", "assert.range", sheet="Report", range="K2:L4",
                     values=[["East", 10], ["East", 20], ["West", 60]]),
                step("outside", "assert.range", sheet="Input", range="Z1", values=[["out-of-scope"]]),
            ])
            code, preview = invoke("plan", source, "--ops", ops)
            self.assertEqual(code, 0, preview)
            code, applied = invoke("apply", "--plan", preview["plan"], "--output", output)
            self.assertEqual(code, 0, applied)
            self.assertEqual(source.read_bytes(), original)
            code, objects = invoke("inventory", output, "--kind", "pivot", "--kind", "slicer")
            self.assertEqual(code, 0, objects)
            self.assertEqual({item["kind"] for item in objects["inventory"]["objects"]}, {"pivot", "slicer"})
            self.assertEqual(objects["inventory"]["warnings"], [])
            csv.write_text("Region,Amount\nEast,50\nEast,20\nWest,60\n", encoding="utf-8")
            write_ops(ops, [
                step("refresh_query", "query.refresh", name="DashboardCsv"),
                step("refresh_pivot", "pivot.refresh", sheet="Report", name="SalesPivot"),
                step("check", "assert.range", sheet="Report", range="B5", values=[[70]]),
            ])
            code, refreshed = invoke("plan", output, "--ops", ops)
            self.assertEqual(code, 0, refreshed)
            if artifacts:
                csv.write_text("Region,Amount\nEast,10\nEast,20\nWest,60\n", encoding="utf-8")
                shutil.copyfile(output, destination / "Dashboard.xlsx")
            code, rejected = invoke("apply", "--plan", preview["plan"], "--output", output)
            self.assertEqual(code, 1, rejected)
            with source.open("ab") as stream:
                stream.write(b"changed")
            code, stale = invoke("apply", "--plan", preview["plan"], "--output", folder / "stale.xlsx")
            self.assertEqual(code, 1, stale)
            self.assertIn("changed", stale["message"])

    def test_failed_batch_leaves_source_and_output_untouched(self):
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory)
            source, ops = folder / "source.xlsx", folder / "invalid.json"
            blank(source)
            original = source.read_bytes()
            write_ops(ops, [
                step("write", "range.values", sheet="Input", range="A1", values=[[1]]),
                step("unknown", "range.values", sheet="Missing", range="A1", values=[[2]]),
            ])
            code, preview = invoke("plan", source, "--ops", ops)
            self.assertEqual(code, 1, preview)
            self.assertEqual(preview["stage"], "operation/unknown")
            self.assertNotIn("plan", preview)
            self.assertFalse((Path(preview["run"]) / "work").exists())
            self.assertEqual(source.read_bytes(), original)

    def test_timeout_preserves_other_excel_and_parallel_runs(self):
        excel = DispatchEx("Excel.Application")
        book = excel.Workbooks.Add(-4167)
        try:
            pid = win32process.GetWindowThreadProcessId(excel.Hwnd)[1]
            book.Worksheets.Item(1).Range("A1").Value2 = "unsaved sentinel"
            self.assertFalse(book.Saved)
            with tempfile.TemporaryDirectory() as directory, ThreadPoolExecutor(2) as pool:
                shutil.copyfile(ROOT / "tests/cases/ModalDialog.bas", Path(directory) / "ModalDialog.bas")
                blocked = pool.submit(invoke, "--timeout", 16, "test", "--tests", directory,
                                      "--entry", "ModalDialog.Smoke")
                healthy = pool.submit(invoke, "doctor")
                code, result = blocked.result()
                self.assertEqual(code, 124, result)
                self.assertTrue(result["stopped_test_excel"], result)
                code, result = healthy.result()
                self.assertEqual(code, 0, result)
            self.assertEqual(win32process.GetWindowThreadProcessId(excel.Hwnd)[1], pid)
            self.assertFalse(book.Saved)
            self.assertEqual(book.Worksheets.Item(1).Range("A1").Value2, "unsaved sentinel")
        finally:
            book.Close(False)
            excel.Quit()
