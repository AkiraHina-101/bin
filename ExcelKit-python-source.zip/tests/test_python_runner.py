"""Run against desktop Excel: python -m unittest discover -s tests -p test_python_runner.py."""

import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
import tempfile
import unittest

from tools.excel_package import ADDIN


ROOT = Path(__file__).resolve().parents[1]


def invoke(*args):
    result = subprocess.run([sys.executable, str(ROOT / "ExcelKit.py"), *map(str, args)],
                            cwd=str(ROOT), capture_output=True, text=True, timeout=120)
    if not result.stdout:
        raise AssertionError(result.stderr)
    return result.returncode, json.loads(result.stdout)


class ExcelRunner(unittest.TestCase):
    def test_smoke_export_run_and_build(self):
        code, report = invoke("test")
        self.assertEqual(code, 0, report)
        self.assertEqual(report["compile"], "vbe-command")
        book = Path(report["run"]) / "Smoke.xlsm"
        original = hashlib.sha256(book.read_bytes()).digest()
        code, report = invoke("export", book)
        self.assertEqual(code, 0, report)
        export = Path(report["export"])
        for name in ("KitSampleForm.frm", "KitSampleForm.frx", "ThisWorkbook.document.cls"):
            self.assertTrue((export / name).is_file(), name)
        code, report = invoke("run", book, "Kit_SelfTest", "--trusted-test")
        self.assertEqual(code, 0, report)
        self.assertEqual(hashlib.sha256(book.read_bytes()).digest(), original)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.xlam"
            code, report = invoke("build", "--output", path)
            self.assertEqual(code, 0, report)
            code, report = invoke("inspect", path, "--verify-crc")
            self.assertEqual(code, 0, report)
            package = report["package"]
            self.assertEqual(package["workbook_content_type"], ADDIN)
            self.assertEqual(package["ribbon_parts"][0]["onAction"], ["Kit_RunSelfTest", "Kit_StampDateTime", "Kit_AutofitColumns", "Kit_ToggleFreezeTopRow", "Kit_About"])
            code, report = invoke("run", path, "Kit_SelfTest", "--trusted-test")
            self.assertEqual(code, 0, report)

    def test_reads_distinguish_formula_and_literal_text(self):
        import pythoncom
        from win32com.client import DispatchEx

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "read.xlsx"
            excel = DispatchEx("Excel.Application")
            book = sheet = None
            try:
                book = excel.Workbooks.Add(-4167)
                sheet = book.Worksheets.Item(1)
                sheet.Range("A1").Formula = "=2+3"
                sheet.Range("B1").NumberFormat = "@"
                sheet.Range("B1").Value2 = "=literal"
                sheet.Range("B2").Formula = "=A1*2"
                sheet.Range("A3").Formula = "=1+1"
                sheet.Range("B3").Formula = "=1+2"
                name = sheet.Name
                book.SaveAs(str(path), 51, pythoncom.Missing)
            finally:
                sheet = None
                if book is not None:
                    book.Close(False)
                    book = None
                excel.Quit()
                excel = None
            code, report = invoke("read", path, "--sheet", name, "--range", "A1:B2")
            self.assertEqual(code, 0, report)
            self.assertEqual(report["range"]["values"], [[5, "=literal"], [None, 10]])
            self.assertEqual(report["range"]["formulas"], [["=2+3", None], [None, "=A1*2"]])
            code, report = invoke("read", path, "--sheet", name, "--range", "B1")
            self.assertEqual(code, 0, report)
            self.assertEqual(report["range"]["formulas"], [[None]])
            code, report = invoke("read", path, "--sheet", name, "--range", "A3:B3")
            self.assertEqual(code, 0, report)
            self.assertEqual(report["range"]["formulas"], [["=1+1", "=1+2"]])

    def test_macro_pass_does_not_override_incorrect_output(self):
        with tempfile.TemporaryDirectory() as directory:
            tests = Path(directory)
            (tests / "OutputTest.bas").write_text(
                'Attribute VB_Name = "OutputTest"\nOption Explicit\n'
                'Public Function Smoke() As String\n'
                'ThisWorkbook.Worksheets(1).Name = "Result"\n'
                'ThisWorkbook.Worksheets(1).Range("A1").Value2 = 42\n'
                'Smoke = "PASS"\nEnd Function\n', encoding="ascii")
            path = tests / "expected.json"
            for expected, code in ((42, 0), (43, 1)):
                path.write_text(json.dumps([{"sheet": "Result", "range": "A1",
                                             "values": [[expected]]}]), encoding="utf-8")
                status, report = invoke("test", "--tests", tests, "--entry", "OutputTest.Smoke",
                                        "--expect", path)
                self.assertEqual(status, code, report)
                if code:
                    self.assertEqual(report["stage"], "assert-range/Result!A1", report)
                else:
                    self.assertEqual(report["verified_ranges"], 1, report)

    def test_failure_modes(self):
        for name in ("CompileFailure", "RuntimeFailure", "ModalDialog"):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                shutil.copyfile(ROOT / "tests" / "cases" / (name + ".bas"), Path(directory) / (name + ".bas"))
                timeout = 12 if name == "ModalDialog" else 40
                code, report = invoke("--timeout", timeout, "test", "--tests", directory,
                                      "--entry", name + ".Smoke")
                if name == "CompileFailure":
                    self.assertIn(code, (1, 124), report)
                    self.assertEqual(report["stage"], "vbe-compile", report)
                elif name == "RuntimeFailure":
                    self.assertEqual(code, 1, report)
                    self.assertIn("line 10 | Intentional test error", report["macro_result"])
                else:
                    self.assertEqual(code, 124, report)
                    self.assertTrue(report["stopped_test_excel"], report)
                    self.assertTrue(any("Intentional modal timeout" in dialog["text"]
                                        for dialog in report["dialogs"]), report)
