"""Measure Value2 batching on the same Excel session and validate both results."""

import json
from statistics import median
from time import perf_counter
import unittest

import win32process
from win32com.client import DispatchEx


class BatchTiming(unittest.TestCase):
    def test_bulk_value2_matches_per_cell_writes(self):
        prior = set(win32process.EnumProcesses())
        excel = DispatchEx("Excel.Application")
        self.assertNotIn(win32process.GetWindowThreadProcessId(excel.Hwnd)[1], prior)
        book = sheet = area = None
        try:
            book = excel.Workbooks.Add(-4167)
            sheet = book.Worksheets.Item(1)
            area = sheet.Range("A1:D100")
            data = tuple(tuple(row * 10 + col for col in range(4)) for row in range(100))
            manual, bulk = [], []
            for _ in range(3):
                area.ClearContents()
                start = perf_counter()
                for row, values in enumerate(data, 1):
                    for column, value in enumerate(values, 1):
                        sheet.Cells.Item(row, column).Value2 = value
                manual.append(perf_counter() - start)
                self.assertEqual(area.Value2, data)
                area.ClearContents()
                start = perf_counter()
                area.Value2 = data
                bulk.append(perf_counter() - start)
                self.assertEqual(area.Value2, data)
            print(json.dumps({"cells": 400, "trials": 3, "excel_starts": 1,
                              "median_cell_loop_seconds": round(median(manual), 4),
                              "median_value2_seconds": round(median(bulk), 4),
                              "writes_per_cell_loop": 400, "writes_per_value2": 1}))
        finally:
            sheet = area = None
            if book is not None:
                book.Close(False)
                book = None
            excel.Quit()
