"""Regression of a real XLSM patch, including the report written by the VBA entry point."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from zipfile import ZipFile

import win32process
from win32com.client import DispatchEx

from tests.test_python_runner import invoke, ROOT
from tools.excel_package import add_ribbon
from tools.excel_task import Task, digest, write_json


FIXTURE = ROOT / "examples" / "vba-report"


def create_form(project):
    form = project.VBComponents.Add(3)
    form.Name = "ReportOptions"
    designer = form.Designer
    designer.Caption = "Export report by region"
    form.Properties.Item("Width").Value = 280
    form.Properties.Item("Height").Value = 142
    controls = (
        ("Label", "RegionLabel", "Region (East or West)", 12, 12, 226),
        ("TextBox", "RegionBox", None, 12, 30, 226),
        ("Label", "MessageLabel", "", 12, 52, 230),
        ("CommandButton", "ExportButton", "Export", 90, 77, 72),
        ("CommandButton", "CancelButton", "Cancel", 166, 77, 72),
    )
    for kind, name, caption, left, top, width in controls:
        item = designer.Controls.Add("Forms.%s.1" % kind, name, True)
        item.Left, item.Top, item.Width = left, top, width
        if caption is not None:
            item.Caption = caption
        if name == "ExportButton":
            item.Default = True
        if name == "CancelButton":
            item.Cancel = True
    form.CodeModule.AddFromString((FIXTURE / "ReportOptions.code").read_text(encoding="ascii"))


def create_fixture(folder):
    previous = set(win32process.EnumProcesses())
    app = DispatchEx("Excel.Application")
    if win32process.GetWindowThreadProcessId(app.Hwnd)[1] in previous:
        raise RuntimeError("Fixture did not get a new Excel session.")
    raw = folder / "original.xlsm"
    book = None
    try:
        book = app.Workbooks.Add(-4167)
        entries = book.Worksheets.Item(1)
        entries.Name = "Input"
        entries.Range("A1:B4").Value2 = (("Region", "Amount"), ("East", 10), ("West", 50), ("East", 20))
        report = book.Worksheets.Add()
        report.Name = "Report"
        report.Range("B2").Value2 = "East"
        report.Range("D1").Value2 = "unchanged"
        project = book.VBProject
        project.VBComponents.Import(str(FIXTURE / "ReportModule.bas"))
        create_form(project)
        helper = project.VBComponents.Add(1)
        helper.Name = "KeepModule"
        helper.CodeModule.AddFromString("Option Explicit\r\nPublic Function KeepMe() As String\r\nKeepMe = \"untouched\"\r\nEnd Function")
        book.SaveAs(str(raw), 52)
        helper = project = report = entries = None
    finally:
        if book is not None:
            book.Close(False)
        app.Quit()
    source = folder / "ReportTool.xlsm"
    add_ribbon(raw, source, (FIXTURE / "customUI.xml").read_bytes())
    return source


class ScopedVbaPatch(unittest.TestCase):
    def test_patch_report_and_reopen(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            source = create_fixture(folder)
            original = hashlib.sha256(source.read_bytes()).hexdigest()

            # Confirm the original actually produces the wrong file on a separate copy.
            legacy = folder / "legacy"
            legacy.mkdir()
            previous = set(win32process.EnumProcesses())
            app = DispatchEx("Excel.Application")
            self.assertNotIn(win32process.GetWindowThreadProcessId(app.Hwnd)[1], previous)
            book = None
            try:
                copy = Path(shutil.copyfile(source, legacy / source.name))
                app.AutomationSecurity = 2
                book = app.Workbooks.Open(str(copy), 0, True)
                app.Run("'ReportTool.xlsm'!ReportModule.ExportReport")
                self.assertEqual(book.Worksheets("Report").Range("B5").Value2, 80)
                self.assertIn("East,80", (legacy / "Report.csv").read_text())
            finally:
                if book is not None:
                    book.Close(False)
                app.Quit()

            code, diff = invoke("vba-diff", source, "--patch", FIXTURE / "patch.json")
            self.assertEqual(code, 0, diff)
            self.assertIn("SumIf", diff["diff"][0])
            self.assertNotIn("KeepModule", diff["diff"][0])
            output = folder / "Verified.xlsm"
            code, done = invoke("vba-patch", "--preview", diff["preview"], "--output", output,
                                "--entry", "ReportModule.ExportReport", "--expect", FIXTURE / "expect.json",
                                "--expect-csv", FIXTURE / "expected.csv", "--trusted-test")
            self.assertEqual(code, 0, done)
            self.assertEqual(done["compile"], "vbe-command")
            self.assertEqual(done["verified_ranges"], 1)
            self.assertIn("East,30", Path(done["report_csv"]).read_text())
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), original)
            with ZipFile(output) as package:
                self.assertEqual(package.read("customUI/customUI.xml"), (FIXTURE / "customUI.xml").read_bytes())
            code, result = invoke("read", output, "--sheet", "Report", "--range", "D1")
            self.assertEqual(code, 0, result)
            self.assertEqual(result["range"]["values"], [["unchanged"]])
            ui_dir = os.environ.get("OFFICE_KIT_EXCEL_UI_FIXTURE")
            if ui_dir:
                target = Path(ui_dir)
                target.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(output, target / "Verified-Report.xlsm")

    def test_recovery_at_three_vba_boundaries(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            task = Task(folder, "vba-report")
            task.start("Repair XLSM and verify CSV.", "Preview the patch.")
            run = folder / "runs" / "patch"
            run.mkdir(parents=True)
            with task.lock():
                task.begin("patch-01", "Patch one procedure on a copy.", run)
            self.assertEqual(task.resume()["outcome"]["state"], "unconfirmed")
            write_json(run / "state.json", {"stage": "vba-edit/ReportModule"})
            self.assertEqual(task.resume()["outcome"]["state"], "unconfirmed")
            staging = folder / "stage.xlsm"
            staging.write_bytes(b"verified staged workbook")
            final = folder / "Verified.xlsm"
            write_json(run / "publication.json", {"path": str(final), "sha256": digest(staging)})
            self.assertEqual(task.resume()["outcome"]["state"], "unconfirmed")
            staging.rename(final)
            report = task.resume()
            self.assertEqual(report["outcome"]["state"], "published_unlogged")
            self.assertEqual(report["outcome"]["output"], str(final))
            self.assertEqual(json.loads(task.path.read_text())["pending"]["step"], "patch-01")
