"""Synthetic report variants for the input/output intake prototype."""

from pathlib import Path
import json
import os
import tempfile
import unittest

from tools.excel_report import profile, reconcile, scan_sample, workbook_ops


class ReportProfile(unittest.TestCase):
    @unittest.skipUnless(os.environ.get("OFFICE_KIT_REPORT_TEST"), "Desktop Excel report generation")
    def test_report_output_for_two_layouts(self):
        from tests.test_python_runner import invoke
        from win32com.client import DispatchEx
        import win32process
        confirmed = {"rule": "net_equals_gross_minus_returns", "currencies": ["JPY", "USD"],
                     "columns": {"id": ["Order"], "month": ["Period"], "region": ["Territory"],
                                 "currency": ["CCY"], "gross": ["Sales"], "returns": ["Refund"]}}
        fixtures = (
            ("Summary", "Detail", 1, 1, "id,month,region,currency,gross,returns\nA,2026-01,North,JPY,1200,300\n"
             "B,2026-02,East,USD,20.10,0.10\n", [["JPY", 900], ["USD", 20]]),
            ("Board KPI", "Region's Detail", 5, 8, "Refund,CCY,Territory,Sales,Period,Order\n"
             "1,USD,North,9,2026-03,C\n25,JPY,South,225,2026-04,D\n", [["JPY", 200], ["USD", 8]]),
        )
        for summary, detail, summary_row, detail_row, csv_text, expected in fixtures:
            with self.subTest(layout=summary), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                base = root / "template.xlsx"
                previous = set(win32process.EnumProcesses())
                app = DispatchEx("Excel.Application")
                self.assertNotIn(win32process.GetWindowThreadProcessId(app.Hwnd)[1], previous)
                book = None
                try:
                    book = app.Workbooks.Add(-4167)
                    dashboard = book.Worksheets.Item(1)
                    dashboard.Name = summary
                    dashboard.Range("A%d:B%d" % (summary_row, summary_row)).Value2 = (("Currency", "Net"),)
                    sheet = book.Worksheets.Add()
                    sheet.Name = detail
                    sheet.Range("G%d" % detail_row).Value2 = "Net"
                    sheet.Range("G%d" % (detail_row + 1)).Formula = "=E%d-F%d" % (detail_row + 1, detail_row + 1)
                    sheet.Range("J1").Value2 = "Template metadata"
                    hidden = book.Worksheets.Add()
                    hidden.Name = "Internal"
                    hidden.Range("A1").Value2 = "Ignore this"
                    hidden.Visible = 0
                    sheet = dashboard = hidden = None
                    book.SaveAs(str(base), 51)
                finally:
                    if book is not None:
                        book.Close(False)
                    app.Quit()
                original = base.read_bytes()
                evidence = {part["name"]: part for part in scan_sample(base)["parts"]}
                self.assertIn({"cell": "B%d" % summary_row, "text": "Net"}, evidence[summary]["text_cells"])
                self.assertEqual(evidence[detail]["formulas"][0]["cell"], "G%d" % (detail_row + 1))
                self.assertEqual(evidence["Internal"]["visibility"], "hidden")
                self.assertNotIn("text_cells", evidence["Internal"])
                input_file = root / "variant.csv"
                input_file.write_text(csv_text, encoding="utf-8")
                spec = dict(confirmed, output_sheets={"summary": summary, "detail": detail},
                            header_rows={"summary": summary_row, "detail": detail_row})
                ops = root / "ops.json"
                ops.write_text(json.dumps(workbook_ops(spec, [input_file])), encoding="utf-8")
                code, preview = invoke("plan", base, "--ops", ops)
                self.assertEqual(code, 0, preview)
                out = root / "Published.xlsx"
                code, report = invoke("apply", "--plan", preview["plan"], "--output", out)
                self.assertEqual(code, 0, report)
                code, observed = invoke("read", out, "--sheet", summary, "--range",
                                        "A%d:B%d" % (summary_row + 1, summary_row + 2))
                self.assertEqual(code, 0, observed)
                self.assertEqual(observed["range"]["values"], expected)
                code, sentinel = invoke("read", out, "--sheet", detail, "--range", "J1")
                self.assertEqual(code, 0, sentinel)
                self.assertEqual(sentinel["range"]["values"], [["Template metadata"]])
                self.assertEqual(base.read_bytes(), original)

    def test_reconcile_multiple_months_regions_and_currencies(self):
        confirmed = {"rule": "net_equals_gross_minus_returns", "currencies": ["JPY", "USD"],
                     "columns": {"id": ["Order"], "month": ["Period"], "region": ["Territory"],
                                 "currency": ["CCY"], "gross": ["Sales"], "returns": ["Refund"]}}
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            first, second = root / "first.csv", root / "second.csv"
            first.write_text("Order,Period,Territory,CCY,Sales,Refund\nA,2026-01,North,JPY,1200,300\n"
                             "B,2026-02,East,USD,20.10,0.10\n", encoding="utf-8")
            second.write_text("returns,currency,region,month,gross,id\n1,USD,East,2026-02,9,C\n",
                              encoding="utf-8")
            result = reconcile(confirmed, [first, second])
            self.assertEqual(result["net_by_currency"], {"JPY": "900", "USD": "28.00"})
            self.assertEqual([group["rows"] for group in result["groups"]], [1, 2])
            self.assertEqual([source["rows"] for source in result["sources"]], [2, 1])
            second.write_text("returns,currency,region,month,gross,id\n1,USD,East,2026-02,9,A\n",
                              encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "duplicate input ID"):
                reconcile(confirmed, [first, second])

    def test_reordered_aliases_new_region_and_month(self):
        layouts = [
            {"sample": "Management.xlsx", "deliverables": ["Summary", "Trend"],
             "metrics": {"Revenue": {"rule": "sum(amount) by month and region"}},
             "fields": {"region": ["Area"], "amount": ["Revenue value"], "month": ["Period"]}},
            {"sample": "Board.pptx", "deliverables": ["Highlights", "Regional split"],
             "metrics": {"Revenue": {"rule": "sum(amount) by month and region"}},
             "fields": {"region": ["Territory"], "amount": ["Sales"], "month": ["Month"]}},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "variant.csv"
            path.write_text("Period,Sales,Territory\n2026-10,20.10,East\n2026-11,9.90,East\n2026-11,4.50,North\n",
                            encoding="utf-8")
            report = profile(layouts, [path])
            self.assertEqual(report["questions"], [])
            self.assertEqual(report["inputs"][0]["raw_amount_by_region"], {"East": "30.00", "North": "4.50"})
            self.assertEqual(len(report["expected_outputs"]), 2)

    def test_missing_currency_conflicting_kpi_and_ambiguous_amount(self):
        report_one = {"sample": "A", "deliverables": ["KPI"], "metrics": {"Revenue": {"rule": "gross"}},
                      "fields": {"currency": [], "amount": ["Sales", "Net"], "region": []}}
        report_two = dict(report_one, sample="B", metrics={"Revenue": {"rule": "net"}})
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ambiguous.csv"
            path.write_text("Region,Sales,Net\nEast,40,30\n", encoding="utf-8")
            questions = profile([report_one, report_two], [path])["questions"]
            self.assertEqual({q["kind"] for q in questions},
                             {"conflicting_definition", "missing_column", "ambiguous_column"})
            path.write_text("Region,Sales,Currency\nEast,40,\n", encoding="utf-8")
            result = profile([report_one], [path])
            self.assertEqual(result["status"], "needs-input")
            self.assertEqual(result["questions"], [
                {"kind": "missing_values", "field": "currency", "file": str(path), "rows": 1}
            ])
