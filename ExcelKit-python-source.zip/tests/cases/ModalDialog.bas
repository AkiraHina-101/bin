Attribute VB_Name = "ModalDialog"
Option Explicit

Public Function Smoke() As String
    MsgBox "Intentional modal timeout", vbOKOnly, "Excel AI Kit Test"
    Smoke = "PASS"
End Function
