Attribute VB_Name = "RuntimeFailure"
Option Explicit

Public Function Smoke() As String
    On Error GoTo Failed
10  Err.Raise 5, "RuntimeFailure.Smoke", "Intentional test error"
    Exit Function
Failed:
    Smoke = "FAIL | " & Err.Number & " | " & Err.Source & " | line " & Erl & " | " & Err.Description
End Function
