Attribute VB_Name = "CompileFailure"
Option Explicit

Public Function Smoke() As String
    unknownVariable = 42
    Smoke = "PASS"
End Function
