"""Prepare disposable Office fixtures for a paired agent evaluation."""

import argparse
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

from tools.excel_task import Task, digest, write_json


ROOT = Path(__file__).resolve().parents[1]
TASK_ID = "trial-resume"
LATEST = "Check that Report!B2 in Result.xlsx equals 42, then deliver the exported copy."


def sample_report(app, path, summary, detail, summary_row, detail_row, net):
    book = app.Workbooks.Add(-4167)
    try:
        overview = book.Worksheets.Item(1)
        overview.Name = summary
        lines = book.Worksheets.Add()
        lines.Name = detail
        overview.Range(f"A{summary_row}:B{summary_row}").Value2 = (("Currency", "Net"),)
        prior_rows = (
            ("Month", "Region", "Currency", "Orders", "Gross", "Returns", "Net"),
            ("2026-03", "East", "USD", 1, 100, 20, None),
            ("2026-03", "North", "USD", 1, 60, 5, None),
            ("2026-03", "South", "USD", 1, 50, 8, None),
            ("2026-03", "West", "USD", 1, 30, 7, None),
            ("2026-03", "Central", "USD", 1, 20, 2, None),
        )
        first, last = detail_row + 1, detail_row + len(prior_rows) - 1
        lines.Range(f"A{detail_row}:G{last}").Value2 = prior_rows
        for row in range(first, last + 1):
            lines.Range(f"G{row}").Formula = f"=E{row}-F{row}" if net else f"=E{row}"
        overview.Range(f"A{summary_row + 1}").Value2 = "USD"
        overview.Range(f"B{summary_row + 1}").Formula = f"=SUM('{detail}'!G{first}:G{last})"
        book.SaveAs(str(path), 51)
    finally:
        book.Close(False)


def recovery_workbook(app, path):
    book = app.Workbooks.Add(-4167)
    try:
        sheet = book.Worksheets.Item(1)
        sheet.Name = "Report"
        sheet.Range("B2").Value2 = 42
        book.SaveAs(str(path), 51)
    finally:
        book.Close(False)


def seed_checkpoint(folder, output):
    shutil.copy2(ROOT / "ExcelKit.py", folder)
    tools = folder / "tools"
    tools.mkdir()
    for file in (ROOT / "tools").glob("excel_*.py"):
        shutil.copy2(file, tools / file.name)
    run = folder / "runs" / "interrupted-publish"
    run.mkdir(parents=True)
    task = Task(folder, TASK_ID)
    task.start("Build the report on a copy.", "Export the workbook.")
    with task.lock():
        task.begin("publish", "Export Result.xlsx and reconcile the figures.", run)
    write_json(run / "publication.json", {"path": str(output), "sha256": digest(output)})
    task.update(LATEST)


def prepare(folder):
    import win32process
    from win32com.client import DispatchEx
    from tests.test_vba_patch import create_fixture

    folder.mkdir(parents=True, exist_ok=False)
    vba, report, recovery = (folder / name for name in ("vba", "report", "recovery"))
    for path in (vba, report, recovery):
        path.mkdir()
    # The fixture builder also writes an intermediate XLSM. Keep one source in the case folder.
    with TemporaryDirectory(dir=folder) as scratch:
        ready = create_fixture(Path(scratch))
        source = vba / ready.name
        shutil.copy2(ready, source)
    previous = set(win32process.EnumProcesses())
    app = DispatchEx("Excel.Application")
    if win32process.GetWindowThreadProcessId(app.Hwnd)[1] in previous:
        raise RuntimeError("Fixture did not get a new Excel session.")
    result = recovery / "Result.xlsx"
    try:
        sample_report(app, report / "Management.xlsx", "Summary", "Detail", 1, 1, net=True)
        sample_report(app, report / "Board.xlsx", "Board KPI", "Regional Detail", 5, 8, net=False)
        recovery_workbook(app, result)
    finally:
        app.Quit()

    (report / "Apr-a.csv").write_text(
        "id,month,region,currency,gross,returns\nA,2026-04,North,USD,20.10,0.10\n"
        "B,2026-04,West,JPY,1200,300\n", encoding="utf-8"
    )
    (report / "Apr-b.csv").write_text(
        "Refund,CCY,Territory,Sales,Period,Order\n1,USD,North,9,2026-04,C\n"
        "25,JPY,South,225,2026-04,D\n", encoding="utf-8"
    )
    seed_checkpoint(recovery, result)
    # This manifest belongs to the evaluator, outside the supplied case folders.
    write_json(folder / "fixture-hashes.json", {
        path.relative_to(folder).as_posix(): digest(path)
        for path in (source, *sorted(report.iterdir()), result)
    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="A new disposable directory")
    args = parser.parse_args()
    prepare(args.output.resolve())
    print(args.output.resolve())
