"""Fresh-process recovery tests for the ExcelKit task protocol."""

import json
from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile
from time import monotonic, sleep
import unittest
from unittest.mock import patch

from tools.excel_task import digest, Task, write_json


ROOT = Path(__file__).resolve().parents[1]


class TaskRecovery(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory()
        self.addCleanup(self.scratch.cleanup)
        self.root = Path(self.scratch.name)
        shutil.copy2(ROOT / "ExcelKit.py", self.root)
        shutil.copytree(ROOT / "tools", self.root / "tools", ignore=shutil.ignore_patterns("__pycache__"))
        self.task = Task(self.root, "excel-027")

    def cli(self, *args, code=0):
        result = subprocess.run([sys.executable, str(self.root / "ExcelKit.py"), *args],
                                capture_output=True, text=True, timeout=50)
        self.assertEqual(result.returncode, code, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def init(self):
        return self.cli("task", "start", "excel-027", "--request", "Fix the report.",
                        "--next", "Inspect workbook and reproduce.")

    def test_interruption_and_compaction_with_fresh_context(self):
        self.init()
        flags = ("--task-id", "excel-027", "--step", "map", "--intent", "Inspect supported operations.")
        receipt = self.cli(*flags, "operations")
        checkpoint = self.cli("task", "resume", "excel-027")
        self.assertEqual(checkpoint["outcome"]["status"], "PASS")
        self.assertTrue(Path(checkpoint["outcome"]["evidence"]).is_file())
        self.cli(*flags, "operations", code=1)
        self.cli("task", "update", "excel-027", "--request", "Fix the report; keep VBA intact.")
        self.assertEqual(len(list(self.task.directory.glob("request-*.json"))), 1)
        checkpoint = self.cli("task", "resume", "excel-027")
        self.assertTrue(checkpoint["summary_outdated"])
        self.cli("task", "resolve", "excel-027", "map", "--complete", code=1)
        summary = self.root / "brief.json"
        write_json(summary, {"objective": "Repair report", "constraints": "Keep VBA intact",
                             "completed": "Operation catalog read", "next": "Inspect the workbook"})
        checkpoint = self.cli("task", "resume", "excel-027")
        for _ in range(3):
            revision = str(checkpoint["revision"])
            checkpoint = self.cli("task", "compact", "excel-027", "--summary", str(summary),
                                  "--revision", revision)
            self.cli("task", "compact", "excel-027", "--summary", str(summary), "--revision", revision, code=1)
            self.assertEqual(checkpoint["pending"]["step"], "map")
            self.assertEqual(checkpoint["outcome"]["evidence"], str(Path(receipt["run"]) / "result.json"))
            self.assertEqual(checkpoint["request"], "Fix the report; keep VBA intact.")
            self.assertFalse(checkpoint["summary_outdated"])
        self.cli("task", "resolve", "excel-027", "map", "--next", "Inspect workbook")
        self.assertTrue((self.task.directory / "steps" / "map.json").is_file())
        self.cli(*flags, "operations", code=1)

    def test_publication_survives_loss_of_final_receipt(self):
        self.init()
        run = self.root / "runs" / "fixture"
        run.mkdir(parents=True)
        output = self.root / "report.xlsx"
        output.write_bytes(b"unique output fixture")
        write_json(run / "publication.json", {"path": str(output), "sha256": digest(output)})
        with self.task.lock():
            self.task.begin("publish", "Export verified report.", run)
        checkpoint = self.cli("task", "resume", "excel-027")
        self.assertEqual(checkpoint["outcome"]["state"], "published_unlogged")
        output.write_bytes(b"different output")
        self.assertEqual(self.cli("task", "resume", "excel-027")["outcome"]["state"], "output_mismatch")
        self.cli("task", "resolve", "excel-027", "publish", "--complete", code=1)

    def test_untracked_action_needs_evidence(self):
        self.init()
        self.cli("task", "begin", "excel-027", "vbe", "--description", "Edit worksheet event.")
        checkpoint = self.cli("task", "resume", "excel-027")
        self.assertEqual(checkpoint["outcome"]["state"], "unconfirmed")
        self.cli("task", "resolve", "excel-027", "vbe", "--complete", code=1)
        done = self.cli("task", "resolve", "excel-027", "vbe", "--complete",
                        "--evidence", "Opened test workbook and checked event output B2=42.")
        self.assertEqual(done["status"], "done")

    def test_status_write_retries_if_a_reader_blocks_replacement(self):
        target = self.root / "state.json"
        write_json(target, {"stage": "first"}, durable=False)
        replace = os.replace
        blocked = []
        with target.open("rb") as reader:
            def replace_while_reading(source, dest):
                try:
                    replace(source, dest)
                except PermissionError as error:
                    blocked.append(error.winerror)
                    reader.close()
                    raise

            with patch("tools.excel_task.os.replace", side_effect=replace_while_reading):
                write_json(target, {"stage": "next"}, durable=False)
        self.assertEqual(len(blocked), 1)
        self.assertEqual(json.loads(target.read_text()), {"stage": "next"})
        self.assertFalse(list(self.root.glob("state.json.*.tmp")))

    @unittest.skipUnless(os.environ.get("EXCELKIT_STOP_TEST"), "Optional Excel publication recovery")
    def test_excel_workflow_recovers_in_fresh_process(self):
        from tests.test_excel_objects import blank, step, write_ops

        self.init()
        source = self.root / "source.xlsx"
        output = self.root / "result.xlsx"
        ops = self.root / "ops.json"
        blank(source)
        original = digest(source)
        write_ops(ops, [
            step("write", "range.values", sheet="Input", range="A1", values=[[42]]),
            step("check", "assert.range", sheet="Input", range="A1", values=[[42]]),
        ])
        preview = self.cli("--task-id", "excel-027", "--step", "plan", "--intent",
                           "Preview A1=42", "plan", str(source), "--ops", str(ops))
        self.cli("task", "resolve", "excel-027", "plan", "--next", "Publish a verified copy.")
        applied = self.cli("--task-id", "excel-027", "--step", "apply", "--intent",
                           "Publish a verified workbook with A1=42", "apply", "--plan",
                           preview["plan"], "--output", str(output))
        run = Path(applied["run"])
        # Simulate losing the final report after publication. Keep a copy for diagnosis.
        (run / "result.json").rename(run / "fixture-hidden-result.json")
        checkpoint = self.cli("task", "resume", "excel-027")
        self.assertEqual(checkpoint["outcome"]["state"], "published_unlogged")
        self.assertEqual(checkpoint["outcome"]["output"], str(output))
        result = self.cli("read", str(output), "--sheet", "Input", "--range", "A1")
        self.assertEqual(result["range"]["values"], [[42]])
        done = self.cli("task", "resolve", "excel-027", "apply", "--complete")
        self.assertEqual(done["status"], "done")
        self.assertEqual(digest(source), original)

    @unittest.skipUnless(os.environ.get("EXCELKIT_STOP_TEST"), "Optional hard stop in desktop Excel")
    def test_hard_stop_owns_only_disposable_excel(self):
        import win32api
        import win32event
        import win32process
        from win32com.client import DispatchEx

        self.init()
        original = DispatchEx("Excel.Application")
        book = original.Workbooks.Add(-4167)
        try:
            book.Worksheets.Item(1).Range("A1").Value2 = "unsaved sentinel"
            cases = self.root / "cases"
            cases.mkdir()
            shutil.copy2(ROOT / "tests/cases/ModalDialog.bas", cases)
            verb = [sys.executable, str(self.root / "ExcelKit.py"), "--task-id", "excel-027",
                    "--step", "modal", "--intent", "Run a modal test.", "test",
                    "--source", str(ROOT / "vba"), "--tests", str(cases), "--entry", "ModalDialog.Smoke"]
            with subprocess.Popen(verb, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as job:
                deadline = monotonic() + 25
                handle = None
                try:
                    while monotonic() < deadline and job.poll() is None:
                        task = json.loads(self.task.path.read_text(encoding="utf-8"))
                        state_file = Path(task["pending"]["run"]) / "state.json" if task["pending"] else None
                        if state_file and state_file.is_file():
                            state = json.loads(state_file.read_text(encoding="utf-8"))
                            if state["stage"].startswith("runtime/"):
                                self.assertNotEqual(state["excel_pid"], win32process.GetWindowThreadProcessId(original.Hwnd)[1])
                                handle = win32api.OpenProcess(0x00100000, False, state["excel_pid"])
                                break
                        sleep(0.05)
                    details = job.communicate(timeout=1)[0] if job.poll() is not None else ""
                    self.assertIsNotNone(handle, "Test did not reach the modal call. " + details)
                    job.kill()
                    job.wait(timeout=5)
                    self.assertEqual(win32event.WaitForSingleObject(handle, 5000), win32event.WAIT_OBJECT_0)
                finally:
                    if handle:
                        handle.Close()
                    if job.poll() is None:
                        job.kill()
            checkpoint = self.cli("task", "resume", "excel-027")
            self.assertEqual(checkpoint["outcome"]["state"], "unconfirmed")
            self.assertFalse(book.Saved)
            self.assertEqual(book.Worksheets.Item(1).Range("A1").Value2, "unsaved sentinel")
        finally:
            book.Close(False)
            original.Quit()
