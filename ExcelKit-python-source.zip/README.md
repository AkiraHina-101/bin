# Excel AI Kit

**Delegating work to an AI:** Open [Starting an Office task](docs/getting-started.md) to choose a workflow. Use [Project lessons](docs/project-lessons.md) when you meet an object type or error that has been checked before.

**For company machines:** [workflow and delegation prompts](docs/company-machine.md) · [Excel COM, VBA, UserForm and RibbonX reference](docs/excel-python-reference.md). Use the standalone Markdown guides, or use the runner where the company allows it.

**Workbook that is already open:** Direct editing is an option reserved for requests that explicitly ask to change the open workbook. The default workflow uses a copy or a separate Excel session. If you add a direct-edit command, identify the workbook by full path and the specific sheet or object, show a preview of the change, and let the user save. The current runner uses a separate session.

**Excel object example:** [Aligning a rectangle to a vertical series on an XY Scatter chart](docs/chart-shape.md), with VBA code and a smoke test that runs in Excel.

**Working with complex workbooks:** [Object catalog, sample JSON and how to verify](docs/object-operations.md) · [Test workbooks and results](docs/acceptance.md).

**Continuing when context is lost:** [Checkpoints, resume prompts and compacting outside the chat](docs/resume-after-stop.md). The workflow has a Markdown-only variant and a variant that uses the `task` command.

**Patching VBA in an existing XLSM:** [Previewing a diff, applying a patch and re-checking the report](docs/vba-patch.md). [Office acceptance evidence](docs/office-evidence.md) records the cases that were checked and how to rerun them.

**PowerPoint VBA:** [Creating a PPTM, building a PPAM, RibbonX and testing](docs/powerpoint-vba.md). **Reports:** [Workflow for reading a sample, asking for input and reconciling the output](docs/report-from-sample.md).

## Python 3.8.10 + pywin32 runner

Run it from the kit folder in a signed-in Windows session. Use the `pywin32` build that IT provides. The runner needs no PowerShell and no other Python package.

```text
python ExcelKit.py operations
python ExcelKit.py inventory "Source.xlsx"
python ExcelKit.py plan "Source.xlsx" --ops ops.json
python ExcelKit.py apply --plan "<plan.json from the previous result>" --output "Result.xlsx"
```

```text
python ExcelKit.py doctor
python ExcelKit.py inspect "SPL_Tool_v3.xlsm" --verify-crc
python ExcelKit.py test
python ExcelKit.py build
```

| Command | Result |
| --- | --- |
| `doctor` | Checks pywin32, Excel COM and VBProject access on a blank workbook |
| `inspect <file> [--verify-crc]` | Inspects an Excel OOXML package. Reports VBA, signs of XLM, RibbonX and package signatures. Uses only the standard library and does not start Excel |
| `read <file> --sheet <name> --range A1:D20` | Reads `Value2` and formulas from one given range, up to 10,000 cells. The data is stored in the run's JSON |
| `export <file>` | Exports the modules, UserForms and document modules of a read-only copy. A `.document.cls` name marks code attached to a workbook or sheet |
| `test [--source <dir>] [--tests <dir>] [--entry Module.Smoke] [--expect <json>]` | Imports components into a blank workbook, compiles and runs the test. Use `--workbook <xlsm> --documents <dir> --events` to try document modules and events on a copy |
| `run <test-workbook> Module.Smoke --trusted-test [--expect <json>]` | Runs an existing test function on a read-only copy under the macro policy. Use `--events` if the case needs workbook events |
| `build [--source <dir>] [--ribbon <xml>] [--entry Kit_SelfTest] [--output <file.xlam>]` | Creates and verifies the RibbonX package, reopens the add-in in Excel, runs the self-test and then publishes. By default it creates `output/ExcelAIKit.xlam` (the `dist/` folder is for the kit only) |

For `test` and `run`, the entry point is a parameterless VBA function that returns exactly the string `PASS`. The `--expect` file, if given, lists the ranges to compare. For example, when the macro writes `42` to cell `Result!A1`:

```json
[
  {"sheet": "Result", "range": "A1", "values": [[42]]}
]
```

Use a two-dimensional array even for a single cell. Values are compared exactly against `Value2`. For calculations that need a tolerance, check the tolerance inside the VBA test function. Cell errors read through COM can appear as negative HRESULT numbers. See the data and formulas section of the [COM reference](docs/excel-python-reference.md).

Each run saves its result to `runs/python-<id>/result.json`. Exit code `0` means pass, `1` means failure or cancellation, and `124` means timeout. Use `python ExcelKit.py --timeout 45 test` to change the limit. On a timeout, the runner records the stage and any readable Windows dialog text. The supervisor holds the handle of the new Excel session from the moment it starts and uses only that handle to stop the session when needed. Run `python -m unittest discover -s tests -p "test_*.py" -v` to accept the kit on the target Office version.

**Test scope.** `read` and `export` open the file with VBA macros disabled, events off and workbook links not updated. `run` is meant for copies and trusted macros. A macro can still write files outside the workbook with the permissions of the running account. `test` on a blank workbook does not cover the sheets, events and references specific to the SPL file. If you need to test `Workbook_Open`, sheet events, UserForm interaction or Ribbon callbacks, try that flow in Excel on an approved copy. Compile calls VBE command `578`, which was confirmed on Excel 16.0 build 20527. If that command is missing on the target Office version, use Debug → Compile manually and then `--skip-compile` to run the runtime test.

The build machine needs access to the VBA project granted through the Trust Center and a policy that allows the sample macro to run. Use `test` and `build` only with trusted VBA code, because macros run with the permissions of the current Windows account. Each run folder contains `state.json`, the sample workbook (for `test`) or the exported code (for `export`). Exported files may contain internal code. The three deliberate failure cases (compile, runtime and modal dialog) are in `tests/cases/` and are used by the `unittest` suite.

## Delegating to an AI where the runner is allowed

Copy the request below, together with the kit, into a working folder you are allowed to use.

> Read the README of Excel AI Kit. Run `python ExcelKit.py doctor`. If you are allowed to read the workbook's VBA, get an export with `export` and edit a working copy. For each defect, record the reproduction steps, the input, the expected result and the actual result. When a test fails, read `stage`, `message`, `macro_result` and `dialogs` in result.json, then fix the cause at the right stage. Rerun the reproduction case after every change. Report the files you changed and the final test evidence.

Put sample modules in `vba/` and tests in `tests/vba/`. You can pass your own folders and the test entry point.

```text
python ExcelKit.py --timeout 60 test --source vba --tests tests\vba --entry KitTests.Smoke
```

The entry point is a parameterless `Public Function`. It returns exactly the string `PASS` after it has checked the output. On failure, record `Err.Number`, `Err.Source`, `Err.Description` and `Erl` if the lines are numbered. `KitTests.bas` has an example with a workbook and a UserForm. When a failure shows up in `dialogs`, keep its text unchanged when you report it. After a timeout, the runner stops only the test Excel session whose PID and start time it verified.

`test` builds the project on a blank workbook. Modules attached to `ThisWorkbook` or to a sheet are exported with the `.document.cls` suffix. Put the edited code back into the right document module in a copy of the workbook, and test with the real sheets, references and events at the integration step.

### UserForm

Create or adjust the layout in the VBE Designer, then export the form. Keep the `.frm` and `.frx` files in the same folder. The runner checks that the `.frx` file referenced in the `.frm` exists before importing. The sample smoke test loads the form in Excel and confirms the Caption and one control. For a business form, keep the data handling in a module that can be called on its own, then also test Enter/Esc, cancel and the other ways of closing on the real form.

### Ribbon and add-in

Edit `ribbon/customUI.xml` and the VBA callbacks in `vba/`. Each sample button calls a `Public Sub` that takes an `Office.IRibbonControl` parameter. For your own code, use `python ExcelKit.py build --source <dir> --ribbon <xml> --entry <PublicFunction> --output <file.xlam>`. The callback gets the target workbook from `Application.ActiveWorkbook` when the button is clicked.

Install through **File → Options → Add-ins → Manage Excel Add-ins → Go → Browse**, following the IT process. The **Excel AI Kit** tab has **Run Self-Test**, **Stamp Date/Time**, **Autofit Columns**, **Freeze Top Row** and **About**. The buttons write their results to the Excel status bar.

### Diagnosing failures

| Sign | Next step |
| --- | --- |
| `vbproject` | Check the Trust access to the VBA project object model permission and whether the project is locked |
| `import/<file>` | Check `Attribute VB_Name`, duplicate names and form file pairs. Keep the encoding of files exported by the VBE |
| `references` | Check for a `MISSING` reference in Tools → References and compare against the right Excel environment |
| `vbe-compile` | Open `Smoke.xlsm` in the test run folder, go to the VBE and choose Debug → Compile. Automatic compile uses command ID `578`, tried on Excel 16.0 build 20527. If another Office version does not provide that command, run Compile manually and use `--skip-compile` for the runtime test |
| `runtime/<macro>` | Read the error code, line, message or dialog recorded in the JSON. Rerun exactly the same test after fixing |
| `reopen-xlam` or a blocked macro | Check the macro policy and how the file is distributed with IT |

The builder does basic checks on the XML, duplicate IDs and the existence of the `onAction` callbacks. When you add a new control type, compare it against the matching callback signature and click the button on the Ribbon. See the [VBA and RibbonX research](docs/research.md) for Microsoft sources and the acceptance checklist for company machines.
