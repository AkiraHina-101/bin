# Read-only geometry, connectivity, and edge-side queries for Advanced Select.
namespace eval ::AdvancedSelect {
    variable corners {103 3 104 4 106 3 108 4 204 4 205 5 206 6 208 8 210 4 213 5 215 6 220 8}
    variable solids {
        4 {{0 1 2} {0 1 3} {0 2 3} {1 2 3}}
        5 {{0 1 2 3} {0 1 4} {1 2 4} {2 3 4} {3 0 4}}
        6 {{0 1 2} {3 4 5} {0 1 4 3} {1 2 5 4} {2 0 3 5}}
        8 {{0 1 2 3} {4 5 6 7} {0 1 5 4} {1 2 6 5} {2 3 7 6} {3 0 4 7}}
    }
    variable filterConfigs {Tria3 103 Tria6 106 Quad4 104 Quad8 108 Tet4 204 Tet10 210}
    variable lineCfg {2 60 61}
    variable shellCfg {103 104 106 108}
}

proc ::AdvancedSelect::sub {a b} {
    set out {}
    foreach x $a y $b {lappend out [expr {$x-$y}]}
    return $out
}
proc ::AdvancedSelect::add {a b} {
    set out {}
    foreach x $a y $b {lappend out [expr {$x+$y}]}
    return $out
}
proc ::AdvancedSelect::scale {a s} {
    set out {}
    foreach x $a {lappend out [expr {$x*$s}]}
    return $out
}
proc ::AdvancedSelect::dot {a b} {
    lassign $a ax ay az
    lassign $b bx by bz
    expr {$ax*$bx+$ay*$by+$az*$bz}
}
proc ::AdvancedSelect::cross {a b} {
    lassign $a x y z
    lassign $b u v w
    list [expr {$y*$w-$z*$v}] [expr {$z*$u-$x*$w}] [expr {$x*$v-$y*$u}]
}
proc ::AdvancedSelect::unit {v} {
    set length [expr {sqrt([dot $v $v])}]
    if {$length == 0} {error "Pick a non-collinear boundary."}
    set out {}
    foreach value $v {lappend out [expr {$value/$length}]}
    return $out
}
proc ::AdvancedSelect::unit0 {v} {
    set length [expr {sqrt([dot $v $v])}]
    if {$length <= 0} {return {0 0 0}}
    scale $v [expr {1.0/$length}]
}
proc ::AdvancedSelect::edge_key {a b} {expr {$a < $b ? "$a $b" : "$b $a"}}
proc ::AdvancedSelect::ufind {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}

proc ::AdvancedSelect::center {points} {
    set sum {0.0 0.0 0.0}
    foreach p $points {
        set next {}
        foreach a $sum b $p {lappend next [expr {$a+$b}]}
        set sum $next
    }
    set result {}
    foreach coordinate $sum {lappend result [expr {$coordinate/[llength $points]}]}
    return $result
}

proc ::AdvancedSelect::coords {ids} {
    set result {}
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set chunk [lrange $ids $i [expr {$i+2047}]]
        foreach n $chunk x [hm_getvalue nodes user_ids=$chunk dataname=x] \
            y [hm_getvalue nodes user_ids=$chunk dataname=y] z [hm_getvalue nodes user_ids=$chunk dataname=z] {
            dict set result $n [list $x $y $z]
        }
    }
    return $result
}

proc ::AdvancedSelect::project {p frame} {
    lassign $frame origin u v n
    set delta [sub $p $origin]
    list [dot $delta $u] [dot $delta $v] [dot $delta $n]
}

proc ::AdvancedSelect::circle {points} {
    lassign $points a b c
    lassign $a ax ay
    lassign $b bx by
    lassign $c cx cy
    set x [expr {$bx-$ax}]; set y [expr {$by-$ay}]
    set u [expr {$cx-$ax}]; set v [expr {$cy-$ay}]
    set b2 [expr {$x*$x+$y*$y}]; set c2 [expr {$u*$u+$v*$v}]
    set d [expr {2.0*($x*$v-$y*$u)}]
    if {abs($d) <= 1e-12*max($b2,$c2)} {error "Pick three non-collinear nodes on each circle."}
    set dx [expr {($b2*$v-$c2*$y)/$d}]
    set dy [expr {($x*$c2-$u*$b2)/$d}]
    list [expr {$ax+$dx}] [expr {$ay+$dy}] [expr {sqrt($dx*$dx+$dy*$dy)}]
}

proc ::AdvancedSelect::shape {mode points} {
    set count [llength $points]
    if {($mode eq "polygon" && $count < 3) || ($mode eq "circle" && $count != 3) || \
            ($mode eq "annulus" && $count != 6)} {error "Pick the required number of boundary nodes."}
    set boundary $points
    if {$mode ne "polygon"} {set boundary [lrange $points 0 2]}
    set origin [center $boundary]
    set normal {0.0 0.0 0.0}
    set previous [lindex $boundary end]
    foreach p $boundary {
        set next {}
        foreach a $normal b [cross [sub $previous $origin] [sub $p $origin]] {lappend next [expr {$a+$b}]}
        set normal $next
        set previous $p
    }
    set n [unit $normal]
    set reference [expr {abs([lindex $n 0]) < 0.9 ? {1 0 0} : {0 1 0}}]
    set u [unit [cross $n $reference]]
    set frame [list $origin $u [cross $n $u] $n]
    set projected {}; set radius 0.0
    foreach p $points {
        lassign [project $p $frame] x y
        lappend projected [list $x $y]
        set radius [expr {max($radius,sqrt($x*$x+$y*$y))}]
    }
    set outer {}; set inner {}
    if {$mode ne "polygon"} {
        set outer [circle [lrange $projected 0 2]]
        lassign $outer x y radius
        if {$mode eq "annulus"} {
            set inner [circle [lrange $projected 3 5]]
            lassign $inner ix iy ir
            if {sqrt(($ix-$x)**2+($iy-$y)**2)+$ir > $radius*(1+1e-9)} {
                error "The inner circle must lie inside the outer circle."
            }
        }
    }
    list $frame $projected $outer $inner [expr {0.3*$radius}] [expr {1e-9*$radius}]
}

proc ::AdvancedSelect::in_polygon {x y polygon tol} {
    set inside 0
    set previous [lindex $polygon end]
    foreach point $polygon {
        lassign $previous a b
        lassign $point c d
        set dx [expr {$c-$a}]; set dy [expr {$d-$b}]
        if {abs($dx*($y-$b)-$dy*($x-$a)) <= $tol*sqrt($dx*$dx+$dy*$dy) &&
            $x >= min($a,$c)-$tol && $x <= max($a,$c)+$tol && $y >= min($b,$d)-$tol && $y <= max($b,$d)+$tol} {
            return 1
        }
        if {($b > $y) != ($d > $y) && $x < $a+($y-$b)*$dx/$dy} {set inside [expr {!$inside}]}
        set previous $point
    }
    return $inside
}

proc ::AdvancedSelect::in_shape {point region} {
    lassign $region frame polygon outer inner depth tol
    lassign [project $point $frame] x y z
    if {abs($z) > $depth} {return 0}
    if {$outer eq {}} {return [in_polygon $x $y $polygon $tol]}
    lassign $outer a b r
    if {($x-$a)**2+($y-$b)**2 > ($r+$tol)**2} {return 0}
    if {$inner eq {}} {return 1}
    lassign $inner a b r
    expr {($x-$a)**2+($y-$b)**2 >= max(0,$r-$tol)**2}
}

proc ::AdvancedSelect::marked {entity slot args} {
    *createmark $entity $slot {*}$args
    set ids [hm_getmark $entity $slot]
    *clearmark $entity $slot
    return $ids
}

proc ::AdvancedSelect::existing {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 "by id only" {*}$ids
    set out [hm_getmark elems 1]
    *clearmark elems 1
    return $out
}

proc ::AdvancedSelect::by_region {mode nodes} {
    variable corners
    if {[llength $nodes] != [llength [lsort -unique $nodes]]} {error "Pick distinct boundary nodes."}
    set positions [coords $nodes]
    set points {}
    foreach node $nodes {lappend points [dict get $positions $node]}
    set region [shape $mode $points]
    set result {}
    set ids [marked elems 1 displayed]
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set chunk [lrange $ids $i [expr {$i+2047}]]
        set records {}; set nodeIds {}
        foreach e $chunk cfg [hm_getvalue elems user_ids=$chunk dataname=config] ns [hm_getvalue elems user_ids=$chunk dataname=nodes] {
            if {![dict exists $corners $cfg]} {continue}
            set ns [lrange $ns 0 [expr {[dict get $corners $cfg]-1}]]
            lappend records [list $e $ns]
            lappend nodeIds {*}$ns
        }
        set xyz [coords [lsort -integer -unique $nodeIds]]
        foreach record $records {
            lassign $record e ns
            set points {}
            foreach n $ns {lappend points [dict get $xyz $n]}
            if {[in_shape [center $points] $region]} {lappend result $e}
        }
    }
    return $result
}

# Match whole shell faces and exterior solid faces using their corner-node IDs.
proc ::AdvancedSelect::face_index {ids} {
    variable corners; variable solids
    set faces {}
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set chunk [lrange $ids $i [expr {$i+2047}]]
        foreach e $chunk comp [hm_getvalue elems user_ids=$chunk dataname=collector.id] \
            cfg [hm_getvalue elems user_ids=$chunk dataname=config] ns [hm_getvalue elems user_ids=$chunk dataname=nodes] {
            if {![dict exists $corners $cfg]} {continue}
            set count [dict get $corners $cfg]
            set solid [expr {$cfg >= 200}]
            if {!$solid} {
                set key [lsort -integer [lrange $ns 0 [expr {$count-1}]]]
                set groups [expr {[dict exists $faces $key $comp shell] ? [dict get $faces $key $comp shell] : {}}]
                dict set faces $key $comp shell [concat $groups $e]
                continue
            }
            foreach pattern [dict get $solids $count] {
                set values {}
                foreach index $pattern {lappend values [lindex $ns $index]}
                set key [lsort -integer $values]
                set groups [expr {[dict exists $faces $key $comp solid] ? [dict get $faces $key $comp solid] : {}}]
                dict set faces $key $comp solid [concat $groups $e]
            }
        }
    }
    return $faces
}

proc ::AdvancedSelect::face_owners {group} {
    set owners {}
    if {[dict exists $group shell]} {set owners [dict get $group shell]}
    if {[dict exists $group solid] && [llength [dict get $group solid]] == 1} {
        lappend owners {*}[dict get $group solid]
    }
    return $owners
}

proc ::AdvancedSelect::shared_elements {comps} {
    if {![llength $comps]} {return {}}
    set selected [marked elems 1 "by collector id" {*}$comps]
    set index [face_index $selected]
    set one [expr {[llength $comps] == 1}]
    if {$one} {
        set comp [lindex $comps 0]
        set rim {}
        dict for {face groups} $index {
            if {[llength [face_owners [dict get $groups $comp]]]} {
                foreach node $face {dict set rim $node 1}
            }
        }
        if {![dict size $rim]} {return {}}
        *createmark nodes 1 "by id only" {*}[dict keys $rim]
        *clearmark elems 2
        set code [catch {hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0; hm_getmark elems 2} near options]
        *clearmark nodes 1
        *clearmark elems 2
        if {$code} {return -options $options $near}
        set index [face_index [lsort -integer -unique [concat $selected $near]]]
    }
    set result {}
    dict for {key groups} $index {
        set participating 0; set matches {}
        if {[dict size $groups] < 2 || ($one && ![dict exists $groups $comp])} {continue}
        dict for {c group} $groups {
            set owners [face_owners $group]
            if {![llength $owners]} {continue}
            incr participating
            if {!$one || $c == $comp} {lappend matches {*}$owners}
        }
        if {$participating > 1} {lappend result {*}$matches}
    }
    lsort -integer -unique $result
}

proc ::AdvancedSelect::by_config {ids filter} {
    variable filterConfigs
    if {![llength $ids]} {return {}}
    set cfg [dict get $filterConfigs $filter]
    set result {}
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set chunk [lrange $ids $i [expr {$i+2047}]]
        foreach e $chunk type [hm_getvalue elems user_ids=$chunk dataname=config] {
            if {$type == $cfg} {lappend result $e}
        }
    }
    return $result
}

proc ::AdvancedSelect::expand {mode seed angle} {
    if {![llength $seed]} {return {}}
    set saved {}
    if {$mode eq "face"} {
        if {![string is double -strict $angle] || !($angle >= 0 && $angle <= 90)} {
            error "Enter a face angle from 0 to 90 degrees."
        }
        set saved [hm_getoption feature_angle]
    }
    set code [catch {
        if {$mode eq "face"} {*setoption feature_angle=$angle}
        *createmark elems 1 "by id only" {*}$seed
        hm_appendmark elems 1 advanced "by $mode"
        hm_getmark elems 1
    } result options]
    *clearmark elems 1
    if {$mode eq "face"} {*setoption feature_angle=$saved}
    if {$code} {return -options $options $result}
    return $result
}

# ---------------------------------------------------------------- Edge sides queries
proc ::AdvancedSelect::shell_corners {cfg nl} {lrange $nl 0 [expr {$cfg in {103 106} ? 2 : 3}]}

proc ::AdvancedSelect::line_edges {ids} {
    variable lineCfg
    set ids [existing $ids]
    if {![llength $ids]} {error "Select the line (plotels)."}
    set edges [dict create]
    foreach e $ids c [hm_getvalue elems user_ids=$ids dataname=config] nl [hm_getvalue elems user_ids=$ids dataname=nodes] {
        if {$c ni $lineCfg} {error "The line has element $e that is not a plotel, bar or rod (config $c)."}
        dict set edges [edge_key [lindex $nl 0] [lindex $nl 1]] 1
    }
    return $edges
}

proc ::AdvancedSelect::adjacent_shells {nodes} {
    variable shellCfg
    set cand {}; set cn [dict create]; set mids [dict create]
    if {![llength $nodes]} {return [list $cand $cn $mids]}
    *createmark nodes 1 {*}$nodes
    *clearmark elems 2
    hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
    set near [hm_getmark elems 2]
    *clearmark nodes 1; *clearmark elems 2
    if {[llength $near]} {
        foreach e $near c [hm_getvalue elems user_ids=$near dataname=config] nl [hm_getvalue elems user_ids=$near dataname=nodes] {
            if {$c ni $shellCfg} {continue}
            lappend cand $e
            set cs [shell_corners $c $nl]
            dict set cn $e $cs
            if {$c in {106 108}} {dict set mids $e [lrange $nl [llength $cs] [expr {2*[llength $cs]-1}]]}
        }
    }
    list $cand $cn $mids
}

proc ::AdvancedSelect::split_sides {lineIds} {
    set raw [line_edges $lineIds]
    set lnodes [dict create]
    dict for {k one} $raw {foreach n $k {dict set lnodes $n 1}}
    for {set pass 0} {$pass < 2} {incr pass} {
        lassign [adjacent_shells [dict keys $lnodes]] cand cn mids
        if {![llength $cand]} {error "No shell element uses a node of the line."}
        set byEdge [dict create]; set L [dict create]; set used [dict create]
        dict for {e nl} $cn {
            set k [llength $nl]
            set ms [expr {[dict exists $mids $e] ? [dict get $mids $e] : {}}]
            for {set i 0} {$i < $k} {incr i} {
                set a [lindex $nl $i]; set b [lindex $nl [expr {($i+1)%$k}]]
                set ek [edge_key $a $b]
                dict lappend byEdge $ek $e
                if {[dict exists $raw $ek]} {dict set L $ek 1; dict set used $ek 1; continue}
                set m [lindex $ms $i]
                if {$m eq ""} {continue}
                foreach h [list [edge_key $a $m] [edge_key $m $b]] {if {[dict exists $raw $h]} {dict set L $ek 1; dict set used $h 1}}
            }
        }
        set more 0
        dict for {k one} $L {foreach n $k {if {![dict exists $lnodes $n]} {dict set lnodes $n 1; set more 1}}}
        if {!$more} {break}
    }
    if {![dict size $L]} {error "The line does not follow the element edges (no element edge is covered by it)."}
    set missing 0
    dict for {k one} $raw {if {![dict exists $used $k]} {incr missing}}
    set deg [dict create]
    dict for {k one} $L {foreach n $k {dict incr deg $n}}
    set cut $L
    set ends {}
    dict for {n d} $deg {if {$d == 1} {lappend ends $n}}
    if {[llength $ends]} {
        set P [coords [lsort -unique -integer [concat {*}[dict values $cn]]]]
        set adj [dict create]
        dict for {k one} $L {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}
        foreach v $ends {
            set w [lindex [dict get $adj $v] 0]
            set d1 [unit0 [sub [dict get $P $v] [dict get $P $w]]]
            set dir $d1
            set u ""
            foreach x [dict get $adj $w] {if {$x != $v} {set u $x}}
            if {$u ne "" && [llength [dict get $adj $w]] == 2} {
                set d0 [unit0 [sub [dict get $P $w] [dict get $P $u]]]
                set ax [cross $d0 $d1]
                set sn [expr {sqrt([dot $ax $ax])}]
                if {$sn > 1e-9} {
                    set ax [scale $ax [expr {1.0/$sn}]]
                    set cs [dot $d0 $d1]
                    set dir [add [add [scale $d1 $cs] [scale [cross $ax $d1] $sn]] [scale $ax [expr {[dot $ax $d1]*(1-$cs)}]]]
                }
            }
            set best ""; set bd -2.0
            dict for {k els} $byEdge {
                if {$v ni $k || [dict exists $L $k]} {continue}
                set x [lindex $k [expr {[lindex $k 0] == $v}]]
                set d [dot [unit0 [sub [dict get $P $x] [dict get $P $v]]] $dir]
                if {$d > $bd} {set bd $d; set best $k}
            }
            if {$best ne ""} {dict set cut $best 1}
        }
    }
    foreach e $cand {set parent($e) $e}
    dict for {k els} $byEdge {
        if {[dict exists $cut $k] || [llength $els] < 2} {continue}
        set r0 [ufind [lindex $els 0]]
        foreach e [lrange $els 1 end] {set r [ufind $e]; if {$r ne $r0} {set parent($r) $r0}}
    }
    set groups [dict create]
    foreach e $cand {dict lappend groups [ufind $e] $e}
    set sides {}
    dict for {r els} $groups {lappend sides [list [llength $els] [lsort -integer $els]]}
    set out {}
    foreach s [lsort -integer -decreasing -index 0 $sides] {lappend out [lindex $s 1]}
    dict create sides $out closed [expr {![llength $ends]}] ends [llength $ends] missing $missing line [existing $lineIds] edges [dict size $L]
}

proc ::AdvancedSelect::split_band {bandIds} {
    variable shellCfg
    set band [existing $bandIds]
    if {![llength $band]} {error "Select the line (plotels) or a band of 2D elements."}
    set inBand [dict create]; set cnt [dict create]; set bnodes [dict create]
    foreach e $band c [hm_getvalue elems user_ids=$band dataname=config] nl [hm_getvalue elems user_ids=$band dataname=nodes] {
        if {$c ni $shellCfg} {error "Pick either line elements or 2D elements (element $e has config $c)."}
        dict set inBand $e 1
        foreach n $nl {dict set bnodes $n 1}
        set cs [shell_corners $c $nl]; set k [llength $cs]
        for {set i 0} {$i < $k} {incr i} {dict incr cnt [edge_key [lindex $cs $i] [lindex $cs [expr {($i+1)%$k}]]]}
    }
    set adj [dict create]
    dict for {k v} $cnt {if {$v == 1} {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}}
    set loops {}; set seen [dict create]
    dict for {n nb} $adj {
        if {[dict exists $seen $n]} {continue}
        set loop {}; set stack [list $n]; dict set seen $n 1
        while {[llength $stack]} {
            set x [lindex $stack end]; set stack [lrange $stack 0 end-1]; lappend loop $x
            foreach y [dict get $adj $x] {if {![dict exists $seen $y]} {dict set seen $y 1; lappend stack $y}}
        }
        lappend loops $loop
    }
    if {![llength $loops]} {error "The band has no free edge."}
    set sideOf [dict create]
    if {[llength $loops] >= 2} {
        set i 0; foreach L $loops {foreach n $L {dict set sideOf $n $i}; incr i}
        set nSides [llength $loops]; set closed 1
    } else {
        set L [lindex $loops 0]
        set order [list [lindex $L 0]]; set prev ""; set cur [lindex $L 0]
        while {1} {
            set nxt ""
            foreach y [dict get $adj $cur] {if {$y ne $prev && $y ni $order} {set nxt $y; break}}
            if {$nxt eq ""} {break}
            lappend order $nxt; set prev $cur; set cur $nxt
        }
        set P [coords $order]
        set best -1; set ia 0; set ib 0
        for {set i 0} {$i < [llength $order]} {incr i} {
            for {set j [expr {$i+1}]} {$j < [llength $order]} {incr j} {
                set diff [sub [dict get $P [lindex $order $i]] [dict get $P [lindex $order $j]]]
                set d [dot $diff $diff]
                if {$d > $best} {set best $d; set ia $i; set ib $j}
            }
        }
        for {set i 0} {$i < [llength $order]} {incr i} {
            if {$i == $ia || $i == $ib} {continue}
            dict set sideOf [lindex $order $i] [expr {$i > $ia && $i < $ib ? 0 : 1}]
        }
        set nSides 2; set closed 0
    }
    lassign [adjacent_shells [dict keys $bnodes]] cand cn mids
    set groups {}; for {set i 0} {$i < $nSides} {incr i} {lappend groups {}}
    set left 0
    foreach e $cand {
        if {[dict exists $inBand $e]} {continue}
        set who [dict create]
        foreach n [dict get $cn $e] {if {[dict exists $sideOf $n]} {dict set who [dict get $sideOf $n] 1}}
        if {[dict size $who] == 1} {
            set i [lindex [dict keys $who] 0]
            lset groups $i [concat [lindex $groups $i] $e]
        } elseif {[dict size $who] > 1} {incr left}
    }
    set sides {}
    foreach g $groups {if {[llength $g]} {lappend sides [list [llength $g] [lsort -integer $g]]}}
    set out {}
    foreach s [lsort -integer -decreasing -index 0 $sides] {lappend out [lindex $s 1]}
    dict create sides $out closed $closed ends [expr {$closed ? 0 : 2}] missing 0 line $band edges 0 band $band left $left
}

proc ::AdvancedSelect::split_any {ids} {
    variable lineCfg
    set ids [existing $ids]
    if {![llength $ids]} {error "Select the line (plotels) or a band of 2D elements."}
    set cfgs [lsort -unique [hm_getvalue elems user_ids=$ids dataname=config]]
    set allLine 1; foreach c $cfgs {if {$c ni $lineCfg} {set allLine 0}}
    if {$allLine} {
        set r [split_sides $ids]
        dict set r band {}
        dict set r left 0
        return $r
    }
    split_band $ids
}

proc ::AdvancedSelect::grow_sides {sides {blocked {}}} {
    variable shellCfg
    set owner [dict create]
    set i 0; foreach s $sides {foreach e $s {dict set owner $e $i}; incr i}
    foreach e $blocked {dict set owner $e -1}
    set claims [dict create]
    set i 0
    foreach s $sides {
        set nodes [dict create]
        for {set j 0} {$j < [llength $s]} {incr j 2048} {
            foreach nl [hm_getvalue elems user_ids=[lrange $s $j [expr {$j+2047}]] dataname=nodes] {foreach n $nl {dict set nodes $n 1}}
        }
        if {[dict size $nodes]} {
            *createmark nodes 1 {*}[dict keys $nodes]
            *clearmark elems 2
            hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0
            set near [hm_getmark elems 2]
            *clearmark nodes 1; *clearmark elems 2
            if {[llength $near]} {
                foreach e $near c [hm_getvalue elems user_ids=$near dataname=config] {
                    if {$c ni $shellCfg || [dict exists $owner $e]} {continue}
                    dict set claims $e $i 1
                }
            }
        }
        incr i
    }
    set out $sides; set added {}; foreach s $sides {lappend added 0}
    set contested 0
    dict for {e who} $claims {
        if {[dict size $who] != 1} {incr contested; lappend blocked $e; continue}
        set k [lindex [dict keys $who] 0]
        lset out $k [concat [lindex $out $k] $e]
        lset added $k [expr {[lindex $added $k]+1}]
    }
    set res {}; foreach s $out {lappend res [lsort -integer $s]}
    list $res $added $contested $blocked
}
