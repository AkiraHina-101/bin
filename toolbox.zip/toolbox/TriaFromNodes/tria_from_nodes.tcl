# Create element (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Pick nodes... opens an editable native node mark. The panel closes automatically when the mark
# reaches three nodes. After creation it opens again with the nodes whose shell fans are still open.
# Order 1 makes tria3, Order 2 tria6 (native *orderchangetosecond, which reuses the midside node of an
# edge shared with a second order neighbour). Each tria is one Undo step "Create element", in the current
# component (none current: the component of the shells around the picked nodes is made current).
# Orientation: the edge shared with an existing shell runs the
# other way, so normals stay consistent; with no neighbour the pick order sets the normal.
# Entry point for the menu: *evaltclscript tria_from_nodes.tcl 0. Set ::TriaFromNodes_no_gui to load
# the procedures without opening the window (tests, or Mesh edit, which shows the controls in its own
# window: embed).

if {![llength [info commands ::TestToolSession::run]]} {
    source [file join [file dirname [file dirname [file normalize [info script]]]] tool_session.tcl]
}
if {![info exists ::TriaFromNodes_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::TriaFromNodes {
    variable label "Create element"
    variable W .triaStrip
    # order: 1 tria3, 2 tria6 (window); status: the line of the window
    variable opt; if {![info exists opt(order)]} {set opt(order) 1}
    variable status ""; variable keptText ""
    variable shellCfg {103 104 106 108}
    variable kept; variable made; variable busy
    variable timer ""; variable panelReady 0; variable panelError ""; variable stop ""; variable panelOpen 0
    variable undoTimer; variable actionSerial; variable selections; variable undone
    # embedded in another window (Mesh edit): its Clear button and the command that closes it
    variable clearButton ""; variable hostClose ""
    foreach {k v} {kept {} made {} busy 0 undoTimer {} actionSerial 0 selections {} undone {}} {
        if {![info exists $k]} {set $k $v}
    }
}

proc ::TriaFromNodes::history_begin {label} {
    hm_private_frwk enablehistoryfromtcl 1
    if {[catch {*startnotehistorystate $label} msg options]} {
        catch {hm_private_frwk enablehistoryfromtcl 0}
        return -options $options $msg
    }
}
proc ::TriaFromNodes::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}
proc ::TriaFromNodes::message {text} {puts "Create element: $text"}

proc ::TriaFromNodes::xyz {ids} {
    set o {}
    foreach x [hm_getvalue nodes user_ids=$ids dataname=x] y [hm_getvalue nodes user_ids=$ids dataname=y] z [hm_getvalue nodes user_ids=$ids dataname=z] {lappend o [list $x $y $z]}
    return $o
}

# Nearby shells (newest first) and possible PLOTEL segments, keyed by their two node IDs.
proc ::TriaFromNodes::neighbours_of {nodes} {
    variable shellCfg
    *createmark nodes 1 {*}$nodes
    set types [hm_getcrossreferencedentitiesmark nodes 1 2 2 0 0]
    *clearmark nodes 1
    set ids [hm_getmark elems 2]
    foreach t $types {catch {*clearmark $t 2}}
    if {![llength $ids]} {return [list {} {}]}
    set shells {}
    set segments {}
    foreach e $ids c [hm_getvalue elems user_ids=$ids dataname=config] nl [hm_getvalue elems user_ids=$ids dataname=nodes] {
        if {$c in $shellCfg} {
            set count [expr {$c in {103 106} ? 3 : 4}]
            lappend shells [list $e $c [lrange $nl 0 [expr {$count-1}]] [lrange $nl $count end]]
        } elseif {$c == 2 && [llength $nl] == 2} {
            dict lappend segments [lsort -integer $nl] $e
        }
    }
    list [lsort -integer -decreasing -index 0 $shells] $segments
}

# 1 when the corner cycle runs a -> b, -1 when it runs b -> a, 0 when a-b is not one of its edges.
proc ::TriaFromNodes::edge_dir {corners a b} {
    set k [llength $corners]
    for {set i 0} {$i < $k} {incr i} {
        set p [lindex $corners $i]; set q [lindex $corners [expr {($i+1)%$k}]]
        if {$p == $a && $q == $b} {return 1}
        if {$p == $b && $q == $a} {return -1}
    }
    return 0
}

# The new tria covers an edge if an existing shell already uses it. Include both halves of a
# quadratic edge when its exact midside node appears in the old PLOTEL connectivity.
proc ::TriaFromNodes::covered_plotels {conn shells segments} {
    if {![dict size $segments]} {return {}}
    lassign $conn a b c
    set candidates {}
    foreach {p q} [list $a $b $b $c $c $a] {
        set edge [lsort -integer [list $p $q]]
        foreach shell $shells {
            lassign $shell id config corners mids
            set dir [edge_dir $corners $p $q]
            if {!$dir} {continue}
            if {[dict exists $segments $edge]} {lappend candidates {*}[dict get $segments $edge]}
            if {$config ni {106 108}} {continue}
            set start [expr {$dir == 1 ? $p : $q}]
            set mid [lindex $mids [lsearch -exact $corners $start]]
            if {$mid eq "" || $mid <= 0} {continue}
            foreach corner $edge {
                set half [lsort -integer [list $corner $mid]]
                if {[dict exists $segments $half]} {lappend candidates {*}[dict get $segments $half]}
            }
        }
    }
    set ids [lsort -unique -integer $candidates]
    if {![llength $ids]} {return {}}
    set plotels {}
    foreach id $ids type [hm_getvalue elems user_ids=$ids dataname=typename] {
        if {$type eq "PLOTEL"} {lappend plotels $id}
    }
    return $plotels
}

# Node order for the tria a b c: the first edge, in the order a-b, b-c, c-a,
# that an existing shell uses decides (newest shell first), so the shared edge runs the other way.
proc ::TriaFromNodes::orient {a b c shells} {
    foreach {p q} [list $a $b $b $c $c $a] {
        foreach s $shells {
            set d [edge_dir [lindex $s 2] $p $q]
            if {$d == 1} {return [list $a $c $b]}
            if {$d == -1} {return [list $a $b $c]}
        }
    }
    list $a $b $c
}

# "" when the node can be picked, else the reason.
proc ::TriaFromNodes::node_problem {n} {
    if {![string is integer -strict $n] || ![hm_entityinfo exist nodes $n]} {return "A selected node does not exist."}
    if {[hm_nodeismidnode $n]} {return "Pick corner nodes only."}
    return ""
}

# Returns the oriented corners, neighbouring shells, the fallback component, and redundant PLOTELs.
proc ::TriaFromNodes::plan {a b c} {
    lassign [xyz [list $a $b $c]] pa pb pc
    set u {}; set v {}
    foreach i {0 1 2} {lappend u [expr {[lindex $pb $i]-[lindex $pa $i]}]; lappend v [expr {[lindex $pc $i]-[lindex $pa $i]}]}
    lassign $u ux uy uz; lassign $v vx vy vz
    set n2 [expr {($uy*$vz-$uz*$vy)**2+($uz*$vx-$ux*$vz)**2+($ux*$vy-$uy*$vx)**2}]
    set l2 0.0
    foreach {p q} [list $pa $pb $pb $pc $pc $pa] {
        set d [expr {([lindex $p 0]-[lindex $q 0])**2+([lindex $p 1]-[lindex $q 1])**2+([lindex $p 2]-[lindex $q 2])**2}]
        if {$d > $l2} {set l2 $d}
    }
    # |u x v| = 2 * area; relative to the longest edge squared
    if {$l2 <= 0 || sqrt($n2) <= 1e-9*$l2} {
        return -code error -errorcode {TRIASTRIP SELECTION} "Selected nodes are collinear."
    }
    lassign [neighbours_of [list $a $b $c]] shells segments
    set want [lsort -integer [list $a $b $c]]
    set matching {}
    set adjacent {}
    foreach shell $shells {
        set corners [lindex $shell 2]
        if {[lsort -integer $corners] eq $want} {
            if {$matching eq {}} {set matching $corners}
        } else {
            lappend adjacent $shell
        }
    }
    set comp ""
    if {[llength $shells]} {set comp [hm_getvalue elems id=[lindex $shells 0 0] dataname=collector.name]}
    set conn $matching
    if {$conn eq {}} {set conn [orient $a $b $c $adjacent]}
    # A coincident face supplies orientation but does not close a free edge.
    list $conn $shells $comp [covered_plotels $conn $adjacent $segments]
}

# A covered corner has a connected shell fan and no free radial edges. Extra incident faces do not
# reopen a covered edge. A repeated sector alone does not cover either of its edges.
proc ::TriaFromNodes::closed_fan {node faces} {
    set links {}
    foreach corners $faces {
        set i [lsearch -exact $corners $node]
        if {$i < 0} {continue}
        set count [llength $corners]
        set a [lindex $corners [expr {($i+$count-1)%$count}]]
        set b [lindex $corners [expr {($i+1)%$count}]]
        if {$a == $b || $a == $node || $b == $node} {return 0}
        dict set links $a $b 1
        dict set links $b $a 1
    }
    if {[dict size $links] < 3} {return 0}
    dict for {n neighbours} $links {
        if {[dict size $neighbours] < 2} {return 0}
    }
    set first [lindex [dict keys $links] 0]
    set visited [dict create $first 1]
    set pending [list $first]
    for {set i 0} {$i < [llength $pending]} {incr i} {
        foreach neighbour [dict keys [dict get $links [lindex $pending $i]]] {
            if {[dict exists $visited $neighbour]} {continue}
            dict set visited $neighbour 1
            lappend pending $neighbour
        }
    }
    expr {[llength $pending] == [dict size $links]}
}

# One tria in the current component, one Undo step. Returns the element id. With no current component
# (a model just read has none) the component comp of the shells around the nodes is made current, by
# name (*currentcollector with an id hangs HyperMesh 2022.3).
proc ::TriaFromNodes::create {conn second comp plotels historyLabel} {
    if {![hm_info currentcollector comps]} {
        if {$comp eq ""} {
            return -code error -errorcode {TRIASTRIP SELECTION} "Set a current component."
        }
        *currentcollector components $comp
        if {![hm_info currentcollector comps]} {error "component $comp could not be made current."}
    }
    set last [hm_entitymaxid elems]
    history_begin $historyLabel
    set code [catch {
        *createlist nodes 1 {*}$conn
        *createelement 103 1 1 0
        *clearlist nodes 1
        set id [hm_latestentityid elems]
        if {$id <= $last} {error "no element was created"}
        if {$second} {*createmark elems 1 $id; *orderchangetosecond 1 0 0; *clearmark elems 1}
        set nl [hm_getvalue elems id=$id dataname=nodes]
        set cfg [hm_getvalue elems id=$id dataname=config]
        if {[lrange $nl 0 2] ne $conn || $cfg != ($second ? 106 : 103)} {
            error "readback of element $id: config $cfg, nodes $nl"
        }
        if {[llength $plotels]} {
            *createmark elems 1 {*}$plotels
            *deletemark elems 1
            *clearmark elems 1
            foreach plotel $plotels {
                if {[hm_entityinfo exist elems $plotel]} {error "PLOTEL $plotel was not deleted"}
            }
        }
    } msg]
    if {$code} {
        catch {*clearlist nodes 1}
        catch {*clearmark elems 1}
    }
    history_end $historyLabel
    if {$code} {
        if {[hm_entitymaxid elems] > $last} {*undohistorystate 1}
        error "creating the tria failed: $msg"
    }
    return $id
}

proc ::TriaFromNodes::submit {} {
    variable kept; variable made; variable opt
    variable label; variable actionSerial; variable selections; variable undone
    if {[llength $kept] != 3} {error "Select exactly three corner nodes."}
    if {[catch {
        if {[llength [lsort -unique $kept]] != 3} {
            error "Pick three distinct nodes." "" {TRIASTRIP SELECTION}
        }
        foreach n $kept {
            set problem [node_problem $n]
            if {$problem ne ""} {error $problem "" {TRIASTRIP SELECTION}}
        }
        lassign [plan {*}$kept] conn shells comp plotels
        set faces [list $conn]
        foreach shell $shells {lappend faces [lindex $shell 2]}
        set remaining {}
        foreach n $kept {
            if {![closed_fan $n $faces]} {lappend remaining $n}
        }
        set second [expr {$opt(order) == 2}]
        set action "$label [incr actionSerial]"
        create $conn $second $comp $plotels $action
    } r options]} {
        set feedback "Creation failed. See Tcl console."
        if {[dict get $options -errorcode] eq {TRIASTRIP SELECTION}} {set feedback $r}
        return [dict create result refused elem "" conn {} feedback $feedback message "Refused: $r (picked $kept)"]
    }
    lappend made $r
    foreach previous $undone {dict unset selections $previous}
    set undone {}
    dict set selections $action [list [lrange $kept 0 1] $r]
    if {[llength $remaining] == 3} {set remaining [lrange $remaining 1 end]}
    set kept $remaining
    set type [expr {$second ? "tria6" : "tria3"}]
    dict create result created elem $r conn $conn feedback "Tria created." message "Element $r ($type, nodes [join $conn {, }])."
}

proc ::TriaFromNodes::reset {} {
    variable kept {}; variable made {}
    variable selections {}; variable undone {}; variable undoTimer
    if {$undoTimer ne ""} {after cancel $undoTimer; set undoTimer ""}
}

# Kept nodes in the selection color between picks.
proc ::TriaFromNodes::show_kept {} {
    variable kept
    clear_kept
    if {![llength $kept]} {return}
    *createmark nodes 2 {*}$kept
    catch {hm_highlightmark nodes 2 high}
    catch {hm_redraw}
}
proc ::TriaFromNodes::clear_kept {} {
    if {[llength [hm_getmark nodes 2]]} {catch {hm_highlightmark nodes 2 norm}}
    *clearmark nodes 2
}

proc ::TriaFromNodes::restore_undo_selection {} {
    variable selections; variable undone; variable kept; variable status; variable made
    if {![dict size $selections]} {return 0}
    # HyperMesh can reject a history query while its history recorder is unavailable.
    if {[catch {hm_getredoactions} redo]} {return 0}
    set now {}
    set action ""
    foreach name $redo {
        if {![dict exists $selections $name]} {continue}
        lappend now $name
        if {$name in $undone} {continue}
        if {$action eq ""} {set action $name}
        set index [lsearch -exact $made [lindex [dict get $selections $name] 1]]
        if {$index >= 0} {set made [lreplace $made $index $index]}
    }
    set undone $now
    if {$action eq ""} {return 0}
    set kept {}
    foreach node [lindex [dict get $selections $action] 0] {
        if {[hm_entityinfo exist nodes $node]} {lappend kept $node}
    }
    set status "Selection restored."
    refresh
    return 1
}

proc ::TriaFromNodes::watch_undo {} {
    variable undoTimer; variable busy; variable W; variable selections
    set undoTimer ""
    if {$busy || ![winfo exists $W] || ![dict size $selections]} {return}
    if {[::TestToolSession::owner] eq "" && [restore_undo_selection]} {show_kept}
    set undoTimer [after 150 ::TriaFromNodes::watch_undo]
}

proc ::TriaFromNodes::set_panel_mark {} {
    variable kept
    catch {hm_highlightmark nodes 1 norm}
    *clearmark nodes 1
    if {[llength $kept]} {
        *createmark nodes 1 {*}$kept
        catch {hm_highlightmark nodes 1 high}
    }
    catch {hm_redraw}
}

# Keep the order of surviving picks. Discard added midside nodes before checking the pick count.
proc ::TriaFromNodes::sync_selection {mark {inPanel 0}} {
    variable kept; variable status
    set ordered {}
    set rejected 0
    foreach n $kept {if {$n in $mark} {lappend ordered $n}}
    foreach n $mark {
        if {$n in $ordered} {continue}
        if {[hm_nodeismidnode $n]} {set rejected 1; continue}
        lappend ordered $n
    }
    if {$kept ne $ordered} {
        set kept $ordered
        refresh
    }
    if {$rejected} {
        set status "Pick corner nodes only."
        if {$inPanel} {set_panel_mark}
    }
}

proc ::TriaFromNodes::pick_poll {seed {initialize 0}} {
    variable kept; variable timer; variable panelReady; variable panelError; variable stop
    set timer ""
    if {$stop ne ""} {return}
    if {[catch {
        # HyperMesh resets the mark on panel entry. Restore the selection in its event loop.
        set restored [restore_undo_selection]
        if {$restored || ($initialize && [llength $kept])} {set_panel_mark}
        sync_selection [hm_getmark nodes 1] 1
    } err]} {
        set panelError $err
        catch {hm_exitpanel}
        return
    }
    if {[llength $kept] == 3 && [lsort -integer $kept] ne $seed} {
        set panelReady 1
        if {[catch {hm_exitpanel} err]} {set panelReady 0; set panelError $err}
        return
    }
    set timer [after 150 [list ::TriaFromNodes::pick_poll $seed]]
}

proc ::TriaFromNodes::pick_panel {} {
    variable kept; variable timer; variable panelReady; variable panelError; variable stop; variable panelOpen
    set seed [lsort -integer $kept]
    set panelReady 0
    set panelError ""
    *clearmark nodes 1
    set timer [after 0 [list ::TriaFromNodes::pick_poll $seed 1]]
    set panelOpen 1
    set code [catch {::TestToolSession::panel *createmarkpanel nodes 1 "Create element: select or deselect nodes; three create a tria. Return to finish."} err]
    set panelOpen 0
    after cancel $timer
    set timer ""
    if {[::TestToolSession::cancelled]} {return 0}
    if {!$code && !$panelReady && $stop eq ""} {
        sync_selection [hm_getmark nodes 1]
        set panelReady [expr {[llength $kept] == 3 && [lsort -integer $kept] ne $seed}]
    }
    *clearmark nodes 1
    if {$panelError ne ""} {error $panelError}
    if {$code && $err ne "0" && !$panelReady && $stop eq ""} {error $err}
    return $panelReady
}

proc ::TriaFromNodes::pick {} {
    variable kept; variable made; variable busy; variable status; variable stop; variable undoTimer
    if {$busy} {return}
    if {$undoTimer ne ""} {after cancel $undoTimer; set undoTimer ""}
    restore_undo_selection
    set busy 1
    set stop ""
    clear_kept
    set code [catch {
        set made {}
        set valid {}
        foreach n $kept {if {[hm_entityinfo exist nodes $n]} {lappend valid $n}}
        set kept $valid
        set failed 0
        set status "Pick 3 corner nodes."
        while {$stop ne "close"} {
            if {$stop eq "clear"} {
                set stop ""
                set kept {}
                set failed 0
                set status "Pick 3 corner nodes."
            }
            refresh
            set ready [pick_panel]
            if {$stop eq "clear"} {continue}
            if {$stop ne "" || !$ready} {break}
            set result [submit]
            set failed [expr {[dict get $result result] eq "refused"}]
            set status [dict get $result feedback]
            message [dict get $result message]
        }
        set k [llength $made]
        if {!$failed} {
            set status [expr {$k ? "$k [expr {$k == 1 ? "tria" : "trias"}] created" : ""}]
        }
    } err]
    set busy 0
    if {$stop eq "close"} {close; return}
    show_kept
    if {$code} {
        message "Picking stopped: $err"
        set status "Picking stopped. See Tcl console."
    }
    refresh
    watch_undo
}

# ---------------------------------------------------------------- window
proc ::TriaFromNodes::refresh {} {
    variable W; variable kept; variable keptText; variable clearButton
    set count [llength $kept]
    set keptText "$count selected"
    set btn [expr {$clearButton ne "" ? $clearButton : "$W.b.clear"}]
    if {[winfo exists $btn]} {$btn configure -state [expr {[llength $kept] ? "normal" : "disabled"}]}
}
proc ::TriaFromNodes::clear {} {
    variable kept; variable status; variable busy; variable stop; variable panelOpen
    if {$busy} {
        set stop clear
        if {$panelOpen} {catch {hm_exitpanel}}
        return
    }
    set kept {}
    clear_kept
    catch {hm_redraw}
    set status ""
    refresh
}
proc ::TriaFromNodes::close {} {
    variable W; variable hostClose
    if {[release]} {return}
    if {$hostClose ne ""} {uplevel #0 $hostClose; return}
    catch {destroy $W}
}
# Stops picking and clears the selection, the marks and the timers (the window stays). Returns 1
# while a pick is running: it stops, then calls close.
proc ::TriaFromNodes::release {} {
    variable busy; variable stop; variable panelOpen
    variable timer; variable panelReady; variable panelError; variable status; variable keptText
    if {$busy} {
        set stop close
        if {$panelOpen} {catch {hm_exitpanel}}
        return 1
    }
    if {$timer ne ""} {after cancel $timer; set timer ""}
    reset
    set panelReady 0
    set panelError ""
    set status ""
    set keptText ""
    set stop ""
    clear_kept
    catch {hm_redraw}
    return 0
}
# The controls inside frame f of another window (host, the toplevel); tool: the session name;
# onClose: the host's close command. Order radios, Pick nodes, Clear and the count on one row.
proc ::TriaFromNodes::embed {f host tool onClose} {
    variable W $host; variable clearButton $f.clear; variable hostClose $onClose
    variable opt; variable status
    if {![info exists opt(order)]} {set opt(order) 1}
    radiobutton $f.o1 -text "Tria3" -variable ::TriaFromNodes::opt(order) -value 1
    radiobutton $f.o2 -text "Tria6" -variable ::TriaFromNodes::opt(order) -value 2
    button $f.pick -text "Pick nodes" -width 12 -command [list ::TestToolSession::run $tool ::TriaFromNodes::pick]
    button $f.clear -text "Clear" -width 12 -command [list ::TestToolSession::run $tool ::TriaFromNodes::clear 1]
    label $f.kept -textvariable ::TriaFromNodes::keptText -anchor w
    set status ""
    refresh
}
# Centered over the HyperMesh main window ([wm frame .], Win32 rectangle through twapi) on its
# monitor, negative coordinates kept, inside the work area of that monitor; without twapi over ".".
proc ::TriaFromNodes::place_center {} {
    variable W
    update idletasks
    set w [winfo reqwidth $W]; set h [winfo reqheight $W]
    set l [winfo rootx .]; set t [winfo rooty .]
    set r [expr {$l+[winfo width .]}]; set b [expr {$t+[winfo height .]}]
    set work {}
    catch {
        package require twapi
        set host [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $host] l t r b
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $host]] -workarea]
    }
    set x [expr {($l+$r-$w)/2}]; set y [expr {($t+$b-$h)/2}]
    if {[llength $work] == 4} {
        lassign $work wl wt wr wb
        set x [expr {max($wl,min($x,$wr-$w))}]; set y [expr {max($wt,min($y,$wb-$h))}]
    }
    wm geometry $W +$x+$y
}
proc ::TriaFromNodes::show {} {
    variable W; variable label; variable opt; variable status
    if {[winfo exists $W]} {raise $W; return}
    if {![info exists opt(order)]} {set opt(order) 1}
    toplevel $W
    wm withdraw $W
    wm title $W $label
    wm resizable $W 0 0
    catch {wm transient $W .}
    set b [ttk::frame $W.b -padding {14 12}]
    pack $b -fill both -expand 1
    ttk::label $b.l_order -text "Order"
    ttk::radiobutton $b.o1 -text "Tria3" -variable ::TriaFromNodes::opt(order) -value 1
    ttk::radiobutton $b.o2 -text "Tria6" -variable ::TriaFromNodes::opt(order) -value 2
    ttk::button $b.pick -text "Pick nodes" -command [list ::TestToolSession::run "Create element" ::TriaFromNodes::pick]
    ttk::button $b.clear -text "Clear" -command [list ::TestToolSession::run "Create element" ::TriaFromNodes::clear 1]
    ttk::label $b.kept -textvariable ::TriaFromNodes::keptText -anchor w
    ttk::label $b.status -textvariable ::TriaFromNodes::status -anchor w -width 25 -wraplength 180
    grid $b.l_order $b.o1 $b.o2 -sticky w -padx {0 10}
    grid $b.pick - $b.clear -sticky ew -pady {8 0}
    grid configure $b.pick -padx {0 8}
    grid $b.kept $b.status - -sticky ew -pady {8 0}
    grid configure $b.kept -padx {0 10}
    grid columnconfigure $b 1 -weight 1
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Create element" ::TriaFromNodes::close 1]
    set status ""
    refresh
    place_center
    wm deiconify $W
}

if {![info exists ::TriaFromNodes_no_gui]} {::TriaFromNodes::show}
