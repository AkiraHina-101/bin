# Center Node (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Pick 2D elements (tria3/tria6/quad4/quad8, e.g. washer faces). For every connected patch of the
# selection the free-edge loops are found (corner nodes only, midside nodes ignored) and the hole
# edge (a patch with exactly one hole) or the outer edge is taken. The nodes of that edge are shown
# in the native selection color before anything is created; Create makes the center node with the
# native *createbestcirclecenternode (best-fit circle of the edge nodes). One Undo step "Center node"
# per Create. The center is checked against the native circle through three far-apart nodes of the
# same edge (printed in the Tcl console).
# Entry point for the menu: *evaltclscript center_node.tcl 0. Set ::CenterNode_no_gui to load the
# procedures without opening the window (tests).

if {![llength [info commands ::TestToolSession::run]]} {
    source [file join [file dirname [file dirname [file normalize [info script]]]] tool_session.tcl]
}
if {![info exists ::CenterNode_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::CenterNode {
    variable W .centerNode
    variable shellCfg {103 104 106 108}
    variable label "Center node"
    variable sel
    variable opt
    variable cs {}
    variable status ""
    if {![info exists sel(elems)]} {set sel(elems) {}}
    foreach {k v} {mode hole info none} {if {![info exists opt($k)]} {set opt($k) $v}}
}

proc ::CenterNode::vsub {a b} {list [expr {[lindex $a 0]-[lindex $b 0]}] [expr {[lindex $a 1]-[lindex $b 1]}] [expr {[lindex $a 2]-[lindex $b 2]}]}
proc ::CenterNode::vadd {a b} {list [expr {[lindex $a 0]+[lindex $b 0]}] [expr {[lindex $a 1]+[lindex $b 1]}] [expr {[lindex $a 2]+[lindex $b 2]}]}
proc ::CenterNode::vscale {a s} {list [expr {[lindex $a 0]*$s}] [expr {[lindex $a 1]*$s}] [expr {[lindex $a 2]*$s}]}
proc ::CenterNode::dot {a b} {expr {[lindex $a 0]*[lindex $b 0]+[lindex $a 1]*[lindex $b 1]+[lindex $a 2]*[lindex $b 2]}}
proc ::CenterNode::cross {a b} {
    lassign $a ax ay az; lassign $b bx by bz
    list [expr {$ay*$bz-$az*$by}] [expr {$az*$bx-$ax*$bz}] [expr {$ax*$by-$ay*$bx}]
}
proc ::CenterNode::norm {a} {expr {sqrt([dot $a $a])}}
proc ::CenterNode::unit {a} {set l [norm $a]; if {$l <= 0} {return {0 0 0}}; vscale $a [expr {1.0/$l}]}
proc ::CenterNode::key {a b} {expr {$a < $b ? "$a $b" : "$b $a"}}
proc ::CenterNode::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::CenterNode::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}

proc ::CenterNode::xyz {ids} {
    set o [dict create]
    for {set i 0} {$i < [llength $ids]} {incr i 2048} {
        set c [lrange $ids $i [expr {$i+2047}]]
        foreach n $c x [hm_getvalue nodes user_ids=$c dataname=x] y [hm_getvalue nodes user_ids=$c dataname=y] z [hm_getvalue nodes user_ids=$c dataname=z] {dict set o $n [list $x $y $z]}
    }
    return $o
}

# Corner loops of the selection: {patches} where a patch is {elements loops}; loops are ordered node
# lists of free edges (edges used once inside the patch). Errors on non-2D elements.
proc ::CenterNode::patches {elems} {
    variable shellCfg
    *createmark elems 1 {*}$elems; set elems [hm_getmark elems 1]; *clearmark elems 1
    if {![llength $elems]} {error "Select the 2D elements."}
    set corners [dict create]
    for {set i 0} {$i < [llength $elems]} {incr i 2048} {
        set c [lrange $elems $i [expr {$i+2047}]]
        foreach e $c cfg [hm_getvalue elems user_ids=$c dataname=config] nl [hm_getvalue elems user_ids=$c dataname=nodes] {
            if {$cfg ni $shellCfg} {error "Element $e is not a 2D shell (config $cfg): select tria3, tria6, quad4 or quad8."}
            dict set corners $e [lrange $nl 0 [expr {$cfg in {103 106} ? 2 : 3}]]
        }
    }
    # connected patches through shared corner nodes
    foreach e $elems {set parent($e) $e}
    set byNode [dict create]
    dict for {e nl} $corners {foreach n $nl {dict lappend byNode $n $e}}
    dict for {n els} $byNode {
        set r0 [find [lindex $els 0]]
        foreach e [lrange $els 1 end] {set r [find $e]; if {$r ne $r0} {set parent($r) $r0}}
    }
    set groups [dict create]
    foreach e $elems {dict lappend groups [find $e] $e}
    set out {}
    dict for {r els} $groups {
        set cnt [dict create]
        foreach e $els {
            set nl [dict get $corners $e]; set k [llength $nl]
            for {set i 0} {$i < $k} {incr i} {dict incr cnt [key [lindex $nl $i] [lindex $nl [expr {($i+1)%$k}]]]}
        }
        set adj [dict create]
        dict for {k v} $cnt {if {$v == 1} {lassign $k a b; dict lappend adj $a $b; dict lappend adj $b $a}}
        lappend out [list $els [loops $adj]]
    }
    return $out
}
proc ::CenterNode::find {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}
# Closed loops of an adjacency dict (node -> neighbours); nodes with other than two neighbours end a walk.
proc ::CenterNode::loops {adj} {
    set seen [dict create]; set out {}
    dict for {n nb} $adj {
        if {[dict exists $seen $n] || [llength $nb] != 2} {continue}
        set loop [list $n]; dict set seen $n 1
        set prev $n; set cur [lindex $nb 0]; set closed 0
        while {1} {
            if {$cur == $n} {set closed 1; break}
            if {[dict exists $seen $cur] || [llength [dict get $adj $cur]] != 2} {break}
            dict set seen $cur 1; lappend loop $cur
            lassign [dict get $adj $cur] a b
            set nxt [expr {$a == $prev ? $b : $a}]
            set prev $cur; set cur $nxt
        }
        if {$closed && [llength $loop] >= 3} {lappend out $loop}
    }
    return $out
}

# Native best-fit circle of nodes (hm_getbestcirclecenter, tolerance ignored): {center radius}.
proc ::CenterNode::native_fit {nodes} {
    *createmark nodes 1 {*}$nodes
    set rc [catch {hm_getbestcirclecenter nodes 1 1} r]
    *clearmark nodes 1
    if {$rc} {error "No circle through the edge nodes ($r)."}
    lassign $r x y z R
    list [list $x $y $z] $R
}
# Three far-apart nodes of a loop (ids): two at the largest distance, the third farthest from both.
proc ::CenterNode::three_far {nodes P} {
    set a [lindex $nodes 0]; set b $a; set best -1
    foreach n $nodes {set d [norm [vsub [dict get $P $n] [dict get $P $a]]]; if {$d > $best} {set best $d; set b $n}}
    set best -1
    foreach n $nodes {set d [norm [vsub [dict get $P $n] [dict get $P $b]]]; if {$d > $best} {set best $d; set a $n}}
    set best -1; set c $a
    foreach n $nodes {
        set d [expr {min([norm [vsub [dict get $P $n] [dict get $P $a]]],[norm [vsub [dict get $P $n] [dict get $P $b]]])}]
        if {$d > $best} {set best $d; set c $n}
    }
    list $a $b $c
}

# Centers of the selection, one per connected patch. mode: hole (the hole edge when the patch has
# exactly one hole, else the outer edge) or outer. Returns a list of dicts: loop (node ids), used
# (hole/outer), note, center, radius, rms (node distance to the circle), nodes, check (distance to
# the circle through three far-apart nodes of the loop), elems.
proc ::CenterNode::centers {elems {mode hole}} {
    if {$mode ni {hole outer}} {error "Unknown mode $mode."}
    set out {}
    foreach pt [patches $elems] {
        lassign $pt els loops
        if {![llength $loops]} {error "A patch of [llength $els] elements has no closed edge."}
        set fits {}
        foreach L $loops {lassign [native_fit $L] c R; lappend fits [list $R $c $L]}
        set fits [lsort -real -decreasing -index 0 $fits]
        set holes [lrange $fits 1 end]
        set used outer; set note ""
        set pick [lindex $fits 0]
        if {$mode eq "hole"} {
            if {[llength $holes] == 1} {
                set pick [lindex $holes 0]; set used hole
            } elseif {![llength $holes]} {
                set note "no hole, outer edge used"
            } else {
                set note "[llength $holes] holes, outer edge used"
            }
        }
        lassign $pick R c L
        set P [xyz $L]
        set s 0.0; dict for {n p} $P {set e [expr {[norm [vsub $p $c]]-$R}]; set s [expr {$s+$e*$e}]}
        set chk ""
        catch {lassign [native_fit [three_far $L $P]] c3 R3; set chk [norm [vsub $c3 $c]]}
        lappend out [dict create loop $L used $used note $note center $c radius $R rms [expr {sqrt($s/[dict size $P])}] \
            nodes [llength $L] check $chk elems [llength $els]]
    }
    return $out
}

# Creates the center nodes with *createbestcirclecenternode (one Undo step). Returns {nodeIds centers}.
proc ::CenterNode::create {elems {mode hole}} {
    variable label
    set cs [centers $elems $mode]
    set ids {}
    history_begin $label
    set code [catch {
        # (no *nodemarkcleartempmark: on a node no element uses it deletes the node)
        foreach c $cs {
            set last [hm_entitymaxid nodes]
            *createmark nodes 1 {*}[dict get $c loop]
            *createbestcirclecenternode nodes 1 0 1 0
            *clearmark nodes 1
            set id [hm_latestentityid nodes]
            if {$id <= $last} {error "no node was created"}
            lappend ids $id
        }
    } msg]
    history_end $label
    if {$code} {error "Creating the center nodes failed: $msg"}
    list $ids $cs
}

proc ::CenterNode::message {text} {puts "Center node: $text"; catch {hm_usermessage $text}}

# ---------------------------------------------------------------- window
proc ::CenterNode::existing {ids} {
    if {![llength $ids]} {return {}}
    *createmark elems 1 {*}$ids; set o [hm_getmark elems 1]; *clearmark elems 1
    return $o
}
# Preview: the edge nodes the centers will be fitted to, in the native selection color (nodes mark
# 2); the picked elements grey (elements mark 1 low).
proc ::CenterNode::preview {} {
    variable sel; variable opt; variable cs; variable status
    clear_preview
    set cs {}
    set els [existing $sel(elems)]
    if {![llength $els]} {set opt(info) "none"; return}
    if {[catch {centers $els $opt(mode)} r]} {set status $r; set opt(info) "[llength $els] elements"; return}
    set cs $r
    set nodes {}; set notes {}
    foreach c $cs {lappend nodes {*}[dict get $c loop]; if {[dict get $c note] ne ""} {lappend notes [dict get $c note]}}
    set opt(info) "[llength $els] elements, [llength $cs] [expr {[llength $cs] == 1 ? "patch" : "patches"}]"
    *createmark elems 1 {*}$els; catch {hm_highlightmark elems 1 low}
    *createmark nodes 2 {*}$nodes; catch {hm_highlightmark nodes 2 high}
    set status ""
    if {[llength $notes]} {set status "[join [lsort -unique $notes] {; }]."}
    catch {hm_redraw}
}
proc ::CenterNode::clear_preview {} {
    variable sel
    set n [hm_getmark nodes 2]
    if {[llength $n]} {catch {hm_highlightmark nodes 2 norm}}
    *clearmark nodes 2
    set els [existing $sel(elems)]
    if {[llength $els]} {catch {*createmark elems 1 {*}$els; hm_highlightmark elems 1 norm}}
    *clearmark elems 1
    catch {hm_redraw}
}
proc ::CenterNode::pick {} {
    variable W; variable sel
    if {[winfo exists $W]} {wm withdraw $W}
    clear_preview
    *clearmark elems 1
    catch {::TestToolSession::panel *createmarkpanel elems 1 "Center: 2D elements (one center per connected patch)"}
    set ids [hm_getmark elems 1]
    *clearmark elems 1
    if {[winfo exists $W]} {wm deiconify $W; raise $W}
    if {[llength $ids]} {set sel(elems) $ids}
    refresh
}
proc ::CenterNode::do_create {} {
    variable sel; variable opt; variable status
    set els [existing $sel(elems)]
    clear_preview
    if {[catch {create $els $opt(mode)} r]} {
        set status $r
        preview
        return
    }
    lassign $r ids cs2
    set worst 0.0
    foreach id $ids c $cs2 {
        set k [dict get $c check]
        if {$k ne "" && $k > $worst} {set worst $k}
        puts [format "Center node: node %d (%s) at (%.6g, %.6g, %.6g), R %.6g, rms %.3g over %d corner nodes, 3-node check %s %s" \
            $id [dict get $c used] {*}[dict get $c center] [dict get $c radius] [dict get $c rms] [dict get $c nodes] \
            [expr {$k eq "" ? "-" : [format %.3g $k]}] [dict get $c note]]
    }
    # the new nodes in the selection color
    *createmark nodes 2 {*}$ids; catch {hm_highlightmark nodes 2 high}
    catch {hm_redraw}
    set status [format "Created %d center %s; 3-node check up to %.3g." [llength $ids] [expr {[llength $ids] == 1 ? "node" : "nodes"}] $worst]
}
proc ::CenterNode::reset {} {
    variable sel; variable status
    clear_preview
    set sel(elems) {}; set status ""
    refresh
}
proc ::CenterNode::close_window {} {
    variable W
    reset
    destroy $W
}
proc ::CenterNode::refresh {} {
    variable W; variable sel
    # read before the preview: existing reuses elements mark 1, which holds the grey highlight
    set n [llength [existing $sel(elems)]]
    if {[winfo exists $W]} {$W.foot.run configure -state [expr {$n ? "normal" : "disabled"}]}
    preview
}
proc ::CenterNode::show {} {
    variable W; variable status
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Center Node"
    wm resizable $W 0 0
    frame $W.body -padx 12 -pady 10
    pack $W.body -fill both -expand 1
    set s [labelframe $W.body.sel -text "Elements" -padx 8 -pady 6]
    button $s.pick -text "Elements..." -width 10 -command [list ::TestToolSession::run "Center node" ::CenterNode::pick]
    label $s.info -textvariable ::CenterNode::opt(info) -anchor w -width 26
    grid $s.pick -row 0 -column 0 -sticky w -pady 2
    grid $s.info -row 0 -column 1 -sticky w -padx {8 0}
    grid $s -row 0 -column 0 -sticky ew
    set e [labelframe $W.body.edge -text "Center of" -padx 8 -pady 6]
    radiobutton $e.hole -text "Hole" -value hole -variable ::CenterNode::opt(mode) -command [list ::TestToolSession::run "Center node" ::CenterNode::preview] -anchor w -width 10
    radiobutton $e.outer -text "Outer edge" -value outer -variable ::CenterNode::opt(mode) -command [list ::TestToolSession::run "Center node" ::CenterNode::preview] -anchor w
    grid $e.hole -row 0 -column 0 -sticky w
    grid $e.outer -row 0 -column 1 -sticky w
    grid $e -row 1 -column 0 -sticky ew -pady {8 0}
    grid columnconfigure $W.body 0 -weight 1
    frame $W.foot -padx 12 -pady 8
    label $W.foot.status -textvariable ::CenterNode::status -anchor nw -justify left -height 2 -wraplength 260
    frame $W.foot.buttons
    button $W.foot.close -text "Close" -width 8 -command [list ::TestToolSession::run "Center node" ::CenterNode::close_window]
    button $W.foot.reset -text "Reset" -width 8 -command [list ::TestToolSession::run "Center node" ::CenterNode::reset]
    button $W.foot.run -text "Create" -width 10 -command [list ::TestToolSession::run "Center node" ::CenterNode::do_create]
    pack $W.foot.close $W.foot.reset $W.foot.run -in $W.foot.buttons -side right -padx {6 0}
    pack $W.foot.status -side top -fill x
    pack $W.foot.buttons -side top -fill x -pady {6 0}
    pack $W.foot -fill x
    wm protocol $W WM_DELETE_WINDOW [list ::TestToolSession::run "Center node" ::CenterNode::close_window]
    set status ""
    refresh
    place_center
    wm deiconify $W
    keep_above_host
}
# Center over the HyperMesh main window, inside the work area of the monitor that holds it.
# A monitor left of or above the primary one has negative coordinates: no clamp to 0, and
# "+$x+$y" keeps them absolute ("%+d" of a negative number counts from the right edge).
proc ::CenterNode::place_center {} {
    variable W
    update idletasks
    $W.foot.status configure -wraplength [expr {max(200,[winfo reqwidth $W.body]-24)}]
    update idletasks
    # Host: the Win32 frame of "." (the HyperWorks top-level window; "." is only its content area),
    # else that content area. wm geometry places the outer frame of W: add its border
    # (SM_CXSIZEFRAME + SM_CXPADDEDBORDER) and caption.
    set host [list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]]
    set border 0; set caption 0; set work {}
    catch {
        package require twapi
        set border [expr {[twapi::GetSystemMetrics 32] + [twapi::GetSystemMetrics 92]}]
        set caption [twapi::GetSystemMetrics 4]
        set frame [list [expr {[wm frame .]}] HWND]
        lassign [twapi::get_window_coordinates $frame] l t r b
        set host [list $l $t [expr {$r - $l}] [expr {$b - $t}]]
        set work [dict get [twapi::get_display_monitor_info [twapi::get_display_monitor_from_window $frame -default nearest]] -workarea]
    }
    set w [expr {[winfo reqwidth $W] + 2*$border}]
    set h [expr {[winfo reqheight $W] + $caption + 2*$border}]
    lassign [fit_box $host $work $w $h] x y
    wm geometry $W +$x+$y
}
# Top-left corner of a w x h frame centered on host {x y width height}, kept inside
# work {left top right bottom} when known (the top-left corner wins if the frame is larger).
proc ::CenterNode::fit_box {host work w h} {
    lassign $host hx hy hw hh
    set x [expr {$hx + ($hw - $w) / 2}]
    set y [expr {$hy + ($hh - $h) / 2}]
    if {[llength $work] == 4} {
        lassign $work left top right bottom
        set x [expr {max($left, min($x, $right - $w))}]
        set y [expr {max($top, min($y, $bottom - $h))}]
    }
    list $x $y
}
# HyperMesh main window as Win32 owner: above HyperMesh only.
proc ::CenterNode::keep_above_host {} {
    variable W
    catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $W]}] HWND] -8 [expr {[wm frame .]}]
    }
}

if {![info exists ::CenterNode_no_gui]} {::CenterNode::show}
