# Bộ tool thử nghiệm HyperMesh 2022.3

Dùng với HyperMesh 2022.3, solver profile Nastran. Cập nhật 23/11/2026.

| Nút | Công dụng |
| --- | --- |
| **Toolbox** | Mở một cửa sổ nhỏ, mỗi tool bên dưới là một nút. Toolbox không đổi model. |
| **RBE2 bar** | Tạo kết nối RBE2–CBAR–RBE2. |
| **Shared faces** | Tạo các mặt chung với màu đang chọn. |
| **Ruled mesh** | Lấp viền kín hoặc tạo lưới giữa hai viền; có Find edges để tạo PLOTEL viền. |
| **Imprint** | Đắp lưới mặt nguồn (ví dụ washer) lên mặt đích để hai mặt chung node. Gap (mm) xóa thêm các element sát vùng bị xóa nếu cạnh của chúng gần viền nguồn hơn Gap. |
| **Pattern** | Chép các element đã chọn từ một node gốc tới nhiều node đích. |
| **Translate** | Dịch hoặc chép element hay node theo vector node 1 → node 2; có Axes, Distance, Duplicate. |
| **Center node** | Tạo node tại tâm lỗ hoặc tâm viền ngoài của element 2D đã chọn. |
| **Mesh edit** | Replace, Split, Cut element (Perpendicular, Split line) và Create element (tạo tria từ 3 node). |
| **Advanced Select** | Chọn element theo vùng, phía của đường PLOTEL, mặt chung hoặc loại, rồi ẩn, xóa, chuyển hay đổi màu. |

## Cài và dùng

1. Chép nguyên thư mục `HyperMesh_Test_Tools_2022.3` sang máy dùng, giữ cấu trúc bên trong. Đường dẫn có thể có khoảng trắng nhưng **không nên có chữ có dấu**: `*evaltclscript` (lệnh các nút gọi) từng bị treo với đường dẫn như vậy.
2. Mở **HyperMesh 2022.3** với profile **Nastran**.
3. Tại **Tcl Console**, chạy lệnh sau (thay đường dẫn theo chỗ đã chép):

```tcl
source {D:/CAE Tools/HyperMesh_Test_Tools_2022.3/Load_Test_Tools.tcl}
```

Trang **TEST** (trang 15) của **Utility** hiện các nút trên, nút **Toolbox** ở đầu. Bấm **Toolbox** để mở cửa sổ nút. Cửa sổ này luôn nằm trên HyperMesh và mở giữa cửa sổ HyperMesh, ở đúng màn hình đang chứa nó.

- Lệnh nạp thay menu Utility mà phiên đang dùng. Muốn trở lại menu cũ của máy, nạp lại MAC của máy đó.
- Mỗi phiên HyperMesh mới, hoặc sau khi chuyển thư mục gói, chạy lại lệnh `source`.
- Chỉ cần Toolbox, không cần menu: `source {D:/CAE Tools/HyperMesh_Test_Tools_2022.3/ToolBox/toolbox.tcl}`.
- Mở thẳng một tool: `source` tệp `.tcl` của tool đó, ví dụ `ElemImprint/elem_imprint.tcl`.

## Cấu trúc

- `tool_session.tcl` ở gốc gói là phần dùng chung. Nó quản lý việc mỗi lúc chỉ một tool giữ panel chọn của HyperMesh. Mọi tool nạp tệp này từ thư mục cha, nên **phải giữ nó cạnh các thư mục tool**.
- Mỗi tool nằm trong một thư mục riêng. `TriaFromNodes/` là phần Create element mà Mesh edit nạp, không có nút riêng.
- `Load_Test_Tools.tcl` kiểm tra đủ tệp, rồi tạo MAC từ `Test_Tools.mac.in` (thay `@PACKAGE_ROOT@` bằng đường dẫn thật) trong thư mục TEMP và nạp vào phiên.

## Kiểm chứng

- Ngày 23/11/2026, bài thử `01_CAE_TOOLS/05-Test/ToolBox/tests/probe_dist.tcl` đạt **5/5** trên HyperMesh 2022.3 scratch, nạp đúng gói này:
  - `Load_Test_Tools.tcl` tạo MAC có 10 nút, mọi nút trỏ tới tệp có thật trong gói.
  - Toolbox mở từ gói với 9 nút, mỗi nút gọi tệp trong gói.
  - Nút Translate và Mesh edit mở đúng cửa sổ.
- Từng tool được kiểm bằng bài thử riêng trong `01_CAE_TOOLS/05-Test/<tool>/tests/`.
- **Chưa thử:** máy khác, đường dẫn có khoảng trắng, và việc bấm nút trên trang Utility bằng chuột thật.
- `HyperMesh_Test_Tools_2022.3.zip` bên cạnh là bản cũ, chưa cập nhật theo thư mục này.
