# Toolbox (HyperMesh 2022.3, Tcl 8.5, Nastran).
# One small window with a grid of same-size buttons, one per test tool, filled column by column like
# the HyperMesh Tool page. Each button runs exactly what the tool's menu button runs
# (*evaltclscript <tool entry point> 0), so the tool opens its own window or panel as from the menu.
# The window stays above the HyperMesh main window only (Win32 owner) and opens centered over it, on
# whatever monitor it is (negative screen coordinates kept). Icons are HyperMesh's own 16 px images
# (hw/images through hwtk::image cache); when one is missing every button shows text only.
# Entry point for the menu: *evaltclscript toolbox.tcl 0. Set ::ToolBox_no_gui to load the
# procedures without opening the window (tests).

namespace eval ::ToolBox {
    variable W .caeToolBox
    # the folder holding the tool folders (05-Test)
    variable root [file dirname [file dirname [file normalize [info script]]]]
    # label, entry point relative to root, native icon name (hw/images, without -16.png); menu order
    variable tools {
        {"RBE2 bar"        RbeBarLink/rbe_bar_link.tcl       entityElementsRigidlink}
        {"Shared faces"    SharedFaces/shared_faces.tcl      meshFace}
        {"Ruled mesh"      RuledMesh/ruled_mesh.tcl          toolbarRuledSurfaceShowStrip}
        {"Imprint"         ElemImprint/elem_imprint.tcl      meshCircleImprint}
        {"Pattern"         ElemPattern/elem_pattern.tcl      glyphCopy}
        {"Translate"       ElemTranslate/elem_translate.tcl  browserTransformPosition}
        {"Center node"     CenterNode/center_node.tcl        microMeasureRadiusStrip}
        {"Mesh edit"       Equiv2nd/equiv_second.tcl         entityEquivalences}
        {"Advanced Select" AdvancedSelect/advanced_select.tcl selectionPolygonalStrip}
    }
    # buttons per column
    variable rows 5
}

if {![llength [info commands ::TestToolSession::run]]} {
    source [file join $::ToolBox::root tool_session.tcl]
}

proc ::ToolBox::message {text} {puts "Toolbox: $text"; catch {hm_usermessage "Toolbox: $text"}}

# Native 16 px icon as a photo owned by the toolbox ("" when missing). A ...Strip image comes back
# from hwtk::image cache as state/image pairs; the normal state is used.
proc ::ToolBox::icon {name} {
    set key ::ToolBox::icon_$name
    if {$key in [image names]} {return $key}
    if {[catch {hwtk::image cache $name-16.png} src] || $src eq ""} {return ""}
    if {[llength $src] > 1} {
        if {[llength $src] % 2 || ![dict exists $src normal]} {return ""}
        set src [dict get $src normal]
    }
    if {[catch {image create photo $key -width 16 -height 16; $key copy $src -from 0 0 16 16}]} {
        catch {image delete $key}
        return ""
    }
    return $key
}

# The menu command of a tool: *evaltclscript <entry point> 0.
proc ::ToolBox::launch {path} {
    if {![file isfile $path]} {message "$path not found."; return}
    if {![::TestToolSession::can_open $path]} {return}
    if {[catch {*evaltclscript $path 0} err]} {message "[file tail $path]: $err"}
}

proc ::ToolBox::show {} {
    variable W; variable root; variable tools; variable rows
    if {[winfo exists $W]} {destroy $W}
    toplevel $W
    wm withdraw $W
    wm title $W "Toolbox"
    wm resizable $W 0 0
    # palette caption: small, close button only (a normal caption cuts the title of this narrow window)
    catch {wm attributes $W -toolwindow 1}
    # 10 px window margin = frame padding + the 3 px / 2 px cell padding of the buttons
    set f [frame $W.grid -padx 7 -pady 8]
    pack $f -fill both -expand 1
    set images {}
    foreach t $tools {lappend images [icon [lindex $t 2]]}
    set withIcons [expr {"" ni $images}]
    set i 0
    foreach t $tools img $images {
        lassign $t label rel
        set b [button $f.b$i -text $label -anchor w -padx 6 -pady 2 -command [list ::ToolBox::launch [file join $root $rel]]]
        if {$withIcons} {$b configure -image $img -compound left}
        set c [expr {$i / $rows}]
        # same padding in every column, so the uniform columns give buttons of one width
        if {$c < 2} {
            grid $b -row [expr {$i % $rows}] -column $c -sticky ew -padx 3 -pady 2
            grid columnconfigure $f $c -uniform tools
        } else {
            grid $b -row $rows -column 0 -columnspan 2 -sticky ew -padx 3 -pady {5 2}
        }
        incr i
    }
    wm protocol $W WM_DELETE_WINDOW [list destroy $W]
    place_center
    wm deiconify $W
    keep_above_host
}

# Screen rectangle {x y width height} of the HyperMesh main window (Win32 frame of "."); the Tk root
# window is the fallback. Coordinates may be negative on a monitor left of or above the primary one.
proc ::ToolBox::host_rect {} {
    if {![catch {
        package require twapi
        lassign [twapi::get_window_coordinates [list [expr {[wm frame .]}] HWND]] l t r b
    }] && $r-$l > 100 && $b-$t > 100} {
        return [list $l $t [expr {$r-$l}] [expr {$b-$t}]]
    }
    list [winfo rootx .] [winfo rooty .] [winfo width .] [winfo height .]
}

# Center over the HyperMesh main window while withdrawn; no clamp to the primary monitor.
proc ::ToolBox::place_center {} {
    variable W
    update idletasks
    lassign [host_rect] hx hy hw hh
    set x [expr {$hx + ($hw - [winfo reqwidth $W])/2}]
    set y [expr {$hy + ($hh - [winfo reqheight $W])/2}]
    wm geometry $W +$x+$y
}

# HyperMesh main window as Win32 owner: above HyperMesh only, not above other applications.
proc ::ToolBox::keep_above_host {} {
    variable W
    catch {
        package require twapi
        update idletasks
        twapi::SetWindowLongPtr [list [expr {[wm frame $W]}] HWND] -8 [expr {[wm frame .]}]
    }
}

if {![info exists ::ToolBox_no_gui]} {::ToolBox::show}
