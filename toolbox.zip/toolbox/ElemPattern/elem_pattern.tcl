# Element Pattern (HyperMesh 2022.3, Tcl 8.5, Nastran).
# Copies the selected elements to many places: pick the elements, one base node, then the target
# nodes. For every target node the elements are duplicated as they are (*duplicatemark into their own
# components: same type, property, component, every attribute) and the copy is moved by the vector
# base node -> target node (*translatemark). The copies get their own new nodes (no merge with the
# model). All copies are one Undo step "Element pattern". To stay fast on large models the copies are
# made by doubling (copies_doubling): about log2(N+1) *duplicatemark calls for N targets.
# No window: three native selection panels, the result in the message bar and the Tcl console.
# Entry point for the menu: *evaltclscript elem_pattern.tcl 0. Set ::ElemPattern_no_gui to load the
# procedures without starting the selection (tests).

if {![llength [info commands ::TestToolSession::run]]} {
    source [file join [file dirname [file dirname [file normalize [info script]]]] tool_session.tcl]
}
if {![info exists ::ElemPattern_no_gui] && ![::TestToolSession::can_open [file normalize [info script]]]} {return}

namespace eval ::ElemPattern {
    variable label "Element pattern"
    variable last {}
}

proc ::ElemPattern::history_begin {label} {catch {hm_private_frwk enablehistoryfromtcl 1}; catch {*startnotehistorystate $label}}
proc ::ElemPattern::history_end {label} {catch {*endnotehistorystate $label}; catch {hm_private_frwk enablehistoryfromtcl 0}}
proc ::ElemPattern::count {type} {hm_count $type all 0 0}
proc ::ElemPattern::xyz {n} {list [hm_getvalue nodes id=$n dataname=x] [hm_getvalue nodes id=$n dataname=y] [hm_getvalue nodes id=$n dataname=z]}

# One native selection panel. Returns the picked ids; empty when the panel was left without a pick
# (return/ESC makes the panel command fail, so it is caught and the mark read instead).
proc ::ElemPattern::pick {type prompt} {
    *clearmark $type 1
    catch {::TestToolSession::panel *createmarkpanel $type 1 $prompt}
    set ids [hm_getmark $type 1]
    *clearmark $type 1
    return $ids
}

# N copies of elems at their own place, with few *duplicatemark calls: every call copies the
# original and the copies made so far (1, 2, 4, ... at once), so N copies take about log2(N+1) calls
# instead of N (each call costs ~1 s on a 3 million element model, whatever its size).
# The new elements of one call are split by pieces: elements joined by shared nodes. Before they are
# moved all copies lie on the original, so every piece has the signature of an original piece (its
# element types and first-node places); each signature must come exactly as many times as copies
# were asked, and every copy takes one piece of each signature. Elements sharing nodes so always stay
# in one copy. An error "copy check: ..." is raised when that does not hold. Returns the N blocks.
proc ::ElemPattern::copies_doubling {elems N} {
    set want [dict create]
    foreach {sig piece} [pieces $elems] {dict incr want $sig}
    set sets [list $elems]
    while {[llength $sets]-1 < $N} {
        set take [expr {min([llength $sets],$N-([llength $sets]-1))}]
        set src {}; foreach s [lrange $sets 0 [expr {$take-1}]] {lappend src {*}$s}
        *createmark elems 1 {*}$src
        *duplicatemark elems 1 0
        set new [hm_getmark elems 1]
        *clearmark elems 1
        if {[llength $new] != $take*[llength $elems]} {error "copy check: [llength $new] new elements instead of [expr {$take*[llength $elems]}]"}
        set bySig [dict create]
        foreach {sig piece} [pieces $new] {dict lappend bySig $sig $piece}
        if {[lsort [dict keys $bySig]] ne [lsort [dict keys $want]]} {error "copy check: the copies do not match the original"}
        set blocks {}; for {set k 0} {$k < $take} {incr k} {lappend blocks {}}
        dict for {sig list} $bySig {
            if {[llength $list] != $take*[dict get $want $sig]} {error "copy check: a piece came [llength $list] times instead of [expr {$take*[dict get $want $sig]}]"}
            set k 0
            foreach piece $list {lset blocks [expr {$k % $take}] [concat [lindex $blocks [expr {$k % $take}]] $piece]; incr k}
        }
        foreach blk $blocks {lappend sets [lsort -integer $blk]}
    }
    lrange $sets 1 end
}
# Pieces of elements (joined by shared nodes) with their signatures: a flat list sig piece sig piece.
# A signature is the sorted list of {config x y z} of the first node of each element (rounded).
proc ::ElemPattern::pieces {elems} {
    set nl [hm_getvalue elems user_ids=$elems dataname=nodes]
    set cf [hm_getvalue elems user_ids=$elems dataname=config]
    foreach e $elems {set parent($e) $e}
    set byNode [dict create]
    foreach e $elems ns $nl {foreach n $ns {if {[dict exists $byNode $n]} {
        set r0 [find [dict get $byNode $n]]; set r1 [find $e]; if {$r0 ne $r1} {set parent($r1) $r0}
    } else {dict set byNode $n $e}}}
    set firsts {}; foreach ns $nl {lappend firsts [lindex $ns 0]}
    set P [nodes_xyz $firsts]
    set groups [dict create]
    foreach e $elems c $cf p $P {
        set key [list $c [format %.6g [lindex $p 0]] [format %.6g [lindex $p 1]] [format %.6g [lindex $p 2]]]
        set r [find $e]
        dict lappend groups $r [list $key $e]
    }
    set out {}
    dict for {r items} $groups {
        set keys {}; set ids {}
        foreach it [lsort -index 0 $items] {lappend keys [lindex $it 0]; lappend ids [lindex $it 1]}
        lappend out $keys $ids
    }
    return $out
}
proc ::ElemPattern::find {x} {upvar 1 parent p; while {$p($x) ne $x} {set p($x) $p($p($x)); set x $p($x)}; return $x}
proc ::ElemPattern::nodes_xyz {ids} {
    set out {}
    for {set i 0} {$i < [llength $ids]} {incr i 4096} {
        set c [lrange $ids $i [expr {$i+4095}]]
        foreach x [hm_getvalue nodes user_ids=$c dataname=x] y [hm_getvalue nodes user_ids=$c dataname=y] z [hm_getvalue nodes user_ids=$c dataname=z] {lappend out [list $x $y $z]}
    }
    return $out
}
# N copies, one *duplicatemark each (the plain way, used when the check of the fast way fails).
proc ::ElemPattern::copies_plain {elems N} {
    set blocks {}
    for {set i 0} {$i < $N} {incr i} {
        *createmark elems 1 {*}$elems
        *duplicatemark elems 1 0
        set new [lsort -integer [hm_getmark elems 1]]
        *clearmark elems 1
        if {[llength $new] != [llength $elems]} {error "Duplicating gave [llength $new] new elements instead of [llength $elems]."}
        lappend blocks $new
    }
    return $blocks
}

# elems: element ids; base: one node id; targets: node ids. Returns a dict: copies (number of
# targets used), created (new element ids, in target order), skipped (targets at the base node), ms,
# way (doubling or plain).
proc ::ElemPattern::pattern {elems base targets {way doubling}} {
    variable label
    if {![llength $elems]} {error "Select the elements to copy."}
    if {[llength $base] != 1} {error "Select exactly one base node ([llength $base] selected)."}
    if {![llength $targets]} {error "Select the target nodes."}
    *createmark elems 1 {*}$elems
    set elems [lsort -integer [hm_getmark elems 1]]
    *clearmark elems 1
    if {![llength $elems]} {error "The selected elements no longer exist."}
    set b [xyz $base]
    set vecs {}; set skipped {}
    foreach t $targets {
        set p [xyz $t]
        set v {}; foreach x $p y $b {lappend v [expr {$x-$y}]}
        lassign $v vx vy vz
        set d [expr {sqrt($vx*$vx+$vy*$vy+$vz*$vz)}]
        if {$d <= 1e-12} {lappend skipped $t; continue}
        lappend vecs [list $t $vx $vy $vz $d]
    }
    if {![llength $vecs]} {error "Every target node is the base node: nothing to copy."}
    set before [list [count elems] [count nodes]]
    set t0 [clock milliseconds]
    set created {}
    history_begin $label
    set code [catch {
        set blocks [expr {$way eq "doubling" ? [copies_doubling $elems [llength $vecs]] : [copies_plain $elems [llength $vecs]]}]
        foreach item $vecs blk $blocks {
            lassign $item t vx vy vz d
            *createmark elems 1 {*}$blk
            *createvector 1 $vx $vy $vz
            *translatemark elems 1 1 $d
            *clearmark elems 1
            lappend created {*}$blk
        }
    } msg]
    catch {*clearmark elems 1}
    history_end $label
    if {$code} {
        # undo the partial pattern so the model is as before
        if {[list [count elems] [count nodes]] ne $before} {
            *undohistorystate 1
            if {[list [count elems] [count nodes]] ne $before} {error "$msg Undoing the partial pattern failed: check the model."}
        }
        # the fast way could not be checked: the plain way
        if {$way eq "doubling" && [string match "copy check:*" $msg]} {return [pattern $elems $base $targets plain]}
        error "$msg Nothing changed."
    }
    dict create copies [llength $vecs] created $created skipped $skipped ms [expr {[clock milliseconds]-$t0}] way $way
}

proc ::ElemPattern::message {text} {
    puts "Element pattern: $text"
    catch {hm_usermessage $text}
}

# The picked elements stay shown in the native selection color (mark 2, high) while the nodes are
# picked; the highlight lasts only while the mark is kept, so it is cleared at the end.
proc ::ElemPattern::highlight {elems} {
    *clearmark elems 2
    if {[llength $elems]} {*createmark elems 2 {*}$elems; catch {hm_highlightmark elems 2 high}}
    catch {hm_redraw}
}
proc ::ElemPattern::clear_highlight {elems} {
    catch {*createmark elems 2 {*}$elems; hm_highlightmark elems 2 norm}
    *clearmark elems 2
    catch {hm_redraw}
}

# Menu entry: three selections, then the copies.
proc ::ElemPattern::run {} {
    set elems [pick elems "Pattern: elements to copy"]
    if {![llength $elems]} {message "No elements selected."; return}
    highlight $elems
    set rc [catch {run_nodes $elems} m]
    clear_highlight $elems
    if {$rc} {message $m}
}
proc ::ElemPattern::run_nodes {elems} {
    variable last
    set base [pick nodes "Pattern: ONE base node (the copies move by base -> target)"]
    if {![llength $base]} {message "No base node selected."; return}
    if {[llength $base] > 1} {message "Select exactly one base node ([llength $base] selected). Nothing changed."; return}
    set targets [pick nodes "Pattern: target nodes"]
    if {![llength $targets]} {message "No target nodes selected."; return}
    if {[catch {pattern $elems $base $targets} r]} {message $r; return}
    set last $r
    set text "[dict get $r copies] copies of [llength $elems] elements ([llength [dict get $r created]] new elements) in [dict get $r ms] ms."
    if {[llength [dict get $r skipped]]} {append text " [llength [dict get $r skipped]] target nodes at the base node skipped."}
    message $text
    catch {hm_redraw}
}

if {![info exists ::ElemPattern_no_gui]} {::TestToolSession::run "Pattern" ::ElemPattern::run}
