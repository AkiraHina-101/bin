# Quy tắc bộ nhớ cho agent

Hội thoại này có thể bị dừng bất cứ lúc nào, và khi đó bạn mất mọi thứ chưa ghi ra file. Vì vậy trạng thái công việc nằm trong `.agent/`, ghi trong lúc làm chứ không đợi làm xong.

## Bộ nhớ

- `.agent/STATE.md`: việc đang làm. Ghi đè liên tục, giữ dưới 80 dòng, viết bằng tiếng Việt.
- `.agent/FILES.md` (sổ file), `.agent/KNOWLEDGE.md` (điều nhớ lâu dài), `.agent/PROJECT.md` (thẻ dự án).
- `.agent/LOG.md`: nhật ký, chỉ ghi thêm vào cuối.

Đầu mỗi phiên, chạy `python .agent/tools/files.py brief`. Lệnh này in toàn bộ bộ nhớ và danh sách file đã thay đổi trong một lần, rẻ hơn đọc từng file. Ở các lượt sau trong cùng phiên chỉ cần đọc lại STATE.md.

## Ghi trước, làm sau

- Trước lệnh hay lần sửa file đầu tiên của một yêu cầu, ghi vào STATE.md: yêu cầu của người dùng chép nguyên văn, điều kiện để coi là xong, hướng đi, kế hoạch dạng ô đánh dấu. Câu hỏi trả lời được ngay thì không cần ghi.
- Mỗi bước ghi STATE.md một lần: đánh dấu ô vừa xong, và sửa dòng "Đang làm" thành bước sắp làm kèm tên các file sắp sửa. Nếu bị dừng, dòng này cho biết file nào có thể đang sửa dở.
- Mục "Hướng đi và giả định" là chỗ người dùng đọc để biết bạn đang hiểu việc thế nào. Viết nó và kế hoạch bằng tiếng Việt, câu thường. Ghi thẳng vào mục có sẵn, không tạo mục mới. Đổi hướng thì sửa mục này trước rồi mới làm.
- LOG.md chỉ ghi ba thứ, mỗi thứ một dòng bắt đầu bằng `BỎ`, `LẠ` hoặc `XONG`: hướng đã thử rồi bỏ kèm lý do, điều bất ngờ, và dòng tổng kết khi xong việc (kết quả, phần chưa kiểm chứng, giả định đã tự quyết).
- Điều đáng nhớ lâu (người dùng sửa cách làm của bạn, một quyết định, nguyên nhân một lỗi khó) thì ghi ngay vào KNOWLEDGE.md.
- Tin nhắn mới là việc khác trong khi việc cũ còn dang dở: chuyển việc cũ xuống mục "Tạm gác" trước, tối đa 3 việc.

## Tự quyết và làm cho xong

Người dùng thường không ngồi chờ, nên một câu hỏi giữa chừng làm cả việc đứng lại. Hãy làm tới khi đạt điều kiện xong.

- Thiếu thông tin thì tự tìm trước. Vẫn chưa rõ mà lựa chọn sửa lại được về sau: chọn phương án hợp lý nhất, ghi giả định vào STATE.md kèm chỗ phải sửa nếu sai, rồi làm tiếp. Chỗ phải sửa phải là tên có thật trong mã lúc bạn báo cáo; nếu chưa có thì nói là cần viết thêm.
- Chỉ dừng lại hỏi khi: hành động không hoàn tác được (xoá file không do bạn tạo, ghi đè dữ liệu gốc, gửi thứ gì ra ngoài máy); yêu cầu có hai cách hiểu cho ra kết quả khác hẳn nhau; hoặc cần thứ chỉ người dùng có.
- Đã thử hai cách khác nhau cho cùng một lỗi mà không tiến triển thì dừng và báo đã thử gì.
- Chưa chạy test hoặc chạy thử thì chưa gọi là xong. Phần nào không kiểm được thì nói rõ.

## File

- File thử nghiệm, script dùng một lần, kết quả trung gian: đặt trong `.agent/scratch/`, không rải trong dự án. Script dựng ra sản phẩm của dự án (dựng file, sinh mã) không phải file nháp: nó là nguồn của sản phẩm, đặt nó trong dự án.
- File thuộc về dự án: đặt đúng chỗ, và thêm một dòng vào bảng "File do agent tạo" trong FILES.md ngay khi tạo.
- Tra FILES.md trước khi đọc. Không mở những gì trong mục "Không đọc" và trong `.agent/scratch/`. File đã có ghi chú thì dùng ghi chú, chỉ mở đúng phần cần.
- Vừa đọc hết một file dài trên 200 dòng thì ghi ngay vào mục "Ghi chú đã đọc" của FILES.md, trước khi sửa gì: nó chứa gì và phần quan trọng ở đâu. Phiên sau sẽ dùng ghi chú này thay vì trả tiền đọc lại cả file.
- Không quét lại cả dự án để lấy bối cảnh. Muốn biết file nào mới hay đã đổi, chạy `python .agent/tools/files.py diff`. Nếu kết quả có chữ "QUÁ DÀI", nhắc người dùng gõ "chốt".

## Lệnh của người dùng

Khi tin nhắn của người dùng là một trong các từ dưới đây (có dấu hoặc không dấu, có thể kèm ghi chú), mở file tương ứng và làm theo phần nằm dưới dòng gạch ngang, coi đó là lời của người dùng.

| Người dùng gõ | Mở file |
|---|---|
| khởi tạo | `.agent/prompts/1-khoi-tao.md` |
| tiếp tục | `.agent/prompts/2-tiep-tuc.md` |
| nén | `.agent/prompts/3-nen.md` |
| chốt | `.agent/prompts/4-chot.md` |
| kiểm kê | `.agent/prompts/5-kiem-ke.md` |

## Giới hạn

- Không ghi mật khẩu, khoá API hay dữ liệu cá nhân vào `.agent/`.
- Viết ngắn và cụ thể: tên file, tên hàm, lệnh đã chạy, kết quả. Một phiên mới không biết gì phải đọc hiểu được.
