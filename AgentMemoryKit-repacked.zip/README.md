# Bộ kit bộ nhớ cho agent

Giúp agent AI không mất việc đang làm khi bị bấm dừng hoặc khi mở chat mới, và không phải đọc lại cả dự án (kể cả file rác) để lấy lại bối cảnh.

Bộ kit gồm các file markdown và một script Python nhỏ chỉ dùng thư viện chuẩn (Python 3.8 trở lên). Không cần cài đặt gì, không cần git.

## Ba cơ chế

1. **Ghi trước, làm sau.** Agent chép nguyên văn yêu cầu, hướng đi và kế hoạch vào `STATE.md` trước khi làm, rồi cập nhật sau mỗi bước. Bấm dừng lúc nào thì file cũng đã có.
2. **Vị trí nói lên loại file.** Mọi file thử nghiệm và file tạm nằm trong `.agent/scratch/`. File thuộc về dự án được ghi một dòng vào sổ `FILES.md` ngay khi tạo. Agent có quên ghi thì vị trí của file vẫn cho biết nó là gì.
3. **Không dựa vào trí nhớ của agent để biết nó vừa làm gì.** Script `files.py` so thư mục dự án với một mốc đã lưu (danh sách tên file, kích thước và giờ sửa tại một thời điểm) và in ra file nào mới, file nào đã sửa, file nào chưa có trong sổ. Phiên sau đọc danh sách ngắn này thay vì quét lại dự án.

Cùng với đó, `FILES.md` giữ ghi chú về các file dài đã đọc và danh sách thứ không cần đọc, để phiên sau không trả tiền đọc lại.

## Trong bộ kit có gì

```
AGENTS.md              quy tắc, công cụ AI tự nạp đầu mỗi phiên
.agent/
  STATE.md             yêu cầu đang làm, hướng đi và giả định, kế hoạch
  LOG.md               nhật ký: hướng đã bỏ, điều bất ngờ, tổng kết
  FILES.md             sổ file: không đọc gì, đã đọc gì, agent đã tạo gì
  KNOWLEDGE.md         điều cần nhớ lâu dài
  PROJECT.md           thẻ phân loại dự án
  scratch/             chỗ cho file thử nghiệm và file tạm
  tools/files.py       so sánh file hiện có với mốc đã lưu gần nhất
  prompts/             năm quy trình, agent tự mở khi bạn gõ lệnh
PROMPTS.txt            nội dung năm quy trình, để bạn đọc
```

## Cài vào một dự án

1. Chép `AGENTS.md` và thư mục `.agent/` vào thư mục gốc của dự án.
2. Đổi tên `AGENTS.md` thành đúng tên file quy tắc mà công cụ AI của bạn tự nạp. Nếu dự án đã có file quy tắc, dán nội dung `AGENTS.md` vào đầu file đó.
3. Mở chat mới và gõ: `khởi tạo`
4. Trả lời các câu agent hỏi. Nếu agent báo có file đáng ngờ từ các phiên cũ, gõ tiếp: `kiểm kê`

## Năm lệnh

Bạn chỉ cần gõ đúng một từ. Agent tự mở quy trình tương ứng trong `.agent/prompts/` và làm theo. Gõ không dấu cũng được.

| Gõ | Khi nào | Agent làm gì |
|---|---|---|
| `khởi tạo` | Lần đầu đưa bộ kit vào dự án | Điền thẻ dự án và sổ file |
| `tiếp tục` | Vừa bấm dừng, hoặc mở chat mới cho việc cũ | Đọc bộ nhớ, xem file nào đã đổi, kiểm tra chỗ sửa dở, làm tiếp |
| `nén` | Hội thoại dài, agent lặp lại hoặc quên chỉ dẫn | Dồn mọi thứ vào bộ nhớ. Sau đó bạn mở chat mới và gõ `tiếp tục` |
| `chốt` | Xong một việc | Dọn file nháp (đợi bạn duyệt), thu gọn bộ nhớ, lưu mốc mới |
| `kiểm kê` | Dự án đầy file lạ không ai nhớ | Phân loại file, trình bảng cho bạn duyệt |

Giao việc bình thường thì không cần gõ lệnh nào: agent tự ghi bộ nhớ theo `AGENTS.md`.

Nếu agent không nhận ra lệnh, mở `PROMPTS.txt`, chép phần DÁN của lệnh đó vào khung chat. `PROMPTS.txt` là bản sao để đọc; bản agent dùng nằm trong `.agent/prompts/`, nên sửa quy trình thì sửa ở đó.

## Xem agent đang hiểu việc thế nào

Mở `.agent/STATE.md`, mục "Hướng đi và giả định". Agent được yêu cầu viết mục này bằng tiếng Việt, câu thường: nó đang giải quyết theo cách nào, và những gì nó đã tự quyết thay bạn. Thấy sai thì bấm dừng và nói lại; bạn cũng có thể sửa thẳng vào file rồi gõ `tiếp tục`.

## Tự xem agent vừa làm gì

Bạn có thể tự chạy lệnh này bất cứ lúc nào, không cần hỏi agent:

```
python .agent/tools/files.py diff
```

Kết quả có dạng:

```
So với mốc lưu lúc 2026-11-16 22:00 (cột giờ là lần sửa cuối của file):

MỚI (13)
  test2.py                     2 B  16/11 22:14  CHƯA GHI SỔ
  .agent/scratch/try1.py       2 B  16/11 22:14  nháp
  output/ (10 file)           20 B  16/11 22:15  có trong sổ
  src/helper.py                2 B  16/11 22:14  có trong sổ

ĐÃ SỬA (1)
  src/main.py                 19 B  16/11 22:13

Thư mục nháp hiện có 1 file, 2 B.
1 file mới chưa ghi sổ.
Bộ nhớ: STATE.md 34 dòng, LOG.md 212 dòng (QUÁ DÀI, ngưỡng 200), FILES.md 41 dòng, KNOWLEDGE.md 18 dòng.
```

- **CHƯA GHI SỔ** là file agent tạo ra mà chưa khai báo. Đây là những file cần phân loại.
- **nháp** là file trong `.agent/scratch/`, bỏ được.
- **có trong sổ** là file, hoặc thư mục chứa nó, đã được ghi trong `FILES.md`.
- **QUÁ DÀI** nghĩa là một file bộ nhớ đã vượt ngưỡng và nên được thu gọn bằng lệnh `chốt`.

Lệnh `python .agent/tools/files.py brief` in thêm toàn bộ bộ nhớ (trạng thái, thẻ dự án, kiến thức, sổ file, cuối nhật ký) phía trên danh sách này. Agent dùng nó đầu mỗi phiên để đọc mọi thứ trong một lần; bạn cũng có thể chạy nó để xem agent đang nhớ gì.

Mốc so sánh được lưu bằng `python .agent/tools/files.py snap`. Lệnh này ghi tên, kích thước và giờ sửa của mọi file vào `.agent/snapshot.json`, không lưu nội dung. Các lệnh `khởi tạo`, `chốt` và `kiểm kê` tự chạy nó sau khi dọn xong, nên bạn hiếm khi phải gõ tay.

## File nào lớn dần

| File | Lớn dần khi nào | Được đọc khi nào | Giới hạn bằng gì |
|---|---|---|---|
| `STATE.md` | Không, vì bị ghi đè | Mỗi lượt | Ngưỡng 80 dòng; "Tạm gác" tối đa 3 việc |
| `LOG.md` | Chậm: mỗi hướng bị bỏ, mỗi việc xong | Chỉ 20 dòng cuối, lúc tiếp tục | Ngưỡng 200 dòng, phần cũ chuyển sang `archive/` |
| `FILES.md` | Mỗi file tạo ra, mỗi file dài được đọc | Một lần mỗi phiên | Ngưỡng 150 dòng; lệnh `chốt` xoá dòng thừa |
| `KNOWLEDGE.md` | Chậm, mỗi bài học một mục | Một lần mỗi phiên | Ngưỡng 150 dòng; lệnh `chốt` gộp mục trùng |
| `scratch/` | Mỗi file thử nghiệm | Không được đọc | Lệnh `chốt` dọn sau khi bạn duyệt |
| `archive/`, `snapshot.json` | Chậm | Không bao giờ | Chỉ tốn chỗ trên đĩa |

Việc thu gọn nằm cả ở lệnh `chốt`. Nếu bạn không bao giờ dùng nó, ba thứ sẽ phình dần: sổ file, thư mục nháp, và danh sách thay đổi mà `files.py diff` in ra (vì mốc so sánh ngày càng cũ). Dấu hiệu nhận biết là chữ "QUÁ DÀI" hoặc danh sách thay đổi dài hàng chục dòng.

## Kiểm tra bộ kit có hoạt động

Giao một việc cần vài bước, đợi agent làm được một hai bước rồi bấm dừng. Mở `.agent/STATE.md`: phải thấy nguyên văn yêu cầu của bạn, hướng đi bằng tiếng Việt, kế hoạch có ô đã đánh dấu, và dòng "Đang làm". Nếu file vẫn như mẫu, công cụ chưa nạp file quy tắc (xem lại bước 2 ở phần cài).

## Khi agent quên ghi

Hội thoại càng dài, agent càng dễ bỏ sót việc ghi. Khi thấy `STATE.md` cũ hơn thực tế, nhắn: "Cập nhật .agent/STATE.md và FILES.md theo đúng tình trạng hiện tại rồi mới làm tiếp." Nếu việc này lặp lại, đã đến lúc gõ `nén`.

## Giới hạn

- **Bộ kit không bật được prompt caching.** Đó là tính năng ở tầng gọi API, do công cụ AI quyết định. Bộ kit chỉ giúp gián tiếp: `AGENTS.md` ít thay đổi, nên nếu công cụ có cache thì phần đầu ngữ cảnh được dùng lại.
- **Bước đang chạy lúc bấm dừng có thể bị sửa dở, và bộ kit không hoàn tác được.** Nó ghi lại bước nào và file nào, và lệnh `tiếp tục` yêu cầu agent kiểm tra các file đó.
- **`files.py` chỉ thấy thay đổi so với mốc gần nhất.** Nếu lưu mốc khi dự án còn rác, rác đó sẽ không được báo là mới nữa. Vì vậy chỉ lưu mốc sau khi đã dọn.
- **Dừng và tiếp tục nhiều lần trong cùng một chat làm chat dài ra**, vì mỗi lần tiếp tục agent đọc lại các file bộ nhớ. Sau ba bốn lần, nên mở chat mới rồi gõ `tiếp tục`.
- **Không có Python thì bộ kit vẫn dùng được.** Các quy trình đều có cách thay thế là liệt kê thư mục, chỉ tốn hơn một chút.
- **Đừng để thông tin mật vào `.agent/`.**
