# Kiến thức bền vững

Chỉ ghi điều sẽ thay đổi cách làm ở các phiên sau. Không ghi tiến độ hay việc đã xong (đó là việc của LOG.md). Điều nào hết đúng thì sửa hoặc xoá.

## Sở thích và chỉ dẫn của người dùng

<!-- Mẫu: Điều gì. Vì sao. Áp dụng khi nào. -->

## Quyết định đã chốt

<!-- Mẫu: Chọn A thay vì B. Vì sao. -->

## Bẫy đã gặp

<!-- Mẫu: Triệu chứng. Nguyên nhân thật. Cách xử lý. -->
