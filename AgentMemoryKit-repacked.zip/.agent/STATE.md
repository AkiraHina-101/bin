# Trạng thái

Viết cả file này bằng tiếng Việt, câu thường, để người dùng đọc hiểu mà không cần xem mã. Khi có việc, thay các dòng "Không có" và "-" bên dưới bằng nội dung thật.

## Yêu cầu hiện tại

Không có. (Khi có việc: chép nguyên văn tin nhắn của người dùng vào đây.)

## Xong khi

-

## Hướng đi và giả định

**Hướng đi:** Chưa có. (Giải quyết theo cách nào và vì sao, hai ba câu.)

**Giả định đã tự quyết:** Chưa có. (Mỗi dòng một điều đã tự quyết thay người dùng, kèm chỗ phải sửa nếu sai.)

## Kế hoạch

- [ ] -

## Đang làm

Không có. (Khi làm: bước nào, đang sửa những file nào.)

## Bước kế tiếp

-

## Điều cần nhớ cho việc này

-

## Tạm gác

Không có. (Việc cũ chưa xong khi người dùng chuyển sang việc khác. Giữ tối đa 3 việc.)
