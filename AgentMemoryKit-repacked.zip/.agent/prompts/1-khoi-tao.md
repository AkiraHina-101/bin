# Lệnh 1: khởi tạo

Dùng một lần khi mới đưa bộ kit vào dự án.

---

Tôi vừa thêm thư mục `.agent/` vào dự án này để bạn lưu bộ nhớ giữa các phiên. Việc của bạn bây giờ là điền `.agent/PROJECT.md` và `.agent/FILES.md`, chưa sửa gì khác trong dự án.

Cách làm:

1. Chạy `python .agent/tools/files.py diff` để lấy danh sách file kèm kích thước. Lần đầu chưa có mốc so sánh nên nó liệt kê toàn bộ. Nếu không chạy được Python, liệt kê cây thư mục kèm kích thước thay thế.
2. Đọc README, các file cấu hình (danh sách thư viện, file build, file cài đặt) và file điểm vào. Chưa cần đọc hết mã nguồn.
3. Điền từng mục của `.agent/PROJECT.md` theo đúng mẫu có sẵn. Ở mục "Loại dự án" chọn đúng một loại trong danh sách. Mục nào không tìm thấy bằng chứng trong dự án thì ghi "chưa rõ", vì một phỏng đoán sai ở đây sẽ làm sai các phiên sau.
4. Ghi lệnh chạy và lệnh kiểm tra đúng như dự án đang dùng. Nếu chạy thử được mà không thay đổi gì thì chạy để xác nhận, và ghi rõ lệnh nào đã chạy thử, lệnh nào chưa.
5. Trong `.agent/FILES.md`, điền mục "Không đọc" (thư mục kết quả, dữ liệu lớn, file nhị phân, mã của bên thứ ba) và viết "Ghi chú đã đọc" cho những file dài bạn vừa đọc ở bước 2.
6. Nhìn danh sách ở bước 1 và chỉ ra những file trông như đồ thử nghiệm hay đồ tạm của các phiên trước (tên kiểu `test2`, `tmp`, `debug`, `copy`, `old`, nằm lạc chỗ). Chưa mở và chưa xoá chúng.
7. Thêm một dòng `XONG` vào `.agent/LOG.md` ghi việc khởi tạo.

Xong thì báo cho tôi: dự án thuộc loại nào, các mục còn "chưa rõ", những câu bạn cần tôi trả lời, và danh sách file đáng ngờ ở bước 6.

Nếu không có file đáng ngờ, chạy `python .agent/tools/files.py snap` để lưu danh sách file hiện tại làm mốc so sánh. Nếu có, đừng lưu mốc: tôi sẽ gõ "kiểm kê" trước.
