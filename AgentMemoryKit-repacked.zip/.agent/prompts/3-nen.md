# Lệnh 3: nén

Dùng khi hội thoại đã dài và agent bắt đầu chậm, lặp lại hoặc quên chỉ dẫn. Sau khi agent làm xong, mở chat mới và gõ "tiếp tục".

---

Hội thoại này sắp bị đóng và phiên sau sẽ không đọc được nó. Hãy dừng công việc đang làm ở một điểm an toàn, rồi chuyển mọi thứ còn giá trị trong hội thoại vào `.agent/`. Chưa làm thêm bước nào của kế hoạch.

Rà lại toàn bộ hội thoại và ghi:

1. **STATE.md**: yêu cầu hiện tại nguyên văn, kể cả mọi lần tôi sửa hay bổ sung yêu cầu; kế hoạch với các ô đã đánh dấu đúng thực tế; bước kế tiếp đủ cụ thể để làm ngay (file nào, hàm nào, thay đổi gì); mục "Hướng đi và giả định" viết bằng tiếng Việt, gồm cả những giả định bạn đã ngầm dùng mà chưa ghi; các câu hỏi còn mở.
2. **FILES.md**: mọi file bạn đã tạo trong hội thoại này mà chưa có trong sổ, kèm loại và mục đích; và "Ghi chú đã đọc" cho những file dài bạn đã đọc, để phiên sau không phải đọc lại. Chạy `python .agent/tools/files.py diff` để chắc không sót file nào.
3. **KNOWLEDGE.md**: mọi chỉ dẫn tôi đã đưa về cách làm việc, mọi quyết định đã chốt kèm lý do, mọi lỗi đã tìm ra nguyên nhân.
4. **LOG.md**: các hướng đã thử rồi bỏ kèm lý do, và những điều bất ngờ gặp phải, để phiên sau không thử lại. Các bước đã xong thì không cần ghi ở đây, vì ô đánh dấu trong STATE.md đã cho biết.

Phiên sau chỉ có các file này, nên những gì bạn đang ngầm hiểu (tên biến đang dùng, lý do chọn cách này, phần nào đã kiểm chứng và phần nào chưa) phải được viết ra thành chữ.

Xong thì đọc lại STATE.md như một người chưa biết gì và tự hỏi: mình làm tiếp được ngay không? Thiếu gì thì bổ sung. Cuối cùng báo cho tôi danh sách những gì đã ghi vào từng file.
