# Lệnh 2: tiếp tục

Dùng sau khi bấm dừng, hoặc khi mở chat mới để làm tiếp việc cũ.

---

Phiên trước bị dừng giữa chừng và bạn không còn nhớ gì về nó. Mọi thứ cần biết nằm trong `.agent/`. Đừng quét lại dự án để lấy bối cảnh: việc đó tốn kém và sẽ kéo cả file rác vào.

1. Chạy `python .agent/tools/files.py brief`. Một lệnh này in ra toàn bộ bộ nhớ (STATE, PROJECT, KNOWLEDGE, FILES, 20 dòng cuối của LOG), nên không cần mở từng file. Nếu không chạy được Python, đọc lần lượt các file đó trong `.agent/`.
2. Phần "File thay đổi" ở cuối kết quả cho biết file nào mới, file nào đã sửa kể từ mốc gần nhất, tức là dấu vết của phiên trước. Nếu không có Python, liệt kê các file sửa gần đây nhất theo ngày giờ thay thế.
3. Với từng file mới ghi "CHƯA GHI SỔ": phiên trước đã tạo nó rồi bị dừng trước khi kịp ghi. Xét theo tên, vị trí, kích thước và nếu cần thì 20 dòng đầu, rồi đối chiếu với kế hoạch trong STATE.md. Thuộc về dự án thì ghi vào sổ; là đồ thử nghiệm thì chuyển vào `.agent/scratch/`; không đoán được thì để nguyên và hỏi tôi.
4. Nếu STATE.md có dòng "Đang làm", bước đó có thể đã bị cắt ngang. Kiểm tra các file ghi ở dòng đó, cùng một vài file có giờ sửa mới nhất trong danh sách, xem có đang sửa dở không (thiếu đoạn, lỗi cú pháp, chỉ sửa một nửa số chỗ, một đoạn bị thêm hai lần) trước khi tin vào các ô đã đánh dấu. Các file sửa từ những lần trước đó thì không cần kiểm lại.
5. Nếu phiên trước đang điều khiển một chương trình ngoài lúc bị dừng (ví dụ Excel), chương trình đó có thể còn chạy và đang giữ khoá file. Dấu hiệu: file khoá kiểu `~$tên-file` nằm cạnh file đang làm, hoặc tiến trình chạy ở chế độ tự động hoá mà không ai dùng. Gặp vậy thì chưa chạy lại lệnh nào dùng chương trình đó: báo cho tôi tên file bị khoá và mã tiến trình (PID) để tôi đóng, rồi làm các phần không cần tới nó.
6. Báo cho tôi bằng tiếng Việt trong tối đa 8 dòng: yêu cầu đang làm là gì, hướng đi và các giả định đang ghi trong STATE.md, xong tới bước nào, có gì hỏng dở không, file nào bạn vừa phân loại, bước kế tiếp là gì. Nếu kết quả ở bước 2 có chữ "QUÁ DÀI" hoặc báo sổ trỏ tới thứ không tồn tại, nhắc tôi gõ "chốt" khi xong việc.
7. Rồi làm tiếp từ bước kế tiếp, không cần đợi tôi xác nhận, trừ khi STATE.md và tình trạng thật của các file mâu thuẫn nhau. Khi đó dừng lại và hỏi tôi.

Chỉ mở thêm file khi bước kế tiếp cần đến nó. File đã có "Ghi chú đã đọc" trong sổ thì dùng ghi chú và chỉ mở đúng đoạn cần. File dài chưa có ghi chú mà bạn phải đọc hết thì viết ghi chú vào FILES.md ngay sau khi đọc, trước khi sửa gì.

Nếu STATE.md ghi "Không có" yêu cầu nào, chỉ cần báo vậy và cho tôi biết việc gần nhất trong LOG.md.
