# Lệnh 4: chốt

Dùng khi một việc đã xong và bạn sắp giao việc khác.

---

Việc hiện tại coi như xong. Hãy dọn bộ nhớ và dọn file trước khi nhận việc mới.

1. Kiểm tra lại mục "Xong khi" trong `.agent/STATE.md`. Điều kiện nào chưa đạt hoặc chưa kiểm chứng thì nói rõ với tôi, đừng coi là xong.
2. Chạy `python .agent/tools/files.py diff`. File mới nào còn "CHƯA GHI SỔ" thì ghi vào `.agent/FILES.md` hoặc chuyển vào `.agent/scratch/`.
3. Lập bảng cho tôi duyệt, gồm mọi file trong `.agent/scratch/` và mọi dòng `chờ xoá` trong sổ, mỗi file một đề xuất kèm lý do một dòng:
   - **Đưa vào dự án**: có giá trị lâu dài (ví dụ một test nên nằm trong bộ test), nêu vị trí mới.
   - **Giữ làm nháp**: phiên sau còn dùng.
   - **Xoá**.
   Đợi tôi trả lời rồi mới di chuyển hay xoá. Sau đó sửa sổ cho khớp.
4. Đọc lại phần LOG.md của việc này và mục "Điều cần nhớ cho việc này" trong STATE.md. Điều nào sẽ còn có ích cho việc khác thì chuyển vào `.agent/KNOWLEDGE.md`. Tiến độ và chi tiết chỉ thuộc việc này thì không chuyển.
5. Nếu việc này làm thay đổi cách chạy, cách kiểm tra, cấu trúc thư mục hay ràng buộc của dự án, cập nhật `.agent/PROJECT.md`. Nếu bạn đã sửa một file có "Ghi chú đã đọc", sửa ghi chú cho khớp.
6. Nếu việc này chưa có dòng `XONG` trong LOG.md, thêm một dòng: đã giao gì, còn gì chưa làm, và các giả định đã tự quyết.
7. Đặt lại STATE.md: "Yêu cầu hiện tại" về "Không có", xoá kế hoạch và mục "Hướng đi và giả định" của việc cũ. Mục "Tạm gác" giữ tối đa 3 việc; hỏi tôi việc nào bỏ được.
8. Chạy `python .agent/tools/files.py snap` để lưu mốc mới cho việc sau.
9. Thu gọn bộ nhớ để các phiên sau đọc rẻ hơn:
   - Trong bảng "File do agent tạo" của FILES.md, xoá các dòng loại `giữ`. Sau khi lưu mốc ở bước 8, chúng đã là file bình thường của dự án và không cần nằm trong sổ nữa. Chỉ giữ các dòng `nháp còn dùng`.
   - Chạy lại `python .agent/tools/files.py diff`. Xoá khỏi sổ những dòng nó báo là trỏ tới thứ không tồn tại.
   - File nào bị ghi "QUÁ DÀI": với LOG.md, chuyển phần cũ sang `.agent/archive/` và giữ 30 dòng cuối; với KNOWLEDGE.md, gộp các mục trùng và xoá mục đã hết đúng; với FILES.md, rút gọn các ghi chú dài.

Báo cho tôi những gì đã thêm vào KNOWLEDGE.md và những gì đã xoá ở bước 9, để tôi sửa nếu bạn hiểu sai.
