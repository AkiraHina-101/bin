# Lệnh 5: kiểm kê

Dùng khi dự án đã bừa bộn file thử nghiệm và file tạm mà không ai nhớ cái nào là gì: lúc mới đưa bộ kit vào một dự án cũ, hoặc sau vài phiên agent quên ghi sổ.

---

Dự án này có nhiều file do các phiên AI trước tạo ra và không ai ghi lại chúng là gì. Hãy phân loại chúng giúp tôi với chi phí đọc thấp nhất. Chưa di chuyển hay xoá gì cho tới khi tôi duyệt.

1. Chạy `python .agent/tools/files.py diff` và đọc `.agent/FILES.md`. Nếu không chạy được Python, liệt kê toàn bộ file kèm kích thước và ngày sửa thay thế.
2. Xét mọi file ghi "CHƯA GHI SỔ". Phân loại dựa trên tên, vị trí, kích thước, ngày sửa, và việc có file nào khác trong dự án gọi tới nó hay không (tìm tên file trong mã nguồn). Chỉ khi các dấu hiệu đó chưa đủ mới mở 20 dòng đầu. Không đọc hết file nào ở bước này.
3. Xếp mỗi file vào một nhóm:
   - **Thuộc dự án**: được mã nguồn, bộ test hay tài liệu dùng tới.
   - **Nháp đáng giữ**: script hay dữ liệu thử nghiệm dùng lại được.
   - **Rác**: bản sao, kết quả chạy cũ, thử nghiệm đã bị thay thế, file rỗng.
   - **Không chắc**: nêu điều bạn cần biết để quyết định. Đừng đoán.
4. Trình cho tôi một bảng: đường dẫn, kích thước, nhóm, lý do một dòng, việc đề xuất (để nguyên và ghi sổ / chuyển vào `.agent/scratch/` / xoá). Thư mục có nhiều file cùng loại thì gộp thành một dòng.
5. Sau khi tôi duyệt: thực hiện đúng những gì tôi đồng ý, ghi các file được giữ vào `.agent/FILES.md`, thêm các thư mục kết quả vào mục "Không đọc", ghi một dòng vào `.agent/LOG.md`, rồi chạy `python .agent/tools/files.py snap`.

Trước khi xoá thứ gì đang được file khác gọi tới, hoặc file không thuộc nhóm nào rõ ràng, hỏi lại tôi dù tôi đã duyệt cả bảng.
