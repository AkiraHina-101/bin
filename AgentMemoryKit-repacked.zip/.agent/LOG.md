# Nhật ký

Chỉ ghi thêm vào cuối, không sửa dòng cũ. Không ghi từng bước đã xong (ô đánh dấu trong STATE.md đã cho biết). Chỉ ghi ba loại, mỗi dòng bắt đầu bằng tên loại:

- `BỎ`: hướng đã thử rồi bỏ, và lý do, để phiên sau không thử lại.
- `LẠ`: điều bất ngờ, khác với dự đoán.
- `XONG`: tổng kết một việc: đã giao gì, phần nào chưa kiểm chứng, giả định nào đã tự quyết.

Ví dụ:

`BỎ | Đọc file bằng openpyxl | thư viện không được phép cài, dùng lại pywin32`
`LẠ | Sheet "Data" có dòng tiêu đề lặp lại ở dòng 501 | đã lọc trong build_report()`
`XONG | Báo cáo tháng thêm cột chênh lệch | chưa thử với file trên 10.000 dòng | giả định: làm tròn 2 chữ số`

---

