# Sổ file

Tra sổ này trước khi mở file, để không đọc lại thứ đã đọc và không đọc rác. Đường dẫn luôn viết trong dấu `` ` `` và tính từ thư mục gốc dự án, vì công cụ `files.py` dò theo đúng dạng đó.

## Không đọc

Thư mục và file không cần mở: kết quả sinh ra, dữ liệu lớn, mã của bên thứ ba. Chỉ mở khi người dùng yêu cầu.

<!-- - `output/` — kết quả chạy, sinh lại được -->

## Ghi chú đã đọc

File gốc của dự án đã đọc và tốn công hiểu. Nếu file chưa đổi kể từ lúc ghi chú thì dùng ghi chú thay cho đọc lại, và chỉ mở đúng phần cần.

<!--
### `src/report.py` (412 dòng, 15.4 KB lúc đọc)
- Chứa gì: dựng báo cáo tháng từ sheet "Data"
- Phần quan trọng: `build_report()` dòng 120-210; bảng ánh xạ cột ở đầu file
- Cần mở lại khi: sửa cách tính tổng
-->

## File do agent tạo

Ghi một dòng ngay khi tạo file. Loại là một trong: `giữ` (thuộc về dự án), `nháp còn dùng` (nằm trong `.agent/scratch/` nhưng phiên sau còn cần), `chờ xoá`.

| Đường dẫn | Loại | Để làm gì | Tạo trong việc nào |
|---|---|---|---|
