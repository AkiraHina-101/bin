# -*- coding: utf-8 -*-
"""So sánh file của dự án với mốc đã lưu gần nhất.

    python .agent/tools/files.py brief   in toàn bộ bộ nhớ và danh sách thay đổi trong một lần
    python .agent/tools/files.py diff    xem file mới, đã sửa, đã xoá
    python .agent/tools/files.py snap    lưu danh sách file hiện tại làm mốc

Chỉ dùng thư viện chuẩn, chạy được từ Python 3.8.
"""
import json
import os
import re
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
AGENT = os.path.join(ROOT, ".agent")
SNAPSHOT = os.path.join(AGENT, "snapshot.json")
BOOK = os.path.join(AGENT, "FILES.md")
SCRATCH = ".agent/scratch/"
SKIP_DIRS = {
    ".git", ".hg", ".svn", "__pycache__", "node_modules", ".venv", "venv",
    ".idea", ".vs", ".mypy_cache", ".pytest_cache",
}
# Thư mục có nhiều file cùng loại hơn số này thì gộp thành một dòng.
COLLAPSE_OVER = 8
# Số dòng tối đa của từng file bộ nhớ trước khi bị cảnh báo.
MEMORY_LIMITS = [("STATE.md", 80), ("LOG.md", 200), ("FILES.md", 150), ("KNOWLEDGE.md", 150)]
# File văn bản dài hơn số dòng này nên có ghi chú trong sổ sau khi được đọc.
LONG_FILE_LINES = 200
TEXT_EXTENSIONS = {
    ".py", ".bas", ".cls", ".frm", ".vba", ".vbs", ".js", ".ts", ".java", ".cs", ".c",
    ".cpp", ".h", ".sql", ".ps1", ".bat", ".sh", ".md", ".txt", ".html", ".css", ".xml",
}


def scan():
    """Trả về {đường dẫn tương đối: [kích thước, thời điểm sửa]}."""
    files = {}
    for dirpath, dirnames, filenames in os.walk(ROOT):
        rel_dir = os.path.relpath(dirpath, ROOT).replace(os.sep, "/")
        if rel_dir == ".":
            rel_dir = ""
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        if rel_dir == ".agent":
            # Các file bộ nhớ đổi liên tục, chỉ theo dõi thư mục nháp.
            dirnames[:] = [d for d in dirnames if d == "scratch"]
            continue
        for name in filenames:
            rel = rel_dir + "/" + name if rel_dir else name
            try:
                st = os.stat(os.path.join(dirpath, name))
            except OSError:
                continue
            files[rel] = [st.st_size, int(st.st_mtime)]
    return files


def load_snapshot():
    try:
        with open(SNAPSHOT, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def load_book():
    try:
        with open(BOOK, "r", encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return ""
    # Bỏ các ví dụ mẫu nằm trong chú thích để chúng không bị tính là đã ghi sổ.
    return re.sub(r"<!--.*?-->", "", text, flags=re.S).replace("\\", "/")


def in_book(path, book):
    """Có trong sổ nếu chính file, hoặc một thư mục chứa nó, được ghi trong dấu `."""
    if ("`" + path + "`") in book:
        return True
    parts = path.split("/")
    return any(
        ("`" + "/".join(parts[:i]) + "/`") in book for i in range(1, len(parts))
    )


def book_dir(path, book):
    """Thư mục cha gần gốc nhất của file mà sổ có ghi, hoặc None."""
    parts = path.split("/")
    for i in range(1, len(parts)):
        d = "/".join(parts[:i]) + "/"
        if ("`" + d + "`") in book:
            return d
    return None


def book_entries(book):
    """Đường dẫn đứng đầu mỗi dòng của sổ: dòng bảng, gạch đầu dòng, tiêu đề."""
    entries = []
    for line in book.splitlines():
        match = re.match(r"\s*(?:\||-|#+)\s*`([^`]+)`", line)
        if match:
            entries.append(match.group(1))
    return entries


def size_text(n):
    if n < 1024:
        return "%d B" % n
    if n < 1024 * 1024:
        return "%.1f KB" % (n / 1024.0)
    return "%.1f MB" % (n / 1048576.0)


def time_text(mtime):
    return time.strftime("%d/%m %H:%M", time.localtime(mtime))


def tag(path, book):
    if path.startswith(SCRATCH):
        # Sổ có nhắc tên thư mục nháp, nên ở đây chỉ tính khi ghi đúng tên file.
        return "nháp còn dùng" if ("`" + path + "`") in book else "nháp"
    return "có trong sổ" if in_book(path, book) else "CHƯA GHI SỔ"


def print_row(name, size, mtime, note):
    print("  %-46s %9s  %s%s" % (name, size_text(size), time_text(mtime), note))


def print_group(title, paths, files, book, with_tag):
    if not paths:
        return
    print("")
    print("%s (%d)" % (title, len(paths)))
    by_dir = {}
    known_dirs = set()
    for p in paths:
        d = book_dir(p, book)
        if d and not p.startswith(SCRATCH):
            # Cả thư mục đã được ghi trong sổ: gộp mọi file bên dưới thành một dòng.
            known_dirs.add(d)
        else:
            d = p.rsplit("/", 1)[0] + "/" if "/" in p else ""
        by_dir.setdefault(d, []).append(p)
    for d in sorted(by_dir):
        items = by_dir[d]
        if d and (d in known_dirs or len(items) > COLLAPSE_OVER):
            note = ""
            if with_tag:
                if d.startswith(SCRATCH):
                    note = "  nháp"
                else:
                    missing = sum(1 for p in items if not in_book(p, book))
                    note = "  %d CHƯA GHI SỔ" % missing if missing else "  có trong sổ"
            print_row(
                d + " (%d file)" % len(items),
                sum(files[p][0] for p in items),
                max(files[p][1] for p in items),
                note,
            )
            continue
        for p in items:
            print_row(p, files[p][0], files[p][1], "  " + tag(p, book) if with_tag else "")


def print_memory_report(book):
    """Số dòng của các file bộ nhớ và các dòng sổ trỏ tới thứ không còn tồn tại."""
    parts = []
    for name, limit in MEMORY_LIMITS:
        try:
            with open(os.path.join(AGENT, name), "r", encoding="utf-8") as f:
                lines = sum(1 for _ in f)
        except OSError:
            continue
        text = "%s %d dòng" % (name, lines)
        if lines > limit:
            text += " (QUÁ DÀI, ngưỡng %d)" % limit
        parts.append(text)
    if parts:
        print("Bộ nhớ: " + ", ".join(parts) + ".")

    gone = [e for e in book_entries(book) if not os.path.exists(os.path.join(ROOT, e))]
    if gone:
        print("Sổ còn %d dòng trỏ tới thứ không tồn tại, cần xoá khỏi sổ:" % len(gone))
        for e in gone:
            print("  " + e)


def print_long_files(files, book):
    """File văn bản dài mà sổ chưa có ghi chú: đọc xong nên ghi chú để khỏi đọc lại."""
    found = []
    for path, (size, _mtime) in files.items():
        if path.startswith(SCRATCH) or in_book(path, book):
            continue
        if os.path.splitext(path)[1].lower() not in TEXT_EXTENSIONS or size > 2 * 1024 * 1024:
            continue
        try:
            with open(os.path.join(ROOT, path), "rb") as f:
                lines = f.read().count(b"\n")
        except OSError:
            continue
        if lines > LONG_FILE_LINES:
            found.append((lines, path))
    if not found:
        return
    found.sort(reverse=True)
    print("%d file dài chưa có ghi chú trong sổ. Đọc file nào thì ghi chú file đó vào FILES.md:" % len(found))
    for lines, path in found[:5]:
        print("  %s (%d dòng)" % (path, lines))


def clean_text(text):
    """Bỏ chú thích mẫu và dòng trống thừa để bản in ngắn nhất có thể."""
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    lines = [line.rstrip() for line in text.splitlines()]
    out = []
    for line in lines:
        if line or (out and out[-1]):
            out.append(line)
    return "\n".join(out).strip()


def cmd_brief():
    for name in ("STATE.md", "PROJECT.md", "KNOWLEDGE.md", "FILES.md"):
        try:
            with open(os.path.join(AGENT, name), "r", encoding="utf-8") as f:
                text = f.read()
        except OSError:
            continue
        print("=" * 20 + " .agent/" + name + " " + "=" * 20)
        print(clean_text(text))
        print("")
    try:
        with open(os.path.join(AGENT, "LOG.md"), "r", encoding="utf-8") as f:
            log = f.read()
    except OSError:
        log = ""
    # Phần đầu file là hướng dẫn; nhật ký thật nằm sau dòng gạch ngang.
    entries = [l for l in log.split("\n---\n", 1)[-1].splitlines() if l.strip()]
    print("=" * 20 + " .agent/LOG.md (20 dòng cuối) " + "=" * 20)
    print("\n".join(entries[-20:]) if entries else "(chưa có dòng nào)")
    print("")
    print("=" * 20 + " File thay đổi " + "=" * 20)
    cmd_diff()


def cmd_diff():
    snapshot = load_snapshot()
    now = scan()
    book = load_book()
    old = snapshot["files"] if snapshot else {}

    if snapshot:
        print("So với mốc lưu lúc %s (cột giờ là lần sửa cuối của file):" % snapshot.get("taken", "?"))
    else:
        print("Chưa có mốc, liệt kê toàn bộ file hiện có:")

    new = sorted(p for p in now if p not in old)
    changed = sorted(p for p in now if p in old and now[p] != old[p])
    deleted = sorted(p for p in old if p not in now)

    if not (new or changed or deleted):
        print("Không có gì thay đổi.")
    print_group("MỚI", new, now, book, True)
    print_group("ĐÃ SỬA", changed, now, book, False)
    if deleted:
        print("")
        print("ĐÃ XOÁ (%d)" % len(deleted))
        for p in deleted:
            print("  " + p)

    scratch = [p for p in now if p.startswith(SCRATCH)]
    missing = [p for p in new if not p.startswith(SCRATCH) and not in_book(p, book)]
    print("")
    print("Thư mục nháp hiện có %d file, %s." % (
        len(scratch), size_text(sum(now[p][0] for p in scratch))))
    print("%d file mới chưa ghi sổ." % len(missing))
    print_memory_report(book)
    print_long_files(now, book)


def cmd_snap():
    files = scan()
    taken = time.strftime("%Y-%m-%d %H:%M")
    with open(SNAPSHOT, "w", encoding="utf-8") as f:
        json.dump({"taken": taken, "files": files}, f, ensure_ascii=False, sort_keys=True)
    print("Đã lưu mốc gồm %d file lúc %s." % (len(files), taken))


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    command = sys.argv[1] if len(sys.argv) > 1 else ""
    if command == "brief":
        cmd_brief()
    elif command == "diff":
        cmd_diff()
    elif command == "snap":
        cmd_snap()
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
