# Thẻ dự án

Điền khi người dùng gõ "khởi tạo". Mục nào không tìm ra thì ghi "chưa rõ", không đoán.

## Phân loại

- **Loại dự án:** (chọn một: ứng dụng web / API hay dịch vụ / công cụ dòng lệnh / thư viện / script tự động hoá / macro Office-VBA / phân tích dữ liệu / tài liệu / khác)
- **Mục đích trong một câu:**
- **Người dùng cuối:**
- **Giai đoạn:** (mới bắt đầu / đang phát triển / đang bảo trì)

## Công nghệ

- **Ngôn ngữ và phiên bản:**
- **Thư viện chính:**
- **Môi trường chạy:** (hệ điều hành, phần mềm bắt buộc)

## Bản đồ

- **Điểm vào:** (file chạy đầu tiên)
- **Thư mục quan trọng:** (mỗi thư mục một dòng, nói nó chứa gì)
- **File không được sửa:**

## Lệnh

- **Chạy:**
- **Kiểm tra (test):**
- **Đóng gói:**

## Ràng buộc

- **Điều cấm:** (ví dụ: không cài thêm thư viện, không gọi mạng ngoài)
- **Quy ước viết code:**
- **Cách xác nhận một thay đổi là đúng:**
