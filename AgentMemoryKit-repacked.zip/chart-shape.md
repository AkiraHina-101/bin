# Aligning a rectangle to a vertical line in an Excel chart

This sample is for a chart embedded on a worksheet. The vertical line is an **XY Scatter with Straight Lines** series with two points that share the same X and have two different Y values, using the linear primary X axis. The sample places the **horizontal center of the rectangle** on the vertical line. The rectangle can be inside the chart or on the worksheet that holds the chart.

**Put the rectangle inside the chart (`Chart.Shapes`) when it has to line up with the series on screen.** A rectangle on the worksheet is drawn a few points away from the line, even though the object model reports the same coordinate for both. See [On-screen offset of worksheet shapes](#on-screen-offset-of-worksheet-shapes).

## Identifying the right object and coordinates

1. Get `Worksheet.ChartObjects(name)` and then `.Chart`. Find the series by name in `Chart.SeriesCollection` and read `Series.XValues`. If two series have the same name, ask for a clearer identification. [ChartObject](https://learn.microsoft.com/en-us/office/vba/api/excel.chartobject) · [Series.XValues](https://learn.microsoft.com/en-us/office/vba/api/excel.series.xvalues)
2. For a scatter chart, `Chart.Axes(xlCategory, xlPrimary)` returns the X axis. With `xMin` and `xMax` from the axis, compute `fraction = (x - xMin) / (xMax - xMin)`. If `ReversePlotOrder` is on, use `1 - fraction`. [Chart.Axes](https://learn.microsoft.com/en-us/office/vba/api/excel.chart.axes) · [Axis.ReversePlotOrder](https://learn.microsoft.com/en-us/office/vba/api/excel.axis.reverseplotorder)
3. Inside the chart, the target coordinate is `PlotArea.InsideLeft + fraction * PlotArea.InsideWidth`, measured in points in chart coordinates. For a rectangle in `Chart.Shapes`, set `rectangle.Left = targetX - rectangle.Width / 2`. The rectangle and the series then share one coordinate system. [PlotArea.InsideLeft](https://learn.microsoft.com/office/vba/api/excel.plotarea.insideleft) · [PlotArea.InsideWidth](https://learn.microsoft.com/office/vba/api/excel.plotarea.insidewidth)
4. For a rectangle in `Worksheet.Shapes`, the sample adds `ChartObject.Left` to the chart coordinate. That is the position the object model reports, and it is not exactly where Excel draws the series. Use this mode only when an error of a few points is acceptable. [ChartObject.Left](https://learn.microsoft.com/en-us/office/vba/api/excel.chartobject.left)

## On-screen offset of worksheet shapes

Measured from captures of the Excel window on Excel 16.0 build 20527, on one machine with the display at 125% scaling (120 dpi), with a 1.5 pt vertical series and a rectangle whose edge was placed on the line:

| Where the rectangle lives | What the screen shows |
| --- | --- |
| `Worksheet.Shapes`, positioned at `ChartObject.Left + PlotArea.InsideLeft + fraction * PlotArea.InsideWidth` | The series is drawn about 3.5 pt to the right of that position (2.8 to 3.7 pt across zoom 50% to 200%). A rectangle left of the line shows a white gap. A rectangle right of the line covers the line. |
| `Chart.Shapes`, positioned at `PlotArea.InsideLeft + fraction * PlotArea.InsideWidth` | The rectangle edge touches the line with no white gap at zoom 50%, 75%, 100%, 125%, 150%, 200% and 400%, on both sides of the line. |

The offset is roughly constant in points, so the gap in pixels grows with the zoom: 2 to 3 px at 50%, 5 px at 100%, 9 to 10 px at 150% and 11 to 12 px at 200%. Rounding to the pixel grid does not explain it and does not fix it.

The object model does not expose the offset. `Point.Left` returns the same number as the formula, and `ChartArea.Left` returns the `Left` of the chart object. Only the horizontal direction was measured. Other Office builds and other display scalings were not measured, so treat 3.5 pt as an observation on that setup. Avoid using it as a correction constant.

What to do:

- **A rectangle that must touch or sit on a series:** put it in `Chart.Shapes`. The user can still drag it, within the chart area.
- **A rectangle that must move across several stacked charts:** add one transparent chart that covers all of them, with its plot area matching theirs, and put both the vertical series and the rectangle in that chart.
- **A rectangle that must stay on the worksheet:** measure the offset from pixels on the target machine, and measure it again after the Office build or the display scaling changes.

Code that converts points to pixels with a fixed 96 dpi is wrong on a scaled display. The alignment in `Chart.Shapes` needs no such conversion.

## Using the sample VBA

Import [AlignChartShape.bas](../examples/chart-shape/AlignChartShape.bas) into a copy you are allowed to edit. Replace the sheet, chart, series and shape names with the real ones. Use `True` if the rectangle belongs to `Chart.Shapes`, or `False` if it belongs to `Worksheet.Shapes`. With `False`, the rectangle is subject to the on-screen offset described above.

```vb
Dim chartBox As ChartObject
Set chartBox = ThisWorkbook.Worksheets("Report").ChartObjects("Plot1")
CenterRectangleOnSeries chartBox, "Reference Line", "Rectangle 1", True
```

Call the procedure again after you update the series, change the axis limits or resize the chart. Put the call at the end of the macro that updates the chart if you want the rectangle to follow automatically. For a shape on the worksheet, also call it again when the chart is moved. For a category chart, a log axis or a series on the secondary axis, you need a mapping and test cases that fit the real chart.

## Testing in Excel

```text
python ExcelKit.py test --source examples/chart-shape --tests examples/chart-shape/tests --entry ChartShapeTest.Smoke
```

The test builds a chart on a blank workbook. It compares the center of the rectangle with the center of the marker as reported by `Point.Left`, tries both places the rectangle can live, changes the axis and the chart size, and then checks that a slanted series is rejected. [Point.Left](https://learn.microsoft.com/en-us/office/vba/api/excel.point.left)

**What the test does not show.** It compares object-model coordinates with a tolerance of 1 pt. It passes for a worksheet rectangle as well, because `Point.Left` carries the same offset as the formula. To check what the user sees, capture the Excel window at several zoom levels and compare the pixel columns of the line with the pixel columns of the rectangle edge. The kit has no command for this yet.
