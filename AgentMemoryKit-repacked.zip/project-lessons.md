# Project lessons

Read the relevant entry after you have identified the object or the error. Compare its conditions with the current file and Office version. Pick one observable check before you apply it. If the conditions differ, treat the old approach as a hypothesis to retest.

## Lessons that were checked

| Situation | When it applies and what to do | Evidence to look at |
| --- | --- | --- |
| Rectangle drifts away from a vertical series | Tell apart a shape that belongs to the worksheet from one that belongs to the chart. The checked sample uses an XY Scatter, a two-point series and a linear primary X axis. Realign after the axis or the chart size changes. | Compare the rectangle's center with the marker on the chart in both configurations. [Chart and shape alignment sample](chart-shape.md) |
| Rectangle on the worksheet shows a gap next to a chart series, and the gap changes with the zoom | Excel draws the series about 3.5 pt away from `ChartObject.Left` plus the chart coordinate (Excel 16.0 build 20527, 120 dpi). `Point.Left` reports the same number as the formula, so a test against it passes anyway. Put the rectangle in `Chart.Shapes`. For several stacked charts, use one transparent chart that covers them and holds both the series and the rectangle. | Window captures at zoom 50% to 400%: a 2 to 12 px gap for a worksheet shape, no gap for a shape in the chart. [On-screen offset of worksheet shapes](chart-shape.md#on-screen-offset-of-worksheet-shapes) |
| The total is right when VBA is called, but the form can still be wrong | The test case calls the procedure that checks the business logic. Also try the callback, data entry, Cancel and export on the UI when the form is the path users take. | The East case exports `East,30`, North is rejected and Cancel closes the form. [Office acceptance cases](office-evidence.md) |
| The file was exported but the chat stopped | `published_unlogged` means the path and SHA-256 match the receipt written before the export. Open the existing file and check the content to be delivered before closing the step. | The case where the final receipt is lost, both when the hash matches and when the file has changed. [Checkpoints](resume-after-stop.md) |
| Windows reports WinError 5 when writing `state.json` | If the log records an error renaming the state file, check whether a process is holding the file open for reading. The runner now retries the atomic replacement within a short wait. VBProject permission is checked separately through `doctor`. | `tests/test_task.py` keeps the file open, confirms that the first replacement is blocked, and then reads the new state. |
| Two samples share a KPI label but use different formulas | Record the file name, the cell or slide address, the visible formula, and ask which rule is the standard. Keep the currency when you group and reconcile. | The aggregation case with a gross/net conflict and several currencies. [Report from a sample](report-from-sample.md) |

## Recording a new lesson

After a check passes, update the relevant entry or add a short one if you found something usable on other tasks. Keep long logs in the task folder. Keep business rules and internal data in the approved workspace.

```markdown
### [Specific object or error]
- Conditions: [File type, object, build or business rule that matters]
- How it was checked: [The action and the sign you look for]
- Evidence: [Task ID, file/step, expected and actual result]
- Retest when: [A change that could make the conditions above no longer hold]
```

When new evidence contradicts an entry, update its scope and point to the new check. Confirm a business rule with the owner or the authoritative source before recording it as shared experience.
