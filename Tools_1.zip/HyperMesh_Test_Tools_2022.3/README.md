# Ba tool HyperMesh 2022.3

| Nút trong Utility | Công dụng |
| --- | --- |
| **RBE2 bar** | Tạo kết nối RBE2–CBAR–RBE2. |
| **Shared faces** | Tạo các mặt chung và dùng màu đang chọn khi tạo. |
| **Ruled mesh** | Lấp một viền kín hoặc tạo lưới tam giác giữa hai viền. |

Trong **Ruled mesh**, chỉnh **Element size** trước khi bấm **Create**. Với một viền kín hoặc hai viền lồng nhau, HyperMesh áp dụng size mục tiêu cho lưới R-trias bằng **Flow align + size** và giữ nguyên cạnh biên. Khe hẹp có thể cho cùng mật độ ở hai mức size nhỏ.

## Chép sang máy khác

1. Chép nguyên thư mục `HyperMesh_Test_Tools_2022.3` sang máy đích. Giữ cấu trúc các thư mục bên trong.
2. Mở **HyperMesh 2022.3** với solver profile **Nastran**.
3. Tại **Tcl Console**, chạy lệnh dưới đây và thay đường dẫn theo chỗ đã chép.

```tcl
source {<thư mục đã giải nén>/HyperMesh_Test_Tools_2022.3/Load_Test_Tools.tcl}
```

Ba nút xuất hiện trên trang **TEST** ở **Utility**. Khi chuyển gói đến vị trí khác hoặc mở phiên HyperMesh mới, chạy lại lệnh với đường dẫn tương ứng. Tcl tạo MAC theo vị trí đang dùng và nạp vào phiên hiện tại. Lệnh nạp thay menu Utility mà phiên đang dùng. Để trở lại menu của máy đích, nạp lại MAC của máy đó.

Để mở riêng một tool từ Tcl Console, dùng `source` với tệp tương ứng.

- [RbeBarLink/rbe_bar_link.tcl](RbeBarLink/rbe_bar_link.tcl)
- [SharedFaces/shared_faces.tcl](SharedFaces/shared_faces.tcl)
- [RuledMesh/ruled_mesh.tcl](RuledMesh/ruled_mesh.tcl)

## Kiểm tra trên máy công ty

Lưu một bản sao mô hình trước khi chạy công cụ. HyperMesh hỏi trước khi thay menu Utility trong phiên hiện tại và khi xóa các component do Shared Faces tạo.
